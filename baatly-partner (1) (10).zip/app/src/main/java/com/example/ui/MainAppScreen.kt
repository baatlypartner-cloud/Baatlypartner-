package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.BaatlyApp
import com.example.data.repository.HostFullStatus
import com.example.ui.screens.auth.HostIntroScreen
import com.example.ui.screens.auth.SignInScreen
import com.example.ui.screens.auth.SignUpScreen
import com.example.ui.screens.call.ActiveCallScreen
import com.example.ui.screens.call.IncomingCallDialog
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.chat.ChatListScreen
import com.example.ui.screens.home.CallKamaiScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.MallScreen
import com.example.ui.screens.home.SkillsScreen
import com.example.ui.screens.home.TrainingVideosScreen
import com.example.ui.screens.onboarding.ApplicationStatusScreen
import com.example.ui.screens.onboarding.VoiceVerificationScreen
import com.example.ui.screens.profile.BlockedUsersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.recent.RecentCallsScreen
import com.example.ui.screens.rules.FrameNiyamScreen
import com.example.ui.screens.rules.StrikeNiyamScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.*

enum class BottomTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    CHATS("Chats", Icons.Default.Chat),
    RECENT("Recent", Icons.Default.History),
    PROFILE("Profile", Icons.Default.Person)
}

@Composable
fun MainApp(app: BaatlyApp) {
    val authViewModel: AuthViewModel = viewModel(
        factory = AuthViewModelFactory(app.authRepository)
    )
    val mainViewModel: MainViewModel = viewModel(
        factory = MainViewModelFactory(app.partnerRepository, app.callRepository, app.walletRepository)
    )
    val callViewModel: CallViewModel = viewModel(
        factory = CallViewModelFactory(app.callRepository, app.partnerRepository, app.agoraCallManager, app.sessionManager)
    )
    val chatViewModel: ChatViewModel = viewModel(
        factory = ChatViewModelFactory(app.chatRepository, app.sessionManager, app.audioRecorderHelper, app.audioPlayerHelper, app.privateMediaRepository)
    )
    val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModelFactory(app.walletRepository)
    )
    val voiceViewModel: VoiceVerificationViewModel = viewModel(
        factory = VoiceVerificationViewModelFactory(app.partnerRepository, app.audioRecorderHelper, app.audioPlayerHelper)
    )

    val authState by authViewModel.uiState.collectAsState()
    val mainUiData by mainViewModel.uiData.collectAsState()

    var authScreenState by remember { mutableStateOf("intro") } // "intro", "signin", "signup"
    var currentTab by remember { mutableStateOf(BottomTab.HOME) }
    var currentSubRoute by remember { mutableStateOf<String?>(null) }
    var activeChatParams by remember { mutableStateOf<Triple<String, String, String>?>(null) }

    // Check incoming call from MainViewModel's poller
    val incomingCall = mainUiData.incomingCall
    val callUiStatus by callViewModel.callUiStatus.collectAsState()

    // Handle Incoming Call Modal
    incomingCall?.let { call ->
        IncomingCallDialog(
            call = call,
            onAccept = {
                mainViewModel.dismissIncomingCall()
                callViewModel.acceptIncomingCall(call)
            },
            onReject = {
                mainViewModel.dismissIncomingCall()
                callViewModel.rejectIncomingCall(call)
            }
        )
    }

    // Top-Level Screen Routing based on Auth & Host Status
    when (val state = authState) {
        is AuthUiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyDarkBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = BaatlyPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Loading Baatly Partner...", color = Color.White, fontSize = 14.sp)
                }
            }
        }

        is AuthUiState.Idle, is AuthUiState.SignedOut, is AuthUiState.Error -> {
            when (authScreenState) {
                "signup" -> {
                    SignUpScreen(
                        authViewModel = authViewModel,
                        onNavigateToSignIn = { authScreenState = "signin" },
                        onBackToIntro = { authScreenState = "intro" }
                    )
                }
                "signin" -> {
                    SignInScreen(
                        authViewModel = authViewModel,
                        onNavigateToSignUp = { authScreenState = "signup" },
                        onBackToIntro = { authScreenState = "intro" }
                    )
                }
                else -> {
                    HostIntroScreen(
                        onNavigateToSignUp = { authScreenState = "signup" },
                        onNavigateToSignIn = { authScreenState = "signin" }
                    )
                }
            }
        }

        is AuthUiState.VoiceVerificationRequired -> {
            VoiceVerificationScreen(
                displayName = state.displayName,
                applicationId = state.applicationId,
                voiceViewModel = voiceViewModel,
                onVerificationSuccess = {
                    authViewModel.checkCurrentStatus()
                }
            )
        }

        is AuthUiState.ApplicationStatus -> {
            ApplicationStatusScreen(
                status = state.status,
                authViewModel = authViewModel,
                onNavigateToReVerification = {
                    authViewModel.transitionToVoiceVerification(
                        displayName = state.status.partnerProfile?.partnerDisplayName ?: "Host",
                        applicationId = state.status.application?.id
                    )
                }
            )
        }

        is AuthUiState.Approved -> {
            // Check if there is an active ongoing call
            if (callUiStatus is ActiveCallUiStatus.Connected || callUiStatus is ActiveCallUiStatus.Connecting || callUiStatus is ActiveCallUiStatus.Ended || callUiStatus is ActiveCallUiStatus.Error) {
                ActiveCallScreen(
                    callViewModel = callViewModel,
                    chatViewModel = chatViewModel,
                    onCallFinished = {
                        mainViewModel.loadAllData()
                    }
                )
            } else if (activeChatParams != null) {
                val (convId, receiverId, name) = activeChatParams!!
                ChatDetailScreen(
                    conversationId = convId,
                    receiverId = receiverId,
                    receiverName = name,
                    chatViewModel = chatViewModel,
                    onBack = { activeChatParams = null }
                )
            } else if (currentSubRoute != null) {
                when (currentSubRoute) {
                    "call_kamai" -> CallKamaiScreen(mainViewModel = mainViewModel, onBack = { currentSubRoute = null })
                    "skills" -> SkillsScreen(mainViewModel = mainViewModel, onBack = { currentSubRoute = null })
                    "training" -> TrainingVideosScreen(onBack = { currentSubRoute = null })
                    "mall" -> MallScreen(onBack = { currentSubRoute = null })
                    "frame_niyam" -> FrameNiyamScreen(onBack = { currentSubRoute = null })
                    "strike_niyam" -> StrikeNiyamScreen(onBack = { currentSubRoute = null })
                    "wallet" -> WalletScreen(walletViewModel = walletViewModel, onBack = { currentSubRoute = null })
                    "blocked_users" -> BlockedUsersScreen(partnerRepository = app.partnerRepository, onBack = { currentSubRoute = null })
                    "recent_calls" -> RecentCallsScreen(callViewModel = callViewModel)
                    else -> currentSubRoute = null
                }
            } else {
                // Main Tabbed Navigation
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color.White,
                            tonalElevation = 3.dp
                        ) {
                            BottomTab.values().forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = tab.icon,
                                            contentDescription = tab.title,
                                            tint = if (selected) Color.White else BaatlySlate
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title.uppercase(),
                                            color = if (selected) BaatlyPrimary else BaatlySlate,
                                            fontSize = 10.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                            letterSpacing = 0.5.sp
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = BaatlyPrimary,
                                        selectedIconColor = Color.White,
                                        unselectedIconColor = BaatlySlate,
                                        selectedTextColor = BaatlyPrimary,
                                        unselectedTextColor = BaatlySlate
                                    ),
                                    modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                                )
                            }
                        }
                    },
                    containerColor = BaatlyLightBackground
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            BottomTab.HOME -> HomeScreen(
                                mainViewModel = mainViewModel,
                                onNavigate = { route ->
                                    if (route == "recent_calls") {
                                        currentTab = BottomTab.RECENT
                                    } else {
                                        currentSubRoute = route
                                    }
                                }
                            )
                            BottomTab.CHATS -> ChatListScreen(
                                chatViewModel = chatViewModel,
                                onOpenConversation = { convId, userId, name ->
                                    activeChatParams = Triple(convId, userId, name?.takeIf { it.isNotBlank() } ?: "Baatly User")
                                }
                            )
                            BottomTab.RECENT -> RecentCallsScreen(callViewModel = callViewModel)
                            BottomTab.PROFILE -> ProfileScreen(
                                mainViewModel = mainViewModel,
                                authViewModel = authViewModel,
                                onNavigate = { route -> currentSubRoute = route }
                            )
                        }
                    }
                }
            }
        }
    }
}
