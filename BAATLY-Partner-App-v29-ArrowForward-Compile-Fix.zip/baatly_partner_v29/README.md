# BAATLY Partner App — v1.2.0 (versionCode 25)

The app starts with **four partner choices** before any onboarding begins:

- **Hosting** — continues into the existing Host onboarding, verification and Host experience. The previous Host flow is kept separate.
- **Two-Wheeler Partner** — one bike/scooter application covers **Bike Taxi, Food Delivery and Parcel Delivery**. After admin approval, the Go Online workspace shows three independent ON/OFF switches. The partner can turn on any one, two or all three services without applying again.
- **Cab Partner** — one cab application for auto, e-rickshaw, mini, sedan, SUV, XL or premium vehicles.
- **Restaurant Partner** — outlet, branch, compliance documents, menu and live restaurant orders.

## Mobility workflow

A two-wheeler applicant submits one identity, bike and banking application with `requested_services` set to `bike_taxi`, `food_delivery` and `parcel`. The existing BAATLY review RPC approves those requested services together. The approved service rows are controlled independently from the Go Online screen. Cab applicants submit only the `cab` service.

The mobility workspace uses a **full-screen Google Map** behind the work panel. Active jobs and incoming offers display pickup/drop pins when the server has coordinates. Each pickup/drop navigation action opens the same coordinate directly in Google Maps; if the Google Maps app is unavailable, it opens Google Maps directions in a browser. While any mobility service is online, `MobilityLocationForegroundService` sends authenticated GPS heartbeats every five seconds / ten metres (subject to actual device movement and Android background-location rules).

## Supabase and Cloudflare R2

The app connects to the existing BAATLY Supabase project and deployed Edge Functions:

- `baatly-mobility-api` — partner application submission, restaurant creation, independent service online state, dashboard offers, active jobs, OTP actions, restaurant order state and menu writes.
- `baatly-mobility-media` — signed Cloudflare R2 uploads for partner documents, restaurant compliance files and menu images.

Private onboarding documents and menu photos upload directly to signed R2 URLs and then call `finalize_upload`. These new mobility/restaurant document paths do not use Supabase Storage.

### Mobility documents

- All driver/vehicle applications: identity proof, driving licence, vehicle RC, vehicle insurance, PUC, police verification, selfie and bank proof.
- Commercial vehicle categories: vehicle permit and fitness certificate.
- Two-Wheeler Partner: bike-taxi permit, because Bike Taxi is included in the same application.

### Restaurant documents

Restaurant onboarding requires FSSAI licence, PAN card, bank proof, owner identity and restaurant photo. The app creates the outlet/branch and owner membership, uploads the files to R2 and attaches them to the restaurant/branch.

## Google Maps API key

The Google Maps SDK for Android and Maps Compose are configured. The key is read from the local root `.env` file through the Secrets Gradle Plugin and inserted into the Android manifest as `com.google.android.geo.API_KEY`.

- Create a local `.env` by copying `.env.example` and set your own `MAPS_API_KEY` for local builds. The real `.env` is intentionally not included in the ZIP.
- `.env` is in `.gitignore`; do **not** commit it or paste the key into Kotlin/XML source.
- For GitHub Actions, save the key as a repository secret named `MAPS_API_KEY`; the included `Build BAATLY Partner Debug APK` workflow writes it into an ignored `.env` file and builds the debug APK.
- In Google Cloud Console, enable **Maps SDK for Android** and restrict the key to Android app `com.aistudio.baatlypartner.hostapp` plus the release/debug signing certificate SHA-1 fingerprints. Also apply API restrictions.

Google Maps Android keys are embedded in the compiled APK, so Android application restrictions are essential even when the source key is kept outside version control.

## Permission flow

- Job/order notifications: explained on a full-screen permission step before the partner workspace.
- Foreground location: requested when a mobility partner turns on a service.
- Background location: explained and requested separately for continuous trip tracking when the app is minimized.
- The location foreground service stays active while at least one mobility service is online and stops after the last service is switched off.
- Documents and menu photos use the Android document picker; camera access is not required for these uploads.

## Build

1. Open this project directory in Android Studio and allow Gradle sync.
2. Confirm the local `.env` has `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `AGORA_APP_ID` and `MAPS_API_KEY`.
3. Build with `./gradlew :app:assembleDebug` or use **Build > Make Project**.
4. For release signing, provide `KEYSTORE_PATH`, `STORE_PASSWORD` and `KEY_PASSWORD` through your local build environment or CI secrets. Do not commit signing credentials.

The previous Host flow is intentionally kept separate. This revision uses the existing BAATLY mobility and restaurant tables/RPCs and the already-deployed R2 media function.


## Partner Workspace v1.2.2 (versionCode 27)

The existing Hosting flow remains the original Host experience. The other partner categories now have their own multi-screen workspace instead of a single long dashboard:

- **Two-Wheeler Partner:** Home, Orders, Wallet and Profile. Bike Taxi, Food Delivery and Parcel Delivery remain independent online switches. Orders includes incoming offers, active fulfilment controls and Google Maps pickup/drop navigation.
- **Cab Partner:** Home, Orders, Wallet and Profile, with trip acceptance, pickup arrival, ride-start verification and completion actions.
- **Restaurant Partner:** Home, Orders, Menu, Wallet and Profile. Restaurant orders retain accept/reject/preparing/ready actions; Menu supports categories, dishes, availability toggles and optional R2 dish photos. Wallet displays the restaurant settlement balance and ledger entries.

The new Mobility Wallet view uses the existing `partner_wallet` and `partner_topup_request` API actions. Restaurant settlement entries are read through the owner-scoped `mobility_restaurant_ledger_entries` RLS policy. The existing v26 stationary GPS heartbeat service is retained.

### Testing checklist

1. Sign in to a Two-Wheeler test account and verify all four bottom tabs.
2. Toggle Bike Taxi, Food Delivery and Parcel Delivery independently.
3. Open Orders and verify new offers, accept/reject and active job status controls.
4. Open Wallet and check COD balance, earnings, transactions and top-up request.
5. Sign in to a Cab Partner account and verify the same Home/Orders/Wallet/Profile navigation.
6. Sign in to an approved Restaurant Partner account and verify Home/Orders/Menu/Wallet/Profile, outlet open/closed state, order actions and menu availability.
7. Confirm the Host account still routes to the original Host bottom navigation and pages.

Build version: `1.2.2` / versionCode `27`. The project build could not be executed in this environment because the Gradle distribution host was unreachable; run the included Gradle wrapper in GitHub Actions or Android Studio to perform the full Android build.


## Partner Workspace v1.2.3 (versionCode 28)

Compile fix: added the missing `androidx.compose.ui.unit.sp` import required by the premium partner workspace text sizes and letter spacing. The workspace's existing Host, Two-Wheeler, Cab and Restaurant routing and service flows are retained.

The premium workspace Kotlin source passed an isolated Kotlin type-check against API stubs in the preparation environment. A complete Android Gradle Release build was not run here because this environment could not resolve the Gradle distribution host; CI/Android Studio remains the authoritative full build check.


## Partner Workspace v1.2.4 (versionCode 29)

Compile audit fix: added the missing `androidx.compose.material.icons.filled.ArrowForward` import used by the partner category selection card. The app archive excludes local `.env` files and signing keystores; provide them through local environment files or GitHub Secrets.
