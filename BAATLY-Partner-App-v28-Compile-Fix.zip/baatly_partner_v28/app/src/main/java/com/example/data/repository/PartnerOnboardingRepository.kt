package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.AuthSignInRequest
import com.example.data.models.AuthSignUpRequest
import com.example.data.models.MobilityPartnerApplicationModel
import com.example.data.models.MobilityRestaurantBranchModel
import com.example.data.models.MobilityRestaurantModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class PartnerOnboardingRepository(
    private val supabase: SupabaseClient,
    private val session: SessionManager
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun hasSession(): Boolean = session.hasStoredSession()
    fun currentUserId(): String? = session.getStoredAuthUuid()

    private fun requireUserId(): String = session.getStoredAuthUuid()
        ?: throw IllegalStateException("Please sign in to continue")

    private fun responseJson(body: okhttp3.ResponseBody?): JSONObject =
        JSONObject(body?.string().orEmpty().ifBlank { "{}" })

    private suspend fun mobility(action: String, payload: Map<String, Any?> = emptyMap()): JSONObject {
        val response = supabase.edgeService.callMobilityApi(mapOf("action" to action) + payload)
        if (!response.isSuccessful) {
            val error = response.errorBody()?.string().orEmpty()
            throw IllegalStateException(extractError(error, "BAATLY mobility request failed (${response.code()})"))
        }
        val json = responseJson(response.body())
        if (json.optBoolean("success", false).not()) {
            throw IllegalStateException(json.optString("error", "Mobility request failed"))
        }
        return json
    }

    private suspend fun mobilityMedia(action: String, payload: Map<String, Any?>): JSONObject {
        val response = supabase.edgeService.callMobilityMedia(mapOf("action" to action) + payload)
        if (!response.isSuccessful) {
            val error = response.errorBody()?.string().orEmpty()
            throw IllegalStateException(extractError(error, "Secure document service failed (${response.code()})"))
        }
        val json = responseJson(response.body())
        if (!json.optBoolean("success", false)) {
            throw IllegalStateException(json.optString("error", "Secure document service failed"))
        }
        return json
    }

    private fun extractError(raw: String, fallback: String): String = try {
        JSONObject(raw).optString("message").ifBlank { JSONObject(raw).optString("error").ifBlank { fallback } }
    } catch (_: Exception) { raw.take(240).ifBlank { fallback } }

    suspend fun signUpAccount(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val normalized = userId.trim().lowercase()
            val signup = supabase.authService.signUp(
                AuthSignUpRequest(email = "$normalized@auth.baatly.app", password = password)
            )
            if (!signup.isSuccessful || signup.body() == null) {
                throw IllegalStateException("Account creation failed: ${signup.errorBody()?.string().orEmpty()}")
            }
            val auth = signup.body()!!
            val user = auth.user ?: throw IllegalStateException("Supabase did not return an account ID")
            session.saveSession(user.id, normalized, auth.accessToken.orEmpty(), auth.refreshToken)
            val profile = supabase.restService.completeUserSignup(
                mapOf(
                    "p_user_id" to normalized,
                    "p_display_name" to displayName.trim(),
                    "p_mobile_number" to mobileNumber.filter(Char::isDigit),
                    "p_avatar_url" to null,
                    "p_referral_code" to null
                )
            )
            if (!profile.isSuccessful) {
                throw IllegalStateException("Account created, but profile setup failed: ${profile.errorBody()?.string().orEmpty()}")
            }
            Result.success(Unit)
        } catch (error: Exception) {
            Log.e("PartnerOnboarding", "Generic partner signup failed", error)
            Result.failure(error)
        }
    }

    suspend fun signInAccount(userId: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val normalized = userId.trim().lowercase()
            val response = supabase.authService.signIn(
                request = AuthSignInRequest(email = "$normalized@auth.baatly.app", password = password)
            )
            if (!response.isSuccessful || response.body() == null) {
                throw IllegalStateException("Sign in failed: ${response.errorBody()?.string().orEmpty()}")
            }
            val auth = response.body()!!
            val user = auth.user ?: throw IllegalStateException("Supabase did not return an account ID")
            session.saveSession(user.id, normalized, auth.accessToken.orEmpty(), auth.refreshToken)
            val profile = supabase.restService.getProfile("eq.${user.id}")
            if (!profile.isSuccessful || profile.body().isNullOrEmpty()) {
                throw IllegalStateException("This account has no BAATLY profile yet. Please complete account creation first.")
            }
            Result.success(Unit)
        } catch (error: Exception) {
            Log.e("PartnerOnboarding", "Partner account sign-in failed", error)
            Result.failure(error)
        }
    }

    suspend fun getLatestMobilityApplication(serviceType: String): Result<MobilityPartnerApplicationModel?> = withContext(Dispatchers.IO) {
        try {
            val response = supabase.restService.getMobilityPartnerApplications("eq.${requireUserId()}")
            if (!response.isSuccessful) throw IllegalStateException(response.errorBody()?.string() ?: "Could not load application")
            Result.success(response.body()?.firstOrNull { it.requestedServices.contains(serviceType) })
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getLatestRestaurant(): Result<MobilityRestaurantModel?> = withContext(Dispatchers.IO) {
        try {
            val response = supabase.restService.getMobilityRestaurants("eq.${requireUserId()}")
            if (!response.isSuccessful) throw IllegalStateException(response.errorBody()?.string() ?: "Could not load restaurant")
            Result.success(response.body()?.firstOrNull())
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getRestaurantBranches(restaurantId: String): Result<List<MobilityRestaurantBranchModel>> = withContext(Dispatchers.IO) {
        try {
            val response = supabase.restService.getMobilityRestaurantBranches("eq.$restaurantId")
            if (!response.isSuccessful) throw IllegalStateException(response.errorBody()?.string() ?: "Could not load restaurant branch")
            Result.success(response.body().orEmpty())
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun submitMobilityApplication(payload: Map<String, Any?>): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = mobility("partner_application_submit", mapOf("payload" to payload))
            Result.success(json.optString("application_id"))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun submitRestaurantApplication(payload: Map<String, Any?>): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = mobility("create_restaurant", mapOf("payload" to payload))
            Result.success(json.optString("restaurant_id"))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun uploadDocument(
        bytes: ByteArray,
        contentType: String,
        purpose: String,
        restaurantId: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (bytes.isEmpty()) throw IllegalArgumentException("Selected document is empty")
            val createPayload = mutableMapOf<String, Any?>(
                "purpose" to purpose,
                "content_type" to contentType,
                "file_size_bytes" to bytes.size
            )
            if (!restaurantId.isNullOrBlank()) createPayload["restaurant_id"] = restaurantId
            val upload = mobilityMedia("create_upload_url", createPayload)
            val uploadUrl = upload.optString("upload_url")
            val objectKey = upload.optString("object_key")
            if (uploadUrl.isBlank() || objectKey.isBlank()) throw IllegalStateException("Secure upload URL was not returned")
            val request = Request.Builder()
                .url(uploadUrl)
                .put(bytes.toRequestBody(contentType.toMediaType()))
                .header("Content-Type", contentType)
                .build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("R2 upload failed (${response.code})")
            }
            val finalized = mobilityMedia("finalize_upload", mapOf("object_key" to objectKey))
            Result.success(finalized.optString("object_key", objectKey))
        } catch (e: Exception) {
            Log.e("PartnerOnboarding", "R2 document upload failed", e)
            Result.failure(e)
        }
    }

    suspend fun addPartnerDocument(
        applicationId: String,
        documentType: String,
        objectKey: String,
        documentNumber: String? = null,
        expiresOn: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("partner_add_document", mapOf(
                "application_id" to applicationId,
                "document_type" to documentType,
                "object_key" to objectKey,
                "document_number" to documentNumber,
                "expires_on" to expiresOn
            ))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun addRestaurantDocument(
        restaurantId: String,
        branchId: String?,
        documentType: String,
        objectKey: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("restaurant_add_document", mapOf(
                "restaurant_id" to restaurantId,
                "branch_id" to branchId,
                "document_type" to documentType,
                "object_key" to objectKey
            ))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun sendPartnerHeartbeat(latitude: Double, longitude: Double, accuracyMeters: Float?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("partner_heartbeat", mapOf(
                "latitude" to latitude,
                "longitude" to longitude,
                "accuracy_meters" to accuracyMeters
            ))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getPartnerDashboard(): Result<JSONObject> = withContext(Dispatchers.IO) {
        try { Result.success(mobility("partner_dashboard")) } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getMobilityWallet(): Result<JSONObject> = withContext(Dispatchers.IO) {
        try { Result.success(mobility("partner_wallet")) } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun requestMobilityTopup(amount: Double, reference: String? = null): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!amount.isFinite() || amount <= 0.0) throw IllegalArgumentException("Enter a valid top-up amount")
            mobility("partner_topup_request", mapOf("amount" to amount, "reference" to reference))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getRestaurantLedgerEntries(restaurantId: String): Result<org.json.JSONArray> = withContext(Dispatchers.IO) {
        try {
            val response = supabase.restService.getRestaurantLedgerEntries("eq.$restaurantId")
            if (!response.isSuccessful) throw IllegalStateException(extractError(response.errorBody()?.string().orEmpty(), "Could not load restaurant settlement ledger"))
            Result.success(org.json.JSONArray(response.body()?.string().orEmpty().ifBlank { "[]" }))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun performMobilityAction(action: String, payload: Map<String, Any?>): Result<JSONObject> = withContext(Dispatchers.IO) {
        try { Result.success(mobility(action, payload)) } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun respondToOffer(offerId: String, accept: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility(if (accept) "accept_offer" else "reject_offer", mapOf("offer_id" to offerId))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun updateRestaurantOrder(orderId: String, action: String, prepMinutes: Int = 20): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("restaurant_order_action", mapOf("order_id" to orderId, "order_action" to action, "prep_minutes" to prepMinutes))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun setPartnerServiceOnline(serviceType: String, online: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("partner_set_online", mapOf("service_type" to serviceType, "online" to online))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun setRestaurantBranchOpen(branchId: String, isOpen: Boolean, preparationMinutes: Int = 20): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            mobility("restaurant_branch_status", mapOf(
                "branch_id" to branchId,
                "is_open" to isOpen,
                "preparation_time_minutes" to preparationMinutes
            ))
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun upsertMenuCategory(payload: Map<String, Any?>): Result<String> = withContext(Dispatchers.IO) {
        try { Result.success(mobility("menu_category_upsert", mapOf("payload" to payload)).optString("category_id")) }
        catch (e: Exception) { Result.failure(e) }
    }

    suspend fun upsertMenuItem(payload: Map<String, Any?>): Result<String> = withContext(Dispatchers.IO) {
        try { Result.success(mobility("menu_item_upsert", mapOf("payload" to payload)).optString("menu_item_id")) }
        catch (e: Exception) { Result.failure(e) }
    }
}
