package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.BaatlyApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps mobility GPS heartbeats fresh while a partner service is online.
 *
 * Location callbacks are requested with zero minimum distance so a stationary
 * partner still receives periodic GPS fixes. A separate 10-second heartbeat
 * loop also refreshes the backend from the newest recent fix, rather than
 * relying only on movement callbacks.
 */
class MobilityLocationForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var locationManager: LocationManager? = null
    private var listener: LocationListener? = null
    private var heartbeatJob: Job? = null

    @Volatile
    private var latestLocation: Location? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        startTracking()
        return START_STICKY
    }

    private fun startTracking() {
        // Avoid registering duplicate LocationListeners if Android restarts or
        // the user toggles another service while this foreground service runs.
        if (listener != null) {
            startHeartbeatLoop()
            return
        }

        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            Log.w(TAG, "Location permission is not granted; stopping partner location service")
            stopSelf()
            return
        }

        try {
            val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locationManager = manager
            val providers = mutableListOf<String>()
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
            if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)

            val updateListener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    val current = latestLocation
                    if (current == null || location.elapsedRealtimeNanos >= current.elapsedRealtimeNanos) {
                        latestLocation = Location(location)
                    }
                }

                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            listener = updateListener

            // A 10m distance filter prevented callbacks whenever a partner was
            // standing still. Use 0m so the providers can refresh stationary fixes.
            providers.forEach { provider ->
                manager.requestLocationUpdates(provider, 5_000L, 0f, updateListener, Looper.getMainLooper())
            }

            latestLocation = newestLastKnownLocation(manager, providers) ?: latestLocation
            if (providers.isEmpty()) Log.w(TAG, "No enabled location provider found")
            startHeartbeatLoop()
        } catch (e: SecurityException) {
            Log.e(TAG, "Location permission revoked while starting tracking", e)
            stopSelf()
        } catch (e: Exception) {
            Log.e(TAG, "Could not start mobility location tracking", e)
            stopSelf()
        }
    }

    private fun newestLastKnownLocation(manager: LocationManager, providers: List<String>): Location? {
        return providers.mapNotNull { provider ->
            try {
                manager.getLastKnownLocation(provider)
            } catch (e: SecurityException) {
                Log.w(TAG, "Permission unavailable for provider $provider", e)
                null
            } catch (e: Exception) {
                Log.w(TAG, "Could not read last-known location for provider $provider", e)
                null
            }
        }.maxByOrNull { it.elapsedRealtimeNanos }?.let { Location(it) }
    }

    private fun startHeartbeatLoop() {
        if (heartbeatJob?.isActive == true) return

        heartbeatJob = scope.launch {
            while (isActive) {
                val location = latestLocation
                if (location != null) {
                    val ageNanos = (SystemClock.elapsedRealtimeNanos() - location.elapsedRealtimeNanos).coerceAtLeast(0L)
                    val ageMillis = ageNanos / 1_000_000L
                    // Do not relabel a very old cached GPS fix as a live position.
                    if (ageMillis <= MAX_LOCATION_AGE_MS) {
                        val repo = (application as BaatlyApp).partnerOnboardingRepository
                        val result = repo.sendPartnerHeartbeat(
                            location.latitude,
                            location.longitude,
                            if (location.hasAccuracy()) location.accuracy else null
                        )
                        if (result.isFailure) {
                            Log.w(TAG, "Partner location heartbeat failed", result.exceptionOrNull())
                        }
                    } else {
                        Log.w(TAG, "Latest GPS fix is stale (${ageMillis}ms); waiting for a fresh fix")
                    }
                } else {
                    Log.w(TAG, "Waiting for first GPS location before sending partner heartbeat")
                }
                delay(HEARTBEAT_INTERVAL_MS)
            }
        }
    }

    private fun stopTracking() {
        heartbeatJob?.cancel()
        heartbeatJob = null
        try {
            listener?.let { locationManager?.removeUpdates(it) }
        } catch (_: Exception) {
        }
        listener = null
        locationManager = null
        latestLocation = null
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "BAATLY Partner location", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle("BAATLY Partner is online")
            .setContentText("Live GPS is syncing securely while your selected service is online.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        stopTracking()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "MobilityLocationService"
        private const val CHANNEL_ID = "baatly_mobility_location"
        private const val NOTIFICATION_ID = 7412
        private const val HEARTBEAT_INTERVAL_MS = 10_000L
        private const val MAX_LOCATION_AGE_MS = 60_000L
        const val ACTION_START = "com.example.service.MOBILITY_LOCATION_START"
        const val ACTION_STOP = "com.example.service.MOBILITY_LOCATION_STOP"
    }
}
