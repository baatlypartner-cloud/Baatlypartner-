package com.example.data.image

import android.net.Uri
import coil.key.Keyer
import coil.request.Options

/**
 * Keyer that strips transient query parameters (such as signed URL tokens and expiries)
 * from Supabase storage URLs so that Coil caches images using stable object paths.
 * This prevents repeated network downloads of unchanged media whenever a signed URL is renewed.
 */
class SupabaseStorageStringKeyer : Keyer<String> {
    override fun key(data: String, options: Options): String? {
        if (data.contains("/storage/v1/object/sign/") || data.contains("/storage/v1/object/public/")) {
            val queryIdx = data.indexOf('?')
            return if (queryIdx != -1) data.substring(0, queryIdx) else data
        }
        return null
    }
}

class SupabaseStorageUriKeyer : Keyer<Uri> {
    override fun key(data: Uri, options: Options): String? {
        val str = data.toString()
        if (str.contains("/storage/v1/object/sign/") || str.contains("/storage/v1/object/public/")) {
            val queryIdx = str.indexOf('?')
            return if (queryIdx != -1) str.substring(0, queryIdx) else str
        }
        return null
    }
}
