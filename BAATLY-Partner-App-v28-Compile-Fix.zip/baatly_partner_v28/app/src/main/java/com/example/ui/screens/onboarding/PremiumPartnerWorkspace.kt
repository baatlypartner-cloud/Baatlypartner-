package com.example.ui.screens.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.models.MobilityPartnerApplicationModel
import com.example.data.models.MobilityRestaurantBranchModel
import com.example.data.models.MobilityRestaurantModel
import com.example.data.repository.PartnerOnboardingRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val WorkspaceBg = Color(0xFF090B18)
private val WorkspacePanel = Color(0xF0171B30)
private val WorkspacePanel2 = Color(0xFF202641)
private val WorkspaceGold = Color(0xFFFFD58A)
private val WorkspaceViolet = Color(0xFF8E6BFF)
private val WorkspaceMint = Color(0xFF5DE2C0)
private val WorkspaceText = Color(0xFFF8F7FF)
private val WorkspaceMuted = Color(0xFFB6BBD0)
private val WorkspaceRed = Color(0xFFFF8090)

private data class WorkspaceNavItem(val key: String, val label: String, val icon: ImageVector)

@Composable
private fun PremiumWorkspaceNav(
    items: List<WorkspaceNavItem>, selected: String, onSelect: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).navigationBarsPadding(),
        color = Color(0xF01B2037),
        shape = RoundedCornerShape(24.dp),
        shadowElevation = 18.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4A456C).copy(alpha = 0.72f))
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp,
            modifier = Modifier.height(80.dp)
        ) {
            items.forEach { item ->
                val active = selected == item.key
                NavigationBarItem(
                    selected = active,
                    onClick = { onSelect(item.key) },
                    icon = {
                        Icon(
                            item.icon,
                            contentDescription = item.label,
                            modifier = Modifier.size(if (active) 22.dp else 20.dp)
                        )
                    },
                    label = { Text(item.label, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WorkspaceGold,
                        selectedTextColor = WorkspaceGold,
                        indicatorColor = WorkspaceViolet.copy(alpha = 0.23f),
                        unselectedIconColor = WorkspaceMuted,
                        unselectedTextColor = WorkspaceMuted
                    )
                )
            }
        }
    }
}

@Composable
private fun WorkspaceHeader(title: String, subtitle: String, onBack: () -> Unit, status: String? = null, online: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xF01C2036), Color(0xE0292146))))
            .border(1.dp, Color(0xFF50466E), RoundedCornerShape(19.dp))
            .padding(horizontal = 7.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = WorkspaceText)
        }
        Column(Modifier.weight(1f)) {
            Text("BAATLY PARTNER", color = WorkspaceGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.6.sp)
            Text(title, color = WorkspaceText, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = WorkspaceMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (status != null) {
            Surface(color = if (online) Color(0xFF16483F) else Color(0xFF3A344F), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (online) WorkspaceMint else WorkspaceMuted))
                    Spacer(Modifier.width(6.dp))
                    Text(status, color = if (online) WorkspaceMint else WorkspaceMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun WorkspaceScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .padding(bottom = 96.dp),
        content = content
    )
}

@Composable
private fun WorkspaceHero(eyebrow: String, title: String, subtitle: String, art: String, trailing: (@Composable () -> Unit)? = null, artRes: Int? = null) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF382A63), Color(0xFF1B2340), Color(0xFF163E4A))))
            .border(1.dp, Color(0xFF66558E), RoundedCornerShape(24.dp))
            .padding(17.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(eyebrow.uppercase(), color = WorkspaceGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(5.dp))
            Text(title, color = WorkspaceText, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 25.sp)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Color(0xFFD0D1E2), fontSize = 11.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(8.dp))
        when {
            trailing != null -> trailing()
            artRes != null -> Image(
                painter = painterResource(artRes),
                contentDescription = "$title artwork",
                modifier = Modifier.size(96.dp),
                contentScale = ContentScale.Fit
            )
            else -> Text(art, fontSize = 43.sp)
        }
    }
}

@Composable
private fun WorkspaceSection(title: String, trailing: String? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title.uppercase(), color = WorkspaceGold, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        if (!trailing.isNullOrBlank()) Text(trailing, color = WorkspaceMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun WorkspaceCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(WorkspacePanel)
            .border(1.dp, Color(0xFF414667), RoundedCornerShape(19.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
private fun WorkspaceStat(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier, accent: Color = WorkspaceGold) {
    Column(
        modifier.clip(RoundedCornerShape(17.dp)).background(Color(0xE9212742))
            .border(1.dp, Color(0xFF43496C), RoundedCornerShape(17.dp)).padding(13.dp)
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, color = WorkspaceText, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = WorkspaceMuted, fontSize = 10.sp)
    }
}

@Composable
private fun WorkspaceMessage(title: String, detail: String, icon: String = "✨") {
    WorkspaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = WorkspaceText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(detail, color = WorkspaceMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
    }
}

@Composable
private fun PremiumTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp),
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = WorkspaceGold,
            unfocusedBorderColor = Color(0xFF535A7B),
            focusedLabelColor = WorkspaceGold,
            unfocusedLabelColor = WorkspaceMuted,
            focusedTextColor = WorkspaceText,
            unfocusedTextColor = WorkspaceText,
            cursorColor = WorkspaceGold
        )
    )
}

@Composable
private fun PremiumPrimaryButton(label: String, enabled: Boolean = true, busy: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled && !busy,
        modifier = Modifier.fillMaxWidth().height(49.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = WorkspaceViolet, disabledContainerColor = Color(0xFF47435E))
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(17.dp), color = Color.White, strokeWidth = 2.dp)
        else Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

private fun jsonCoordinate(json: JSONObject?, key: String): Double? {
    if (json == null || !json.has(key) || json.isNull(key)) return null
    return json.optDouble(key).takeIf { it.isFinite() && it in -180.0..180.0 }
}

private fun money(json: JSONObject?, key: String, fallback: String = "0"): String =
    json?.optString(key)?.takeIf { it.isNotBlank() && it != "null" } ?: fallback

@Composable
fun MobilityPartnerWorkspace(
    category: PartnerCategory,
    application: MobilityPartnerApplicationModel?,
    repository: PartnerOnboardingRepository,
    refreshToken: Int,
    busy: Boolean,
    error: String?,
    onToggleService: (serviceType: String, enable: Boolean, otherServiceOnline: Boolean) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("home") }
    var dashboard by remember { mutableStateOf<JSONObject?>(null) }
    var walletData by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var walletLoading by remember { mutableStateOf(false) }
    var actionBusy by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }
    var otpCode by remember { mutableStateOf("") }
    var topupAmount by remember { mutableStateOf("") }
    var topupReference by remember { mutableStateOf("") }

    suspend fun reloadDashboard() {
        loading = true
        val result = repository.getPartnerDashboard()
        if (result.isSuccess) {
            dashboard = result.getOrThrow()
            localError = null
        } else localError = result.exceptionOrNull()?.message ?: "Could not refresh your partner workspace"
        loading = false
    }

    suspend fun reloadWallet() {
        walletLoading = true
        val result = repository.getMobilityWallet()
        if (result.isSuccess) walletData = result.getOrThrow()
        else localError = result.exceptionOrNull()?.message ?: "Could not load wallet"
        walletLoading = false
    }

    LaunchedEffect(category, refreshToken) { reloadDashboard() }
    LaunchedEffect(tab, refreshToken) {
        if (tab == "wallet") reloadWallet()
        if (tab == "jobs" || tab == "home") {
            while (true) {
                delay(if (tab == "jobs") 7000L else 15000L)
                reloadDashboard()
            }
        }
    }

    fun runAction(action: String, payload: Map<String, Any?>) {
        scope.launch {
            actionBusy = true
            localError = null
            val result = repository.performMobilityAction(action, payload)
            if (result.isFailure) localError = result.exceptionOrNull()?.message ?: "Action failed"
            else {
                otpCode = ""
                reloadDashboard()
            }
            actionBusy = false
        }
    }

    val offers = dashboard?.optJSONArray("offers") ?: JSONArray()
    val active = dashboard?.optJSONObject("active_job")
    val activeType = active?.optString("job_type").orEmpty()
    val activeId = active?.optString("job_id").orEmpty()
    val activeJob = active?.optJSONObject("job")
    val activeStatus = activeJob?.optString("status").orEmpty()
    val wallet = dashboard?.optJSONObject("wallet")
    val services = dashboard?.optJSONArray("services") ?: JSONArray()
    val serviceTypes = if (category == PartnerCategory.TWO_WHEELER) listOf("bike_taxi", "food_delivery", "parcel") else listOf("cab")
    val online = (0 until services.length()).mapNotNull { services.optJSONObject(it) }.any { it.optBoolean("is_online") }
    val mapJob = activeJob ?: offers.optJSONObject(0)?.optJSONObject("job")
    val mapJobType = if (activeJob != null) activeType else offers.optJSONObject(0)?.optString("job_type").orEmpty()
    val pickupLat = jsonCoordinate(mapJob, "pickup_latitude")
    val pickupLng = jsonCoordinate(mapJob, "pickup_longitude")
    val dropLat = jsonCoordinate(mapJob, if (mapJobType == "food") "delivery_latitude" else "drop_latitude")
    val dropLng = jsonCoordinate(mapJob, if (mapJobType == "food") "delivery_longitude" else "drop_longitude")
    val pickupAddress = mapJob?.optString("pickup_address")?.takeIf { it.isNotBlank() }
        ?: mapJob?.optString("restaurant_name")?.takeIf { it.isNotBlank() } ?: "Pickup location"
    val dropAddress = mapJob?.optString("delivery_address")?.takeIf { it.isNotBlank() }
        ?: mapJob?.optString("drop_address")?.takeIf { it.isNotBlank() } ?: "Drop location"

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(WorkspaceBg, Color(0xFF151A32), Color(0xFF101A28))))) {
        if (tab == "home" || tab == "jobs") {
            PartnerFullScreenGoogleMap(
                modifier = Modifier.fillMaxSize(),
                pickupAddress = pickupAddress,
                pickupLatitude = pickupLat,
                pickupLongitude = pickupLng,
                dropAddress = dropAddress,
                dropLatitude = dropLat,
                dropLongitude = dropLng
            )
        }
        Column(Modifier.fillMaxSize()) {
            WorkspaceHeader(category.title, "Live partner workspace · secure operations", onBack, if (online) "ONLINE" else "OFFLINE", online)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "home" -> WorkspaceScroll {
                        WorkspaceHero(
                            eyebrow = if (online) "You are visible to nearby customers" else "Your partner control centre",
                            title = if (category == PartnerCategory.TWO_WHEELER) "One bike. Three earning options." else "Your next trip starts here.",
                            subtitle = if (category == PartnerCategory.TWO_WHEELER) "Choose Bike Taxi, Food Delivery or Parcel independently." else "Keep your cab service online and accept nearby bookings.",
                            art = if (category == PartnerCategory.TWO_WHEELER) "🏍️" else "🚘",
                            artRes = if (category == PartnerCategory.TWO_WHEELER) R.drawable.partner_art_bike else R.drawable.partner_art_cab
                        )
                        WorkspaceSection(if (category == PartnerCategory.TWO_WHEELER) "Your earning switches" else "Cab service availability")
                        serviceTypes.forEach { serviceType ->
                            val service = (0 until services.length()).mapNotNull { services.optJSONObject(it) }.firstOrNull { it.optString("service_type") == serviceType }
                            val enabled = service?.optBoolean("is_enabled") == true
                            val isOnline = service?.optBoolean("is_online") == true
                            val otherOnline = (0 until services.length()).mapNotNull { services.optJSONObject(it) }
                                .any { it.optString("service_type") != serviceType && it.optBoolean("is_online") }
                            val title = when (serviceType) {
                                "bike_taxi" -> "Bike Taxi"
                                "food_delivery" -> "Food Delivery"
                                "parcel" -> "Parcel Delivery"
                                else -> "Cab / Auto"
                            }
                            val subtitle = when (serviceType) {
                                "bike_taxi" -> "Passenger pickup and drop"
                                "food_delivery" -> "Restaurant pickup and customer delivery"
                                "parcel" -> "Local parcel pickup and delivery"
                                else -> "Auto, e-rickshaw or car bookings"
                            }
                            WorkspaceCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(title, color = WorkspaceText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(if (enabled) subtitle else "Waiting for admin approval", color = WorkspaceMuted, fontSize = 10.sp)
                                        Text(if (!enabled) "LOCKED" else if (isOnline) "RECEIVING REQUESTS" else "NOT RECEIVING REQUESTS", color = if (isOnline) WorkspaceMint else WorkspaceMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Switch(
                                        checked = isOnline,
                                        onCheckedChange = { onToggleService(serviceType, it, otherOnline) },
                                        enabled = enabled && !busy && !actionBusy
                                    )
                                }
                            }
                        }
                        WorkspaceSection("Your account snapshot")
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            WorkspaceStat("COD wallet", "₹${money(wallet, "balance_rupees")}", Icons.Default.AccountBalanceWallet, Modifier.weight(1f), WorkspaceGold)
                            WorkspaceStat("Earnings", "₹${money(wallet, "earning_balance_rupees")}", Icons.Default.TrendingUp, Modifier.weight(1f), WorkspaceMint)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            WorkspaceStat("New requests", offers.length().toString(), Icons.Default.NotificationsActive, Modifier.weight(1f), WorkspaceViolet)
                            WorkspaceStat("Account", "Approved", Icons.Default.VerifiedUser, Modifier.weight(1f), WorkspaceMint)
                        }
                        WorkspaceSection("Current assignment")
                        if (activeJob != null) {
                            WorkspaceCard {
                                Text("${activeType.uppercase()} · ${activeStatus.replace('_', ' ').uppercase()}", color = WorkspaceGold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(6.dp))
                                Text(pickupAddress, color = WorkspaceText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("↓ $dropAddress", color = WorkspaceMuted, fontSize = 11.sp)
                                TextButton(onClick = { tab = "jobs" }) { Text("Open job workspace →", color = WorkspaceGold) }
                            }
                        } else WorkspaceMessage("No active job", "Incoming bookings will appear in the Jobs tab. Keep GPS and your chosen services active.", "🧭")
                        localError?.let { WorkspaceMessage("Could not refresh", it, "⚠️") }
                        error?.let { WorkspaceMessage("Notice", it, "ℹ️") }
                    }
                    "jobs" -> WorkspaceScroll {
                        WorkspaceHero("Dispatch and fulfilment", "Orders & requests", "Review new offers, navigate to pickup and finish every trip with the in-app verification steps.", "🧾")
                        WorkspaceSection("Active job", if (activeId.isBlank()) "NONE" else activeStatus.replace('_', ' ').uppercase())
                        if (activeId.isNotBlank() && activeJob != null) {
                            MobilityActiveJobCard(
                                activeType, activeStatus, activeId, activeJob, otpCode,
                                onOtp = { otpCode = it }, actionBusy = actionBusy,
                                onAction = { action, payload -> runAction(action, payload) }
                            )
                        } else WorkspaceMessage("No active job", "When you accept an offer, it will move here with pickup/drop navigation and completion controls.", "🧭")
                        WorkspaceSection("Incoming offers", "${offers.length()} available")
                        if (loading) {
                            Box(Modifier.fillMaxWidth().padding(22.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = WorkspaceGold) }
                        } else if (offers.length() == 0) {
                            WorkspaceMessage("No new offers right now", "This page refreshes automatically. Leave your selected service ON to receive matching work.", "🔔")
                        } else {
                            for (i in 0 until offers.length()) {
                                val offer = offers.optJSONObject(i) ?: continue
                                val job = offer.optJSONObject("job") ?: JSONObject()
                                val jobType = offer.optString("job_type")
                                val offerId = offer.optString("id")
                                val pAddress = job.optString("pickup_address").ifBlank { job.optString("restaurant_name", "Restaurant pickup") }
                                val dAddress = if (jobType == "food") job.optString("delivery_address") else job.optString("drop_address")
                                val pLat = jsonCoordinate(job, "pickup_latitude")
                                val pLng = jsonCoordinate(job, "pickup_longitude")
                                val dLat = jsonCoordinate(job, if (jobType == "food") "delivery_latitude" else "drop_latitude")
                                val dLng = jsonCoordinate(job, if (jobType == "food") "delivery_longitude" else "drop_longitude")
                                val amount = if (jobType == "food") job.optString("delivery_partner_net", "—") else job.optString("quoted_fare", "—")
                                WorkspaceCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(jobType.uppercase(), color = WorkspaceGold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                                        Text("${offer.optString("radius_km")} KM AWAY", color = WorkspaceMuted, fontSize = 9.sp)
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    Text(pAddress, color = WorkspaceText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("↓ ${dAddress.ifBlank { "Drop location" }}", color = WorkspaceMuted, fontSize = 11.sp)
                                    Text("₹$amount · ${job.optString("route_distance_km", job.optString("road_distance_km", "—"))} km · ${job.optString("payment_method", "COD")}", color = WorkspaceMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        GoogleMapsNavigationButton("Pickup", pLat, pLng, modifier = Modifier.weight(1f))
                                        GoogleMapsNavigationButton("Drop", dLat, dLng, modifier = Modifier.weight(1f))
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        OutlinedButton(onClick = { runAction("reject_offer", mapOf("offer_id" to offerId)) }, enabled = !actionBusy && !busy, modifier = Modifier.weight(1f)) {
                                            Text("Reject", color = WorkspaceRed)
                                        }
                                        Button(onClick = {
                                            scope.launch {
                                                actionBusy = true
                                                val result = repository.respondToOffer(offerId, true)
                                                if (result.isFailure) localError = result.exceptionOrNull()?.message else reloadDashboard()
                                                actionBusy = false
                                            }
                                        }, enabled = !actionBusy && !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = WorkspaceViolet)) {
                                            Text("Accept offer", color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        TextButton(onClick = { scope.launch { reloadDashboard() } }, enabled = !loading) { Text("Refresh jobs", color = WorkspaceGold) }
                        localError?.let { WorkspaceMessage("Action failed", it, "⚠️") }
                    }
                    "wallet" -> WorkspaceScroll {
                        WorkspaceHero("Your money centre", "Wallet & earnings", "Track COD float, partner earnings and every wallet entry in one place.", "💳")
                        val walletObject = walletData?.optJSONObject("wallet")
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            WorkspaceStat("COD balance", "₹${money(walletObject, "balance_rupees")}", Icons.Default.AccountBalanceWallet, Modifier.weight(1f))
                            WorkspaceStat("Earnings", "₹${money(walletObject, "earning_balance_rupees")}", Icons.Default.Savings, Modifier.weight(1f), WorkspaceMint)
                        }
                        Spacer(Modifier.height(8.dp))
                        WorkspaceCard {
                            Text("Cash collected lifetime", color = WorkspaceMuted, fontSize = 10.sp)
                            Text("₹${money(walletObject, "cash_collected_lifetime")}", color = WorkspaceText, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            val blocked = walletObject?.optBoolean("online_blocked") == true
                            Text(if (blocked) "Wallet restricted · ${walletObject?.optString("block_reason")}" else "Wallet status · Healthy", color = if (blocked) WorkspaceRed else WorkspaceMint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        WorkspaceSection("Request COD top-up")
                        WorkspaceCard {
                            PremiumTextField("Top-up amount (₹)", topupAmount, { topupAmount = it }, KeyboardType.Decimal)
                            PremiumTextField("Payment reference (optional)", topupReference, { topupReference = it })
                            PremiumPrimaryButton("Submit top-up request", enabled = topupAmount.toDoubleOrNull()?.let { it > 0.0 } == true, busy = actionBusy) {
                                val amount = topupAmount.toDoubleOrNull() ?: 0.0
                                scope.launch {
                                    actionBusy = true
                                    val result = repository.requestMobilityTopup(amount, topupReference.ifBlank { null })
                                    if (result.isSuccess) {
                                        topupAmount = ""; topupReference = ""; reloadWallet()
                                    } else localError = result.exceptionOrNull()?.message ?: "Top-up request failed"
                                    actionBusy = false
                                }
                            }
                            Text("A top-up remains pending until the BAATLY admin team verifies it.", color = WorkspaceMuted, fontSize = 9.sp, lineHeight = 14.sp)
                        }
                        WorkspaceSection("Wallet activity")
                        val transactions = walletData?.optJSONArray("transactions") ?: JSONArray()
                        if (walletLoading) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = WorkspaceGold) }
                        else if (transactions.length() == 0) WorkspaceMessage("No wallet entries yet", "Completed jobs, collections and approved top-ups will appear here.", "📒")
                        else for (i in 0 until transactions.length()) {
                            val tx = transactions.optJSONObject(i) ?: continue
                            val amount = tx.optString("amount_delta", "0").toDoubleOrNull() ?: 0.0
                            WorkspaceCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(tx.optString("description").ifBlank { tx.optString("entry_type").replace('_', ' ') }, color = WorkspaceText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(tx.optString("created_at").replace('T', ' ').take(16), color = WorkspaceMuted, fontSize = 9.sp)
                                    }
                                    Text("${if (amount >= 0) "+" else "−"}₹${String.format(Locale.US, "%.2f", kotlin.math.abs(amount))}", color = if (amount >= 0) WorkspaceMint else WorkspaceRed, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                }
                                Text("Balance after · ₹${tx.optString("balance_after", "0")}", color = WorkspaceMuted, fontSize = 9.sp)
                            }
                        }
                        val topups = walletData?.optJSONArray("topups") ?: JSONArray()
                        if (topups.length() > 0) {
                            WorkspaceSection("Top-up requests")
                            for (i in 0 until topups.length()) {
                                val topup = topups.optJSONObject(i) ?: continue
                                WorkspaceCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("₹${topup.optString("amount", "0")}", color = WorkspaceText, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text(topup.optString("status").uppercase(), color = when (topup.optString("status")) { "approved" -> WorkspaceMint; "rejected" -> WorkspaceRed; else -> WorkspaceGold }, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(topup.optString("payment_reference").ifBlank { "No payment reference" }, color = WorkspaceMuted, fontSize = 9.sp)
                                }
                            }
                        }
                        localError?.let { WorkspaceMessage("Wallet message", it, "⚠️") }
                    }
                    else -> WorkspaceScroll {
                        WorkspaceHero("Your partner identity", "Profile & account", "Your approved details and active service permissions.", "👤")
                        WorkspaceCard {
                            Text(application?.applicantName ?: "BAATLY Partner", color = WorkspaceText, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                            Text(application?.phoneNumber ?: "Mobile number not available", color = WorkspaceMuted, fontSize = 11.sp)
                            Spacer(Modifier.height(12.dp))
                            WorkspaceProfileRow("Partner type", category.title)
                            WorkspaceProfileRow("Approval", application?.applicationStatus?.uppercase() ?: "APPROVED")
                            WorkspaceProfileRow("Vehicle category", application?.vehicleCategory?.replace('_', ' ')?.uppercase() ?: "—")
                            WorkspaceProfileRow("City", listOfNotNull(application?.city, application?.state).joinToString(", ").ifBlank { "—" })
                            WorkspaceProfileRow("Application ID", application?.id?.take(8)?.uppercase() ?: "—")
                            WorkspaceProfileRow("Account ID", repository.currentUserId()?.take(8)?.uppercase() ?: "—")
                        }
                        WorkspaceSection("Approved services")
                        serviceTypes.forEach { serviceType ->
                            val service = (0 until services.length()).mapNotNull { services.optJSONObject(it) }.firstOrNull { it.optString("service_type") == serviceType }
                            WorkspaceProfileRow(
                                when (serviceType) { "bike_taxi" -> "Bike Taxi"; "food_delivery" -> "Food Delivery"; "parcel" -> "Parcel Delivery"; else -> "Cab" },
                                when { service?.optBoolean("is_online") == true -> "ONLINE"; service?.optBoolean("is_enabled") == true -> "ENABLED"; else -> "LOCKED" }
                            )
                        }
                        WorkspaceMessage("Account security", "Your login and uploaded KYC documents remain tied to this BAATLY partner account.", "🔐")
                        PremiumPrimaryButton("Switch partner category", onClick = onBack)
                    }
                }
            }
            PremiumWorkspaceNav(
                items = listOf(
                    WorkspaceNavItem("home", "Home", Icons.Default.Home),
                    WorkspaceNavItem("jobs", "Orders", Icons.Default.Assignment),
                    WorkspaceNavItem("wallet", "Wallet", Icons.Default.AccountBalanceWallet),
                    WorkspaceNavItem("profile", "Profile", Icons.Default.Person)
                ),
                selected = tab,
                onSelect = { tab = it; localError = null }
            )
        }
    }
}

@Composable
private fun MobilityActiveJobCard(
    jobType: String, status: String, jobId: String, job: JSONObject,
    otpCode: String, onOtp: (String) -> Unit, actionBusy: Boolean,
    onAction: (String, Map<String, Any?>) -> Unit
) {
    val pickup = job.optString("pickup_address").ifBlank { job.optString("restaurant_name", "Pickup location") }
    val drop = job.optString("delivery_address").ifBlank { job.optString("drop_address", "Drop location") }
    val pickupLat = jsonCoordinate(job, "pickup_latitude")
    val pickupLng = jsonCoordinate(job, "pickup_longitude")
    val dropLat = jsonCoordinate(job, if (jobType == "food") "delivery_latitude" else "drop_latitude")
    val dropLng = jsonCoordinate(job, if (jobType == "food") "delivery_longitude" else "drop_longitude")
    WorkspaceCard {
        Text("${jobType.uppercase()} · ${status.replace('_', ' ').uppercase()}", color = WorkspaceGold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(7.dp))
        Text(pickup, color = WorkspaceText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("↓ $drop", color = WorkspaceMuted, fontSize = 11.sp)
        Text("₹${job.optString("quoted_fare", job.optString("customer_total", "—"))} · ${job.optString("route_distance_km", job.optString("road_distance_km", "—"))} km · ${job.optString("payment_method", "COD")}", color = WorkspaceMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            GoogleMapsNavigationButton("Navigate pickup", pickupLat, pickupLng, modifier = Modifier.weight(1f))
            GoogleMapsNavigationButton("Navigate drop", dropLat, dropLng, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        when (jobType) {
            "cab" -> when (status) {
                "accepted", "driver_arriving" -> PremiumPrimaryButton("I've reached pickup", busy = actionBusy) { onAction("mark_cab_arrived", mapOf("ride_id" to jobId)) }
                "arrived" -> {
                    PremiumTextField("Customer ride start code", otpCode, onOtp, KeyboardType.Number)
                    PremiumPrimaryButton("Verify code & start ride", busy = actionBusy) { onAction("verify_ride_code", mapOf("ride_id" to jobId, "code" to otpCode)) }
                }
                "in_progress" -> PremiumPrimaryButton("Complete ride", busy = actionBusy) { onAction("complete_cab_ride", mapOf("ride_id" to jobId)) }
            }
            "food" -> when (status) {
                "partner_assigned" -> {
                    PremiumTextField("Restaurant pickup code", otpCode, onOtp, KeyboardType.Number)
                    PremiumPrimaryButton("Verify pickup code", busy = actionBusy) { onAction("partner_pickup_food", mapOf("order_id" to jobId, "code" to otpCode)) }
                }
                "picked_up" -> PremiumPrimaryButton("Picked up · Start delivery", busy = actionBusy) { onAction("partner_food_on_the_way", mapOf("order_id" to jobId)) }
                "on_the_way" -> {
                    PremiumTextField("Customer delivery code", otpCode, onOtp, KeyboardType.Number)
                    PremiumPrimaryButton("Verify delivery & complete", busy = actionBusy) { onAction("complete_food_order", mapOf("order_id" to jobId, "code" to otpCode)) }
                }
            }
            "parcel" -> when (status) {
                "accepted", "driver_arriving", "arrived" -> {
                    if (status != "arrived") PremiumPrimaryButton("Arrived at parcel pickup", busy = actionBusy) { onAction("mark_parcel_arrived", mapOf("parcel_id" to jobId)) }
                    PremiumTextField("Sender pickup code", otpCode, onOtp, KeyboardType.Number)
                    PremiumPrimaryButton("Verify pickup & start delivery", busy = actionBusy) { onAction("partner_pickup_parcel", mapOf("parcel_id" to jobId, "code" to otpCode)) }
                }
                "in_transit" -> {
                    PremiumTextField("Receiver delivery code", otpCode, onOtp, KeyboardType.Number)
                    PremiumPrimaryButton("Verify delivery & complete", busy = actionBusy) { onAction("complete_parcel", mapOf("parcel_id" to jobId, "code" to otpCode)) }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceProfileRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = WorkspaceMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))
        Text(value.ifBlank { "—" }, color = WorkspaceText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    HorizontalDivider(color = Color(0xFF353B58).copy(alpha = 0.7f))
}

@Composable
fun RestaurantPartnerWorkspace(
    restaurant: MobilityRestaurantModel?, branch: MobilityRestaurantBranchModel?, repository: PartnerOnboardingRepository,
    categoryName: String, onCategoryName: (String) -> Unit, categoryId: String, onCategoryId: (String) -> Unit,
    itemName: String, onItemName: (String) -> Unit, itemPrice: String, onItemPrice: (String) -> Unit,
    foodType: String, onFoodType: (String) -> Unit,
    menuImage: Any?, onPickMenuImage: () -> Unit, onClearMenuImage: () -> Unit,
    onUploadMenuImage: suspend () -> Result<String?>,
    busy: Boolean, error: String?, onBusy: (Boolean) -> Unit, onError: (String?) -> Unit, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("home") }
    var isOpen by remember { mutableStateOf(branch?.isOpen == true) }
    var dashboard by remember { mutableStateOf<JSONObject?>(null) }
    var orders by remember { mutableStateOf(JSONArray()) }
    var menuCategories by remember { mutableStateOf(JSONArray()) }
    var menuItems by remember { mutableStateOf(JSONArray()) }
    var settlementBalance by remember { mutableStateOf("0") }
    var ledger by remember { mutableStateOf<JSONArray?>(null) }
    var loading by remember { mutableStateOf(true) }
    var walletLoading by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        val result = repository.getPartnerDashboard()
        if (result.isSuccess) {
            dashboard = result.getOrThrow()
            val restaurants = dashboard?.optJSONArray("restaurants") ?: JSONArray()
            val found = (0 until restaurants.length()).mapNotNull { restaurants.optJSONObject(it) }.firstOrNull { it.optString("id") == restaurant?.id }
            orders = found?.optJSONArray("orders") ?: JSONArray()
            menuCategories = found?.optJSONArray("menu_categories") ?: JSONArray()
            menuItems = found?.optJSONArray("menu_items") ?: JSONArray()
            settlementBalance = found?.optString("settlement_balance", "0") ?: "0"
            val branches = found?.optJSONArray("branches") ?: JSONArray()
            val current = (0 until branches.length()).mapNotNull { branches.optJSONObject(it) }.firstOrNull { it.optString("id") == branch?.id }
            if (current != null) isOpen = current.optBoolean("is_open", isOpen)
            localError = null
        } else localError = result.exceptionOrNull()?.message ?: "Could not load restaurant workspace"
        loading = false
    }

    suspend fun reloadLedger() {
        val id = restaurant?.id ?: return
        walletLoading = true
        val result = repository.getRestaurantLedgerEntries(id)
        if (result.isSuccess) ledger = result.getOrThrow()
        else localError = result.exceptionOrNull()?.message ?: "Could not load settlement ledger"
        walletLoading = false
    }

    LaunchedEffect(restaurant?.id) { reload() }
    LaunchedEffect(tab, restaurant?.id) {
        if (tab == "wallet") reloadLedger()
        if (tab == "orders" || tab == "home") {
            while (true) {
                delay(if (tab == "orders") 10000L else 20000L)
                reload()
            }
        }
    }

    fun updateOrder(orderId: String, action: String) {
        scope.launch {
            onBusy(true); onError(null); localError = null
            val result = repository.updateRestaurantOrder(orderId, action)
            if (result.isFailure) { onError(result.exceptionOrNull()?.message); localError = result.exceptionOrNull()?.message }
            else reload()
            onBusy(false)
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(WorkspaceBg, Color(0xFF19172F), Color(0xFF112A36))))) {
        Column(Modifier.fillMaxSize()) {
            WorkspaceHeader(restaurant?.restaurantName ?: "Restaurant Partner", "Outlet operations · menu · settlement", onBack, if (isOpen) "OPEN" else "CLOSED", isOpen)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    "home" -> WorkspaceScroll {
                        WorkspaceHero("Restaurant control centre", restaurant?.restaurantName ?: "Your restaurant", "Manage outlet availability, orders, menu and settlement from one premium workspace.", "🍽️", artRes = R.drawable.partner_art_restaurant)
                        WorkspaceCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(if (isOpen) "Outlet is accepting orders" else "Outlet is currently closed", color = WorkspaceText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text("Only active, approved branches can receive new BAATLY orders.", color = WorkspaceMuted, fontSize = 10.sp)
                                }
                                Switch(checked = isOpen, onCheckedChange = { value ->
                                    val branchId = branch?.id
                                    if (branchId != null) scope.launch {
                                        onBusy(true); onError(null)
                                        val result = repository.setRestaurantBranchOpen(branchId, value)
                                        if (result.isSuccess) isOpen = value else onError(result.exceptionOrNull()?.message)
                                        onBusy(false)
                                    }
                                }, enabled = !busy && branch?.isActive == true)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            WorkspaceStat("Live orders", orders.length().toString(), Icons.Default.ReceiptLong, Modifier.weight(1f), WorkspaceGold)
                            WorkspaceStat("Menu items", menuItems.length().toString(), Icons.Default.RestaurantMenu, Modifier.weight(1f), WorkspaceMint)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                            WorkspaceStat("Settlement", "₹$settlementBalance", Icons.Default.AccountBalanceWallet, Modifier.weight(1f), WorkspaceViolet)
                            WorkspaceStat("Branch", if (branch?.isActive == true) "Active" else "Inactive", Icons.Default.Storefront, Modifier.weight(1f), WorkspaceMint)
                        }
                        WorkspaceSection("Order pulse", "${orders.length()} in progress")
                        val nextOrder = orders.optJSONObject(0)
                        if (nextOrder != null) {
                            WorkspaceCard {
                                Text("ORDER #${nextOrder.optString("id").take(8).uppercase()}", color = WorkspaceGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(nextOrder.optString("delivery_address", "Customer delivery"), color = WorkspaceText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("₹${nextOrder.optString("customer_total", "0")} · ${nextOrder.optString("status").replace('_', ' ')}", color = WorkspaceMint, fontSize = 10.sp)
                                TextButton(onClick = { tab = "orders" }) { Text("View all orders →", color = WorkspaceGold) }
                            }
                        } else WorkspaceMessage("No live orders", "New customer orders will appear here while your outlet is open.", "🧾")
                        localError?.let { WorkspaceMessage("Update notice", it, "⚠️") }
                        error?.let { WorkspaceMessage("Attention", it, "ℹ️") }
                    }
                    "orders" -> WorkspaceScroll {
                        WorkspaceHero("Incoming and in-progress", "Restaurant orders", "Accept, prepare and mark orders ready for rider pickup.", "🛎️")
                        WorkspaceSection("Live orders", "${orders.length()}")
                        if (loading) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = WorkspaceGold) }
                        else if (orders.length() == 0) WorkspaceMessage("No active orders", "When customers place an order, it will appear here with item details and action buttons.", "🧾")
                        else for (index in 0 until orders.length()) {
                            val order = orders.optJSONObject(index) ?: continue
                            val orderId = order.optString("id")
                            val orderStatus = order.optString("status")
                            val items = order.optJSONArray("items") ?: JSONArray()
                            WorkspaceCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("#${orderId.take(8).uppercase()}", color = WorkspaceGold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                                    Text(orderStatus.replace('_', ' ').uppercase(), color = if (orderStatus == "ready") WorkspaceMint else WorkspaceMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(order.optString("delivery_address", "Customer delivery"), color = WorkspaceText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("₹${order.optString("customer_total", "0")} · ${order.optString("payment_method", "COD")}", color = WorkspaceMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                for (i in 0 until items.length()) {
                                    val item = items.optJSONObject(i) ?: continue
                                    Text("${item.optString("quantity")} × ${item.optString("item_name_snapshot")} · ₹${item.optString("line_total")}", color = WorkspaceMuted, fontSize = 10.sp)
                                }
                                Spacer(Modifier.height(8.dp))
                                when (orderStatus) {
                                    "placed" -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { updateOrder(orderId, "reject") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Reject", color = WorkspaceRed) }
                                        Button(onClick = { updateOrder(orderId, "accept") }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = WorkspaceViolet)) { Text("Accept order", color = Color.White) }
                                    }
                                    "restaurant_accepted" -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { updateOrder(orderId, "preparing") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Preparing", color = WorkspaceGold) }
                                        Button(onClick = { updateOrder(orderId, "ready") }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = WorkspaceViolet)) { Text("Ready", color = Color.White) }
                                    }
                                    "preparing" -> PremiumPrimaryButton("Mark ready for pickup", busy = busy) { updateOrder(orderId, "ready") }
                                    "ready" -> Text("Ready · Waiting for delivery partner", color = WorkspaceMint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    "menu" -> WorkspaceScroll {
                        WorkspaceHero("Manage dishes and availability", "Menu manager", "Create categories, add dishes and pause unavailable items instantly.", "🍲")
                        WorkspaceSection("Categories", "${menuCategories.length()}")
                        if (menuCategories.length() == 0) WorkspaceMessage("No menu categories", "Create your first category below, such as Main Course, Snacks or Drinks.", "📚")
                        else Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                            for (i in 0 until menuCategories.length()) {
                                val item = menuCategories.optJSONObject(i) ?: continue
                                Surface(color = Color(0xFF2E2A4D), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF59507A))) {
                                    Text(item.optString("name"), color = WorkspaceText, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
                                }
                            }
                        }
                        WorkspaceSection("Current menu", "${menuItems.length()} items")
                        if (menuItems.length() == 0) WorkspaceMessage("Menu is empty", "Add the first menu item using the form below.", "🍽️")
                        else for (i in 0 until menuItems.length()) {
                            val menuItem = menuItems.optJSONObject(i) ?: continue
                            val itemId = menuItem.optString("id")
                            val available = menuItem.optBoolean("is_available", true)
                            WorkspaceCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(menuItem.optString("item_name"), color = WorkspaceText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("₹${menuItem.optString("price")} · ${menuItem.optString("food_type").replace('_', ' ')}", color = WorkspaceMuted, fontSize = 10.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Switch(checked = available, onCheckedChange = { value ->
                                            scope.launch {
                                                onBusy(true); onError(null)
                                                val update = repository.upsertMenuItem(mapOf(
                                                    "id" to itemId, "restaurant_id" to restaurant?.id, "branch_id" to branch?.id,
                                                    "category_id" to menuItem.optString("category_id").ifBlank { null },
                                                    "item_name" to menuItem.optString("item_name"), "description" to menuItem.optString("description"),
                                                    "price" to menuItem.optDouble("price"), "image_object_key" to menuItem.optString("image_object_key").ifBlank { null },
                                                    "food_type" to menuItem.optString("food_type", "veg"), "is_available" to value,
                                                    "is_active" to menuItem.optBoolean("is_active", true),
                                                    "preparation_time_minutes" to menuItem.optInt("preparation_time_minutes", 20),
                                                    "display_order" to menuItem.optInt("display_order", 0)
                                                ))
                                                if (update.isSuccess) reload() else onError(update.exceptionOrNull()?.message)
                                                onBusy(false)
                                            }
                                        }, enabled = !busy)
                                        Text(if (available) "Available" else "Paused", color = if (available) WorkspaceMint else WorkspaceRed, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                        WorkspaceSection("Add category")
                        WorkspaceCard {
                            PremiumTextField("Category name", categoryName, onCategoryName)
                            PremiumPrimaryButton("Save category", enabled = categoryName.isNotBlank(), busy = busy) {
                                val restaurantId = restaurant?.id ?: return@PremiumPrimaryButton
                                scope.launch {
                                    onBusy(true); onError(null)
                                    val saved = repository.upsertMenuCategory(mapOf("restaurant_id" to restaurantId, "branch_id" to branch?.id, "name" to categoryName.trim()))
                                    if (saved.isSuccess) { onCategoryId(saved.getOrThrow()); onCategoryName(""); reload() }
                                    else onError(saved.exceptionOrNull()?.message)
                                    onBusy(false)
                                }
                            }
                        }
                        WorkspaceSection("Add menu item")
                        WorkspaceCard {
                            PremiumTextField("Dish name", itemName, onItemName)
                            PremiumTextField("Price (₹)", itemPrice, onItemPrice, KeyboardType.Decimal)
                            Text("Food type", color = WorkspaceMuted, fontSize = 10.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                                listOf("veg", "non_veg", "egg").forEach { type ->
                                    FilterChip(selected = foodType == type, onClick = { onFoodType(type) }, label = { Text(type.replace('_', ' ').uppercase(), fontSize = 9.sp) })
                                }
                            }
                            OutlinedButton(onClick = onPickMenuImage, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.AddPhotoAlternate, null)
                                Spacer(Modifier.width(7.dp))
                                Text(if (menuImage != null) "Dish photo selected · change photo" else "Add dish photo (optional)")
                            }
                            PremiumPrimaryButton("Add menu item", enabled = itemName.isNotBlank() && (itemPrice.toDoubleOrNull()?.let { it >= 0 } == true), busy = busy) {
                                scope.launch {
                                    onBusy(true); onError(null)
                                    val restId = restaurant?.id
                                    if (restId == null) { onError("Restaurant profile is missing"); onBusy(false); return@launch }
                                    val uploaded = onUploadMenuImage()
                                    if (uploaded.isFailure) { onError(uploaded.exceptionOrNull()?.message); onBusy(false); return@launch }
                                    val saved = repository.upsertMenuItem(mapOf(
                                        "restaurant_id" to restId, "branch_id" to branch?.id, "category_id" to categoryId.ifBlank { null },
                                        "item_name" to itemName.trim(), "price" to itemPrice.toDouble(), "food_type" to foodType,
                                        "image_object_key" to uploaded.getOrNull(), "is_available" to true, "is_active" to true
                                    ))
                                    if (saved.isSuccess) { onItemName(""); onItemPrice(""); onClearMenuImage(); reload() }
                                    else onError(saved.exceptionOrNull()?.message)
                                    onBusy(false)
                                }
                            }
                            Text("Photos upload privately to Cloudflare R2.", color = WorkspaceMuted, fontSize = 9.sp)
                        }
                    }
                    "wallet" -> WorkspaceScroll {
                        WorkspaceHero("Restaurant settlement", "Wallet & payouts", "Review your restaurant's settlement balance and ledger entries.", "💰")
                        WorkspaceCard {
                            Text("Available settlement balance", color = WorkspaceMuted, fontSize = 10.sp)
                            Text("₹$settlementBalance", color = WorkspaceText, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Settlement is based on verified order and adjustment entries.", color = WorkspaceMuted, fontSize = 10.sp)
                        }
                        WorkspaceSection("Settlement activity")
                        if (walletLoading) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = WorkspaceGold) }
                        else if (ledger?.length() == 0 || ledger == null) WorkspaceMessage("No settlement entries yet", "Food sales, platform commission and settlements will appear here.", "📒")
                        else {
                            val entries = ledger ?: JSONArray()
                            for (i in 0 until entries.length()) {
                                val entry = entries.optJSONObject(i) ?: continue
                                val amount = entry.optString("amount_delta", "0").toDoubleOrNull() ?: 0.0
                                WorkspaceCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(entry.optString("description").ifBlank { entry.optString("entry_type").replace('_', ' ') }, color = WorkspaceText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(entry.optString("created_at").replace('T', ' ').take(16), color = WorkspaceMuted, fontSize = 9.sp)
                                        }
                                        Text("${if (amount >= 0) "+" else "−"}₹${String.format(Locale.US, "%.2f", kotlin.math.abs(amount))}", color = if (amount >= 0) WorkspaceMint else WorkspaceRed, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                                    }
                                    Text("Balance after · ₹${entry.optString("balance_after", "0")}", color = WorkspaceMuted, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                    else -> WorkspaceScroll {
                        WorkspaceHero("Your restaurant identity", "Profile & outlet", "Verified business information and current branch status.", "🏬", artRes = R.drawable.partner_art_restaurant)
                        WorkspaceCard {
                            Text(restaurant?.restaurantName ?: "Restaurant Partner", color = WorkspaceText, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                            WorkspaceProfileRow("Onboarding", restaurant?.onboardingStatus?.uppercase() ?: "—")
                            WorkspaceProfileRow("Business status", if (restaurant?.isActive == true) "ACTIVE" else "INACTIVE")
                            WorkspaceProfileRow("Branch", branch?.branchName ?: "Primary branch")
                            WorkspaceProfileRow("Phone", restaurant?.supportPhone ?: "—")
                            WorkspaceProfileRow("Address", branch?.address ?: "—")
                            WorkspaceProfileRow("City", listOfNotNull(branch?.city, branch?.state).joinToString(", ").ifBlank { "—" })
                            WorkspaceProfileRow("Restaurant ID", restaurant?.id?.take(8)?.uppercase() ?: "—")
                        }
                        WorkspaceMessage("Outlet controls", "Keep your branch hours and availability accurate. Customers can only place orders while an approved branch is open.", "🔐")
                        PremiumPrimaryButton("Switch partner category", onClick = onBack)
                    }
                }
            }
            val navItems = if (tab == "profile") listOf(
                WorkspaceNavItem("home", "Home", Icons.Default.Home), WorkspaceNavItem("orders", "Orders", Icons.Default.ReceiptLong),
                WorkspaceNavItem("menu", "Menu", Icons.Default.RestaurantMenu), WorkspaceNavItem("wallet", "Wallet", Icons.Default.AccountBalanceWallet),
                WorkspaceNavItem("profile", "Profile", Icons.Default.Person)
            ) else listOf(
                WorkspaceNavItem("home", "Home", Icons.Default.Home), WorkspaceNavItem("orders", "Orders", Icons.Default.ReceiptLong),
                WorkspaceNavItem("menu", "Menu", Icons.Default.RestaurantMenu), WorkspaceNavItem("wallet", "Wallet", Icons.Default.AccountBalanceWallet),
                WorkspaceNavItem("profile", "Profile", Icons.Default.Person)
            )
            PremiumWorkspaceNav(items = navItems, selected = tab, onSelect = { tab = it; localError = null })
        }
    }
}
