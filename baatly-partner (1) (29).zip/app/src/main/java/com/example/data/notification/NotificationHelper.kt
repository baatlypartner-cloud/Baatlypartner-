package com.example.data.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import org.json.JSONObject

object NotificationHelper {
    private const val TAG = "NotificationHelper"
    const val CHANNEL_ID = "baatly_notifications"
    const val CHANNEL_NAME = "Baatly Notifications"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val existingChannel = notificationManager.getNotificationChannel(CHANNEL_ID)
            if (existingChannel == null) {
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                    .build()

                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Baatly Partner notifications for chats, calls, and updates"
                    enableLights(true)
                    enableVibration(true)
                    setSound(soundUri, audioAttributes)
                    setShowBadge(true)
                }
                notificationManager.createNotificationChannel(channel)
                Log.d(TAG, "Notification channel created: $CHANNEL_ID")
            }
        }
    }

    fun showNotification(
        context: Context,
        data: Map<String, String>,
        notificationTitle: String?,
        notificationBody: String?
    ) {
        createNotificationChannel(context)

        // Parse fields
        val type = data["notification_type"] ?: data["type"] ?: data["event_type"] ?: "admin"
        val conversationId = data["conversation_id"] ?: data["conversationId"] ?: data["conv_id"]
        val callId = data["call_id"] ?: data["callId"]
        val senderId = data["sender_id"] ?: data["senderId"] ?: data["caller_id"] ?: ""
        var senderName = data["sender_name"] ?: data["caller_name"] ?: ""
        val messageText = data["message_text"] ?: data["message"] ?: data["body"]
        val giftId = data["gift_id"] ?: data["giftId"]
        val notificationId = data["notification_id"] ?: data["id"]

        // Also check if raw payload json exists inside "data"
        val rawDataStr = data["data"]
        if (!rawDataStr.isNullOrBlank()) {
            try {
                val json = JSONObject(rawDataStr)
                if (senderName.isBlank()) senderName = json.optString("sender_name", json.optString("caller_name"))
            } catch (_: Exception) {}
        }

        val displayName = if (senderName.isNotBlank() && !senderName.contains("-") && senderName.length < 30) {
            senderName
        } else {
            "Baatly User"
        }

        // Foreground suppression check
        if (type == "chat_message" || type == "message") {
            if (!conversationId.isNullOrBlank() && NotificationRouter.currentVisibleConversationId == conversationId) {
                Log.d(TAG, "Suppressing chat notification because conversation $conversationId is currently open")
                return
            }
        }

        if (type == "incoming_call" || type == "call") {
            if (!callId.isNullOrBlank() && NotificationRouter.currentVisibleCallId == callId) {
                Log.d(TAG, "Suppressing call notification because call $callId is currently active")
                return
            }
        }

        // Resolve Title and Body
        val (finalTitle, finalBody) = when (type.lowercase().trim()) {
            "chat_message", "message", "chat" -> {
                val title = notificationTitle?.takeIf { it.isNotBlank() } ?: "New message from $displayName"
                val body = notificationBody?.takeIf { it.isNotBlank() }
                    ?: messageText?.takeIf { it.isNotBlank() }
                    ?: "You have a new message."
                title to body
            }
            "incoming_call", "call" -> {
                val title = notificationTitle?.takeIf { it.isNotBlank() } ?: "Incoming call from $displayName"
                val body = notificationBody?.takeIf { it.isNotBlank() } ?: "$displayName is calling you."
                title to body
            }
            "gift_received", "gift" -> {
                val title = notificationTitle?.takeIf { it.isNotBlank() } ?: "You received a gift"
                val body = notificationBody?.takeIf { it.isNotBlank() } ?: "$displayName sent you a gift."
                title to body
            }
            "admin", "system", "announcement" -> {
                val title = notificationTitle?.takeIf { it.isNotBlank() } ?: "Baatly Partner"
                val body = notificationBody?.takeIf { it.isNotBlank() } ?: messageText ?: "You have a new update."
                title to body
            }
            else -> {
                return
            }
        }

        // Create deep-link Intent to launch / resume MainActivity
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("notification_type", type)
            if (!conversationId.isNullOrBlank()) putExtra("conversation_id", conversationId)
            if (!callId.isNullOrBlank()) putExtra("call_id", callId)
            if (senderId.isNotBlank()) putExtra("sender_id", senderId)
            putExtra("sender_name", displayName)
            if (!giftId.isNullOrBlank()) putExtra("gift_id", giftId)
            if (!notificationId.isNullOrBlank()) putExtra("notification_id", notificationId)
            // Copy all additional payload items
            data.forEach { (k, v) ->
                putExtra(k, v)
            }
        }

        val notifId = when {
            !callId.isNullOrBlank() -> callId.hashCode()
            !conversationId.isNullOrBlank() -> conversationId.hashCode()
            !notificationId.isNullOrBlank() -> notificationId.hashCode()
            else -> (System.currentTimeMillis() % 100000).toInt()
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(
            if (type == "incoming_call" || type == "call") RingtoneManager.TYPE_RINGTONE else RingtoneManager.TYPE_NOTIFICATION
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(finalTitle)
            .setContentText(finalBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(finalBody))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (type == "incoming_call" || type == "call") {
            builder.setCategory(NotificationCompat.CATEGORY_CALL)
            builder.setOngoing(false)
        } else if (type == "chat_message" || type == "message") {
            builder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
        } else {
            builder.setCategory(NotificationCompat.CATEGORY_EVENT)
        }

        try {
            val notificationManagerCompat = NotificationManagerCompat.from(context)
            if (notificationManagerCompat.areNotificationsEnabled()) {
                notificationManagerCompat.notify(notifId, builder.build())
                Log.d(TAG, "Notification posted successfully: id=$notifId title=$finalTitle")
            } else {
                Log.w(TAG, "Notifications are disabled on this device")
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "POST_NOTIFICATIONS permission not granted: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to post notification", e)
        }
    }
}
