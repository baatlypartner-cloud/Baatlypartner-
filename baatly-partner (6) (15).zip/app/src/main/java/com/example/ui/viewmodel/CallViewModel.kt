package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BaatlyApp
import com.example.data.agora.AgoraCallManager
import com.example.data.agora.AgoraCallState
import com.example.data.agora.RemoteVideoState
import com.example.data.local.SessionManager
import com.example.data.models.CallModel
import com.example.data.repository.CallRepository
import com.example.data.repository.PartnerRepository
import com.example.service.BaatlyPartnerCallForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

sealed class ActiveCallUiStatus {
    object Idle : ActiveCallUiStatus()
    data class Incoming(val call: CallModel) : ActiveCallUiStatus()
    data class Connecting(val call: CallModel) : ActiveCallUiStatus()
    data class Connected(
        val call: CallModel,
        val durationSeconds: Int = 0,
        val elapsedSeconds: Int = 0,
        val isMuted: Boolean = false,
        val isSpeakerOn: Boolean = true,
        val maxDurationSeconds: Int? = null
    ) : ActiveCallUiStatus() {
        val remainingSeconds: Int get() = durationSeconds
    }
    data class Ended(val call: CallModel, val durationSeconds: Int, val earning: Double) : ActiveCallUiStatus()
    data class Error(val message: String) : ActiveCallUiStatus()
}

class CallViewModel(
    private val callRepository: CallRepository,
    private val partnerRepository: PartnerRepository,
    private val agoraCallManager: AgoraCallManager,
    private val sessionManager: SessionManager,
    private val context: Context = BaatlyApp.instance.applicationContext
) : ViewModel() {

    private val TAG = "CallViewModel"

    private val _callUiStatus = MutableStateFlow<ActiveCallUiStatus>(ActiveCallUiStatus.Idle)
    val callUiStatus: StateFlow<ActiveCallUiStatus> = _callUiStatus.asStateFlow()

    private val _isCallScreenMinimized = MutableStateFlow(false)
    val isCallScreenMinimized: StateFlow<Boolean> = _isCallScreenMinimized.asStateFlow()

    private val _recentCalls = MutableStateFlow<List<CallModel>>(emptyList())
    val recentCalls: StateFlow<List<CallModel>> = _recentCalls.asStateFlow()

    private val _isLoadingRecent = MutableStateFlow(false)
    val isLoadingRecent: StateFlow<Boolean> = _isLoadingRecent.asStateFlow()

    private var durationTimerJob: Job? = null
    private var realtimeSubscription: com.example.data.api.RealtimeSubscription? = null
    private val callRealtimeManager = com.example.data.api.CallRealtimeManager(sessionManager)
    private var currentActiveCall: CallModel? = null
    private var activeCallDurationSeconds = 0
    private val isAcceptingCall = AtomicBoolean(false)
    private val isTerminatingCall = AtomicBoolean(false)

    init {
        loadRecentCalls()
    }

    fun minimizeCallScreen() {
        _isCallScreenMinimized.value = true
    }

    fun restoreCallScreen() {
        _isCallScreenMinimized.value = false
    }

    fun loadRecentCalls() {
        viewModelScope.launch {
            _isLoadingRecent.value = true
            val res = callRepository.getRecentCalls()
            if (res.isSuccess) {
                _recentCalls.value = res.getOrNull() ?: emptyList()
            }
            _isLoadingRecent.value = false
        }
    }

    fun acceptIncomingCall(call: CallModel) {
        Log.d(TAG, "ACCEPT_CLICKED: callId=${call.id}")
        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
        if (!isAcceptingCall.compareAndSet(false, true)) {
            Log.w(TAG, "ACCEPT_CLICKED: ignored duplicate concurrent accept action")
            return
        }

        viewModelScope.launch {
            try {
                // 1. Fetch latest call row from backend BEFORE accepting
                Log.d(TAG, "CALL_STATE: checking current status for callId=${call.id}")
                val freshCallRes = callRepository.getCallById(call.id)
                var latestCall = freshCallRes.getOrNull() ?: call

                val terminalStatuses = listOf("missed", "rejected", "cancelled", "completed", "ended")
                if (latestCall.status in terminalStatuses || latestCall.endedAt != null) {
                    Log.w(TAG, "CALL_STATE: call already cancelled or ended (${latestCall.status}). Aborting accept safely.")
                    com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                    com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
                    _callUiStatus.value = ActiveCallUiStatus.Error("Call was cancelled by user.")
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                currentActiveCall = latestCall
                isTerminatingCall.set(false)
                _callUiStatus.value = ActiveCallUiStatus.Connecting(latestCall)
                _isCallScreenMinimized.value = false

                // 2. If call is in 'requested' state, transition to 'ringing' first
                if (latestCall.status == "requested") {
                    val ringRes = callRepository.markCallRinging(call.id)
                    if (ringRes.isFailure) {
                        val refreshed = callRepository.getCallById(call.id).getOrNull()
                        if (refreshed?.status in terminalStatuses || refreshed?.endedAt != null) {
                            Log.w(TAG, "Call was cancelled during markCallRinging. Aborting safely.")
                            com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                            com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
                            _callUiStatus.value = ActiveCallUiStatus.Error("Call was cancelled by user.")
                            currentActiveCall = null
                            isAcceptingCall.set(false)
                            return@launch
                        }
                        val err = "Could not update call state to ringing: ${ringRes.exceptionOrNull()?.message}"
                        Log.e(TAG, "CALL_STATE_FAILED: $err")
                        _callUiStatus.value = ActiveCallUiStatus.Error(err)
                        currentActiveCall = null
                        isAcceptingCall.set(false)
                        return@launch
                    }
                }

                // 3. Only if status is valid, call acceptCall(call_id)
                val acceptRes = callRepository.acceptCall(call.id)
                if (acceptRes.isFailure) {
                    val refreshed = callRepository.getCallById(call.id).getOrNull()
                    if (refreshed?.status in terminalStatuses || refreshed?.endedAt != null) {
                        Log.w(TAG, "Call was cancelled while partner accepted. Aborting safely.")
                        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
                        _callUiStatus.value = ActiveCallUiStatus.Error("Call was cancelled by user.")
                        currentActiveCall = null
                        isAcceptingCall.set(false)
                        return@launch
                    }
                    val err = acceptRes.exceptionOrNull()?.message ?: "Failed to accept call"
                    Log.e(TAG, "CALL_STATE_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }
                Log.d(TAG, "CALL_STATE: call accepted on server")

                // Double check status after accept to ensure caller didn't cancel simultaneously
                val verifyRes = callRepository.getCallById(call.id)
                if (verifyRes.isSuccess && verifyRes.getOrNull() != null) {
                    latestCall = verifyRes.getOrNull()!!
                    if (latestCall.status in terminalStatuses || latestCall.endedAt != null) {
                        Log.w(TAG, "Call became terminal right after accept (${latestCall.status}). Aborting safely.")
                        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
                        _callUiStatus.value = ActiveCallUiStatus.Error("Call was cancelled by user.")
                        currentActiveCall = null
                        isAcceptingCall.set(false)
                        return@launch
                    }
                }

                // 4. Read calls.agora_channel_id from Supabase call record
                if (latestCall.agoraChannelId.isNullOrBlank()) {
                    val refreshedRes = callRepository.getCallById(call.id)
                    if (refreshedRes.isSuccess && refreshedRes.getOrNull() != null) {
                        latestCall = refreshedRes.getOrNull()!!
                    }
                }

                val agoraChannelId = latestCall.agoraChannelId?.trim().orEmpty()
                if (agoraChannelId.isBlank()) {
                    val err = "Agora channel ID missing on call record (calls.agora_channel_id is empty)"
                    Log.e(TAG, "AGORA_ERROR: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val channelName = agoraChannelId
                Log.d(TAG, "TOKEN_REQUEST_START: channelName=$channelName")
                val tokenRes = callRepository.fetchAgoraToken(channelName)
                if (tokenRes.isFailure) {
                    val err = tokenRes.exceptionOrNull()?.message ?: "Failed to get Agora token"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val agoraData = tokenRes.getOrNull()
                if (agoraData == null) {
                    val err = "Empty response received from Agora token service"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }
                Log.d(TAG, "TOKEN_REQUEST_SUCCESS")

                val tokenToUse = agoraData.resolvedToken
                if (tokenToUse.isBlank()) {
                    val err = "Received empty Agora token from token service"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val rawAppId = if (!agoraData.appId.isNullOrBlank()) agoraData.appId else sessionManager.getAgoraAppId()
                val appId = rawAppId.trim()
                val isVideo = (latestCall.callType?.lowercase() == "video" || call.callType?.lowercase() == "video")

                if (isVideo) {
                    val hasCamera = androidx.core.content.ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.CAMERA
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasCamera) {
                        val err = "Camera permission (CAMERA) is required for video calls. Permission not granted."
                        Log.e(TAG, "CAMERA_PERMISSION_DENIED: $err")
                        _callUiStatus.value = ActiveCallUiStatus.Error(err)
                        currentActiveCall = null
                        isAcceptingCall.set(false)
                        return@launch
                    }
                }

                // 5. Initialize Agora Engine
                val initOk = agoraCallManager.initialize(appId, isVideo = isVideo)
                if (!initOk) {
                    val errorMsg = agoraCallManager.lastErrorMessage ?: "Failed to initialize Agora RTC engine"
                    Log.e(TAG, "AGORA_ERROR: initialize failed: $errorMsg")
                    _callUiStatus.value = ActiveCallUiStatus.Error(errorMsg)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                // 6. Join Agora Channel using exact calls.agora_channel_id and consistent token UID
                val uid = agoraData.uid?.toInt() ?: 0
                Log.d(TAG, "UID_CONSISTENCY_CHECK: tokenUid=${agoraData.uid}, joinUid=$uid, channelName=$channelName")

                val joinOk = agoraCallManager.joinChannel(token = tokenToUse, channelName = channelName, uid = uid, isVideo = isVideo)
                if (!joinOk) {
                    val errorMsg = agoraCallManager.lastErrorMessage ?: "Failed to join voice channel"
                    Log.e(TAG, "AGORA_ERROR: joinChannel failed to initiate: $errorMsg")
                    _callUiStatus.value = ActiveCallUiStatus.Error(errorMsg)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                // 7. Wait for ON_JOIN_CHANNEL_SUCCESS callback before marking connected
                val joinState = withTimeoutOrNull(15000) {
                    agoraCallManager.callState.first { it is AgoraCallState.Joined || it is AgoraCallState.Error }
                }

                if (joinState == null) {
                    val err = "Timed out waiting for Agora voice connection confirmation"
                    Log.e(TAG, "AGORA_ERROR: $err")
                    agoraCallManager.leaveChannel()
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                if (joinState is AgoraCallState.Error) {
                    val err = joinState.message
                    Log.e(TAG, "AGORA_ERROR: Join failed with state error: $err")
                    agoraCallManager.leaveChannel()
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                Log.i(TAG, "[AGORA_JOIN_SUCCESS] ON_JOIN_CHANNEL_SUCCESS: voice channel connected")

                // 8. Only mark backend connected AFTER Agora join succeeds
                val markRes = callRepository.markCallConnected(call.id)
                if (markRes.isFailure) {
                    val err = "Failed to mark call connected on server: ${markRes.exceptionOrNull()?.message}"
                    Log.e(TAG, "CALL_STATE_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    try {
                        agoraCallManager.leaveChannel()
                    } catch (_: Throwable) {}
                    return@launch
                }

                // 9. Fetch the latest refreshed call row from server with authoritative connected_at and max_duration_seconds
                var refreshedCallRes = callRepository.getCallById(call.id)
                var connectedCall = refreshedCallRes.getOrNull()

                if (connectedCall == null || connectedCall.connectedAt.isNullOrBlank() || connectedCall.maxDurationSeconds == null || (connectedCall.maxDurationSeconds ?: 0) <= 0) {
                    // Brief retry to allow server update_call_state commit propagation
                    delay(150)
                    refreshedCallRes = callRepository.getCallById(call.id)
                    connectedCall = refreshedCallRes.getOrNull()
                }

                if (connectedCall == null) {
                    val err = "Failed to retrieve refreshed call details from server"
                    Log.e(TAG, "CALL_REFRESH_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    try {
                        agoraCallManager.leaveChannel()
                    } catch (_: Throwable) {}
                    return@launch
                }

                val maxDurationSec = connectedCall.maxDurationSeconds
                if (maxDurationSec == null || maxDurationSec <= 0) {
                    val err = "Invalid or zero call duration limit received from server (max_duration_seconds=$maxDurationSec)"
                    Log.e(TAG, "CALL_LIMIT_ERROR: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    try {
                        agoraCallManager.leaveChannel()
                    } catch (_: Throwable) {}
                    return@launch
                }

                val connectedAtStr = connectedCall.connectedAt
                val connectedAtEpochMs = parseIsoTimestampToEpochMillis(connectedAtStr ?: "")
                if (connectedAtStr.isNullOrBlank() || connectedAtEpochMs == null) {
                    val err = "Missing or unparseable connected_at timestamp from server (connected_at=$connectedAtStr)"
                    Log.e(TAG, "CALL_TIMESTAMP_ERROR: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    try {
                        agoraCallManager.leaveChannel()
                    } catch (_: Throwable) {}
                    return@launch
                }

                // Update currentActiveCall to the refreshed server CallModel
                currentActiveCall = connectedCall

                // 10. Auto turn off Call availability for Host, but keep Chat availability state untouched!
                val partnerProf = partnerRepository.getPartnerProfile().getOrNull()
                val chatState = partnerProf?.chatEnabled ?: false
                partnerRepository.updateServiceAvailability(
                    displayName = partnerProf?.partnerDisplayName,
                    isAvailable = false,
                    isOnline = chatState,
                    audioEnabled = false,
                    chatEnabled = chatState
                )

                // 11. Subscribe to Supabase Realtime for this call ID
                realtimeSubscription?.close()
                realtimeSubscription = callRealtimeManager.subscribeToCall(connectedCall.id) { status, record ->
                    Log.d(TAG, "REALTIME_CALL_UPDATE: callId=${connectedCall.id} status=$status")
                    val terminalStatuses = listOf("completed", "cancelled", "rejected", "failed", "missed", "ended")
                    val endedAt = record?.optString("ended_at", "")
                    if (status.lowercase() in terminalStatuses || !endedAt.isNullOrBlank()) {
                        handleRemoteCallTerminated(connectedCall.id, status)
                    }
                }

                // 12. Calculate initial remaining countdown and elapsed time from server connected_at timestamp
                val nowMs = System.currentTimeMillis()
                val elapsedMs = maxOf(0L, nowMs - connectedAtEpochMs)
                val elapsedSec = (elapsedMs / 1000L).toInt()
                val initialRemainingSec = maxOf(0, maxDurationSec - elapsedSec)
                activeCallDurationSeconds = elapsedSec

                Log.d(TAG, "CONNECTED_CALL_INITIALIZED: callId=${connectedCall.id} maxDurationSec=$maxDurationSec elapsedSec=$elapsedSec remainingSec=$initialRemainingSec")

                _callUiStatus.value = ActiveCallUiStatus.Connected(
                    call = connectedCall,
                    durationSeconds = initialRemainingSec,
                    elapsedSeconds = elapsedSec,
                    isMuted = false,
                    isSpeakerOn = true,
                    maxDurationSeconds = maxDurationSec
                )

                // Start dedicated foreground service with MICROPHONE type for active voice call
                val callerDisplayName = connectedCall.userProfile?.displayName
                BaatlyPartnerCallForegroundService.start(
                    context = context,
                    callId = connectedCall.id,
                    callerName = callerDisplayName
                )

                startCountdownTimer(connectedCall, connectedAtEpochMs, maxDurationSec)
            } catch (t: Throwable) {
                Log.e(TAG, "CRITICAL_EXCEPTION during call accept flow: ${t.javaClass.name}: ${t.message}", t)
                BaatlyPartnerCallForegroundService.stop(context)
                val err = "Call connection failure: ${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                _callUiStatus.value = ActiveCallUiStatus.Error(err)
                currentActiveCall = null
                realtimeSubscription?.close()
                realtimeSubscription = null
                try {
                    agoraCallManager.release()
                } catch (_: Throwable) {}
            } finally {
                isAcceptingCall.set(false)
            }
        }
    }

    fun rejectIncomingCall(call: CallModel) {
        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, call.id)
        realtimeSubscription?.close()
        realtimeSubscription = null
        viewModelScope.launch {
            callRepository.rejectCall(call.id)
            _callUiStatus.value = ActiveCallUiStatus.Idle
            currentActiveCall = null
        }
    }

    private fun handleRemoteCallTerminated(callId: String, status: String) {
        if (!isTerminatingCall.compareAndSet(false, true)) {
            return
        }
        Log.d(TAG, "HANDLE_REMOTE_CALL_TERMINATED: callId=$callId terminalStatus=$status")
        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(context, callId)

        // 1. Cancel local duration timer and realtime subscription
        durationTimerJob?.cancel()
        realtimeSubscription?.close()
        realtimeSubscription = null

        // Stop foreground call service immediately
        BaatlyPartnerCallForegroundService.stop(context)

        // If call was cancelled or missed before becoming connected, abort safely without settling
        val previousStatus = _callUiStatus.value
        if (previousStatus is ActiveCallUiStatus.Connecting || previousStatus is ActiveCallUiStatus.Incoming) {
            Log.i(TAG, "Call was terminated before connecting ($status). Resetting to Idle.")
            try {
                agoraCallManager.leaveChannel()
            } catch (_: Throwable) {}
            _callUiStatus.value = ActiveCallUiStatus.Idle
            currentActiveCall = null
            isTerminatingCall.set(false)
            return
        }

        // 2. Leave Agora RTC channel immediately
        try {
            agoraCallManager.leaveChannel()
        } catch (e: Exception) {
            Log.w(TAG, "Error leaving Agora channel: ${e.message}")
        }

        viewModelScope.launch {
            val call = currentActiveCall
            // 3. Settle and get final authoritative duration & earnings from backend
            val settleRes = callRepository.endCall(callId)
            val settlement = settleRes.getOrNull()

            val finalDuration = settlement?.durationSeconds
                ?: call?.durationSeconds
                ?: activeCallDurationSeconds
            val finalEarning = settlement?.effectivePartnerEarning
                ?: call?.effectivePartnerEarning
                ?: 0.0

            val endedCall = call?.copy(
                status = status,
                durationSeconds = finalDuration,
                partnerEarningRupees = finalEarning
            ) ?: CallModel(
                id = callId,
                userId = "",
                partnerId = sessionManager.authUuid.value ?: "",
                status = status,
                durationSeconds = finalDuration,
                partnerEarningRupees = finalEarning
            )

            // 4. Update UI to Ended state (shows summary dialog)
            _callUiStatus.value = ActiveCallUiStatus.Ended(
                call = endedCall,
                durationSeconds = finalDuration,
                earning = finalEarning
            )
            currentActiveCall = null
            loadRecentCalls()

            // 5. Refresh partner availability state
            partnerRepository.getPartnerProfile()
        }
    }

    private fun parseIsoTimestampToEpochMillis(isoString: String): Long? {
        if (isoString.isBlank()) return null
        val clean = isoString.trim().replace(" ", "T")

        // 1. Try Java 8 / ThreeTen / modern OffsetDateTime and Instant
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                try {
                    return java.time.OffsetDateTime.parse(clean).toInstant().toEpochMilli()
                } catch (_: Exception) {}
                try {
                    return java.time.Instant.parse(clean).toEpochMilli()
                } catch (_: Exception) {}
            }
        } catch (_: Throwable) {}

        // 2. Try SimpleDateFormat with multiple ISO 8601 patterns
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSSSSS",
            "yyyy-MM-dd'T'HH:mm:ss.SSS",
            "yyyy-MM-dd'T'HH:mm:ss"
        )

        for (pattern in patterns) {
            try {
                val sdf = java.text.SimpleDateFormat(pattern, java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                val date = sdf.parse(clean)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }

        // 3. Fallback: extract substring(0, 19)
        try {
            if (clean.length >= 19) {
                val sub = clean.substring(0, 19)
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                return sdf.parse(sub)?.time
            }
        } catch (_: Exception) {}

        return null
    }

    private fun startCountdownTimer(call: CallModel, connectedAtEpochMs: Long, maxDurationSeconds: Int) {
        durationTimerJob?.cancel()
        durationTimerJob = viewModelScope.launch {
            var checkCounter = 0
            while (isActive) {
                delay(1000)
                checkCounter++

                // Recompute exact elapsed and remaining seconds from the authoritative server connected_at timestamp
                val nowMs = System.currentTimeMillis()
                val elapsedMs = maxOf(0L, nowMs - connectedAtEpochMs)
                val currentElapsedSeconds = (elapsedMs / 1000L).toInt()
                activeCallDurationSeconds = currentElapsedSeconds
                val remainingSeconds = maxOf(0, maxDurationSeconds - currentElapsedSeconds)

                val current = _callUiStatus.value
                if (current is ActiveCallUiStatus.Connected) {
                    _callUiStatus.value = current.copy(
                        durationSeconds = remainingSeconds,
                        elapsedSeconds = currentElapsedSeconds
                    )

                    // Companion check every 2 seconds to instantly detect if user ended call
                    if (checkCounter % 2 == 0) {
                        launch {
                            val checkRes = callRepository.getCallById(call.id)
                            if (checkRes.isSuccess) {
                                val latest = checkRes.getOrNull()
                                if (latest != null) {
                                    val isTerminal = latest.status in listOf("completed", "cancelled", "rejected", "failed", "missed", "ended") || latest.endedAt != null
                                    if (isTerminal) {
                                        Log.d(TAG, "COMPANION_CHECK: Detected backend terminal status '${latest.status}' for callId=${call.id}")
                                        handleRemoteCallTerminated(call.id, latest.status)
                                    }
                                }
                            }
                        }
                    }

                    // Periodic backend balance check every 10 seconds
                    if (currentElapsedSeconds % 10 == 0 && currentElapsedSeconds > 0) {
                        val enforceRes = callRepository.enforceCallBalanceLimit(call.id)
                        if (enforceRes.isSuccess && enforceRes.getOrNull()?.shouldDisconnect == true) {
                            endActiveCall("User balance limit reached")
                            break
                        }
                    }

                    // Check if remaining countdown reached 00:00 or elapsed exceeded max duration
                    if (remainingSeconds <= 0 || currentElapsedSeconds >= maxDurationSeconds) {
                        Log.d(TAG, "COUNTDOWN_EXPIRED: callId=${call.id} maxDurationSeconds=$maxDurationSeconds elapsed=$currentElapsedSeconds")
                        endActiveCall("User balance limit reached")
                        break
                    }
                } else {
                    break
                }
            }
        }
    }

    fun toggleMute() {
        agoraCallManager.toggleMute()
        val current = _callUiStatus.value
        if (current is ActiveCallUiStatus.Connected) {
            _callUiStatus.value = current.copy(isMuted = agoraCallManager.isMuted.value)
        }
    }

    fun toggleSpeakerphone() {
        agoraCallManager.toggleSpeakerphone()
        val current = _callUiStatus.value
        if (current is ActiveCallUiStatus.Connected) {
            _callUiStatus.value = current.copy(isSpeakerOn = agoraCallManager.isSpeakerphoneOn.value)
        }
    }

    val isVideoCall: StateFlow<Boolean> = agoraCallManager.isVideoCall
    val remoteVideoUid: StateFlow<Int?> = agoraCallManager.remoteVideoUid
    val remoteVideoFirstFrameRendered: StateFlow<Boolean> = agoraCallManager.remoteVideoFirstFrameRendered
    val remoteVideoState: StateFlow<RemoteVideoState> = agoraCallManager.remoteVideoState
    val isCameraMuted: StateFlow<Boolean> = agoraCallManager.isCameraMuted

    fun attachRemoteSurface(surfaceView: android.view.SurfaceView) {
        agoraCallManager.attachRemoteSurface(surfaceView)
    }

    fun detachRemoteSurface() {
        agoraCallManager.detachRemoteSurface()
    }

    fun setupLocalVideo(surfaceView: android.view.SurfaceView) {
        agoraCallManager.setupLocalVideo(surfaceView)
    }

    fun setupRemoteVideo(surfaceView: android.view.SurfaceView, uid: Int) {
        agoraCallManager.setupRemoteVideo(surfaceView, uid)
    }

    fun switchCamera() {
        agoraCallManager.switchCamera()
    }

    fun toggleCameraMute() {
        agoraCallManager.toggleCameraMute()
    }

    fun endActiveCall(reason: String? = null) {
        if (!isTerminatingCall.compareAndSet(false, true)) {
            return
        }
        durationTimerJob?.cancel()
        realtimeSubscription?.close()
        realtimeSubscription = null

        // Stop foreground call service immediately
        BaatlyPartnerCallForegroundService.stop(context)

        val call = currentActiveCall
        if (call == null) {
            _callUiStatus.value = ActiveCallUiStatus.Idle
            return
        }

        viewModelScope.launch {
            try {
                agoraCallManager.leaveChannel()
            } catch (e: Exception) {
                Log.w(TAG, "Error leaving Agora channel: ${e.message}")
            }
            // Backend-authoritative settlement (single idempotent execution)
            val settleRes = callRepository.endCall(call.id)
            val settlement = settleRes.getOrNull()

            val finalDuration = settlement?.durationSeconds ?: activeCallDurationSeconds
            val finalEarning = settlement?.effectivePartnerEarningRupees ?: settlement?.partnerEarningRupees ?: 0.0

            _callUiStatus.value = ActiveCallUiStatus.Ended(
                call = call,
                durationSeconds = finalDuration,
                earning = finalEarning
            )
            currentActiveCall = null
            loadRecentCalls()
            partnerRepository.getPartnerProfile()
        }
    }

    fun resetCallState() {
        BaatlyPartnerCallForegroundService.stop(context)
        realtimeSubscription?.close()
        realtimeSubscription = null
        durationTimerJob?.cancel()
        _callUiStatus.value = ActiveCallUiStatus.Idle
        currentActiveCall = null
        isTerminatingCall.set(false)
    }

    override fun onCleared() {
        super.onCleared()
        BaatlyPartnerCallForegroundService.stop(context)
        durationTimerJob?.cancel()
        realtimeSubscription?.close()
        realtimeSubscription = null
        try {
            agoraCallManager.leaveChannel()
        } catch (_: Exception) {}
    }
}

class CallViewModelFactory(
    private val callRepository: CallRepository,
    private val partnerRepository: PartnerRepository,
    private val agoraCallManager: AgoraCallManager,
    private val sessionManager: SessionManager,
    private val context: Context = BaatlyApp.instance.applicationContext
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CallViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CallViewModel(callRepository, partnerRepository, agoraCallManager, sessionManager, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
