package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.ui.screens.legal.BAATLY_SAFETY_CONTACT_EMAIL
import com.example.ui.screens.legal.CHILD_SAFETY_URL
import com.example.ui.screens.legal.PRIVACY_POLICY_URL
import com.example.ui.screens.legal.PartnerChildSafetyScreen
import com.example.ui.screens.legal.PartnerPrivacyPolicyScreen
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LegalScreensTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testLegalConstants() {
        assertEquals("https://REPLACE_WITH_BAATLY_PARTNER_PRIVACY_URL", PRIVACY_POLICY_URL)
        assertEquals("https://REPLACE_WITH_BAATLY_PARTNER_CHILD_SAFETY_URL", CHILD_SAFETY_URL)
        assertEquals("baatly72@gmail.com", BAATLY_SAFETY_CONTACT_EMAIL)
    }

    @Test
    fun testPartnerPrivacyPolicyScreenRenders() {
        var backClicked = false
        composeTestRule.setContent {
            PartnerPrivacyPolicyScreen(onBack = { backClicked = true })
        }

        composeTestRule.onNodeWithText("Privacy Policy").assertExists()
        composeTestRule.onNodeWithText("Baatly Partner Privacy Policy").assertExists()
        composeTestRule.onNodeWithText("1. About this Privacy Policy").assertExists()
        composeTestRule.onNodeWithText("2. Information We Collect").assertExists()
        composeTestRule.onNodeWithText("3. How We Use Information").assertExists()
        composeTestRule.onNodeWithText("4. Third-Party Service Providers").assertExists()
        composeTestRule.onNodeWithText("5. Data Storage and Security").assertExists()
        composeTestRule.onNodeWithText("6. Data Sharing").assertExists()
        composeTestRule.onNodeWithText("7. Data Retention").assertExists()
        composeTestRule.onNodeWithText("8. Account and Data Deletion").assertExists()
        composeTestRule.onNodeWithText("9. Children's Safety / Age Safety").assertExists()
        composeTestRule.onNodeWithText("10. User Privacy Rights").assertExists()
        composeTestRule.onNodeWithText("11. Policy Changes").assertExists()
        composeTestRule.onNodeWithText("12. Contact Us").assertExists()
        composeTestRule.onNodeWithText("Baatly Privacy & Child Safety Contact").assertExists()

        // Test back button
        composeTestRule.onNodeWithTag("privacy_policy_back_button").assertExists()
        composeTestRule.onNodeWithTag("privacy_policy_back_button").performClick()
        assertTrue(backClicked)
    }

    @Test
    fun testPartnerChildSafetyScreenRenders() {
        var backClicked = false
        composeTestRule.setContent {
            PartnerChildSafetyScreen(onBack = { backClicked = true })
        }

        composeTestRule.onNodeWithText("Child Safety Standards").assertExists()
        composeTestRule.onNodeWithText("Baatly Partner Child Safety Standards").assertExists()
        composeTestRule.onNodeWithText("1. Zero Tolerance for CSAE and CSAM").assertExists()
        composeTestRule.onNodeWithText("2. Prohibited Conduct for Partners").assertExists()
        composeTestRule.onNodeWithText("3. Safety & Enforcement Actions").assertExists()
        composeTestRule.onNodeWithText("4. Reporting Child Safety Concerns").assertExists()
        composeTestRule.onNodeWithText("5. Cooperation With Authorities").assertExists()
        composeTestRule.onNodeWithText("6. Scope and Applicability").assertExists()
        composeTestRule.onNodeWithText("CRITICAL INSTRUCTION FOR REPORTS").assertExists()

        // Test back button
        composeTestRule.onNodeWithTag("child_safety_back_button").assertExists()
        composeTestRule.onNodeWithTag("child_safety_back_button").performClick()
        assertTrue(backClicked)
    }
}
