package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import com.example.BaatlyApp
import com.example.data.repository.HostFullStatus
import com.example.ui.screens.auth.HostIntroScreen
import com.example.ui.screens.auth.SignInScreen
import com.example.ui.screens.auth.SignUpScreen
import com.example.ui.screens.call.ActiveCallScreen
import com.example.ui.screens.call.IncomingCallDialog
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.chat.ChatListScreen
import com.example.ui.screens.chat.BaatlySupportChatScreen
import com.example.ui.screens.home.CallKamaiScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.MallScreen
import com.example.ui.screens.home.SkillsScreen
import com.example.ui.screens.home.TrainingVideosScreen
import com.example.ui.screens.onboarding.ApplicationStatusScreen
import com.example.ui.screens.onboarding.VoiceVerificationScreen
import com.example.ui.screens.performance.DailyPerformanceScreen
import com.example.ui.screens.performance.PerformanceHistoryScreen
import com.example.ui.screens.performance.WeeklyPerformanceScreen
import com.example.ui.screens.profile.BlockedUsersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.recent.RecentCallsScreen
import com.example.ui.screens.rules.FrameNiyamScreen
import com.example.ui.screens.rules.StrikeNiyamScreen
import com.example.ui.screens.legal.PartnerPrivacyPolicyScreen
import com.example.ui.screens.legal.PartnerChildSafetyScreen
import com.example.ui.screens.social.SocialScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.*

enum class BottomTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    CHATS("Chat", Icons.Default.Chat),
    SOCIAL("Social", Icons.Default.Diversity1),
    RECENT("Recent", Icons.Default.History),
    PROFILE("Profile", Icons.Default.Person)
}

@Composable
fun MainApp(app: BaatlyApp) {
    val authViewModel: AuthViewModel = viewModel(
        factory = AuthViewModelFactory(app.authRepository)
    )
    val mainViewModel: MainViewModel = viewModel(
        factory = MainViewModelFactory(
            app.partnerRepository,
            app.callRepository,
            app.walletRepository,
            app.privateMediaRepository,
            app.hostPresenceManager,
            app.hostPerformanceRepository
        )
    )
    val callViewModel: CallViewModel = viewModel(
        factory = CallViewModelFactory(app.callRepository, app.partnerRepository, app.agoraCallManager, app.sessionManager)
    )
    val chatViewModel: ChatViewModel = viewModel(
        factory = ChatViewModelFactory(app.chatRepository, app.sessionManager, app.audioRecorderHelper, app.audioPlayerHelper, app.privateMediaRepository)
    )
    val socialViewModel: SocialViewModel = viewModel(
        factory = SocialViewModelFactory(app)
    )
    val walletViewModel: WalletViewModel = viewModel(
        factory = WalletViewModelFactory(app.walletRepository)
    )
    val voiceViewModel: VoiceVerificationViewModel = viewModel(
        factory = VoiceVerificationViewModelFactory(app.partnerRepository, app.audioRecorderHelper, app.audioPlayerHelper)
    )
    val performanceViewModel: PerformanceViewModel = viewModel(
        factory = PerformanceViewModelFactory(app.hostPerformanceRepository)
    )
    val partnerAiChatViewModel: PartnerAiChatViewModel = viewModel(
        factory = PartnerAiChatViewModelFactory(app.partnerAiChatRepository)
    )

    val authState by authViewModel.uiState.collectAsState()
    val mainUiData by mainViewModel.uiData.collectAsState()
    val pendingNotificationDest by com.example.data.notification.NotificationRouter.pendingDestination.collectAsState()

    var authScreenState by remember { mutableStateOf("intro") } // "intro", "signin", "signup"
    var currentTab by remember { mutableStateOf(BottomTab.HOME) }
    var currentSubRoute by remember { mutableStateOf<String?>(null) }
    var activeChatParams by remember { mutableStateOf<Triple<String, String, String>?>(null) }

    // Check incoming call from MainViewModel's poller
    val incomingCall = mainUiData.incomingCall
    val callUiStatus by callViewModel.callUiStatus.collectAsState()

    // Foreground tracking to avoid duplicate system notifications when screen is active
    val coroutineScope = rememberCoroutineScope()
    LaunchedEffect(activeChatParams) {
        com.example.data.notification.NotificationRouter.currentVisibleConversationId = activeChatParams?.first
    }
    LaunchedEffect(callUiStatus) {
        val currentCallId = when (val c = callUiStatus) {
            is ActiveCallUiStatus.Connected -> c.call.id
            is ActiveCallUiStatus.Connecting -> c.call.id
            else -> null
        }
        com.example.data.notification.NotificationRouter.currentVisibleCallId = currentCallId
    }

    // Android 13+ Notification Permission Request Launcher
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        app.sessionManager.setNotificationPermissionRequested(true)
        if (isGranted) {
            coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                app.notificationRepository.syncFcmToken(force = true)
            }
        }
    }

    // Handle Incoming Call Modal
    incomingCall?.let { call ->
        IncomingCallDialog(
            call = call,
            onAccept = {
                mainViewModel.dismissIncomingCall()
                callViewModel.acceptIncomingCall(call)
            },
            onReject = {
                mainViewModel.dismissIncomingCall()
                callViewModel.rejectIncomingCall(call)
            }
        )
    }

    // Auto-reload data and sync notifications when partner is confirmed approved
    LaunchedEffect(authState) {
        if (authState is AuthUiState.Approved) {
            mainViewModel.loadAllData()
            walletViewModel.loadWalletData()
            chatViewModel.loadConversations()
            socialViewModel.refreshAllSocialData()
            partnerAiChatViewModel.initChat(forceReload = true)

            // Request POST_NOTIFICATIONS permission on Android 13+ if not previously prompted
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                val hasPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                if (!hasPerm && !app.sessionManager.isNotificationPermissionRequested()) {
                    permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            // Sync FCM token in background
            app.notificationRepository.syncFcmToken()
        }
    }

    // Centralized Notification Tap Router
    LaunchedEffect(authState, pendingNotificationDest) {
        if (authState is AuthUiState.Approved && pendingNotificationDest != null) {
            when (val dest = com.example.data.notification.NotificationRouter.consumeDestination()) {
                is com.example.data.notification.NotificationDestination.Chat -> {
                    currentSubRoute = null
                    currentTab = BottomTab.CHATS
                    activeChatParams = Triple(dest.conversationId, dest.senderId, dest.senderName)
                }
                is com.example.data.notification.NotificationDestination.StoryReply -> {
                    currentSubRoute = null
                    currentTab = BottomTab.CHATS
                    activeChatParams = Triple(dest.conversationId, dest.senderId, dest.senderName)
                }
                is com.example.data.notification.NotificationDestination.Call -> {
                    val callRes = app.callRepository.getCallById(dest.callId)
                    if (callRes.isSuccess) {
                        val call = callRes.getOrNull()
                        if (call != null && (call.status == "calling" || call.status == "pending" || call.status == "ringing")) {
                            callViewModel.acceptIncomingCall(call)
                        } else {
                            currentSubRoute = "recent_calls"
                        }
                    }
                }
                is com.example.data.notification.NotificationDestination.Gift -> {
                    if (!dest.conversationId.isNullOrBlank() && !dest.senderId.isNullOrBlank()) {
                        currentSubRoute = null
                        currentTab = BottomTab.CHATS
                        activeChatParams = Triple(dest.conversationId, dest.senderId, dest.senderName ?: "Baatly User")
                    } else {
                        currentSubRoute = "wallet"
                    }
                }
                is com.example.data.notification.NotificationDestination.Follow -> {
                    currentSubRoute = null
                    currentTab = BottomTab.SOCIAL
                    if (!dest.followerId.isNullOrBlank()) {
                        socialViewModel.openUserProfileById(dest.followerId)
                    } else {
                        socialViewModel.navigateToHome()
                    }
                }
                is com.example.data.notification.NotificationDestination.Like -> {
                    currentSubRoute = null
                    currentTab = BottomTab.SOCIAL
                    if (dest.contentType.equals("story", ignoreCase = true) && !dest.contentId.isNullOrBlank()) {
                        socialViewModel.openStoryById(dest.contentId)
                    } else if (!dest.contentId.isNullOrBlank()) {
                        socialViewModel.openPostById(dest.contentId)
                    } else {
                        socialViewModel.navigateToHome()
                    }
                }
                is com.example.data.notification.NotificationDestination.Comment -> {
                    currentSubRoute = null
                    currentTab = BottomTab.SOCIAL
                    if (!dest.contentId.isNullOrBlank()) {
                        socialViewModel.openPostAndCommentsById(dest.contentId)
                    } else {
                        socialViewModel.navigateToHome()
                    }
                }
                is com.example.data.notification.NotificationDestination.NewPost -> {
                    currentSubRoute = null
                    currentTab = BottomTab.SOCIAL
                    if (!dest.postId.isNullOrBlank()) {
                        socialViewModel.openPostById(dest.postId)
                    } else {
                        socialViewModel.navigateToHome()
                    }
                }
                is com.example.data.notification.NotificationDestination.NewStory -> {
                    currentSubRoute = null
                    currentTab = BottomTab.SOCIAL
                    if (!dest.storyId.isNullOrBlank()) {
                        socialViewModel.openStoryById(dest.storyId)
                    } else {
                        socialViewModel.navigateToHome()
                    }
                }
                is com.example.data.notification.NotificationDestination.Admin -> {
                    currentSubRoute = null
                    currentTab = BottomTab.HOME
                    if (!dest.notificationId.isNullOrBlank()) {
                        app.notificationRepository.markNotificationAsRead(dest.notificationId)
                    }
                }
                null -> {}
            }
        }
    }

    // Top-Level Screen Routing based on Auth & Host Status
    when (val state = authState) {
        is AuthUiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyDarkBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = BaatlyPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Loading Baatly Partner...", color = Color.White, fontSize = 14.sp)
                }
            }
        }

        is AuthUiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyLightBackground)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = BaatlyRed,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Connection Error",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.message,
                        fontSize = 14.sp,
                        color = TextSecondaryLight,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { authViewModel.checkCurrentStatus() },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Retry Connection")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(
                        onClick = { authViewModel.logout() }
                    ) {
                        Text("Sign In with Another Account", color = BaatlyPrimary)
                    }
                }
            }
        }

        is AuthUiState.Idle, is AuthUiState.SignedOut -> {
            when (authScreenState) {
                "signup" -> {
                    SignUpScreen(
                        authViewModel = authViewModel,
                        onNavigateToSignIn = { authScreenState = "signin" },
                        onBackToIntro = { authScreenState = "intro" }
                    )
                }
                "signin" -> {
                    SignInScreen(
                        authViewModel = authViewModel,
                        onNavigateToSignUp = { authScreenState = "signup" },
                        onBackToIntro = { authScreenState = "intro" }
                    )
                }
                else -> {
                    HostIntroScreen(
                        onNavigateToSignUp = { authScreenState = "signup" },
                        onNavigateToSignIn = { authScreenState = "signin" }
                    )
                }
            }
        }

        is AuthUiState.VoiceVerificationRequired -> {
            VoiceVerificationScreen(
                displayName = state.displayName,
                applicationId = state.applicationId,
                voiceViewModel = voiceViewModel,
                onVerificationSuccess = {
                    authViewModel.checkCurrentStatus()
                }
            )
        }

        is AuthUiState.ApplicationStatus -> {
            ApplicationStatusScreen(
                status = state.status,
                authViewModel = authViewModel,
                onNavigateToReVerification = {
                    authViewModel.transitionToVoiceVerification(
                        displayName = state.status.partnerProfile?.partnerDisplayName ?: "Host",
                        applicationId = state.status.application?.id
                    )
                }
            )
        }

        is AuthUiState.Approved -> {
            // Check if there is an active ongoing call
            if (callUiStatus is ActiveCallUiStatus.Connected || callUiStatus is ActiveCallUiStatus.Connecting || callUiStatus is ActiveCallUiStatus.Ended || callUiStatus is ActiveCallUiStatus.Error) {
                ActiveCallScreen(
                    callViewModel = callViewModel,
                    chatViewModel = chatViewModel,
                    onCallFinished = {
                        mainViewModel.loadAllData()
                    }
                )
            } else if (activeChatParams != null) {
                val (convId, receiverId, name) = activeChatParams!!
                ChatDetailScreen(
                    conversationId = convId,
                    receiverId = receiverId,
                    receiverName = name,
                    chatViewModel = chatViewModel,
                    onBack = { activeChatParams = null }
                )
            } else if (currentSubRoute != null) {
                when (currentSubRoute) {
                    "baatly_support" -> BaatlySupportChatScreen(
                        partnerAiChatViewModel = partnerAiChatViewModel,
                        onBack = { currentSubRoute = null }
                    )
                    "call_kamai" -> CallKamaiScreen(mainViewModel = mainViewModel, onBack = { currentSubRoute = null })
                    "skills" -> SkillsScreen(mainViewModel = mainViewModel, onBack = { currentSubRoute = null })
                    "training" -> TrainingVideosScreen(onBack = { currentSubRoute = null })
                    "mall" -> MallScreen(onBack = { currentSubRoute = null })
                    "frame_niyam" -> FrameNiyamScreen(onBack = { currentSubRoute = null })
                    "strike_niyam" -> StrikeNiyamScreen(onBack = { currentSubRoute = null })
                    "wallet" -> WalletScreen(walletViewModel = walletViewModel, onBack = { currentSubRoute = null })
                    "blocked_users" -> BlockedUsersScreen(partnerRepository = app.partnerRepository, onBack = { currentSubRoute = null })
                    "recent_calls" -> RecentCallsScreen(callViewModel = callViewModel)
                    "performance_daily" -> DailyPerformanceScreen(viewModel = performanceViewModel, onBack = { currentSubRoute = null })
                    "performance_weekly" -> WeeklyPerformanceScreen(viewModel = performanceViewModel, onBack = { currentSubRoute = null })
                    "performance_history" -> PerformanceHistoryScreen(viewModel = performanceViewModel, onBack = { currentSubRoute = null })
                    "privacy_policy" -> PartnerPrivacyPolicyScreen(onBack = { currentSubRoute = null })
                    "child_safety" -> PartnerChildSafetyScreen(onBack = { currentSubRoute = null })
                    else -> currentSubRoute = null
                }
            } else {
                val socialDestination by socialViewModel.currentDestination.collectAsState()
                val isSocialFullScreen = currentTab == BottomTab.SOCIAL && socialDestination !is SocialDestination.Home

                // Main Tabbed Navigation
                Scaffold(
                    bottomBar = {
                        if (!isSocialFullScreen) {
                            NavigationBar(
                                containerColor = Color.White,
                                tonalElevation = 3.dp
                            ) {
                                BottomTab.values().forEach { tab ->
                                    val selected = currentTab == tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            if (currentTab == tab && tab == BottomTab.SOCIAL) {
                                                socialViewModel.navigateToHome()
                                            }
                                            currentTab = tab
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = tab.icon,
                                                contentDescription = tab.title,
                                                tint = if (selected) Color.White else BaatlySlate
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = tab.title.uppercase(),
                                                color = if (selected) BaatlyPrimary else BaatlySlate,
                                                fontSize = 10.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                                letterSpacing = 0.5.sp
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = BaatlyPrimary,
                                            selectedIconColor = Color.White,
                                            unselectedIconColor = BaatlySlate,
                                            selectedTextColor = BaatlyPrimary,
                                            unselectedTextColor = BaatlySlate
                                        ),
                                        modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                                    )
                                }
                            }
                        }
                    },
                    containerColor = BaatlyLightBackground
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(if (isSocialFullScreen) PaddingValues(0.dp) else innerPadding)) {
                        when (currentTab) {
                            BottomTab.HOME -> HomeScreen(
                                mainViewModel = mainViewModel,
                                onNavigate = { route ->
                                    if (route == "recent_calls") {
                                        currentTab = BottomTab.RECENT
                                    } else {
                                        currentSubRoute = route
                                    }
                                }
                            )
                            BottomTab.CHATS -> ChatListScreen(
                                chatViewModel = chatViewModel,
                                partnerAiChatViewModel = partnerAiChatViewModel,
                                onOpenConversation = { convId, userId, name ->
                                    activeChatParams = Triple(convId, userId, name?.takeIf { it.isNotBlank() } ?: "Baatly User")
                                },
                                onOpenSupportChat = {
                                    currentSubRoute = "baatly_support"
                                }
                            )
                            BottomTab.SOCIAL -> SocialScreen(
                                socialViewModel = socialViewModel,
                                privateMediaRepo = app.privateMediaRepository,
                                hostUserId = app.sessionManager.authUuid.value ?: ""
                            )
                            BottomTab.RECENT -> RecentCallsScreen(callViewModel = callViewModel)
                            BottomTab.PROFILE -> ProfileScreen(
                                mainViewModel = mainViewModel,
                                authViewModel = authViewModel,
                                onNavigate = { route -> currentSubRoute = route }
                            )
                        }
                    }
                }
            }
        }
    }
}
