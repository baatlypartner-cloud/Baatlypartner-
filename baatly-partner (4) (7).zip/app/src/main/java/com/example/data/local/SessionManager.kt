package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("baatly_partner_session", Context.MODE_PRIVATE)

    private val _accessToken = MutableStateFlow<String?>(prefs.getString(KEY_ACCESS_TOKEN, null))
    val accessToken: StateFlow<String?> = _accessToken.asStateFlow()

    private val _userId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _authUuid = MutableStateFlow<String?>(prefs.getString(KEY_AUTH_UUID, null))
    val authUuid: StateFlow<String?> = _authUuid.asStateFlow()

    fun getSupabaseUrl(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_URL, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder") && !stored.contains("your-supabase-url")) {
            return stored.trim().removeSuffix("/")
        }
        val buildConfigUrl = try {
            BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
        } catch (_: Exception) { null }
        return if (!buildConfigUrl.isNullOrBlank() && !buildConfigUrl.contains("placeholder") && !buildConfigUrl.contains("your-supabase-url")) {
            buildConfigUrl.trim().removeSuffix("/")
        } else {
            DEFAULT_SUPABASE_URL
        }
    }

    fun getSupabasePublishableKey(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_KEY, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder")) {
            return stored.trim()
        }
        val buildConfigKey = try {
            BuildConfig::class.java.getField("SUPABASE_PUBLISHABLE_KEY").get(null) as? String
        } catch (_: Exception) { null }
        return if (!buildConfigKey.isNullOrBlank() && !buildConfigKey.contains("placeholder")) {
            buildConfigKey.trim()
        } else {
            DEFAULT_SUPABASE_PUBLISHABLE_KEY
        }
    }

    fun getAgoraAppId(): String {
        val stored = prefs.getString(KEY_CUSTOM_AGORA_APP_ID, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder")) {
            return stored.trim()
        }
        val buildConfigAgora = try {
            BuildConfig::class.java.getField("AGORA_APP_ID").get(null) as? String
        } catch (_: Exception) { null }
        return if (!buildConfigAgora.isNullOrBlank() && !buildConfigAgora.contains("placeholder")) {
            buildConfigAgora.trim()
        } else {
            DEFAULT_AGORA_APP_ID
        }
    }

    fun saveCredentials(supabaseUrl: String?, publishableKey: String?, agoraAppId: String?) {
        prefs.edit().apply {
            if (!supabaseUrl.isNullOrBlank()) putString(KEY_CUSTOM_SUPABASE_URL, supabaseUrl.trim())
            if (!publishableKey.isNullOrBlank()) putString(KEY_CUSTOM_SUPABASE_KEY, publishableKey.trim())
            if (!agoraAppId.isNullOrBlank()) putString(KEY_CUSTOM_AGORA_APP_ID, agoraAppId.trim())
            apply()
        }
    }

    fun saveSession(authUuid: String, userId: String, accessToken: String, refreshToken: String?) {
        prefs.edit()
            .putString(KEY_AUTH_UUID, authUuid)
            .putString(KEY_USER_ID, userId)
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .putString(KEY_REFRESH_TOKEN, refreshToken)
            .apply()

        _authUuid.value = authUuid
        _userId.value = userId
        _accessToken.value = accessToken
    }

    fun updateTokens(accessToken: String, refreshToken: String?) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .apply {
                if (refreshToken != null) putString(KEY_REFRESH_TOKEN, refreshToken)
            }
            .apply()
        _accessToken.value = accessToken
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_UUID)
            .remove(KEY_USER_ID)
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_LAST_REGISTERED_AUTH_UUID)
            .remove(KEY_LAST_REGISTERED_FCM_TOKEN)
            .apply()

        _authUuid.value = null
        _userId.value = null
        _accessToken.value = null
    }

    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)

    fun getStoredAuthUuid(): String? = prefs.getString(KEY_AUTH_UUID, null)

    fun getStoredUserId(): String? = prefs.getString(KEY_USER_ID, null)

    fun getStoredFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)

    fun saveFcmToken(token: String) {
        prefs.edit().putString(KEY_FCM_TOKEN, token.trim()).apply()
    }

    fun getLastRegisteredFcmToken(): String? = prefs.getString(KEY_LAST_REGISTERED_FCM_TOKEN, null)

    fun getLastRegisteredAuthUuid(): String? = prefs.getString(KEY_LAST_REGISTERED_AUTH_UUID, null)

    fun setLastRegisteredFcmToken(token: String?, authUuid: String?) {
        prefs.edit()
            .putString(KEY_LAST_REGISTERED_FCM_TOKEN, token)
            .putString(KEY_LAST_REGISTERED_AUTH_UUID, authUuid)
            .apply()
    }

    fun isNotificationPermissionRequested(): Boolean = prefs.getBoolean(KEY_NOTIFICATION_PERM_REQUESTED, false)

    fun setNotificationPermissionRequested(requested: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATION_PERM_REQUESTED, requested).apply()
    }

    fun hasStoredSession(): Boolean {
        val authId = _authUuid.value ?: prefs.getString(KEY_AUTH_UUID, null)
        val token = _accessToken.value ?: prefs.getString(KEY_ACCESS_TOKEN, null)
        val refresh = prefs.getString(KEY_REFRESH_TOKEN, null)
        return !authId.isNullOrBlank() && (!token.isNullOrBlank() || !refresh.isNullOrBlank())
    }

    fun isLoggedIn(): Boolean {
        val authId = _authUuid.value ?: prefs.getString(KEY_AUTH_UUID, null)
        val token = _accessToken.value ?: prefs.getString(KEY_ACCESS_TOKEN, null)
        return !authId.isNullOrBlank() && !token.isNullOrBlank()
    }

    companion object {
        const val DEFAULT_SUPABASE_URL = "https://qewhxsbrnlgunygghpez.supabase.co"
        const val DEFAULT_SUPABASE_PUBLISHABLE_KEY = "sb_publishable_X05JHyvFNsJLfQ7k2iFp0w_ezNwN8Jj"
        const val DEFAULT_AGORA_APP_ID = "82771d17f30f40b09cb1790e9afc1e3f"

        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_AUTH_UUID = "auth_uuid"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_CUSTOM_SUPABASE_URL = "custom_supabase_url"
        private const val KEY_CUSTOM_SUPABASE_KEY = "custom_supabase_key"
        private const val KEY_CUSTOM_AGORA_APP_ID = "custom_agora_app_id"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_LAST_REGISTERED_FCM_TOKEN = "last_registered_fcm_token"
        private const val KEY_LAST_REGISTERED_AUTH_UUID = "last_registered_auth_uuid"
        private const val KEY_NOTIFICATION_PERM_REQUESTED = "notification_perm_requested"
    }
}
