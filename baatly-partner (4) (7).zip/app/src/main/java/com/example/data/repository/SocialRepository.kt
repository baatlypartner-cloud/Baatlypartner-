package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SocialRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "SocialRepository"

    /**
     * Ensures the social profile exists for the current logged-in host via authoritative RPC:
     * social_ensure_profile()
     * Then fetches and returns the social_profiles record combined with profiles.
     */
    suspend fun getHostSocialProfile(): Result<SocialProfileModel> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))

            // 1. Authoritative RPC: social_ensure_profile()
            try {
                supabaseClient.restService.socialEnsureProfile()
            } catch (e: Exception) {
                Log.w(TAG, "social_ensure_profile RPC call note: ${e.message}")
            }

            // 2. Fetch social_profiles for current user
            val socialRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$authUuid")
            val socialProfile = socialRes.body()?.firstOrNull()

            // 3. Fetch main profile
            val profileRes = supabaseClient.restService.getProfile(idFilter = "eq.$authUuid")
            val profile = profileRes.body()?.firstOrNull()

            val combined = SocialProfileModel(
                userId = authUuid,
                bio = socialProfile?.bio ?: profile?.bio,
                hobbies = socialProfile?.hobbies,
                socialAvatarUrl = socialProfile?.socialAvatarUrl ?: profile?.avatarUrl,
                followersCount = socialProfile?.followersCount ?: profile?.followersCount ?: 0,
                followingCount = socialProfile?.followingCount ?: profile?.followingCount ?: 0,
                totalLikes = socialProfile?.totalLikes ?: 0,
                totalViews = socialProfile?.totalViews ?: 0,
                createdAt = socialProfile?.createdAt ?: profile?.createdAt,
                updatedAt = socialProfile?.updatedAt ?: profile?.updatedAt,
                profile = profile
            )

            Result.success(combined)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getHostSocialProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Updates the host social profile using authoritative RPC:
     * social_update_profile(p_bio, p_hobbies, p_avatar_url)
     */
    suspend fun updateHostSocialProfile(
        bio: String?,
        hobbies: String?,
        avatarFile: File? = null
    ): Result<SocialProfileModel> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            var socialAvatarUrl: String? = null

            if (avatarFile != null && avatarFile.exists()) {
                val filename = "social_avatar_${System.currentTimeMillis()}.jpg"
                val storagePath = "$authUuid/$filename"
                val body = avatarFile.asRequestBody("image/jpeg".toMediaTypeOrNull())

                val uploadRes = supabaseClient.storageService.uploadObject(
                    bucket = "social-media",
                    path = storagePath,
                    contentType = "image/jpeg",
                    body = body
                )

                if (!uploadRes.isSuccessful) {
                    val err = uploadRes.errorBody()?.string() ?: "HTTP ${uploadRes.code()}"
                    Log.e(TAG, "Failed to upload social avatar to social-media/$storagePath: $err")
                    return@withContext Result.failure(Exception("Failed to upload avatar: $err"))
                }
                socialAvatarUrl = "social-media/$storagePath"
            }

            // Authoritative RPC: social_update_profile
            val rpcRes = supabaseClient.restService.socialUpdateProfile(
                SocialUpdateProfileParams(
                    pBio = bio?.trim(),
                    pHobbies = hobbies?.trim(),
                    pAvatarUrl = socialAvatarUrl
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                getHostSocialProfile()
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to update social profile"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in updateHostSocialProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Search User Social Profile using authoritative RPC:
     * social_search_profile(p_target_user_id)
     *
     * HOST SEARCH RULE:
     * - Host can search/view ONLY User Social Profiles.
     * - Host cannot search/view another Host Social Profile.
     */
    suspend fun searchUserProfile(targetUserId: String): Result<SocialSearchResult> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val cleanQuery = targetUserId.trim()
            if (cleanQuery.isBlank()) {
                return@withContext Result.failure(Exception("Please enter a User ID to search"))
            }

            var searchResult: SocialSearchResult? = null

            // 1. Authoritative RPC: social_search_profile
            val rpcRes = supabaseClient.restService.socialSearchProfile(
                SocialSearchProfileParams(pTargetUserId = cleanQuery)
            )

            if (rpcRes.isSuccessful) {
                val rawBody = rpcRes.body()?.string()?.trim().orEmpty()
                if (rawBody.isNotBlank()) {
                    try {
                        val json = if (rawBody.startsWith("[")) {
                            val arr = JSONArray(rawBody)
                            if (arr.length() > 0) arr.getJSONObject(0) else null
                        } else if (rawBody.startsWith("{")) {
                            JSONObject(rawBody)
                        } else null

                        if (json != null) {
                            val isHost = json.optBoolean("is_host", false) ||
                                    json.optBoolean("is_partner", false) ||
                                    json.optString("account_type", "").equals("partner", ignoreCase = true) ||
                                    json.optString("role", "").equals("partner", ignoreCase = true) ||
                                    json.optString("role", "").equals("host", ignoreCase = true)

                            // Check is_host via authoritative RPC if needed
                            val targetId = json.optString("user_id", json.optString("id", ""))
                            var verifiedIsHost = isHost

                            if (!verifiedIsHost && targetId.isNotBlank()) {
                                verifiedIsHost = checkIsHost(targetId)
                            }

                            // STRICT RULE: HOST -> may NOT search/view HOST profiles.
                            if (verifiedIsHost) {
                                return@withContext Result.failure(Exception("HOST_PROFILE_RESTRICTED: You cannot search or view other Host profiles. Only User profiles can be viewed."))
                            }

                            searchResult = SocialSearchResult(
                                userId = targetId,
                                signupUserId = json.optString("signup_user_id", json.optString("username", null)),
                                displayName = json.optString("display_name", "Baatly User"),
                                username = json.optString("username", null),
                                avatarUrl = json.optString("avatar_url", null),
                                socialAvatarUrl = json.optString("social_avatar_url", null),
                                bio = json.optString("bio", null),
                                hobbies = json.optString("hobbies", null),
                                followersCount = json.optInt("followers_count", 0),
                                followingCount = json.optInt("following_count", 0),
                                totalLikes = json.optInt("total_likes", 0),
                                totalViews = json.optInt("total_views", 0),
                                isHost = false,
                                isPartner = false,
                                isFollowing = json.optBoolean("is_following", false)
                            )
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing search RPC response: ${e.message}")
                    }
                }
            }

            // Fallback via profiles table if search RPC didn't match
            if (searchResult == null) {
                val profilesRes = supabaseClient.restService.getProfile(idFilter = "eq.$cleanQuery")
                var profile = profilesRes.body()?.firstOrNull()

                if (profile == null) {
                    val searchByUserId = supabaseClient.restService.getProfile(idFilter = "ilike.*$cleanQuery*")
                    profile = searchByUserId.body()?.firstOrNull()
                }

                if (profile == null) {
                    return@withContext Result.failure(Exception("No user found with ID: $cleanQuery"))
                }

                // Check if target is a Host
                val isHost = checkIsHost(profile.id)
                if (isHost) {
                    return@withContext Result.failure(Exception("HOST_PROFILE_RESTRICTED: You cannot search or view other Host profiles. Only User profiles can be viewed."))
                }

                // Fetch social_profiles
                val socialRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.${profile.id}")
                val socialProfile = socialRes.body()?.firstOrNull()

                // Check follow status
                val followRes = supabaseClient.restService.getSocialFollows(
                    followerIdFilter = "eq.$authUuid",
                    followingIdFilter = "eq.${profile.id}"
                )
                val isFollowing = followRes.isSuccessful && !followRes.body().isNullOrEmpty()

                searchResult = SocialSearchResult(
                    userId = profile.id,
                    signupUserId = profile.userId ?: profile.username,
                    displayName = profile.displayName ?: profile.username ?: "Baatly User",
                    username = profile.username,
                    avatarUrl = profile.avatarUrl,
                    socialAvatarUrl = socialProfile?.socialAvatarUrl ?: profile.avatarUrl,
                    bio = socialProfile?.bio ?: profile.bio,
                    hobbies = socialProfile?.hobbies,
                    followersCount = socialProfile?.followersCount ?: profile.followersCount ?: 0,
                    followingCount = socialProfile?.followingCount ?: profile.followingCount ?: 0,
                    totalLikes = socialProfile?.totalLikes ?: 0,
                    totalViews = socialProfile?.totalViews ?: 0,
                    isHost = false,
                    isPartner = false,
                    isFollowing = isFollowing
                )
            }

            Result.success(searchResult)
        } catch (e: Exception) {
            Log.e(TAG, "Error in searchUserProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Checks if a user is a host using authoritative RPCs:
     * social_is_host(p_user_id) or social_role(p_user_id) or partner_profiles table.
     */
    private suspend fun checkIsHost(userId: String): Boolean {
        // 1. Try social_is_host RPC
        try {
            val res = supabaseClient.restService.socialIsHost(SocialIsHostParams(pUserId = userId))
            if (res.isSuccessful) {
                val bodyStr = res.body()?.string()?.trim().orEmpty().lowercase()
                if (bodyStr == "true" || bodyStr.contains("true")) return true
                if (bodyStr == "false" || bodyStr.contains("false")) return false
            }
        } catch (_: Exception) {}

        // 2. Try social_role RPC
        try {
            val roleRes = supabaseClient.restService.socialRole(SocialRoleParams(pUserId = userId))
            if (roleRes.isSuccessful) {
                val roleStr = roleRes.body()?.string()?.trim().orEmpty().lowercase()
                if (roleStr.contains("host") || roleStr.contains("partner")) return true
                if (roleStr.contains("user") || roleStr.contains("client")) return false
            }
        } catch (_: Exception) {}

        // 3. Check partner_profiles table
        try {
            val partnerRes = supabaseClient.restService.getPartnerProfile(userIdFilter = "eq.$userId")
            if (partnerRes.isSuccessful) {
                val pp = partnerRes.body()?.firstOrNull()
                if (pp?.isPartner == true || pp?.approvalStatus?.equals("approved", ignoreCase = true) == true) {
                    return true
                }
            }
        } catch (_: Exception) {}

        return false
    }

    private fun optString(obj: JSONObject, vararg keys: String): String? {
        for (key in keys) {
            if (obj.has(key) && !obj.isNull(key)) {
                val str = obj.optString(key).trim()
                if (str.isNotBlank() && str != "null") return str
            }
        }
        return null
    }

    private fun optInt(obj: JSONObject, vararg keys: String, default: Int = 0): Int {
        for (key in keys) {
            if (obj.has(key) && !obj.isNull(key)) {
                return obj.optInt(key, default)
            }
        }
        return default
    }

    private fun optBoolean(obj: JSONObject, vararg keys: String, default: Boolean = false): Boolean {
        for (key in keys) {
            if (obj.has(key) && !obj.isNull(key)) {
                return obj.optBoolean(key, default)
            }
        }
        return default
    }

    private fun parseFeedPosts(rawJson: String, authUuid: String?): List<SocialPostModel> {
        if (rawJson.isBlank()) return emptyList()
        val list = mutableListOf<SocialPostModel>()
        try {
            val jsonArray = if (rawJson.trim().startsWith("[")) {
                JSONArray(rawJson)
            } else if (rawJson.trim().startsWith("{")) {
                val single = JSONObject(rawJson)
                if (single.has("data") && !single.isNull("data")) {
                    single.getJSONArray("data")
                } else {
                    val arr = JSONArray()
                    arr.put(single)
                    arr
                }
            } else {
                return emptyList()
            }

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = optString(obj, "id", "post_id") ?: continue
                val ownerId = optString(obj, "owner_id", "user_id", "author_id")
                val signupUserId = optString(obj, "signup_user_id", "signup_id", "user_signup_id")
                val displayName = optString(obj, "display_name", "author_name", "user_name", "name")
                val username = optString(obj, "username", "user_handle")
                val avatarUrl = optString(obj, "avatar_url", "social_avatar_url", "author_avatar", "user_avatar")
                val mediaPath = optString(obj, "media_path", "media_url", "image_path", "image_url", "path")
                val caption = optString(obj, "caption", "text", "description", "title")
                val publishedAt = optString(obj, "published_at", "created_at")
                val visibleUntil = optString(obj, "visible_until", "expires_at")
                val createdAt = optString(obj, "created_at")
                val updatedAt = optString(obj, "updated_at")
                val likesCount = optInt(obj, "likes_count", "like_count", "total_likes", default = 0)
                val commentsCount = optInt(obj, "comments_count", "comment_count", "total_comments", default = 0)
                val viewsCount = optInt(obj, "views_count", "view_count", "total_views", default = 0)
                val isLiked = optBoolean(obj, "is_liked", "liked", default = false)
                val isFollowing = optBoolean(obj, "is_following", "following", default = false)

                val profile = Profile(
                    id = ownerId ?: "",
                    displayName = displayName,
                    username = username,
                    avatarUrl = avatarUrl
                )

                val socialProfile = SocialProfileModel(
                    userId = ownerId ?: "",
                    signupUserId = signupUserId,
                    socialAvatarUrl = avatarUrl,
                    bio = optString(obj, "bio"),
                    hobbies = optString(obj, "hobbies")
                )

                list.add(
                    SocialPostModel(
                        id = id,
                        ownerId = ownerId,
                        signupUserId = signupUserId,
                        displayName = displayName,
                        username = username,
                        avatarUrl = avatarUrl,
                        socialAvatarUrl = avatarUrl,
                        mediaPath = mediaPath,
                        caption = caption,
                        publishedAt = publishedAt,
                        visibleUntil = visibleUntil,
                        createdAt = createdAt,
                        updatedAt = updatedAt,
                        likesCount = likesCount,
                        likeCount = likesCount,
                        commentsCount = commentsCount,
                        commentCount = commentsCount,
                        viewsCount = viewsCount,
                        viewCount = viewsCount,
                        profile = profile,
                        socialProfile = socialProfile,
                        isLiked = isLiked,
                        isFollowing = isFollowing
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse feed posts: ${e.message}", e)
        }
        return list
    }

    private fun parseStories(rawJson: String): List<SocialStoryModel> {
        if (rawJson.isBlank()) return emptyList()
        val list = mutableListOf<SocialStoryModel>()
        try {
            val jsonArray = if (rawJson.trim().startsWith("[")) {
                JSONArray(rawJson)
            } else if (rawJson.trim().startsWith("{")) {
                val single = JSONObject(rawJson)
                if (single.has("data") && !single.isNull("data")) {
                    single.getJSONArray("data")
                } else {
                    val arr = JSONArray()
                    arr.put(single)
                    arr
                }
            } else {
                return emptyList()
            }

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = optString(obj, "id", "story_id") ?: continue
                val ownerId = optString(obj, "owner_id", "user_id", "author_id")
                val signupUserId = optString(obj, "signup_user_id", "signup_id", "user_signup_id")
                val displayName = optString(obj, "display_name", "author_name", "user_name", "name")
                val username = optString(obj, "username", "user_handle")
                val avatarUrl = optString(obj, "avatar_url", "social_avatar_url", "author_avatar", "user_avatar")
                val mediaPath = optString(obj, "media_path", "media_url", "image_path", "image_url", "path")
                val caption = optString(obj, "caption", "text", "description")
                val isActive = optBoolean(obj, "is_active", default = true)
                val expiresAt = optString(obj, "expires_at", "visible_until")
                val createdAt = optString(obj, "created_at")
                val likesCount = optInt(obj, "likes_count", "like_count", "total_likes", default = 0)
                val viewsCount = optInt(obj, "views_count", "view_count", "total_views", default = 0)
                val isLiked = optBoolean(obj, "is_liked", "liked", default = false)
                val isViewed = optBoolean(obj, "is_viewed", "viewed", default = false)

                val profile = Profile(
                    id = ownerId ?: "",
                    displayName = displayName,
                    username = username,
                    avatarUrl = avatarUrl
                )

                val socialProfile = SocialProfileModel(
                    userId = ownerId ?: "",
                    signupUserId = signupUserId,
                    socialAvatarUrl = avatarUrl,
                    bio = optString(obj, "bio"),
                    hobbies = optString(obj, "hobbies")
                )

                list.add(
                    SocialStoryModel(
                        id = id,
                        ownerId = ownerId,
                        signupUserId = signupUserId,
                        displayName = displayName,
                        username = username,
                        avatarUrl = avatarUrl,
                        socialAvatarUrl = avatarUrl,
                        mediaPath = mediaPath,
                        caption = caption,
                        isActive = isActive,
                        expiresAt = expiresAt,
                        createdAt = createdAt,
                        likesCount = likesCount,
                        likeCount = likesCount,
                        viewsCount = viewsCount,
                        viewCount = viewsCount,
                        profile = profile,
                        socialProfile = socialProfile,
                        isLiked = isLiked,
                        isViewed = isViewed
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse stories: ${e.message}", e)
        }
        return list
    }

    /**
     * Fetches feed posts using authoritative backend RPC:
     * social_get_visible_feed(p_limit, p_offset)
     */
    suspend fun getFeedPosts(limit: Int = 50, offset: Int = 0): Result<List<SocialPostModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.socialGetVisibleFeed(
                SocialGetVisibleFeedParams(pLimit = limit, pOffset = offset)
            )

            if (res.isSuccessful) {
                val rawBody = res.body()?.string() ?: "[]"
                val posts = parseFeedPosts(rawBody, authUuid)
                Result.success(posts)
            } else {
                Log.w(TAG, "social_get_visible_feed returned ${res.code()}: ${res.errorBody()?.string()}")
                // Fallback gracefully to direct query if needed
                val fallbackRes = supabaseClient.restService.getSocialPosts()
                if (fallbackRes.isSuccessful) {
                    val raw = fallbackRes.body() ?: emptyList()
                    Result.success(raw)
                } else {
                    Result.failure(Exception(res.errorBody()?.string()))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getFeedPosts", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches posts for a specific user:
     * Uses social_get_visible_feed or owner query with search profile lookup
     */
    suspend fun getUserPosts(userId: String): Result<List<SocialPostModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            
            // First try visible feed to find posts from this user
            val feedRes = getFeedPosts(limit = 100, offset = 0)
            if (feedRes.isSuccess) {
                val feedMatches = feedRes.getOrNull()?.filter { it.userId == userId || it.ownerId == userId } ?: emptyList()
                if (feedMatches.isNotEmpty()) {
                    return@withContext Result.success(feedMatches)
                }
            }

            val postsRes = supabaseClient.restService.getSocialPostsByOwner(ownerIdFilter = "eq.$userId")
            if (!postsRes.isSuccessful) {
                return@withContext Result.failure(Exception(postsRes.errorBody()?.string()))
            }

            val rawPosts = postsRes.body() ?: emptyList()
            if (rawPosts.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            // Resolve public profile via social_search_profile without hitting restricted profiles table
            val searchRes = searchUserProfile(userId)
            val publicInfo = searchRes.getOrNull()

            val enriched = rawPosts.map { post ->
                post.copy(
                    displayName = publicInfo?.displayName ?: post.displayName,
                    signupUserId = publicInfo?.signupUserId ?: post.signupUserId,
                    avatarUrl = publicInfo?.avatarUrl ?: publicInfo?.socialAvatarUrl ?: post.avatarUrl,
                    profile = Profile(
                        id = userId,
                        displayName = publicInfo?.displayName,
                        username = publicInfo?.username,
                        avatarUrl = publicInfo?.avatarUrl ?: publicInfo?.socialAvatarUrl
                    ),
                    socialProfile = SocialProfileModel(
                        userId = userId,
                        signupUserId = publicInfo?.signupUserId,
                        socialAvatarUrl = publicInfo?.socialAvatarUrl ?: publicInfo?.avatarUrl,
                        bio = publicInfo?.bio,
                        hobbies = publicInfo?.hobbies
                    )
                )
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getUserPosts", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches active visible stories using authoritative backend RPC:
     * social_get_visible_stories()
     */
    suspend fun getActiveStories(): Result<List<SocialStoryModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetVisibleStories()
            if (res.isSuccessful) {
                val rawBody = res.body()?.string() ?: "[]"
                val stories = parseStories(rawBody)
                Result.success(stories)
            } else {
                Log.w(TAG, "social_get_visible_stories returned ${res.code()}: ${res.errorBody()?.string()}")
                val fallbackRes = supabaseClient.restService.getSocialStories()
                if (fallbackRes.isSuccessful) {
                    Result.success(fallbackRes.body() ?: emptyList())
                } else {
                    Result.failure(Exception(res.errorBody()?.string()))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getActiveStories", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches stories for a specific owner using authoritative backend RPC:
     * social_get_visible_stories_for_owner(p_owner_id)
     */
    suspend fun getUserStories(userId: String): Result<List<SocialStoryModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetVisibleStoriesForOwner(
                SocialGetVisibleStoriesForOwnerParams(pOwnerId = userId)
            )
            if (res.isSuccessful) {
                val rawBody = res.body()?.string() ?: "[]"
                val stories = parseStories(rawBody)
                Result.success(stories)
            } else {
                Log.w(TAG, "social_get_visible_stories_for_owner returned ${res.code()}: ${res.errorBody()?.string()}")
                val fallbackRes = supabaseClient.restService.getSocialStoriesByOwner(ownerIdFilter = "eq.$userId")
                if (fallbackRes.isSuccessful) {
                    Result.success(fallbackRes.body() ?: emptyList())
                } else {
                    Result.failure(Exception(res.errorBody()?.string()))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getUserStories", e)
            Result.failure(e)
        }
    }

    /**
     * Creates a post or story using authoritative RPC:
     * social_create_content(p_type, p_media_path, p_caption)
     *
     * Post: p_type = "post"
     * Story: p_type = "story"
     */
    suspend fun createContent(
        type: String,
        mediaFile: File,
        caption: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val extension = mediaFile.extension.ifBlank { "jpg" }
            val mimeType = if (extension.equals("mp4", ignoreCase = true)) "video/mp4" else "image/jpeg"
            val filename = "${type}_${System.currentTimeMillis()}.$extension"
            val storagePath = "$authUuid/$filename"

            val body = mediaFile.asRequestBody(mimeType.toMediaTypeOrNull())

            val uploadRes = supabaseClient.storageService.uploadObject(
                bucket = "social-media",
                path = storagePath,
                contentType = mimeType,
                body = body
            )

            if (!uploadRes.isSuccessful) {
                val err = uploadRes.errorBody()?.string() ?: "HTTP ${uploadRes.code()}"
                Log.e(TAG, "Failed to upload social content to social-media/$storagePath: $err")
                return@withContext Result.failure(Exception("Failed to upload media: $err"))
            }

            val finalPath = "social-media/$storagePath"

            // Authoritative RPC: social_create_content
            val rpcRes = supabaseClient.restService.socialCreateContent(
                SocialCreateContentParams(
                    pType = type.lowercase(),
                    pMediaPath = finalPath,
                    pCaption = caption?.trim()
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                Result.success(Unit)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to create social content"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in createContent", e)
            Result.failure(e)
        }
    }

    /**
     * Deletes a host's own social post via authoritative RPC:
     * social_delete_post(p_post_id uuid)
     *
     * RPC behavior:
     * - Only authenticated post owner can delete the post.
     * - Related non-financial social records are cleaned up.
     * - No coin refund is issued.
     * - User/partner wallet is not modified.
     * - Storage object is cleaned up if media_path is returned.
     */
    suspend fun deletePost(postId: String): Result<SocialDeletePostResult> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))

            val rpcRes = supabaseClient.restService.socialDeletePost(
                SocialDeletePostParams(pPostId = postId)
            )

            if (!rpcRes.isSuccessful) {
                val err = rpcRes.errorBody()?.string() ?: "HTTP ${rpcRes.code()} Failed to delete post"
                Log.e(TAG, "social_delete_post RPC failed: $err")
                return@withContext Result.failure(Exception(err))
            }

            val rawBody = rpcRes.body()?.string()?.trim().orEmpty()
            Log.d(TAG, "social_delete_post raw response: $rawBody")

            var deleted = false
            var returnedPostId: String? = postId
            var mediaPath: String? = null
            var refundIssued = false

            if (rawBody.isNotBlank()) {
                try {
                    if (rawBody.startsWith("[")) {
                        val arr = JSONArray(rawBody)
                        if (arr.length() > 0) {
                            val obj = arr.getJSONObject(0)
                            deleted = optBoolean(obj, "deleted", "success", default = true)
                            returnedPostId = optString(obj, "post_id", "id") ?: postId
                            mediaPath = optString(obj, "media_path", "media_url", "path")
                            refundIssued = optBoolean(obj, "refund_issued", default = false)
                        }
                    } else if (rawBody.startsWith("{")) {
                        val obj = JSONObject(rawBody)
                        deleted = optBoolean(obj, "deleted", "success", default = true)
                        returnedPostId = optString(obj, "post_id", "id") ?: postId
                        mediaPath = optString(obj, "media_path", "media_url", "path")
                        refundIssued = optBoolean(obj, "refund_issued", default = false)
                    } else if (rawBody.lowercase() == "true" || rawBody.contains("true")) {
                        deleted = true
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error parsing social_delete_post JSON: ${e.message}")
                    deleted = true
                }
            } else {
                deleted = true
            }

            if (!deleted) {
                return@withContext Result.failure(Exception("Post deletion failed on server"))
            }

            // Cleanup storage object if media_path is present
            if (!mediaPath.isNullOrBlank()) {
                val cleanPath = mediaPath.removePrefix("social-media/").removePrefix("/")
                try {
                    val delRes = supabaseClient.storageService.deleteObject(
                        bucket = "social-media",
                        path = cleanPath
                    )
                    if (!delRes.isSuccessful) {
                        // Fallback attempt with deleteObjects
                        supabaseClient.storageService.deleteObjects(
                            bucket = "social-media",
                            body = mapOf("prefixes" to listOf(cleanPath))
                        )
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Storage cleanup notice for social-media/$cleanPath: ${e.message}")
                }
            }

            Result.success(
                SocialDeletePostResult(
                    deleted = true,
                    postId = returnedPostId,
                    mediaPath = mediaPath,
                    refundIssued = refundIssued
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error in deletePost", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches Host Social Earnings via authoritative RPC:
     * social_get_earnings()
     *
     * Displays backend-returned:
     * - total
     * - view_earnings
     * - like_earnings
     * - comment_earnings
     * - any breakdown
     * Never calculate or hardcode amounts.
     */
    suspend fun getHostSocialEarnings(): Result<SocialEarningsModel> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetEarnings()
            if (res.isSuccessful) {
                val rawBody = res.body()?.string()?.trim().orEmpty()
                val json = if (rawBody.startsWith("[")) {
                    val arr = JSONArray(rawBody)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else if (rawBody.startsWith("{")) {
                    JSONObject(rawBody)
                } else JSONObject()

                val earnings = SocialEarningsModel(
                    total = json.optDouble("total", json.optDouble("total_social_earnings", 0.0)),
                    totalSocialEarnings = json.optDouble("total_social_earnings", json.optDouble("total", 0.0)),
                    viewEarnings = json.optDouble("view_earnings", 0.0),
                    likeEarnings = json.optDouble("like_earnings", 0.0),
                    commentEarnings = json.optDouble("comment_earnings", 0.0),
                    unlockEarnings = json.optDouble("unlock_earnings", 0.0),
                    storyView = json.optDouble("story_view", 0.0),
                    postUnlock = json.optDouble("post_unlock", 0.0),
                    storyLike = json.optDouble("story_like", 0.0),
                    postLike = json.optDouble("post_like", 0.0),
                    storyReply = json.optDouble("story_reply", 0.0),
                    postComment = json.optDouble("post_comment", 0.0)
                )
                Result.success(earnings)
            } else {
                val err = res.errorBody()?.string() ?: "Failed to fetch social earnings"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getHostSocialEarnings", e)
            Result.failure(e)
        }
    }

    /**
     * Records content view via authoritative RPC:
     * social_view_content(p_content_type, p_content_id)
     */
    suspend fun viewContent(contentType: String, contentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialViewContent(
                SocialViewContentParams(pContentType = contentType, pContentId = contentId)
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Toggles like on content via authoritative RPC:
     * social_toggle_like(p_content_type, p_content_id)
     *
     * Host Like on User content is FREE.
     */
    suspend fun toggleLike(contentType: String, contentId: String, currentIsLiked: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rpcRes = supabaseClient.restService.socialToggleLike(
                SocialToggleLikeParams(pContentType = contentType, pContentId = contentId)
            )

            if (rpcRes.isSuccessful) {
                Result.success(!currentIsLiked)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to toggle like"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in toggleLike", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches comments for a piece of content from social_comments table:
     * Columns: id, content_type, content_id, author_id, comment, created_at
     */
    suspend fun getComments(contentId: String): Result<List<SocialCommentModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getSocialComments(contentIdFilter = "eq.$contentId")
            if (!res.isSuccessful) {
                return@withContext Result.failure(Exception(res.errorBody()?.string()))
            }

            val rawComments = res.body() ?: emptyList()
            if (rawComments.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            // Fetch authors
            val authorIds = rawComments.mapNotNull { it.authorId ?: it.legacyUserId }.filter { it.isNotBlank() }.distinct()
            val profileMap = mutableMapOf<String, Profile>()

            for (authorId in authorIds) {
                try {
                    val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$authorId")
                    pRes.body()?.firstOrNull()?.let { profileMap[authorId] = it }
                } catch (_: Exception) {}
            }

            val enriched = rawComments.map { comment ->
                val authorId = comment.authorId ?: comment.legacyUserId ?: ""
                comment.copy(profile = profileMap[authorId])
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getComments", e)
            Result.failure(e)
        }
    }

    /**
     * Adds a comment via authoritative RPC:
     * social_add_comment(p_content_type, p_content_id, p_comment)
     *
     * Host Comment on User content is FREE.
     */
    suspend fun addComment(contentType: String, contentId: String, commentText: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val cleanText = commentText.trim()
            if (cleanText.isBlank()) return@withContext Result.failure(Exception("Comment cannot be empty"))

            val rpcRes = supabaseClient.restService.socialAddComment(
                SocialAddCommentParams(
                    pContentType = contentType,
                    pContentId = contentId,
                    pComment = cleanText
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                Result.success(Unit)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to post comment"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in addComment", e)
            Result.failure(e)
        }
    }

    /**
     * Toggles follow via authoritative RPC:
     * social_follow_toggle(p_target_user_id)
     */
    suspend fun toggleFollow(targetUserId: String, currentIsFollowing: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rpcRes = supabaseClient.restService.socialFollowToggle(
                SocialFollowToggleParams(pTargetUserId = targetUserId)
            )
            if (rpcRes.isSuccessful) {
                Result.success(!currentIsFollowing)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to toggle follow"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in toggleFollow", e)
            Result.failure(e)
        }
    }
}
