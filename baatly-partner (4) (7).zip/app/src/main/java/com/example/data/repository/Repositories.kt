package com.example.data.repository

import android.util.Log
import com.example.data.agora.AgoraCallManager
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class HostApplicationState {
    NOT_LOGGED_IN,
    NO_APPLICATION,
    PENDING,
    RESUBMISSION,
    REJECTED,
    APPROVED
}

data class HostFullStatus(
    val state: HostApplicationState,
    val profile: Profile? = null,
    val partnerProfile: PartnerProfile? = null,
    val application: PartnerApplication? = null,
    val voiceVerification: VoiceVerification? = null,
    val rejectionReason: String? = null,
    val resubmissionReason: String? = null
)

class AuthRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager,
    private val notificationRepository: NotificationRepository? = null
) {
    private val TAG = "AuthRepository"

    suspend fun signUpHost(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        age: Int,
        bio: String?,
        avatarFile: File?
    ): Result<HostFullStatus> = withContext(Dispatchers.IO) {
        try {
            val normalizedUserId = userId.trim().lowercase()
            val internalEmail = "$normalizedUserId@auth.baatly.app"

            // 1. Supabase Auth signup
            val signUpResponse = supabaseClient.authService.signUp(
                AuthSignUpRequest(email = internalEmail, password = password)
            )

            if (!signUpResponse.isSuccessful || signUpResponse.body() == null) {
                val err = signUpResponse.errorBody()?.string() ?: "Sign up failed"
                return@withContext Result.failure(Exception("Sign up error: $err"))
            }

            val authBody = signUpResponse.body()!!
            val authUser = authBody.user ?: return@withContext Result.failure(Exception("User data missing from signup response"))
            val accessToken = authBody.accessToken ?: ""
            val refreshToken = authBody.refreshToken

            sessionManager.saveSession(
                authUuid = authUser.id,
                userId = normalizedUserId,
                accessToken = accessToken,
                refreshToken = refreshToken
            )

            // 2. Upload avatar if present
            var avatarStoragePath: String? = null
            if (avatarFile != null && avatarFile.exists()) {
                val filename = "avatar_${System.currentTimeMillis()}.jpg"
                val storagePath = "${authUser.id}/$filename"
                val requestBody = avatarFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val uploadRes = supabaseClient.storageService.uploadObject(
                    bucket = "profile-media",
                    path = storagePath,
                    contentType = "image/jpeg",
                    body = requestBody
                )
                if (uploadRes.isSuccessful) {
                    avatarStoragePath = "profile-media/$storagePath"
                } else {
                    Log.w(TAG, "Avatar upload failed: ${uploadRes.errorBody()?.string()}")
                }
            }

            // 3. Complete Host Onboarding RPC
            val rpcParams = CompleteHostOnboardingParams(
                pUserId = normalizedUserId,
                pDisplayName = displayName.trim(),
                pMobileNumber = mobileNumber.trim(),
                pAge = age,
                pBio = bio?.trim()?.ifBlank { null },
                pHobbies = null,
                pAvatarUrl = avatarStoragePath,
                pUsername = null
            )

            val rpcRes = supabaseClient.restService.completeHostOnboarding(rpcParams)
            if (!rpcRes.isSuccessful) {
                val err = rpcRes.errorBody()?.string() ?: "Onboarding RPC failed"
                Log.e(TAG, "Onboarding error: $err")
                return@withContext Result.failure(Exception("Onboarding failed: $err"))
            }

            fetchHostStatus()
        } catch (e: Exception) {
            Log.e(TAG, "Error in signUpHost", e)
            Result.failure(e)
        }
    }

    suspend fun signInHost(userId: String, password: String): Result<HostFullStatus> = withContext(Dispatchers.IO) {
        try {
            val normalizedUserId = userId.trim().lowercase()
            val internalEmail = "$normalizedUserId@auth.baatly.app"

            val signInRes = supabaseClient.authService.signIn(
                request = AuthSignInRequest(email = internalEmail, password = password)
            )

            if (!signInRes.isSuccessful || signInRes.body() == null) {
                val err = signInRes.errorBody()?.string() ?: "Sign in failed"
                return@withContext Result.failure(Exception("Sign in failed: $err"))
            }

            val body = signInRes.body()!!
            val user = body.user ?: return@withContext Result.failure(Exception("User data missing"))
            val accessToken = body.accessToken ?: ""

            sessionManager.saveSession(
                authUuid = user.id,
                userId = normalizedUserId,
                accessToken = accessToken,
                refreshToken = body.refreshToken
            )

            fetchHostStatus()
        } catch (e: Exception) {
            Log.e(TAG, "Error in signInHost", e)
            Result.failure(e)
        }
    }

    suspend fun fetchHostStatus(): Result<HostFullStatus> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
            val hasSession = sessionManager.hasStoredSession()

            if (authUuid.isNullOrBlank() || !hasSession) {
                return@withContext Result.success(HostFullStatus(state = HostApplicationState.NOT_LOGGED_IN))
            }

            // If access token is empty or invalid, try to refresh
            if (sessionManager.accessToken.value.isNullOrBlank() && !sessionManager.getRefreshToken().isNullOrBlank()) {
                val refreshed = tryRefreshToken()
                if (!refreshed) {
                    sessionManager.clearSession()
                    return@withContext Result.success(HostFullStatus(state = HostApplicationState.NOT_LOGGED_IN))
                }
            }

            // Query profiles
            var profileRes = supabaseClient.restService.getProfile(idFilter = "eq.$authUuid")
            if (profileRes.code() == 401) {
                if (tryRefreshToken()) {
                    profileRes = supabaseClient.restService.getProfile(idFilter = "eq.$authUuid")
                } else {
                    sessionManager.clearSession()
                    return@withContext Result.success(HostFullStatus(state = HostApplicationState.NOT_LOGGED_IN))
                }
            }

            if (!profileRes.isSuccessful && profileRes.code() != 404) {
                val err = profileRes.errorBody()?.string() ?: "Failed to load profile"
                return@withContext Result.failure(Exception(err))
            }

            val profile = profileRes.body()?.firstOrNull()

            // Query partner_profiles
            val partnerProfileRes = supabaseClient.restService.getPartnerProfile(userIdFilter = "eq.$authUuid")
            if (!partnerProfileRes.isSuccessful && partnerProfileRes.code() != 404) {
                val err = partnerProfileRes.errorBody()?.string() ?: "Failed to load partner profile"
                return@withContext Result.failure(Exception(err))
            }
            val partnerProfile = partnerProfileRes.body()?.firstOrNull()

            // Query partner_applications
            val appRes = supabaseClient.restService.getPartnerApplications(userIdFilter = "eq.$authUuid")
            if (!appRes.isSuccessful && appRes.code() != 404) {
                val err = appRes.errorBody()?.string() ?: "Failed to load partner applications"
                return@withContext Result.failure(Exception(err))
            }
            val application = appRes.body()?.firstOrNull()

            // Query voice_verifications
            val voiceRes = supabaseClient.restService.getVoiceVerifications(userIdFilter = "eq.$authUuid")
            if (!voiceRes.isSuccessful && voiceRes.code() != 404) {
                val err = voiceRes.errorBody()?.string() ?: "Failed to load voice verifications"
                return@withContext Result.failure(Exception(err))
            }
            val voiceVerification = voiceRes.body()?.firstOrNull()

            // Determine Partner Status accurately based on Supabase database state
            val isPartnerApproved = partnerProfile?.approvalStatus?.equals("approved", ignoreCase = true) == true ||
                    application?.status?.equals("approved", ignoreCase = true) == true ||
                    voiceVerification?.status?.equals("approved", ignoreCase = true) == true ||
                    (partnerProfile?.isPartner == true &&
                     partnerProfile.approvalStatus?.lowercase() != "rejected" &&
                     partnerProfile.approvalStatus?.lowercase() != "pending" &&
                     partnerProfile.approvalStatus?.lowercase() != "resubmission")

            val appState = when {
                isPartnerApproved -> HostApplicationState.APPROVED

                // Rejections
                application?.status?.equals("rejected", ignoreCase = true) == true ||
                voiceVerification?.status?.equals("rejected", ignoreCase = true) == true ||
                partnerProfile?.approvalStatus?.equals("rejected", ignoreCase = true) == true -> HostApplicationState.REJECTED

                // Resubmission
                application?.status?.equals("resubmission", ignoreCase = true) == true ||
                partnerProfile?.approvalStatus?.equals("resubmission", ignoreCase = true) == true -> HostApplicationState.RESUBMISSION

                // Pending / Under review
                application?.status?.equals("pending", ignoreCase = true) == true ||
                voiceVerification?.status?.equals("pending", ignoreCase = true) == true ||
                (partnerProfile?.approvalStatus?.equals("pending", ignoreCase = true) == true && (partnerProfile.voiceVerified == true || voiceVerification != null)) -> HostApplicationState.PENDING

                // Needs voice verification (new onboarding / unsubmitted)
                else -> HostApplicationState.NO_APPLICATION
            }

            val status = HostFullStatus(
                state = appState,
                profile = profile,
                partnerProfile = partnerProfile,
                application = application,
                voiceVerification = voiceVerification,
                rejectionReason = application?.rejectionReason ?: voiceVerification?.rejectionReason,
                resubmissionReason = application?.resubmissionReason
            )

            // Trigger background FCM token sync when partner is active
            if (appState == HostApplicationState.APPROVED) {
                try {
                    notificationRepository?.syncFcmToken()
                } catch (ne: Exception) {
                    Log.w(TAG, "Background FCM token sync attempt failed: ${ne.message}")
                }
            }

            Result.success(status)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching host status", e)
            Result.failure(e)
        }
    }

    private suspend fun tryRefreshToken(): Boolean = withContext(Dispatchers.IO) {
        try {
            val refreshToken = sessionManager.getRefreshToken() ?: return@withContext false
            val res = supabaseClient.authService.refreshToken(
                grantType = "refresh_token",
                body = mapOf("refresh_token" to refreshToken)
            )
            if (res.isSuccessful && res.body() != null) {
                val body = res.body()!!
                val newAccess = body.accessToken ?: return@withContext false
                val newRefresh = body.refreshToken ?: refreshToken
                sessionManager.updateTokens(newAccess, newRefresh)
                return@withContext true
            }
        } catch (e: Exception) {
            Log.e(TAG, "tryRefreshToken error", e)
        }
        false
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Deactivate device token on server before clearing session
            notificationRepository?.deactivateFcmToken()
        } catch (e: Exception) {
            Log.w(TAG, "FCM token deactivation on logout warning: ${e.message}")
        }
        try {
            supabaseClient.authService.logout()
        } catch (_: Exception) {}
        sessionManager.clearSession()
        Result.success(Unit)
    }
}

class PartnerRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager,
    private val privateMediaRepository: PrivateMediaRepository? = null
) {
    private val TAG = "PartnerRepository"

    suspend fun submitVoiceVerification(audioFile: File, applicationId: String?): Result<String> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val filename = "voice_${System.currentTimeMillis()}.m4a"
            val storagePath = "$authUuid/$filename"

            val body = audioFile.asRequestBody("audio/mp4".toMediaTypeOrNull())
            val uploadRes = supabaseClient.storageService.uploadObject(
                bucket = "voice-verifications",
                path = storagePath,
                contentType = "audio/mp4",
                body = body
            )

            if (!uploadRes.isSuccessful) {
                val err = uploadRes.errorBody()?.string() ?: "Voice upload failed"
                return@withContext Result.failure(Exception("Upload voice failed: $err"))
            }

            val audioUrl = "voice-verifications/$storagePath"
            val rpcRes = supabaseClient.restService.createPartnerVoiceVerification(
                CreateVoiceVerificationParams(
                    pAudioUrl = audioUrl,
                    pApplicationId = applicationId
                )
            )

            if (!rpcRes.isSuccessful) {
                val err = rpcRes.errorBody()?.string() ?: "Voice verification RPC error"
                return@withContext Result.failure(Exception(err))
            }

            val voiceId = rpcRes.body() ?: ""
            Result.success(voiceId)
        } catch (e: Exception) {
            Log.e(TAG, "Error in submitVoiceVerification", e)
            Result.failure(e)
        }
    }

    suspend fun submitPartnerApplication(displayName: String, voiceVerificationId: String?): Result<String> = withContext(Dispatchers.IO) {
        try {
            val rpcRes = supabaseClient.restService.submitPartnerApplication(
                SubmitPartnerApplicationParams(
                    pPartnerDisplayName = displayName,
                    pVoiceVerificationId = voiceVerificationId
                )
            )
            if (!rpcRes.isSuccessful) {
                val err = rpcRes.errorBody()?.string() ?: "Submit application RPC failed"
                return@withContext Result.failure(Exception(err))
            }
            Result.success(rpcRes.body() ?: "")
        } catch (e: Exception) {
            Log.e(TAG, "Error submitting application", e)
            Result.failure(e)
        }
    }

    suspend fun updateServiceAvailability(
        displayName: String?,
        isAvailable: Boolean,
        isOnline: Boolean,
        audioEnabled: Boolean,
        chatEnabled: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.updateMyPartnerProfile(
                UpdateMyPartnerProfileParams(
                    pPartnerDisplayName = displayName,
                    pIsAvailable = isAvailable,
                    pIsOnline = isOnline,
                    pAudioEnabled = audioEnabled,
                    pChatEnabled = chatEnabled
                )
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = res.errorBody()?.string() ?: "Failed to update availability"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating availability", e)
            Result.failure(e)
        }
    }

    suspend fun getPartnerProfile(): Result<PartnerProfile?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getPartnerProfile(userIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body()?.firstOrNull())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getProfile(): Result<Profile?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getProfile(idFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body()?.firstOrNull())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getBlockedUsers(): Result<List<BlockModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getBlocks(blockerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun unblockUser(blockedUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.unblockUserRpc(
                UnblockUserParams(pBlockedUserId = blockedUserId)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val rawErr = res.errorBody()?.string().orEmpty()
                val parsedMsg = try {
                    val jsonObj = org.json.JSONObject(rawErr)
                    jsonObj.optString("message", rawErr)
                } catch (_: Exception) {
                    rawErr.ifBlank { "Failed to unblock user" }
                }
                Result.failure(Exception(parsedMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateHostProfile(
        displayName: String?,
        bio: String? = null,
        age: Int? = null,
        avatarFile: File? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))

            // 1. Upload avatar if present to existing profile-media bucket
            if (avatarFile != null && avatarFile.exists()) {
                val filename = "avatar_${System.currentTimeMillis()}.jpg"
                val storagePath = "$authUuid/$filename"
                val body = avatarFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val uploadRes = supabaseClient.storageService.uploadObject(
                    bucket = "profile-media",
                    path = storagePath,
                    contentType = "image/jpeg",
                    body = body
                )
                if (uploadRes.isSuccessful) {
                    val avatarUrl = "profile-media/$storagePath"
                    val rpcRes = supabaseClient.restService.updateMyProfileAvatar(
                        UpdateMyProfileAvatarParams(pAvatarPath = avatarUrl)
                    )
                    if (!rpcRes.isSuccessful) {
                        Log.w(TAG, "updateMyProfileAvatar rpc failed: ${rpcRes.errorBody()?.string()}")
                    }
                    privateMediaRepository?.invalidateCache("profile-media")
                    privateMediaRepository?.loadProfileImage(avatarUrl, forceRefresh = true)
                } else {
                    val err = uploadRes.errorBody()?.string() ?: "Avatar upload failed"
                    Log.w(TAG, "Avatar upload failed: $err")
                }
            }

            // 2. Update display name in profile and partner_profile
            if (!displayName.isNullOrBlank()) {
                supabaseClient.restService.updateMyProfile(
                    UpdateMyProfileParams(
                        pDisplayName = displayName.trim(),
                        pBio = bio?.trim(),
                        pAge = age
                    )
                )

                val currentPartner = getPartnerProfile().getOrNull()
                supabaseClient.restService.updateMyPartnerProfile(
                    UpdateMyPartnerProfileParams(
                        pPartnerDisplayName = displayName.trim(),
                        pIsAvailable = currentPartner?.isAvailable ?: false,
                        pIsOnline = currentPartner?.isOnline ?: false,
                        pAudioEnabled = currentPartner?.audioEnabled ?: false,
                        pChatEnabled = currentPartner?.chatEnabled ?: false
                    )
                )
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating host profile", e)
            Result.failure(e)
        }
    }

    suspend fun getReviews(): Result<List<ReviewModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getReviews(partnerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class CallRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager,
    private val agoraCallManager: AgoraCallManager
) {
    private val TAG = "CallRepository"
    private val callerProfileCache = java.util.concurrent.ConcurrentHashMap<String, Profile>()

    suspend fun resolveCallerProfile(callerUserId: String): Profile? = withContext(Dispatchers.IO) {
        if (callerUserId.isBlank()) return@withContext null
        callerProfileCache[callerUserId]?.let { return@withContext it }

        try {
            // 1. Direct lookup in public.profiles table
            val profileRes = supabaseClient.restService.getProfile(idFilter = "eq.$callerUserId")
            if (profileRes.isSuccessful && !profileRes.body().isNullOrEmpty()) {
                val prof = profileRes.body()!!.first()
                if (!prof.displayName.isNullOrBlank() || !prof.avatarUrl.isNullOrBlank()) {
                    callerProfileCache[callerUserId] = prof
                    return@withContext prof
                }
            }

            val authUuid = sessionManager.authUuid.value ?: return@withContext null
            // 2. Authoritative: resolve participant profile using conversation lookup & RPC
            val convsRes = supabaseClient.restService.getConversations(partnerIdFilter = "eq.$authUuid")
            if (convsRes.isSuccessful) {
                val conv = convsRes.body()?.find { it.userId == callerUserId }
                if (conv != null) {
                    val rpcRes = supabaseClient.restService.getConversationParticipantProfile(
                        GetConversationParticipantProfileParams(
                            pConversationId = conv.id,
                            pParticipantId = callerUserId
                        )
                    )
                    if (rpcRes.isSuccessful) {
                        val raw = rpcRes.body()?.string()?.trim() ?: ""
                        var dName: String? = null
                        var aUrl: String? = null
                        if (raw.startsWith("[")) {
                            val arr = org.json.JSONArray(raw)
                            if (arr.length() > 0) {
                                val obj = arr.getJSONObject(0)
                                dName = if (obj.has("display_name") && !obj.isNull("display_name")) obj.getString("display_name") else null
                                aUrl = if (obj.has("avatar_url") && !obj.isNull("avatar_url")) obj.getString("avatar_url") else null
                            }
                        } else if (raw.startsWith("{")) {
                            val obj = org.json.JSONObject(raw)
                            dName = if (obj.has("display_name") && !obj.isNull("display_name")) obj.getString("display_name") else null
                            aUrl = if (obj.has("avatar_url") && !obj.isNull("avatar_url")) obj.getString("avatar_url") else null
                        }

                        if (!dName.isNullOrBlank() && !isUuid(dName)) {
                            val prof = Profile(
                                id = callerUserId,
                                displayName = dName,
                                avatarUrl = aUrl
                            )
                            callerProfileCache[callerUserId] = prof
                            return@withContext prof
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not resolve caller profile for $callerUserId: ${e.message}")
        }
        null
    }

    suspend fun checkForIncomingCall(): Result<CallModel?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getIncomingCalls(partnerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                val call = res.body()?.firstOrNull()
                if (call != null) {
                    val needsResolution = call.userProfile == null || call.userProfile.displayName.isNullOrBlank() || isUuid(call.userProfile.displayName) || call.userProfile.displayName == "Baatly User" || call.userProfile.avatarUrl.isNullOrBlank()
                    if (needsResolution && call.userId.isNotBlank()) {
                        val resolved = resolveCallerProfile(call.userId)
                        if (resolved != null) {
                            return@withContext Result.success(call.copy(userProfile = resolved))
                        }
                    }
                }
                Result.success(call)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCallById(callId: String): Result<CallModel?> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getCallById(idFilter = "eq.$callId")
            if (res.isSuccessful) {
                val call = res.body()?.firstOrNull()
                if (call != null) {
                    val needsResolution = call.userProfile == null || call.userProfile.displayName.isNullOrBlank() || isUuid(call.userProfile.displayName) || call.userProfile.displayName == "Baatly User" || call.userProfile.avatarUrl.isNullOrBlank()
                    if (needsResolution && call.userId.isNotBlank()) {
                        val resolved = resolveCallerProfile(call.userId)
                        if (resolved != null) {
                            return@withContext Result.success(call.copy(userProfile = resolved))
                        }
                    }
                }
                Result.success(call)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markCallRinging(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.updateCallState(
                UpdateCallStateParams(pCallId = callId, pNewStatus = "ringing")
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to update call to ringing"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun acceptCall(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.updateCallState(
                UpdateCallStateParams(pCallId = callId, pNewStatus = "accepted")
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to accept call"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rejectCall(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.updateCallState(
                UpdateCallStateParams(pCallId = callId, pNewStatus = "rejected")
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to reject call"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchAgoraToken(channelName: String): Result<AgoraTokenResponse> = withContext(Dispatchers.IO) {
        try {
            val supabaseUrl = sessionManager.getSupabaseUrl()
            val supabaseKey = sessionManager.getSupabasePublishableKey()
            val agoraAppId = sessionManager.getAgoraAppId()

            if (supabaseUrl.isBlank()) {
                return@withContext Result.failure(Exception("Android configuration missing: SUPABASE_URL is not configured"))
            }
            if (supabaseKey.isBlank()) {
                return@withContext Result.failure(Exception("Android configuration missing: SUPABASE_PUBLISHABLE_KEY is not configured"))
            }
            if (agoraAppId.isBlank()) {
                return@withContext Result.failure(Exception("Agora configuration problem: AGORA_APP_ID is not configured"))
            }

            val res = supabaseClient.edgeService.getAgoraToken(AgoraTokenRequest(channelName = channelName))
            if (res.isSuccessful && res.body() != null) {
                Result.success(res.body()!!)
            } else {
                val errBody = res.errorBody()?.string() ?: ""
                val code = res.code()
                val diagnosticMessage = when {
                    code == 401 || code == 403 -> "Supabase authentication/session problem (HTTP $code): $errBody"
                    code == 404 -> "agora-token Edge Function environment problem: Endpoint not found (HTTP 404)"
                    code >= 500 -> "agora-token Edge Function environment problem (HTTP $code): $errBody"
                    errBody.contains("AGORA_APP_CERTIFICATE", ignoreCase = true) || errBody.contains("AGORA_APP_ID", ignoreCase = true) ->
                        "agora-token Edge Function environment problem: Missing Agora server environment variables ($errBody)"
                    errBody.contains("supabaseKey", ignoreCase = true) ->
                        "Supabase authentication/session problem: $errBody"
                    else -> "Failed to get Agora token (HTTP $code): ${errBody.ifBlank { "Unknown server error" }}"
                }
                Result.failure(Exception(diagnosticMessage))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Network or connection failure fetching Agora token: ${e.message}", e))
        }
    }

    suspend fun markCallConnected(callId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.updateCallState(
                UpdateCallStateParams(pCallId = callId, pNewStatus = "connected")
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to update call to connected"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun endCall(callId: String): Result<SettleCallResponse> = withContext(Dispatchers.IO) {
        try {
            agoraCallManager.leaveChannel()
            // 1. Transition call status to completed
            supabaseClient.restService.updateCallState(
                UpdateCallStateParams(pCallId = callId, pNewStatus = "completed")
            )

            // 2. Authoritative backend settlement (settle exactly once, idempotent)
            val settleRes = supabaseClient.restService.settleCall(SettleCallParams(pCallId = callId))
            if (settleRes.isSuccessful) {
                val rawBody = settleRes.body()?.string() ?: "{}"
                val settleObj = try {
                    val json = org.json.JSONObject(rawBody)
                    SettleCallResponse(
                        success = json.optBoolean("success", true),
                        callId = json.optString("call_id", callId),
                        conversationId = json.optString("conversation_id", null),
                        durationSeconds = json.optInt("duration_seconds", 0),
                        userCoinsCharged = json.optInt("user_coins_charged", 0),
                        partnerEarning = json.optDouble("partner_earning", 0.0),
                        maxDurationSeconds = if (json.has("max_duration_seconds")) json.optInt("max_duration_seconds") else null,
                        alreadySettled = json.optBoolean("already_settled", false)
                    )
                } catch (e: Exception) {
                    // Fallback to reading the updated call row from calls table
                    val callRow = supabaseClient.restService.getCallById(idFilter = "eq.$callId").body()?.firstOrNull()
                    SettleCallResponse(
                        success = true,
                        callId = callId,
                        durationSeconds = callRow?.durationSeconds ?: 0,
                        userCoinsCharged = callRow?.userCoinsCharged ?: 0,
                        partnerEarning = callRow?.partnerEarning ?: 0.0
                    )
                }
                Result.success(settleObj)
            } else {
                // Fetch call row directly if RPC had a conflict/already settled
                val callRow = supabaseClient.restService.getCallById(idFilter = "eq.$callId").body()?.firstOrNull()
                Result.success(
                    SettleCallResponse(
                        success = true,
                        callId = callId,
                        durationSeconds = callRow?.durationSeconds ?: 0,
                        userCoinsCharged = callRow?.userCoinsCharged ?: 0,
                        partnerEarning = callRow?.partnerEarning ?: 0.0
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun enforceCallBalanceLimit(callId: String): Result<EnforceCallBalanceLimitResponse> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.enforceCallBalanceLimit(EnforceCallBalanceLimitParams(pCallId = callId))
            if (res.isSuccessful) {
                val rawBody = res.body()?.string() ?: "{}"
                val json = org.json.JSONObject(rawBody)
                val response = EnforceCallBalanceLimitResponse(
                    shouldDisconnect = json.optBoolean("should_disconnect", false),
                    reason = json.optString("reason", null),
                    remainingSeconds = if (json.has("remaining_seconds")) json.optInt("remaining_seconds") else null,
                    userCoinsRemaining = if (json.has("user_coins_remaining")) json.optInt("user_coins_remaining") else null
                )
                Result.success(response)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getRecentCalls(): Result<List<CallModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getPartnerCalls(partnerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                val calls = res.body() ?: emptyList()
                val enriched = calls.map { call ->
                    val needsResolution = call.userProfile?.displayName.isNullOrBlank() || isUuid(call.userProfile?.displayName) || call.userProfile?.displayName == "Baatly User"
                    if (needsResolution && call.userId.isNotBlank()) {
                        val resolved = resolveCallerProfile(call.userId)
                        if (resolved != null) {
                            call.copy(userProfile = resolved)
                        } else {
                            call
                        }
                    } else {
                        call
                    }
                }
                Result.success(enriched)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAverageCallDuration(): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val callsRes = getRecentCalls()
            if (callsRes.isSuccess) {
                val completed = callsRes.getOrNull()?.filter { it.status == "completed" }?.take(30) ?: emptyList()
                if (completed.isEmpty()) {
                    Result.success(0)
                } else {
                    val totalDuration = completed.sumOf { it.durationSeconds ?: 0 }
                    val avg = totalDuration / completed.size
                    Result.success(avg)
                }
            } else {
                Result.failure(callsRes.exceptionOrNull() ?: Exception("Failed to load calls"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class ChatRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "ChatRepository"

    suspend fun getParticipantProfile(conversationId: String, participantId: String): Result<ConversationParticipantProfile> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getConversationParticipantProfile(
                GetConversationParticipantProfileParams(
                    pConversationId = conversationId,
                    pParticipantId = participantId
                )
            )
            if (res.isSuccessful) {
                val rawJson = res.body()?.string()?.trim()
                if (!rawJson.isNullOrBlank()) {
                    var userId: String? = null
                    var displayName: String? = null
                    var avatarUrl: String? = null

                    if (rawJson.startsWith("[")) {
                        val jsonArray = org.json.JSONArray(rawJson)
                        if (jsonArray.length() > 0) {
                            val obj = jsonArray.getJSONObject(0)
                            userId = if (obj.has("user_id") && !obj.isNull("user_id")) obj.getString("user_id") else null
                            displayName = if (obj.has("display_name") && !obj.isNull("display_name")) obj.getString("display_name") else null
                            avatarUrl = if (obj.has("avatar_url") && !obj.isNull("avatar_url")) obj.getString("avatar_url") else null
                        }
                    } else if (rawJson.startsWith("{")) {
                        val obj = org.json.JSONObject(rawJson)
                        userId = if (obj.has("user_id") && !obj.isNull("user_id")) obj.getString("user_id") else null
                        displayName = if (obj.has("display_name") && !obj.isNull("display_name")) obj.getString("display_name") else null
                        avatarUrl = if (obj.has("avatar_url") && !obj.isNull("avatar_url")) obj.getString("avatar_url") else null
                    }

                    Result.success(
                        ConversationParticipantProfile(
                            userId = userId ?: participantId,
                            displayName = displayName,
                            avatarUrl = avatarUrl
                        )
                    )
                } else {
                    Result.success(ConversationParticipantProfile(userId = participantId))
                }
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching participant profile", e)
            Result.failure(e)
        }
    }

    suspend fun getConversations(): Result<List<ConversationModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getConversations(partnerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                val rawList = res.body() ?: emptyList()

                val enriched = rawList.map { conv ->
                    var profile = conv.userProfile

                    // Authoritative: resolve participant profile using get_conversation_participant_profile
                    val needsResolution = profile == null || profile.displayName.isNullOrBlank() || isUuid(profile.displayName) || profile.displayName == "Baatly User"
                    if (needsResolution) {
                        try {
                            val partRes = getParticipantProfile(conv.id, conv.userId)
                            if (partRes.isSuccess) {
                                val p = partRes.getOrNull()
                                if (p != null) {
                                    val resolvedName = p.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                                    profile = Profile(
                                        id = p.userId ?: conv.userId,
                                        displayName = resolvedName ?: profile?.displayName,
                                        avatarUrl = p.avatarUrl ?: profile?.avatarUrl,
                                        username = profile?.username
                                    )
                                }
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to resolve participant profile for conv ${conv.id}: ${e.message}")
                        }
                    }

                    var latestMsg: MessageModel? = conv.lastMessage
                    var unread = conv.unreadCount ?: 0
                    try {
                        val msgRes = supabaseClient.restService.getMessages(conversationIdFilter = "eq.${conv.id}")
                        if (msgRes.isSuccessful && !msgRes.body().isNullOrEmpty()) {
                            val msgs = msgRes.body()!!
                            val effectiveClearedAt = listOfNotNull(conv.partnerClearedAt, conv.userClearedAt).maxOrNull()
                            val visibleMsgs = if (!effectiveClearedAt.isNullOrBlank()) {
                                msgs.filter { m -> m.createdAt == null || m.createdAt > effectiveClearedAt }
                            } else {
                                msgs
                            }
                            latestMsg = visibleMsgs.lastOrNull()
                            unread = visibleMsgs.count { it.receiverId == authUuid && it.readAt == null }
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to fetch messages for conv ${conv.id}: ${e.message}")
                    }

                    conv.copy(
                        userProfile = profile,
                        lastMessage = latestMsg,
                        unreadCount = unread
                    )
                }

                Result.success(enriched)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMessages(
        conversationId: String,
        partnerClearedAt: String? = null,
        userClearedAt: String? = null
    ): Result<List<MessageModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getMessages(conversationIdFilter = "eq.$conversationId")
            if (res.isSuccessful) {
                val allMsgs = res.body() ?: emptyList()
                val effectiveClearedAt = listOfNotNull(partnerClearedAt, userClearedAt).maxOrNull()
                val visibleMsgs = if (!effectiveClearedAt.isNullOrBlank()) {
                    allMsgs.filter { m -> m.createdAt == null || m.createdAt > effectiveClearedAt }
                } else {
                    allMsgs
                }
                Result.success(visibleMsgs)
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markMessagesAsRead(conversationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())

            supabaseClient.restService.markMessagesAsRead(
                conversationIdFilter = "eq.$conversationId",
                receiverIdFilter = "eq.$authUuid",
                body = mapOf("read_at" to nowIso)
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendTextMessage(conversationId: String, receiverId: String, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.sendMessage(
                SendMessageParams(
                    pConversationId = conversationId,
                    pReceiverId = receiverId,
                    pMessageType = "text",
                    pMessageText = text,
                    pMediaUrl = null,
                    pMediaDurationSeconds = null
                )
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = res.errorBody()?.string() ?: "Failed to send message"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendImageMessage(conversationId: String, receiverId: String, imageFile: File): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val filename = "img_${System.currentTimeMillis()}.jpg"
            val storagePath = "$authUuid/$filename"
            val body = imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())

            val uploadRes = supabaseClient.storageService.uploadObject(
                bucket = "chat-media",
                path = storagePath,
                contentType = "image/jpeg",
                body = body
            )

            if (!uploadRes.isSuccessful) {
                return@withContext Result.failure(Exception("Upload image failed: ${uploadRes.errorBody()?.string()}"))
            }

            val mediaUrl = "chat-media/$storagePath"
            val res = supabaseClient.restService.sendMessage(
                SendMessageParams(
                    pConversationId = conversationId,
                    pReceiverId = receiverId,
                    pMessageType = "image",
                    pMessageText = null,
                    pMediaUrl = mediaUrl,
                    pMediaDurationSeconds = null
                )
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to send image message"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendVoiceMessage(conversationId: String, receiverId: String, audioFile: File, durationSeconds: Int): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val filename = "voice_${System.currentTimeMillis()}.m4a"
            val storagePath = "$authUuid/$filename"
            val body = audioFile.asRequestBody("audio/mp4".toMediaTypeOrNull())

            val uploadRes = supabaseClient.storageService.uploadObject(
                bucket = "chat-media",
                path = storagePath,
                contentType = "audio/mp4",
                body = body
            )

            if (!uploadRes.isSuccessful) {
                return@withContext Result.failure(Exception("Upload voice message failed: ${uploadRes.errorBody()?.string()}"))
            }

            val mediaUrl = "chat-media/$storagePath"
            val res = supabaseClient.restService.sendMessage(
                SendMessageParams(
                    pConversationId = conversationId,
                    pReceiverId = receiverId,
                    pMessageType = "voice",
                    pMessageText = null,
                    pMediaUrl = mediaUrl,
                    pMediaDurationSeconds = durationSeconds
                )
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to send voice message"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getGifts(): Result<List<GiftModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getGifts()
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getReceivedGiftTransactions(): Result<List<GiftTransactionModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getGiftTransactions(receiverIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearConversation(conversationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.clearMyConversation(
                ClearMyConversationParams(pConversationId = conversationId)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to clear conversation"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun blockUser(blockedUserId: String, reason: String? = "Blocked by host"): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.blockUser(
                BlockUserParams(pBlockedUserId = blockedUserId, pReason = reason)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to block user"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun unblockUser(blockedUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.unblockUserRpc(
                UnblockUserParams(pBlockedUserId = blockedUserId)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val rawErr = res.errorBody()?.string().orEmpty()
                val parsedMsg = try {
                    val jsonObj = org.json.JSONObject(rawErr)
                    jsonObj.optString("message", rawErr)
                } catch (_: Exception) {
                    rawErr.ifBlank { "Failed to unblock user" }
                }
                Result.failure(Exception(parsedMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getStoryById(storyId: String): Result<com.example.data.models.SocialStoryModel?> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getSocialStoryById(idFilter = "eq.$storyId")
            if (res.isSuccessful) {
                Result.success(res.body()?.firstOrNull())
            } else {
                Result.failure(Exception(res.errorBody()?.string() ?: "Failed to fetch story"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class TodayEarningsBreakdown(
    val totalToday: Double = 0.0,
    val callEarningsToday: Double = 0.0,
    val chatEarningsToday: Double = 0.0,
    val giftEarningsToday: Double = 0.0
)

class WalletRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "WalletRepository"

    suspend fun getWallet(): Result<WalletModel?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getWallet(userIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body()?.firstOrNull())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTransactions(): Result<List<TransactionModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid() ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getTransactions(userIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTodayEarningsBreakdown(): Result<TodayEarningsBreakdown> = withContext(Dispatchers.IO) {
        try {
            val txsRes = getTransactions()
            if (txsRes.isSuccess) {
                val txs = txsRes.getOrNull() ?: emptyList()
                val calendar = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val startOfDay = calendar.time

                val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }

                var total = 0.0
                var calls = 0.0
                var chats = 0.0
                var gifts = 0.0

                for (tx in txs) {
                    val createdAtDate = try {
                        tx.createdAt?.let { isoFormat.parse(it.substring(0, 19)) }
                    } catch (_: Exception) { null }

                    val isToday = createdAtDate != null && createdAtDate.after(startOfDay)
                    if (isToday || createdAtDate == null) {
                        val amount = tx.cashAmount ?: 0.0
                        when (tx.transactionType) {
                            "partner_call_earning" -> {
                                calls += amount
                                total += amount
                            }
                            "partner_chat_earning" -> {
                                chats += amount
                                total += amount
                            }
                            "partner_gift_earning" -> {
                                gifts += amount
                                total += amount
                            }
                        }
                    }
                }

                Result.success(
                    TodayEarningsBreakdown(
                        totalToday = total,
                        callEarningsToday = calls,
                        chatEarningsToday = chats,
                        giftEarningsToday = gifts
                    )
                )
            } else {
                Result.failure(txsRes.exceptionOrNull() ?: Exception("Failed to load transactions"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getWithdrawals(): Result<List<WithdrawalModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val res = supabaseClient.restService.getWithdrawals(partnerIdFilter = "eq.$authUuid")
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                Result.failure(Exception(res.errorBody()?.string()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestWithdrawal(
        amount: Double,
        accountHolderName: String,
        accountNumber: String,
        ifscCode: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.requestPartnerWithdrawal(
                RequestPartnerWithdrawalParams(
                    pRequestedAmount = amount,
                    pAccountHolderName = accountHolderName,
                    pAccountNumber = accountNumber,
                    pIfscCode = ifscCode
                )
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val rawErr = res.errorBody()?.string().orEmpty()
                val parsedMsg = try {
                    val jsonObj = org.json.JSONObject(rawErr)
                    jsonObj.optString("message", rawErr)
                } catch (_: Exception) {
                    rawErr.ifBlank { "Failed to submit withdrawal request" }
                }
                Result.failure(Exception(parsedMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
