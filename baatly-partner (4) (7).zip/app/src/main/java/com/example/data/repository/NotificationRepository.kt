package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.NotificationItemModel
import com.example.data.models.RegisterFcmTokenParams
import com.example.data.models.TokenActionParams
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class NotificationRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    companion object {
        private const val TAG = "NotificationRepository"
    }

    private fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    /**
     * Obtains the FCM token and synchronizes it with the authenticated Supabase partner profile.
     */
    suspend fun syncFcmToken(force: Boolean = false): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = try {
                FirebaseMessaging.getInstance().token.await()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to retrieve Firebase FCM token: ${e.message}")
                sessionManager.getStoredFcmToken()
            }

            if (token.isNullOrBlank()) {
                return@withContext Result.failure(IllegalStateException("FCM Token not available"))
            }

            sessionManager.saveFcmToken(token)

            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
            if (authUuid.isNullOrBlank()) {
                Log.d(TAG, "Partner not yet authenticated, FCM token safely stored locally for post-login sync")
                return@withContext Result.success(token)
            }

            val lastRegisteredToken = sessionManager.getLastRegisteredFcmToken()
            val lastRegisteredAuth = sessionManager.getLastRegisteredAuthUuid()

            if (!force && token == lastRegisteredToken && authUuid == lastRegisteredAuth) {
                Log.d(TAG, "FCM token already synchronized for current partner account")
                return@withContext Result.success(token)
            }

            Log.d(TAG, "Registering FCM token for partner $authUuid...")
            var registered = false

            // Try standard RPC register_fcm_token
            try {
                val resp = supabaseClient.restService.registerFcmToken(
                    RegisterFcmTokenParams(pToken = token, pDeviceType = "android")
                )
                if (resp.isSuccessful) {
                    registered = true
                    Log.d(TAG, "Successfully registered FCM token via RPC register_fcm_token")
                } else {
                    Log.w(TAG, "RPC register_fcm_token returned ${resp.code()}, trying map RPC")
                }
            } catch (e: Exception) {
                Log.w(TAG, "RPC register_fcm_token error: ${e.message}")
            }

            // Try alternate parameter names in RPC
            if (!registered) {
                try {
                    val resp = supabaseClient.restService.registerFcmTokenMap(
                        mapOf(
                            "token" to token,
                            "fcm_token" to token,
                            "p_token" to token,
                            "device_type" to "android",
                            "p_device_type" to "android"
                        )
                    )
                    if (resp.isSuccessful) {
                        registered = true
                        Log.d(TAG, "Successfully registered FCM token via alternate RPC map")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Alternate RPC register_fcm_token error: ${e.message}")
                }
            }

            // Direct device_tokens table upsert fallback
            if (!registered) {
                try {
                    val resp = supabaseClient.restService.upsertDeviceToken(
                        body = mapOf(
                            "user_id" to authUuid,
                            "token" to token,
                            "fcm_token" to token,
                            "device_type" to "android",
                            "is_active" to true,
                            "updated_at" to currentIsoTimestamp()
                        )
                    )
                    if (resp.isSuccessful) {
                        registered = true
                        Log.d(TAG, "Successfully upserted device token directly in device_tokens table")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Direct device_tokens upsert error: ${e.message}")
                }
            }

            if (registered) {
                sessionManager.setLastRegisteredFcmToken(token, authUuid)
                Result.success(token)
            } else {
                Result.failure(Exception("Failed to register FCM token with Supabase backend"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "syncFcmToken unexpected error", e)
            Result.failure(e)
        }
    }

    /**
     * Deactivates/unregisters this device's FCM token upon logout.
     */
    suspend fun deactivateFcmToken(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = sessionManager.getStoredFcmToken() ?: return@withContext Result.success(Unit)
        Log.d(TAG, "Deactivating FCM token for current device...")

        try {
            // Try deactivate_fcm_token RPC
            try {
                supabaseClient.restService.deactivateFcmToken(TokenActionParams(pToken = token))
            } catch (_: Exception) {}

            try {
                supabaseClient.restService.unregisterFcmToken(TokenActionParams(pToken = token))
            } catch (_: Exception) {}

            try {
                supabaseClient.restService.deactivateFcmTokenMap(
                    mapOf("token" to token, "fcm_token" to token, "p_token" to token)
                )
            } catch (_: Exception) {}

            // Try direct device_tokens table deactivation
            try {
                supabaseClient.restService.deactivateDeviceToken(
                    tokenFilter = "eq.$token",
                    body = mapOf(
                        "is_active" to false,
                        "updated_at" to currentIsoTimestamp()
                    )
                )
            } catch (_: Exception) {}

            sessionManager.setLastRegisteredFcmToken(null, null)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deactivateFcmToken error", e)
            sessionManager.setLastRegisteredFcmToken(null, null)
            Result.success(Unit)
        }
    }

    /**
     * Fetches notifications for current partner from Supabase backend.
     */
    suspend fun getNotifications(): Result<List<NotificationItemModel>> = withContext(Dispatchers.IO) {
        val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
            ?: return@withContext Result.failure(IllegalStateException("Not logged in"))

        try {
            val resp = supabaseClient.restService.getNotifications(userIdFilter = "eq.$authUuid")
            if (resp.isSuccessful && resp.body() != null) {
                Result.success(resp.body()!!)
            } else {
                Result.failure(Exception("Failed to fetch notifications: ${resp.code()}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "getNotifications error", e)
            Result.failure(e)
        }
    }

    /**
     * Marks a specific notification as read in Supabase.
     */
    suspend fun markNotificationAsRead(notificationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (notificationId.isBlank()) return@withContext Result.success(Unit)

        try {
            val resp = supabaseClient.restService.markNotificationAsRead(
                idFilter = "eq.$notificationId",
                body = mapOf(
                    "is_read" to true,
                    "read_at" to currentIsoTimestamp()
                )
            )
            if (resp.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to mark notification as read: ${resp.code()}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "markNotificationAsRead error", e)
            Result.failure(e)
        }
    }
}
