package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AudioPlayerHelper
import com.example.data.audio.AudioRecorderHelper
import com.example.data.local.SessionManager
import com.example.data.models.ConversationModel
import com.example.data.models.ConversationParticipantProfile
import com.example.data.models.GiftModel
import com.example.data.models.GiftTransactionModel
import com.example.data.models.MessageModel
import com.example.data.repository.ChatRepository
import com.example.data.repository.PrivateMediaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val sessionManager: SessionManager,
    val audioRecorderHelper: AudioRecorderHelper,
    val audioPlayerHelper: AudioPlayerHelper,
    val privateMediaRepository: PrivateMediaRepository
) : ViewModel() {

    private val _conversations = MutableStateFlow<List<ConversationModel>>(emptyList())
    val conversations: StateFlow<List<ConversationModel>> = _conversations.asStateFlow()

    private val _activeMessages = MutableStateFlow<List<MessageModel>>(emptyList())
    val activeMessages: StateFlow<List<MessageModel>> = _activeMessages.asStateFlow()

    private val messagesCache = java.util.concurrent.ConcurrentHashMap<String, List<MessageModel>>()

    private val _gifts = MutableStateFlow<List<GiftModel>>(emptyList())
    val gifts: StateFlow<List<GiftModel>> = _gifts.asStateFlow()

    private val _receivedGifts = MutableStateFlow<List<GiftTransactionModel>>(emptyList())
    val receivedGifts: StateFlow<List<GiftTransactionModel>> = _receivedGifts.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _activeParticipantProfile = MutableStateFlow<ConversationParticipantProfile?>(null)
    val activeParticipantProfile: StateFlow<ConversationParticipantProfile?> = _activeParticipantProfile.asStateFlow()

    private val _storyPreviews = MutableStateFlow<Map<String, com.example.data.models.SocialStoryModel?>>(emptyMap())
    val storyPreviews: StateFlow<Map<String, com.example.data.models.SocialStoryModel?>> = _storyPreviews.asStateFlow()

    private var messagePollerJob: Job? = null
    private var conversationPollerJob: Job? = null
    private var currentConversationId: String? = null
    private var currentParticipantId: String? = null

    val currentAuthUuid: String?
        get() = sessionManager.authUuid.value

    init {
        loadConversations()
        loadGifts()
        loadReceivedGifts()
        startConversationPoller()
    }

    private fun startConversationPoller() {
        conversationPollerJob?.cancel()
        conversationPollerJob = viewModelScope.launch {
            while (isActive) {
                delay(5000)
                val res = chatRepository.getConversations()
                if (res.isSuccess) {
                    _conversations.value = res.getOrNull() ?: emptyList()
                }
            }
        }
    }

    fun loadConversations() {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.getConversations()
            if (res.isSuccess) {
                _conversations.value = res.getOrNull() ?: emptyList()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message
            }
            _isLoading.value = false
        }
    }

    fun openConversation(conversationId: String, participantId: String? = null) {
        currentConversationId = conversationId
        currentParticipantId = participantId
        _activeParticipantProfile.value = null

        val cached = messagesCache[conversationId]
        if (!cached.isNullOrEmpty()) {
            _activeMessages.value = cached
        }

        val conv = _conversations.value.find { it.id == conversationId }
        val targetParticipantId = participantId ?: conv?.userId

        if (!targetParticipantId.isNullOrBlank()) {
            viewModelScope.launch {
                val pRes = chatRepository.getParticipantProfile(conversationId, targetParticipantId)
                if (pRes.isSuccess) {
                    _activeParticipantProfile.value = pRes.getOrNull()
                }
            }
        }

        loadMessages(conversationId)
        startMessagePoller(conversationId)

        viewModelScope.launch {
            chatRepository.markMessagesAsRead(conversationId)
            val res = chatRepository.getConversations()
            if (res.isSuccess) {
                _conversations.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    fun closeConversation() {
        messagePollerJob?.cancel()
        audioPlayerHelper.stopAudio()
        currentConversationId?.let { id ->
            if (_activeMessages.value.isNotEmpty()) {
                messagesCache[id] = _activeMessages.value
            }
        }
        currentConversationId = null
        currentParticipantId = null
        _activeParticipantProfile.value = null
    }

    fun loadMessages(conversationId: String) {
        viewModelScope.launch {
            val conv = _conversations.value.find { it.id == conversationId }
            val res = chatRepository.getMessages(conversationId, conv?.partnerClearedAt, conv?.userClearedAt)
            if (res.isSuccess) {
                val list = res.getOrNull() ?: emptyList()
                if (list.isNotEmpty()) {
                    messagesCache[conversationId] = list
                    if (currentConversationId == conversationId) {
                        _activeMessages.value = list
                    }
                } else {
                    val cached = messagesCache[conversationId]
                    if (cached.isNullOrEmpty() && currentConversationId == conversationId) {
                        _activeMessages.value = emptyList()
                    }
                }
            }
        }
    }

    private fun startMessagePoller(conversationId: String) {
        messagePollerJob?.cancel()
        messagePollerJob = viewModelScope.launch {
            while (isActive) {
                delay(3000)
                val conv = _conversations.value.find { it.id == conversationId }
                val res = chatRepository.getMessages(conversationId, conv?.partnerClearedAt, conv?.userClearedAt)
                if (res.isSuccess) {
                    val list = res.getOrNull() ?: emptyList()
                    if (list.isNotEmpty()) {
                        messagesCache[conversationId] = list
                        if (currentConversationId == conversationId) {
                            _activeMessages.value = list
                        }
                    }
                }
            }
        }
    }

    fun sendTextMessage(conversationId: String, receiverId: String, text: String) {
        if (text.trim().isBlank()) return
        val currentAuth = currentAuthUuid ?: ""
        val optimisticMsg = MessageModel(
            id = "temp_${System.currentTimeMillis()}",
            conversationId = conversationId,
            senderId = currentAuth,
            receiverId = receiverId,
            messageType = "text",
            messageText = text.trim(),
            createdAt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())
        )
        val updated = _activeMessages.value + optimisticMsg
        _activeMessages.value = updated
        messagesCache[conversationId] = updated

        viewModelScope.launch {
            val res = chatRepository.sendTextMessage(conversationId, receiverId, text.trim())
            if (res.isSuccess) {
                loadMessages(conversationId)
                loadConversations()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send message"
            }
        }
    }

    fun sendImageMessage(conversationId: String, receiverId: String, imageFile: File) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.sendImageMessage(conversationId, receiverId, imageFile)
            if (res.isSuccess) {
                loadMessages(conversationId)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send image"
            }
            _isLoading.value = false
        }
    }

    fun sendVoiceMessage(conversationId: String, receiverId: String, audioFile: File, durationSeconds: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.sendVoiceMessage(conversationId, receiverId, audioFile, durationSeconds)
            if (res.isSuccess) {
                loadMessages(conversationId)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send voice message"
            }
            _isLoading.value = false
        }
    }

    fun playVoiceMessage(rawMediaUrl: String) {
        viewModelScope.launch {
            val resolved = privateMediaRepository.loadChatVoice(rawMediaUrl) ?: rawMediaUrl
            audioPlayerHelper.playAudio(resolved)
        }
    }

    fun loadGifts() {
        viewModelScope.launch {
            val res = chatRepository.getGifts()
            if (res.isSuccess) {
                _gifts.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    fun loadReceivedGifts() {
        viewModelScope.launch {
            val res = chatRepository.getReceivedGiftTransactions()
            if (res.isSuccess) {
                _receivedGifts.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    private val storyCache = java.util.concurrent.ConcurrentHashMap<String, com.example.data.models.SocialStoryModel>()
    private val storyLoadingIds = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    fun getStoryPreview(storyId: String): com.example.data.models.SocialStoryModel? {
        return storyCache[storyId]
    }

    fun fetchStoryPreview(storyId: String, onLoaded: (com.example.data.models.SocialStoryModel?) -> Unit = {}) {
        storyCache[storyId]?.let {
            onLoaded(it)
            return
        }
        if (!storyLoadingIds.add(storyId)) return
        viewModelScope.launch {
            try {
                val res = chatRepository.getStoryById(storyId)
                if (res.isSuccess) {
                    res.getOrNull()?.let { story ->
                        storyCache[storyId] = story
                    }
                }
            } catch (_: Exception) {
            } finally {
                storyLoadingIds.remove(storyId)
                onLoaded(storyCache[storyId])
            }
        }
    }

    fun clearConversation(conversationId: String, onCleared: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            // Immediately clear local UI and cached messages
            messagesCache[conversationId] = emptyList()
            if (currentConversationId == conversationId) {
                _activeMessages.value = emptyList()
            }
            val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())

            _conversations.value = _conversations.value.map { conv ->
                if (conv.id == conversationId) {
                    conv.copy(
                        lastMessage = null,
                        lastMessageAt = null,
                        unreadCount = 0,
                        partnerClearedAt = nowIso,
                        userClearedAt = nowIso
                    )
                } else conv
            }

            val res = chatRepository.clearConversation(conversationId)
            if (res.isSuccess) {
                messagesCache.remove(conversationId)
                _activeMessages.value = emptyList()
                loadConversations()
                onCleared()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to clear chat"
            }
            _isLoading.value = false
        }
    }

    fun blockUser(userId: String, onBlocked: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.blockUser(userId)
            if (res.isSuccess) {
                _conversations.value = _conversations.value.map { conv ->
                    if (conv.userId == userId) {
                        conv.copy(partnerBlocked = true)
                    } else conv
                }
                loadConversations()
                onBlocked()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to block user"
            }
            _isLoading.value = false
        }
    }

    fun unblockUser(userId: String, onUnblocked: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.unblockUser(userId)
            if (res.isSuccess) {
                _conversations.value = _conversations.value.map { conv ->
                    if (conv.userId == userId) {
                        conv.copy(partnerBlocked = false, userBlocked = false)
                    } else conv
                }
                loadConversations()
                onUnblocked()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to unblock user"
            }
            _isLoading.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        messagePollerJob?.cancel()
        audioPlayerHelper.stopAudio()
    }
}

class ChatViewModelFactory(
    private val chatRepository: ChatRepository,
    private val sessionManager: SessionManager,
    private val audioRecorderHelper: AudioRecorderHelper,
    private val audioPlayerHelper: AudioPlayerHelper,
    private val privateMediaRepository: PrivateMediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(chatRepository, sessionManager, audioRecorderHelper, audioPlayerHelper, privateMediaRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

