package com.example.ui.screens.home

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

data class HostShortcutItem(
    val title: String,
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconTintColor: Color,
    val route: String
)

@Composable
fun HomeScreen(
    mainViewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val uiData by mainViewModel.uiData.collectAsState()

    val shortcuts = listOf(
        HostShortcutItem("HISTORY", Icons.Default.History, BaatlyPrimaryLight, BaatlyPrimary, "recent_calls"),
        HostShortcutItem("WALLET", Icons.Default.AccountBalanceWallet, BaatlyGreenLight, BaatlyGreen, "wallet"),
        HostShortcutItem("RULES", Icons.Default.MenuBook, BaatlyGoldLight, BaatlyGold, "frame_niyam"),
        HostShortcutItem("BLOCKS", Icons.Default.Block, BaatlyRedLight, BaatlyRed, "blocked_users"),
        HostShortcutItem("KAMAI", Icons.Default.MonetizationOn, BaatlyGoldLight, BaatlyGold, "call_kamai"),
        HostShortcutItem("SKILLS", Icons.Default.Psychology, BaatlyBlueLight, BaatlyBlue, "skills"),
        HostShortcutItem("LEARN", Icons.Default.PlayCircle, BaatlyCyanLight, BaatlyCyan, "training"),
        HostShortcutItem("STRIKE", Icons.Default.Gavel, BaatlyRedLight, BaatlyRed, "strike_niyam"),
        HostShortcutItem("REFER", Icons.Default.Share, BaatlyPurpleLight, BaatlyPurple, "refer"),
        HostShortcutItem("MALL", Icons.Default.Storefront, BaatlySlateLight, BaatlySlate, "mall")
    )

    val avgMinutes = uiData.averageCallDurationSeconds / 60
    val avgSeconds = uiData.averageCallDurationSeconds % 60
    val avgDurationStr = String.format("%02d:%02d", avgMinutes, avgSeconds)

    val hostId = uiData.profile?.userId?.uppercase() ?: if (uiData.isLoading) "..." else "BAATLY_HOST"
    val displayName = uiData.partnerProfile?.partnerDisplayName ?: uiData.profile?.displayName ?: if (uiData.isLoading) "Loading..." else "Baatly Host"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BaatlyLightBackground)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Professional Header
        Surface(
            color = Color.White,
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val avatarUrl = uiData.profile?.avatarUrl
                    val privateMediaRepo = (LocalContext.current.applicationContext as BaatlyApp).privateMediaRepository
                    val resolvedAvatarUrl by rememberProfileAvatarUrl(avatarUrl, privateMediaRepo)
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(2.dp, BaatlyPrimary, CircleShape)
                    ) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                contentDescription = "Host Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = displayName.take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = displayName,
                            color = TextPrimaryLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ID: $hostId",
                            color = TextSecondaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                IconButton(
                    onClick = { mainViewModel.loadAllData() },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(BaatlyLightSurfaceVariant)
                        .testTag("refresh_home_button")
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = TextSecondaryLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Content Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            // Indigo Hero Earnings Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BaatlyPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("wallet") }
                    .testTag("today_earnings_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF4F46E5),
                                    Color(0xFF4338CA)
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Today's Earnings",
                                color = Color(0xFFE0E7FF),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "LIVE",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (uiData.isLoading && uiData.partnerProfile == null) {
                            Box(modifier = Modifier.padding(vertical = 4.dp)) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.5.dp
                                )
                            }
                        } else {
                            Text(
                                text = "₹${String.format("%.2f", uiData.todayEarnings.totalToday)}",
                                color = Color.White,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Divider(color = Color.White.copy(alpha = 0.2f), thickness = 1.dp)

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "CALLS",
                                    color = Color(0xFFC7D2FE),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "₹${String.format("%.2f", uiData.todayEarnings.callEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "CHATS",
                                    color = Color(0xFFC7D2FE),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "₹${String.format("%.2f", uiData.todayEarnings.chatEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "GIFTS",
                                    color = Color(0xFFC7D2FE),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "₹${String.format("%.2f", uiData.todayEarnings.giftEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Service Availability Controls (Grid 2 cols with custom pill switches)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Call Service Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mainViewModel.toggleCallAvailability(!uiData.isCallOnline) }
                        .testTag("call_service_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp, horizontal = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Switch Pill
                        Box(
                            modifier = Modifier
                                .width(48.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(if (uiData.isCallOnline) BaatlyGreen else Color(0xFFCBD5E1))
                                .padding(3.dp),
                            contentAlignment = if (uiData.isCallOnline) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .shadow(2.dp, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "CALL SERVICE",
                            color = TextPrimaryLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (uiData.isCallOnline) "ONLINE" else "OFFLINE",
                            color = if (uiData.isCallOnline) BaatlyGreen else TextSecondaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Chat Service Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mainViewModel.toggleChatAvailability(!uiData.isChatOnline) }
                        .testTag("chat_service_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp, horizontal = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Switch Pill
                        Box(
                            modifier = Modifier
                                .width(48.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(if (uiData.isChatOnline) BaatlyBlue else Color(0xFFCBD5E1))
                                .padding(3.dp),
                            contentAlignment = if (uiData.isChatOnline) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .shadow(2.dp, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "CHAT SERVICE",
                            color = TextPrimaryLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (uiData.isChatOnline) "ONLINE" else "OFFLINE",
                            color = if (uiData.isChatOnline) BaatlyBlue else TextSecondaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Average Call Duration Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BaatlyGoldLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                tint = BaatlyGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Avg. Call Duration",
                                color = TextPrimaryLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Last 30 completed calls",
                                color = TextSecondaryLight,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Text(
                        text = avgDurationStr,
                        color = BaatlyGold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Professional Polish Action Grid (4 Columns)
            val chunkedShortcuts = shortcuts.chunked(4)
            chunkedShortcuts.forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowItems.forEach { item ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(88.dp)
                                .padding(vertical = 4.dp)
                                .clickable {
                                    if (item.route == "refer") {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Join Baatly Partner App as an Audio Jockey Host! Register here: https://baatly.com/partner")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, "Share Baatly Partner"))
                                    } else {
                                        onNavigate(item.route)
                                    }
                                }
                                .testTag("shortcut_${item.route}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(item.iconBgColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        item.icon,
                                        contentDescription = item.title,
                                        tint = item.iconTintColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.title,
                                    color = TextSecondaryLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 11.sp
                                )
                            }
                        }
                    }
                    // Pad empty spots if incomplete row
                    for (i in 0 until (4 - rowItems.size)) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Need Help / WhatsApp Support Banner
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = BaatlyPrimaryLight),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyPrimaryBorder, BaatlyPrimaryBorder))),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val url = "https://wa.me/8744048708?text=Hello%20Baatly%20Support,%20I%20need%20assistance"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    }
                    .testTag("shortcut_support")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.HeadsetMic,
                                contentDescription = null,
                                tint = BaatlyPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Need Help?",
                                color = Color(0xFF312E81), // Indigo 900
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Contact Support via WhatsApp",
                                color = BaatlyPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BaatlyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = "Contact WhatsApp",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
