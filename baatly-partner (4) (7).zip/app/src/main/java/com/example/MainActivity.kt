package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.notification.NotificationRouter
import com.example.ui.MainApp
import com.example.ui.theme.BaatlyPartnerTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Handle notification intent on cold start
    NotificationRouter.handleIntent(intent)

    val baatlyApp = application as BaatlyApp
    setContent {
      BaatlyPartnerTheme {
        MainApp(app = baatlyApp)
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    // Handle notification intent when app is already running in background / foreground
    NotificationRouter.handleIntent(intent)
  }
}


