package com.example.ui.screens.social

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.example.data.models.*
import com.example.data.repository.PrivateMediaRepository
import com.example.data.repository.rememberPrivateStorageUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.SocialViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(
    socialViewModel: SocialViewModel,
    privateMediaRepo: PrivateMediaRepository,
    hostUserId: String
) {
    val context = LocalContext.current
    val feedPosts by socialViewModel.feedPosts.collectAsState()
    val stories by socialViewModel.stories.collectAsState()
    val hostProfile by socialViewModel.hostSocialProfile.collectAsState()
    val hostEarnings by socialViewModel.hostSocialEarnings.collectAsState()
    val isLoadingFeed by socialViewModel.isLoadingFeed.collectAsState()
    val isPosting by socialViewModel.isPosting.collectAsState()
    val isUploadingStory by socialViewModel.isUploadingStory.collectAsState()

    val searchQuery by socialViewModel.searchQuery.collectAsState()
    val isSearching by socialViewModel.isSearching.collectAsState()
    val searchResult by socialViewModel.searchResult.collectAsState()
    val searchError by socialViewModel.searchError.collectAsState()

    val selectedUserProfile by socialViewModel.selectedUserProfile.collectAsState()
    val selectedUserPosts by socialViewModel.selectedUserPosts.collectAsState()
    val selectedUserStories by socialViewModel.selectedUserStories.collectAsState()

    val hostPosts by socialViewModel.hostPosts.collectAsState()
    val hostStories by socialViewModel.hostStories.collectAsState()

    val activeCommentPostId by socialViewModel.activeCommentPostId.collectAsState()
    val comments by socialViewModel.comments.collectAsState()
    val isLoadingComments by socialViewModel.isLoadingComments.collectAsState()
    val isPostingComment by socialViewModel.isPostingComment.collectAsState()

    val activeStoryViewerList by socialViewModel.activeStoryViewerList.collectAsState()
    val activeStoryViewerIndex by socialViewModel.activeStoryViewerIndex.collectAsState()

    val errorMessage by socialViewModel.errorMessage.collectAsState()
    val successMessage by socialViewModel.successMessage.collectAsState()

    var isSearchExpanded by remember { mutableStateOf(false) }
    var showCreateContentChoice by remember { mutableStateOf(false) }
    var showCreatePostDialog by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var showHostSocialProfileFullScreen by remember { mutableStateOf(false) }
    var showHostSocialEarningsDialog by remember { mutableStateOf(false) }
    var showEditHostProfileDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
    }

    LaunchedEffect(successMessage) {
        successMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
    }

    // Full Screen Host Profile View
    if (showHostSocialProfileFullScreen) {
        HostSocialProfileFullScreen(
            hostProfile = hostProfile,
            hostPosts = hostPosts,
            hostStories = hostStories,
            hostEarnings = hostEarnings,
            privateMediaRepo = privateMediaRepo,
            onBack = { showHostSocialProfileFullScreen = false },
            onEditProfileClick = { showEditHostProfileDialog = true },
            onEarningsClick = { showHostSocialEarningsDialog = true },
            onStoryClick = { storyList, idx ->
                socialViewModel.openStoryViewer(storyList, idx)
            },
            onPostLike = { post -> socialViewModel.toggleLikePost(post) },
            onPostComment = { post -> socialViewModel.openComments(post.id) }
        )
    }
    // Full Screen User Profile View (NO CALL BUTTON)
    else if (selectedUserProfile != null) {
        val user = selectedUserProfile!!
        UserSocialProfileFullScreen(
            user = user,
            posts = selectedUserPosts,
            stories = selectedUserStories,
            privateMediaRepo = privateMediaRepo,
            onBack = { socialViewModel.closeUserProfile() },
            onFollowToggle = { socialViewModel.toggleFollowUser(user.userId, user.isFollowing == true) },
            onStoryClick = { storyList, idx ->
                socialViewModel.openStoryViewer(storyList, idx)
            },
            onPostLike = { post -> socialViewModel.toggleLikePost(post) },
            onPostComment = { post -> socialViewModel.openComments(post.id) }
        )
    }
    // Main Social Feed
    else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Baatly Social",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = BaatlyPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = BaatlyPrimaryLight
                            ) {
                                Text(
                                    text = "HOST",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BaatlyPrimary,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    actions = {
                        // Toggle Search
                        IconButton(
                            onClick = {
                                isSearchExpanded = !isSearchExpanded
                                if (!isSearchExpanded) socialViewModel.clearSearch()
                            },
                            modifier = Modifier.testTag("social_search_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isSearchExpanded) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search Users",
                                tint = if (isSearchExpanded) BaatlyPrimary else TextPrimaryLight
                            )
                        }

                        // Create Content (+)
                        IconButton(
                            onClick = { showCreateContentChoice = true },
                            modifier = Modifier.testTag("social_create_content_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddCircleOutline,
                                contentDescription = "Create Post or Story",
                                tint = BaatlyPrimary
                            )
                        }

                        // Host Social Profile icon (opens Host's Social Profile Full Screen)
                        IconButton(
                            onClick = {
                                socialViewModel.loadHostSocialProfile()
                                socialViewModel.loadHostSocialEarnings()
                                showHostSocialProfileFullScreen = true
                            },
                            modifier = Modifier.testTag("social_host_profile_button")
                        ) {
                            val hostAvatarUrl = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
                            val resolvedHostAvatar = rememberPrivateStorageUrl(rawUrl = hostAvatarUrl, privateMediaRepo = privateMediaRepo).value

                            if (!resolvedHostAvatar.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedHostAvatar,
                                    contentDescription = "Host Social Profile",
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, BaatlyPrimary, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(BaatlyPrimaryLight)
                                        .border(1.5.dp, BaatlyPrimary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Host Social Profile",
                                        tint = BaatlyPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White,
                        titleContentColor = TextPrimaryLight
                    )
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = BaatlyLightBackground
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("social_feed_list")
                ) {
                    // Search Bar Expandable
                    if (isSearchExpanded) {
                        item(key = "search_section") {
                            SocialSearchSection(
                                searchQuery = searchQuery,
                                isSearching = isSearching,
                                searchResult = searchResult,
                                searchError = searchError,
                                onQueryChange = { socialViewModel.setSearchQuery(it) },
                                onSearch = { socialViewModel.performSearch() },
                                onClear = { socialViewModel.clearSearch() },
                                onSelectUser = { user -> socialViewModel.openUserProfile(user) },
                                privateMediaRepo = privateMediaRepo
                            )
                        }
                    }

                    // Stories Row
                    item(key = "stories_row") {
                        StoriesRowSection(
                            stories = stories,
                            hostProfile = hostProfile,
                            onAddStoryClick = { showCreateStoryDialog = true },
                            onStoryClick = { storyList, index ->
                                socialViewModel.openStoryViewer(storyList, index)
                            },
                            privateMediaRepo = privateMediaRepo
                        )
                        Divider(color = BaatlyLightBorder, thickness = 1.dp)
                    }

                    // Feed Posts
                    if (feedPosts.isEmpty() && !isLoadingFeed) {
                        item(key = "empty_feed") {
                            EmptySocialFeed(
                                onCreatePostClick = { showCreatePostDialog = true }
                            )
                        }
                    } else {
                        items(
                            items = feedPosts,
                            key = { it.id }
                        ) { post ->
                            SocialPostCard(
                                post = post,
                                hostUserId = hostUserId,
                                privateMediaRepo = privateMediaRepo,
                                onLikeClick = { socialViewModel.toggleLikePost(post) },
                                onCommentClick = { socialViewModel.openComments(post.id) },
                                onFollowClick = { socialViewModel.toggleFollowUser(post.userId, post.isFollowing == true) },
                                onUserClick = {
                                    if (post.userId != hostUserId) {
                                        val userResult = SocialSearchResult(
                                            userId = post.userId,
                                            signupUserId = post.profile?.userId ?: post.profile?.username,
                                            displayName = post.profile?.displayName ?: "Baatly User",
                                            username = post.profile?.username,
                                            avatarUrl = post.profile?.avatarUrl,
                                            socialAvatarUrl = post.socialProfile?.socialAvatarUrl ?: post.profile?.avatarUrl,
                                            bio = post.socialProfile?.bio ?: post.profile?.bio,
                                            hobbies = post.socialProfile?.hobbies,
                                            followersCount = post.socialProfile?.followersCount ?: post.profile?.followersCount ?: 0,
                                            followingCount = post.socialProfile?.followingCount ?: post.profile?.followingCount ?: 0,
                                            totalLikes = post.socialProfile?.totalLikes ?: 0,
                                            totalViews = post.socialProfile?.totalViews ?: 0,
                                            isHost = false,
                                            isPartner = false,
                                            isFollowing = post.isFollowing == true
                                        )
                                        socialViewModel.openUserProfile(userResult)
                                    } else {
                                        showHostSocialProfileFullScreen = true
                                    }
                                }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }

                if (isLoadingFeed && feedPosts.isEmpty()) {
                    CircularProgressIndicator(
                        color = BaatlyPrimary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }

    // Choice Dialog: Create Post vs Create Story
    if (showCreateContentChoice) {
        AlertDialog(
            onDismissRequest = { showCreateContentChoice = false },
            title = { Text("Create Social Content", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            showCreateContentChoice = false
                            showCreatePostDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("choose_create_post_button")
                    ) {
                        Icon(Icons.Default.PostAdd, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Create Post", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            showCreateContentChoice = false
                            showCreateStoryDialog = true
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("choose_create_story_button")
                    ) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = BaatlyPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Add Story (Live 24 Hours)", fontWeight = FontWeight.Bold, color = BaatlyPrimary)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showCreateContentChoice = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            }
        )
    }

    // Create Post Dialog
    if (showCreatePostDialog) {
        CreatePostDialog(
            isPosting = isPosting,
            onDismiss = { showCreatePostDialog = false },
            onSubmit = { file, caption ->
                socialViewModel.createPost(file, caption) { success ->
                    if (success) showCreatePostDialog = false
                }
            }
        )
    }

    // Create Story Dialog
    if (showCreateStoryDialog) {
        CreateStoryDialog(
            isUploading = isUploadingStory,
            onDismiss = { showCreateStoryDialog = false },
            onSubmit = { file, caption ->
                socialViewModel.createStory(file, caption) { success ->
                    if (success) showCreateStoryDialog = false
                }
            }
        )
    }

    // Edit Host Social Profile Dialog
    if (showEditHostProfileDialog) {
        EditHostSocialProfileDialog(
            currentProfile = hostProfile,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { showEditHostProfileDialog = false },
            onSave = { bio, hobbies, avatarFile ->
                socialViewModel.updateHostSocialProfile(bio, hobbies, avatarFile) {
                    showEditHostProfileDialog = false
                }
            }
        )
    }

    // Host Social Earnings Dialog (Confidential Host-Only)
    if (showHostSocialEarningsDialog) {
        HostSocialEarningsDialog(
            earnings = hostEarnings,
            onDismiss = { showHostSocialEarningsDialog = false }
        )
    }

    // Comments Sheet
    if (activeCommentPostId != null) {
        CommentsBottomSheet(
            comments = comments,
            isLoading = isLoadingComments,
            isPosting = isPostingComment,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { socialViewModel.closeComments() },
            onPostComment = { text -> socialViewModel.postComment(text) }
        )
    }

    // Fullscreen Story Viewer
    activeStoryViewerList?.let { storyList ->
        FullscreenStoryViewer(
            stories = storyList,
            initialIndex = activeStoryViewerIndex,
            privateMediaRepo = privateMediaRepo,
            onClose = { socialViewModel.closeStoryViewer() },
            onNext = { socialViewModel.nextStory() },
            onPrev = { socialViewModel.prevStory() }
        )
    }
}

// -------------------------------------------------------------------------------------------------
// STORIES ROW
// -------------------------------------------------------------------------------------------------

@Composable
fun StoriesRowSection(
    stories: List<SocialStoryModel>,
    hostProfile: SocialProfileModel?,
    onAddStoryClick: () -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    privateMediaRepo: PrivateMediaRepository
) {
    // Group stories by user
    val userStoryGroups = remember(stories) {
        stories.groupBy { it.userId }
    }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        // "Add Story" Button (Host's story button)
        item(key = "add_story_item") {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onAddStoryClick() }
                    .testTag("add_story_button")
            ) {
                Box(
                    contentAlignment = Alignment.BottomEnd,
                    modifier = Modifier.size(68.dp)
                ) {
                    val hostAvatar = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
                    val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = hostAvatar, privateMediaRepo = privateMediaRepo).value

                    if (!resolvedAvatar.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatar,
                            contentDescription = "Your Story",
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .border(2.dp, BaatlyPrimaryLight, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight)
                                .border(2.dp, BaatlyPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = BaatlyPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    // Plus badge
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(BaatlyPrimary)
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Story",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your Story",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextPrimaryLight
                )
            }
        }

        // Active Stories by other users
        items(
            items = userStoryGroups.entries.toList(),
            key = { it.key }
        ) { entry ->
            val userStories = entry.value
            val firstStory = userStories.first()
            val userName = firstStory.profile?.displayName ?: firstStory.profile?.username ?: "User"
            val userAvatar = firstStory.socialProfile?.socialAvatarUrl ?: firstStory.profile?.avatarUrl
            val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = userAvatar, privateMediaRepo = privateMediaRepo).value

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onStoryClick(userStories, 0) }
                    .testTag("story_user_${entry.key}")
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(BaatlyPrimary, BaatlyGold, BaatlyPrimaryLight)
                            )
                        )
                        .padding(2.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(Color.White)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!resolvedAvatar.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatar,
                                contentDescription = userName,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = userName.take(1).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = BaatlyPrimary,
                                    fontSize = 18.sp
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = userName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    color = TextPrimaryLight,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 70.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// SEARCH SECTION
// -------------------------------------------------------------------------------------------------

@Composable
fun SocialSearchSection(
    searchQuery: String,
    isSearching: Boolean,
    searchResult: SocialSearchResult?,
    searchError: String?,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
    onSelectUser: (SocialSearchResult) -> Unit,
    privateMediaRepo: PrivateMediaRepository
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("social_search_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Search User by User ID...", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = BaatlyPrimary)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = onClear) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondaryLight)
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("social_search_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onSearch,
                    enabled = searchQuery.isNotBlank() && !isSearching,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("social_search_submit_button")
                ) {
                    if (isSearching) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    } else {
                        Text("Search", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Error display (e.g. Host profile restriction warning)
            if (searchError != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BaatlyRedLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = searchError,
                            color = BaatlyRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Search Result Card
            if (searchResult != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BaatlyLightBackground),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectUser(searchResult) }
                        .testTag("searched_user_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = searchResult.socialAvatarUrl ?: searchResult.avatarUrl
                        val resolved = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        if (!resolved.isNullOrBlank()) {
                            AsyncImage(
                                model = resolved,
                                contentDescription = searchResult.displayName,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (searchResult.displayName ?: "U").take(1).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = BaatlyPrimary,
                                    fontSize = 20.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = searchResult.displayName ?: "Baatly User",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = searchResult.handle,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = BaatlyPrimary
                            )
                            if (!searchResult.bio.isNullOrBlank()) {
                                Text(
                                    text = searchResult.bio,
                                    fontSize = 11.sp,
                                    color = TextSecondaryLight,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Button(
                            onClick = { onSelectUser(searchResult) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("view_searched_user_button")
                        ) {
                            Text("View", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// POST CARD
// -------------------------------------------------------------------------------------------------

@Composable
fun SocialPostCard(
    post: SocialPostModel,
    hostUserId: String,
    privateMediaRepo: PrivateMediaRepository,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onFollowClick: () -> Unit,
    onUserClick: () -> Unit
) {
    val authorName = post.profile?.displayName ?: post.profile?.username ?: "Baatly User"
    val authorAvatar = post.socialProfile?.socialAvatarUrl ?: post.profile?.avatarUrl
    val resolvedAuthorAvatar = rememberPrivateStorageUrl(rawUrl = authorAvatar, privateMediaRepo = privateMediaRepo).value

    val postMedia = post.mediaPath ?: post.mediaUrl
    val resolvedPostMedia = rememberPrivateStorageUrl(rawUrl = postMedia, privateMediaRepo = privateMediaRepo).value

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("social_post_${post.id}")
    ) {
        Column {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onUserClick() }
                ) {
                    if (!resolvedAuthorAvatar.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAuthorAvatar,
                            contentDescription = authorName,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = authorName.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = BaatlyPrimary,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = authorName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )
                        val authorHandle = formatSocialHandle(
                            signupUserId = post.profile?.userId,
                            username = post.profile?.username,
                            displayName = post.profile?.displayName
                        )
                        Text(
                            text = authorHandle,
                            fontSize = 11.sp,
                            color = TextSecondaryLight
                        )
                    }
                }

                // Follow button (if not self)
                if (post.userId != hostUserId) {
                    val isFollowing = post.isFollowing == true
                    OutlinedButton(
                        onClick = onFollowClick,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isFollowing) Color.Transparent else BaatlyPrimaryLight,
                            contentColor = if (isFollowing) TextSecondaryLight else BaatlyPrimary
                        ),
                        border = BorderStroke(1.dp, if (isFollowing) BaatlyLightBorder else BaatlyPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("follow_user_button_${post.userId}")
                    ) {
                        Text(
                            text = if (isFollowing) "Following" else "Follow",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Post Media Image
            if (!resolvedPostMedia.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = resolvedPostMedia,
                        contentDescription = "Post image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Interaction Row (Like, Comment, Views)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button (Host Like is FREE)
                val isLiked = post.isLiked == true
                IconButton(
                    onClick = onLikeClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("like_post_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like Post",
                        tint = if (isLiked) BaatlyRed else TextPrimaryLight,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = "${post.likesCount ?: 0}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.width(16.dp))

                // Comment Button (Host Comment is FREE)
                IconButton(
                    onClick = onCommentClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("comment_post_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = TextPrimaryLight,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Text(
                    text = "${post.commentsCount ?: 0}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.weight(1f))

                // Views Count
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Visibility,
                        contentDescription = "Views",
                        tint = TextSecondaryLight,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${post.viewsCount ?: 0} views",
                        fontSize = 12.sp,
                        color = TextSecondaryLight
                    )
                }
            }

            // Caption
            if (!post.caption.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "$authorName  ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = post.caption,
                        fontSize = 13.sp,
                        color = TextPrimaryLight
                    )
                }
            }

            // View all comments button
            if ((post.commentsCount ?: 0) > 0) {
                TextButton(
                    onClick = onCommentClick,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    modifier = Modifier.testTag("view_comments_button_${post.id}")
                ) {
                    Text(
                        text = "View all ${post.commentsCount} comments",
                        color = TextSecondaryLight,
                        fontSize = 12.sp
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// EMPTY FEED
// -------------------------------------------------------------------------------------------------

@Composable
fun EmptySocialFeed(onCreatePostClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.PhotoCamera,
            contentDescription = null,
            tint = BaatlyPrimary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Welcome to Baatly Social",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = TextPrimaryLight
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Share photos, create stories, and connect with users.",
            fontSize = 13.sp,
            color = TextSecondaryLight,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onCreatePostClick,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
            modifier = Modifier.testTag("empty_feed_create_post_button")
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Create First Post", fontWeight = FontWeight.Bold)
        }
    }
}

// -------------------------------------------------------------------------------------------------
// HOST SOCIAL PROFILE FULL SCREEN
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostSocialProfileFullScreen(
    hostProfile: SocialProfileModel?,
    hostPosts: List<SocialPostModel>,
    hostStories: List<SocialStoryModel>,
    hostEarnings: SocialEarningsModel?,
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit,
    onEditProfileClick: () -> Unit,
    onEarningsClick: () -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    onPostLike: (SocialPostModel) -> Unit,
    onPostComment: (SocialPostModel) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Posts, 1: Stories
    var selectedPostForDetail by remember { mutableStateOf<SocialPostModel?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Host Social Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("host_profile_back_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .testTag("host_social_profile_screen")
        ) {
            // Profile Card Header
            Card(
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Profile Header Row (Avatar + Stats)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
                        val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        if (!resolvedAvatar.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatar,
                                contentDescription = "Host Avatar",
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.5.dp, BaatlyPrimary, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight)
                                    .border(2.5.dp, BaatlyPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (hostProfile?.profile?.displayName ?: "H").take(1).uppercase(),
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BaatlyPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Stats Row
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ProfileStatItem("Followers", hostProfile?.followersCount ?: 0)
                            ProfileStatItem("Following", hostProfile?.followingCount ?: 0)
                            ProfileStatItem("Likes", hostProfile?.totalLikes ?: 0)
                            ProfileStatItem("Views", hostProfile?.totalViews ?: 0)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Account Identity Display: NEVER UUID!
                    Text(
                        text = hostProfile?.profile?.displayName ?: "Host",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = hostProfile?.handle ?: "@host",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = BaatlyPrimary
                    )

                    // Bio & Hobbies
                    if (!hostProfile?.bio.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = hostProfile?.bio ?: "",
                            fontSize = 13.sp,
                            color = TextPrimaryLight
                        )
                    }
                    if (!hostProfile?.hobbies.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hobbies: ${hostProfile?.hobbies}",
                            fontSize = 12.sp,
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Actions: Edit Profile & Social Earnings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onEditProfileClick,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("edit_social_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = BaatlyPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit Profile", fontWeight = FontWeight.Bold, color = BaatlyPrimary, fontSize = 13.sp)
                        }

                        Button(
                            onClick = onEarningsClick,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("social_earnings_button")
                        ) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Social Earnings", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tabs: Posts vs Stories
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = BaatlyPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Posts (${hostPosts.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Stories (${hostStories.size})", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (selectedTab == 0) {
                if (hostPosts.isEmpty()) {
                    Text(
                        text = "No posts created yet",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .heightIn(max = 600.dp)
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(hostPosts) { post ->
                            val postMedia = post.mediaPath ?: post.mediaUrl
                            val resolved = rememberPrivateStorageUrl(rawUrl = postMedia, privateMediaRepo = privateMediaRepo).value

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black)
                                    .clickable { selectedPostForDetail = post }
                            ) {
                                if (!resolved.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolved,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                if (hostStories.isEmpty()) {
                    Text(
                        text = "No active stories (Stories expire after 24h)",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(hostStories) { story ->
                            val media = story.mediaPath ?: story.mediaUrl
                            val resolved = rememberPrivateStorageUrl(rawUrl = media, privateMediaRepo = privateMediaRepo).value

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .size(width = 110.dp, height = 160.dp)
                                    .clickable { onStoryClick(hostStories, hostStories.indexOf(story)) }
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    if (!resolved.isNullOrBlank()) {
                                        AsyncImage(
                                            model = resolved,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Detail dialog if tapping a post in host profile
    selectedPostForDetail?.let { post ->
        PostDetailDialog(
            post = post,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { selectedPostForDetail = null },
            onLikeClick = { onPostLike(post) },
            onCommentClick = {
                selectedPostForDetail = null
                onPostComment(post)
            }
        )
    }
}

@Composable
fun ProfileStatItem(label: String, count: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimaryLight
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondaryLight
        )
    }
}

// -------------------------------------------------------------------------------------------------
// EDIT HOST SOCIAL PROFILE DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun EditHostSocialProfileDialog(
    currentProfile: SocialProfileModel?,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onSave: (bio: String?, hobbies: String?, avatarFile: File?) -> Unit
) {
    val context = LocalContext.current
    var editBio by remember { mutableStateOf(currentProfile?.bio ?: "") }
    var editHobbies by remember { mutableStateOf(currentProfile?.hobbies ?: "") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Edit Social Profile",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Identity from Baatly Signup (${currentProfile?.profile?.displayName ?: "Host"})",
                    fontSize = 12.sp,
                    color = TextSecondaryLight
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Avatar edit
                Box(
                    contentAlignment = Alignment.BottomEnd,
                    modifier = Modifier.clickable { photoPicker.launch("image/*") }
                ) {
                    if (selectedImageUri != null) {
                        Image(
                            painter = rememberAsyncImagePainter(model = selectedImageUri),
                            contentDescription = "New Avatar",
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .border(2.dp, BaatlyPrimary, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        val avatarUrl = currentProfile?.socialAvatarUrl ?: currentProfile?.profile?.avatarUrl
                        val resolved = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        if (!resolved.isNullOrBlank()) {
                            AsyncImage(
                                model = resolved,
                                contentDescription = "Current Avatar",
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, BaatlyPrimary, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight)
                                    .border(2.dp, BaatlyPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(40.dp))
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(BaatlyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Change photo", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                TextButton(onClick = { photoPicker.launch("image/*") }) {
                    Text("Change Social Avatar", color = BaatlyPrimary, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bio
                OutlinedTextField(
                    value = editBio,
                    onValueChange = { editBio = it },
                    label = { Text("Bio") },
                    placeholder = { Text("Share something about yourself...") },
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_social_bio_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Hobbies
                OutlinedTextField(
                    value = editHobbies,
                    onValueChange = { editHobbies = it },
                    label = { Text("Hobbies") },
                    placeholder = { Text("e.g. Music, Traveling, Fitness") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_social_hobbies_input")
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            isSaving = true
                            val avatarFile = selectedImageUri?.let { uri ->
                                try {
                                    val inputStream = context.contentResolver.openInputStream(uri)
                                    val tempFile = File(context.cacheDir, "social_avatar_${System.currentTimeMillis()}.jpg")
                                    val outputStream = FileOutputStream(tempFile)
                                    inputStream?.copyTo(outputStream)
                                    inputStream?.close()
                                    outputStream.close()
                                    tempFile
                                } catch (_: Exception) { null }
                            }
                            onSave(editBio.trim(), editHobbies.trim(), avatarFile)
                        },
                        enabled = !isSaving,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_social_profile_button")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// HOST SOCIAL EARNINGS DIALOG (HOST-ONLY)
// -------------------------------------------------------------------------------------------------

@Composable
fun HostSocialEarningsDialog(
    earnings: SocialEarningsModel?,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("host_social_earnings_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header with Host Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Host Social Earnings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "Host-Only Confidential",
                            fontSize = 11.sp,
                            color = BaatlyPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Total Earnings Highlight Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Total Social Earnings",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${String.format("%.2f", earnings?.total ?: earnings?.totalSocialEarnings ?: 0.0)}",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Breakdown Grid
                Text(
                    text = "Earnings Breakdown",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.height(8.dp))

                EarningsRowItem(
                    title = "View Earnings",
                    amount = earnings?.viewEarnings ?: 0.0,
                    icon = Icons.Outlined.Visibility
                )
                Divider(color = BaatlyLightBorder, thickness = 0.8.dp)

                EarningsRowItem(
                    title = "Like Earnings",
                    amount = earnings?.likeEarnings ?: 0.0,
                    icon = Icons.Outlined.FavoriteBorder
                )
                Divider(color = BaatlyLightBorder, thickness = 0.8.dp)

                EarningsRowItem(
                    title = "Comment Earnings",
                    amount = earnings?.commentEarnings ?: 0.0,
                    icon = Icons.Outlined.ChatBubbleOutline
                )

                if ((earnings?.unlockEarnings ?: 0.0) > 0.0) {
                    Divider(color = BaatlyLightBorder, thickness = 0.8.dp)
                    EarningsRowItem(
                        title = "Post Unlock Earnings",
                        amount = earnings?.unlockEarnings ?: 0.0,
                        icon = Icons.Outlined.LockOpen
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EarningsRowItem(title: String, amount: Double, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = title, fontSize = 13.sp, color = TextPrimaryLight)
        }
        Text(
            text = "₹${String.format("%.2f", amount)}",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = BaatlyGreen
        )
    }
}

// -------------------------------------------------------------------------------------------------
// USER SOCIAL PROFILE FULL SCREEN (STRICT RULE: NO CALL BUTTON)
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSocialProfileFullScreen(
    user: SocialSearchResult,
    posts: List<SocialPostModel>,
    stories: List<SocialStoryModel>,
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit,
    onFollowToggle: () -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    onPostLike: (SocialPostModel) -> Unit,
    onPostComment: (SocialPostModel) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    var selectedPostForDetail by remember { mutableStateOf<SocialPostModel?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = user.displayName ?: "User Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("user_profile_back_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .testTag("user_social_profile_screen")
        ) {
            // Header Profile Card
            Card(
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Avatar + Stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = user.socialAvatarUrl ?: user.avatarUrl
                        val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        if (!resolvedAvatar.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatar,
                                contentDescription = user.displayName,
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .border(2.5.dp, BaatlyPrimaryLight, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (user.displayName ?: "U").take(1).uppercase(),
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BaatlyPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ProfileStatItem("Followers", user.followersCount ?: 0)
                            ProfileStatItem("Following", user.followingCount ?: 0)
                            ProfileStatItem("Likes", user.totalLikes ?: 0)
                            ProfileStatItem("Views", user.totalViews ?: 0)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // User Identity: Display name and @signupUserId (NEVER UUID)
                    Text(
                        text = user.displayName ?: "Baatly User",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = user.handle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = BaatlyPrimary
                    )

                    if (!user.bio.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = user.bio,
                            fontSize = 13.sp,
                            color = TextPrimaryLight
                        )
                    }
                    if (!user.hobbies.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hobbies: ${user.hobbies}",
                            fontSize = 12.sp,
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action: Follow / Unfollow (STRICT RULE: NEVER ADD A CALL BUTTON HERE)
                    val isFollowing = user.isFollowing == true
                    Button(
                        onClick = onFollowToggle,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFollowing) Color.LightGray else BaatlyPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("user_profile_follow_button")
                    ) {
                        Text(
                            text = if (isFollowing) "Following" else "Follow",
                            fontWeight = FontWeight.Bold,
                            color = if (isFollowing) TextPrimaryLight else Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Posts & Stories Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = BaatlyPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Posts (${posts.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Stories (${stories.size})", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (selectedTab == 0) {
                if (posts.isEmpty()) {
                    Text(
                        text = "No posts from this user",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .heightIn(max = 600.dp)
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(posts) { post ->
                            val postMedia = post.mediaPath ?: post.mediaUrl
                            val resolved = rememberPrivateStorageUrl(rawUrl = postMedia, privateMediaRepo = privateMediaRepo).value

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black)
                                    .clickable { selectedPostForDetail = post }
                            ) {
                                if (!resolved.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolved,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                if (stories.isEmpty()) {
                    Text(
                        text = "No active stories",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(stories) { story ->
                            val media = story.mediaPath ?: story.mediaUrl
                            val resolved = rememberPrivateStorageUrl(rawUrl = media, privateMediaRepo = privateMediaRepo).value

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .size(width = 110.dp, height = 160.dp)
                                    .clickable { onStoryClick(stories, stories.indexOf(story)) }
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    if (!resolved.isNullOrBlank()) {
                                        AsyncImage(
                                            model = resolved,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Detail dialog if tapping a post in user profile
    selectedPostForDetail?.let { post ->
        PostDetailDialog(
            post = post,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { selectedPostForDetail = null },
            onLikeClick = { onPostLike(post) },
            onCommentClick = {
                selectedPostForDetail = null
                onPostComment(post)
            }
        )
    }
}

// -------------------------------------------------------------------------------------------------
// POST DETAIL DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun PostDetailDialog(
    post: SocialPostModel,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit
) {
    val postMedia = post.mediaPath ?: post.mediaUrl
    val resolvedPostMedia = rememberPrivateStorageUrl(rawUrl = postMedia, privateMediaRepo = privateMediaRepo).value

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 24.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = post.profile?.displayName ?: "Baatly User",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = formatSocialHandle(post.profile?.userId, post.profile?.username, post.profile?.displayName),
                            fontSize = 11.sp,
                            color = TextSecondaryLight
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Divider(color = BaatlyLightBorder, thickness = 0.8.dp)

                // Image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedPostMedia.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedPostMedia,
                            contentDescription = post.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                // Action Bar (Like & Comment)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val isLiked = post.isLiked == true
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onLikeClick() }
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = if (isLiked) "Unlike" else "Like",
                            tint = if (isLiked) Color.Red else TextPrimaryLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.likesCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onCommentClick() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "Comment",
                            tint = TextPrimaryLight,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.commentsCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )
                    }
                }

                // Caption
                if (!post.caption.isNullOrBlank()) {
                    Text(
                        text = post.caption,
                        fontSize = 13.sp,
                        color = TextPrimaryLight,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// CREATE POST DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun CreatePostDialog(
    isPosting: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (File, String?) -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedUri = uri
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Create New Post",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Image preview or selector
                if (selectedUri != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .clickable { photoPicker.launch("image/*") }
                    ) {
                        Image(
                            painter = rememberAsyncImagePainter(model = selectedUri),
                            contentDescription = "Selected post image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BaatlyPrimaryLight)
                            .clickable { photoPicker.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Select Photo from Gallery", fontWeight = FontWeight.SemiBold, color = BaatlyPrimary, fontSize = 14.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Caption") },
                    placeholder = { Text("Write a caption for your post...") },
                    maxLines = 4,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_caption_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(errorMessage ?: "", color = BaatlyRed, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (selectedUri == null) {
                                errorMessage = "Please select a photo"
                                return@Button
                            }
                            val file = try {
                                val inputStream = context.contentResolver.openInputStream(selectedUri!!)
                                val tempFile = File(context.cacheDir, "post_${System.currentTimeMillis()}.jpg")
                                val outputStream = FileOutputStream(tempFile)
                                inputStream?.copyTo(outputStream)
                                inputStream?.close()
                                outputStream.close()
                                tempFile
                            } catch (e: Exception) {
                                errorMessage = "Failed to load image file"
                                return@Button
                            }
                            onSubmit(file, caption.trim())
                        },
                        enabled = !isPosting,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_post_button")
                    ) {
                        if (isPosting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Share Post", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// CREATE STORY DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun CreateStoryDialog(
    isUploading: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (File, String?) -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedUri = uri
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Add to Your Story",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Stories remain visible for 24 hours",
                    fontSize = 12.sp,
                    color = TextSecondaryLight
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Media Preview
                if (selectedUri != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black)
                            .clickable { photoPicker.launch("image/*") }
                    ) {
                        Image(
                            painter = rememberAsyncImagePainter(model = selectedUri),
                            contentDescription = "Selected story image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(BaatlyPrimaryLight)
                            .clickable { photoPicker.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Select Story Photo", fontWeight = FontWeight.SemiBold, color = BaatlyPrimary, fontSize = 14.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Story Caption (Optional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(errorMessage ?: "", color = BaatlyRed, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (selectedUri == null) {
                                errorMessage = "Please select a photo for your story"
                                return@Button
                            }
                            val file = try {
                                val inputStream = context.contentResolver.openInputStream(selectedUri!!)
                                val tempFile = File(context.cacheDir, "story_${System.currentTimeMillis()}.jpg")
                                val outputStream = FileOutputStream(tempFile)
                                inputStream?.copyTo(outputStream)
                                inputStream?.close()
                                outputStream.close()
                                tempFile
                            } catch (e: Exception) {
                                errorMessage = "Failed to load image file"
                                return@Button
                            }
                            onSubmit(file, caption.trim().takeIf { it.isNotBlank() })
                        },
                        enabled = !isUploading,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_story_button")
                    ) {
                        if (isUploading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Post Story", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// COMMENTS BOTTOM SHEET
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsBottomSheet(
    comments: List<SocialCommentModel>,
    isLoading: Boolean,
    isPosting: Boolean,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onPostComment: (String) -> Unit
) {
    var commentText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        modifier = Modifier.testTag("comments_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Comments",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BaatlyGreenLight
                    ) {
                        Text(
                            text = "FREE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BaatlyGreen,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                }
            }

            Divider(color = BaatlyLightBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            // Comments List
            Box(modifier = Modifier.weight(1f)) {
                if (comments.isEmpty() && !isLoading) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, tint = TextSecondaryLight, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No comments yet. Be the first to comment!", color = TextSecondaryLight, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(comments) { comment ->
                            val commenterName = comment.profile?.displayName ?: comment.profile?.username ?: "User"
                            val commenterAvatar = comment.profile?.avatarUrl
                            val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = commenterAvatar, privateMediaRepo = privateMediaRepo).value

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                if (!resolvedAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatar,
                                        contentDescription = commenterName,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(BaatlyPrimaryLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = commenterName.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = BaatlyPrimary,
                                            fontSize = 14.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = commenterName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimaryLight
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = comment.text,
                                        fontSize = 13.sp,
                                        color = TextPrimaryLight
                                    )
                                }
                            }
                        }
                    }
                }

                if (isLoading) {
                    CircularProgressIndicator(
                        color = BaatlyPrimary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Divider(color = BaatlyLightBorder, thickness = 1.dp)

            // Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("Add a comment...", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("comment_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (commentText.isNotBlank()) {
                            onPostComment(commentText.trim())
                            commentText = ""
                        }
                    },
                    enabled = commentText.isNotBlank() && !isPosting,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (commentText.isNotBlank()) BaatlyPrimary else BaatlyLightBorder)
                        .testTag("send_comment_button")
                ) {
                    if (isPosting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send Comment",
                            tint = if (commentText.isNotBlank()) Color.White else TextSecondaryLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// FULLSCREEN STORY VIEWER
// -------------------------------------------------------------------------------------------------

@Composable
fun FullscreenStoryViewer(
    stories: List<SocialStoryModel>,
    initialIndex: Int,
    privateMediaRepo: PrivateMediaRepository,
    onClose: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit
) {
    val currentStory = stories.getOrNull(initialIndex) ?: return
    val authorName = currentStory.profile?.displayName ?: currentStory.profile?.username ?: "Baatly User"
    val authorAvatar = currentStory.socialProfile?.socialAvatarUrl ?: currentStory.profile?.avatarUrl
    val resolvedAuthorAvatar = rememberPrivateStorageUrl(rawUrl = authorAvatar, privateMediaRepo = privateMediaRepo).value

    val storyMedia = currentStory.mediaPath ?: currentStory.mediaUrl
    val resolvedMedia = rememberPrivateStorageUrl(rawUrl = storyMedia, privateMediaRepo = privateMediaRepo).value

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Story Image
            if (!resolvedMedia.isNullOrBlank()) {
                AsyncImage(
                    model = resolvedMedia,
                    contentDescription = "Story",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }

            // Left & Right Touch Targets for navigation
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onPrev() }
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onNext() }
                )
            }

            // Top Progress Bars & Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                // Segmented Progress Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    stories.forEachIndexed { index, _ ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (index <= initialIndex) Color.White else Color.White.copy(alpha = 0.35f)
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Author Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!resolvedAuthorAvatar.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAuthorAvatar,
                            contentDescription = authorName,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = authorName.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = BaatlyPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = authorName,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close story", tint = Color.White)
                    }
                }
            }

            // Caption overlay at bottom
            if (!currentStory.caption.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 24.dp)
                ) {
                    Text(
                        text = currentStory.caption,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
