package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BaatlyApp
import com.example.data.models.*
import com.example.data.repository.SocialRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class SocialViewModel(application: Application) : AndroidViewModel(application) {
    private val socialRepository: SocialRepository =
        (application as BaatlyApp).socialRepository

    private val _feedPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val feedPosts: StateFlow<List<SocialPostModel>> = _feedPosts.asStateFlow()

    private val _stories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val stories: StateFlow<List<SocialStoryModel>> = _stories.asStateFlow()

    private val _hostSocialProfile = MutableStateFlow<SocialProfileModel?>(null)
    val hostSocialProfile: StateFlow<SocialProfileModel?> = _hostSocialProfile.asStateFlow()

    private val _hostSocialEarnings = MutableStateFlow<SocialEarningsModel?>(null)
    val hostSocialEarnings: StateFlow<SocialEarningsModel?> = _hostSocialEarnings.asStateFlow()

    private val _isLoadingFeed = MutableStateFlow(false)
    val isLoadingFeed: StateFlow<Boolean> = _isLoadingFeed.asStateFlow()

    private val _isPosting = MutableStateFlow(false)
    val isPosting: StateFlow<Boolean> = _isPosting.asStateFlow()

    private val _isUploadingStory = MutableStateFlow(false)
    val isUploadingStory: StateFlow<Boolean> = _isUploadingStory.asStateFlow()

    private val _isUpdatingProfile = MutableStateFlow(false)
    val isUpdatingProfile: StateFlow<Boolean> = _isUpdatingProfile.asStateFlow()

    // Search state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResult = MutableStateFlow<SocialSearchResult?>(null)
    val searchResult: StateFlow<SocialSearchResult?> = _searchResult.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // Active User Profile view
    private val _selectedUserProfile = MutableStateFlow<SocialSearchResult?>(null)
    val selectedUserProfile: StateFlow<SocialSearchResult?> = _selectedUserProfile.asStateFlow()

    private val _selectedUserPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val selectedUserPosts: StateFlow<List<SocialPostModel>> = _selectedUserPosts.asStateFlow()

    private val _selectedUserStories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val selectedUserStories: StateFlow<List<SocialStoryModel>> = _selectedUserStories.asStateFlow()

    // Host Profile Posts & Stories
    private val _hostPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val hostPosts: StateFlow<List<SocialPostModel>> = _hostPosts.asStateFlow()

    private val _hostStories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val hostStories: StateFlow<List<SocialStoryModel>> = _hostStories.asStateFlow()

    // Comments Sheet State
    private val _activeCommentPostId = MutableStateFlow<String?>(null)
    val activeCommentPostId: StateFlow<String?> = _activeCommentPostId.asStateFlow()

    private val _comments = MutableStateFlow<List<SocialCommentModel>>(emptyList())
    val comments: StateFlow<List<SocialCommentModel>> = _comments.asStateFlow()

    private val _isLoadingComments = MutableStateFlow(false)
    val isLoadingComments: StateFlow<Boolean> = _isLoadingComments.asStateFlow()

    private val _isPostingComment = MutableStateFlow(false)
    val isPostingComment: StateFlow<Boolean> = _isPostingComment.asStateFlow()

    // Story Viewer State
    private val _activeStoryViewerList = MutableStateFlow<List<SocialStoryModel>?>(null)
    val activeStoryViewerList: StateFlow<List<SocialStoryModel>?> = _activeStoryViewerList.asStateFlow()

    private val _activeStoryViewerIndex = MutableStateFlow(0)
    val activeStoryViewerIndex: StateFlow<Int> = _activeStoryViewerIndex.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    init {
        loadInitialData()
    }

    fun loadInitialData() {
        refreshFeed()
        loadHostSocialProfile()
        loadHostSocialEarnings()
    }

    fun refreshFeed() {
        viewModelScope.launch {
            _isLoadingFeed.value = true
            try {
                val postsRes = socialRepository.getFeedPosts()
                if (postsRes.isSuccess) {
                    _feedPosts.value = postsRes.getOrNull() ?: emptyList()
                }

                val storiesRes = socialRepository.getActiveStories()
                if (storiesRes.isSuccess) {
                    _stories.value = storiesRes.getOrNull() ?: emptyList()
                }
            } catch (e: Exception) {
                _errorMessage.value = e.message
            } finally {
                _isLoadingFeed.value = false
            }
        }
    }

    fun loadHostSocialProfile() {
        viewModelScope.launch {
            val res = socialRepository.getHostSocialProfile()
            if (res.isSuccess) {
                val profile = res.getOrNull()
                _hostSocialProfile.value = profile
                if (profile != null) {
                    loadHostPostsAndStories(profile.userId)
                }
            }
        }
    }

    fun loadHostPostsAndStories(hostUserId: String) {
        viewModelScope.launch {
            val postsRes = socialRepository.getUserPosts(hostUserId)
            if (postsRes.isSuccess) {
                _hostPosts.value = postsRes.getOrNull() ?: emptyList()
            }
            val storiesRes = socialRepository.getUserStories(hostUserId)
            if (storiesRes.isSuccess) {
                _hostStories.value = storiesRes.getOrNull() ?: emptyList()
            }
        }
    }

    fun loadHostSocialEarnings() {
        viewModelScope.launch {
            val res = socialRepository.getHostSocialEarnings()
            if (res.isSuccess) {
                _hostSocialEarnings.value = res.getOrNull()
            }
        }
    }

    fun updateHostSocialProfile(bio: String?, hobbies: String?, avatarFile: File?, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isUpdatingProfile.value = true
            _errorMessage.value = null
            val res = socialRepository.updateHostSocialProfile(bio = bio, hobbies = hobbies, avatarFile = avatarFile)
            _isUpdatingProfile.value = false
            if (res.isSuccess) {
                _hostSocialProfile.value = res.getOrNull()
                _successMessage.value = "Profile updated successfully"
                onSuccess()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to update profile"
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        _searchError.value = null
    }

    fun performSearch() {
        val query = _searchQuery.value.trim()
        if (query.isBlank()) return

        viewModelScope.launch {
            _isSearching.value = true
            _searchError.value = null
            _searchResult.value = null

            val res = socialRepository.searchUserProfile(query)
            _isSearching.value = false
            if (res.isSuccess) {
                val result = res.getOrNull()
                _searchResult.value = result
            } else {
                val ex = res.exceptionOrNull()
                val msg = ex?.message ?: "User not found"
                if (msg.contains("HOST_PROFILE_RESTRICTED", ignoreCase = true)) {
                    _searchError.value = "Cannot view Host profiles. You can search User profiles only."
                } else {
                    _searchError.value = msg
                }
            }
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchResult.value = null
        _searchError.value = null
    }

    fun openUserProfile(user: SocialSearchResult) {
        // STRICT RULE: HOST -> may NOT search/view HOST profiles
        if (user.isHost == true || user.isPartner == true) {
            _errorMessage.value = "Cannot view Host profiles. You can search User profiles only."
            return
        }

        _selectedUserProfile.value = user
        viewModelScope.launch {
            val postsRes = socialRepository.getUserPosts(user.userId)
            if (postsRes.isSuccess) {
                _selectedUserPosts.value = postsRes.getOrNull() ?: emptyList()
            }
            val storiesRes = socialRepository.getUserStories(user.userId)
            if (storiesRes.isSuccess) {
                _selectedUserStories.value = storiesRes.getOrNull() ?: emptyList()
            }
        }
    }

    fun closeUserProfile() {
        _selectedUserProfile.value = null
        _selectedUserPosts.value = emptyList()
        _selectedUserStories.value = emptyList()
    }

    fun createPost(mediaFile: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isPosting.value = true
            _errorMessage.value = null
            val res = socialRepository.createContent(type = "post", mediaFile = mediaFile, caption = caption)
            _isPosting.value = false
            if (res.isSuccess) {
                _successMessage.value = "Post shared successfully"
                refreshFeed()
                _hostSocialProfile.value?.userId?.let { loadHostPostsAndStories(it) }
                onComplete(true)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to create post"
                onComplete(false)
            }
        }
    }

    fun createStory(mediaFile: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isUploadingStory.value = true
            _errorMessage.value = null
            val res = socialRepository.createContent(type = "story", mediaFile = mediaFile, caption = caption)
            _isUploadingStory.value = false
            if (res.isSuccess) {
                _successMessage.value = "Story uploaded successfully (Live 24h)"
                refreshFeed()
                _hostSocialProfile.value?.userId?.let { loadHostPostsAndStories(it) }
                onComplete(true)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to upload story"
                onComplete(false)
            }
        }
    }

    fun toggleLikePost(post: SocialPostModel) {
        viewModelScope.launch {
            val currentLiked = post.isLiked == true
            val currentCount = post.likesCount ?: 0
            val newLiked = !currentLiked
            val newCount = if (newLiked) currentCount + 1 else maxOf(0, currentCount - 1)

            // Optimistic update
            _feedPosts.value = _feedPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }
            _selectedUserPosts.value = _selectedUserPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }
            _hostPosts.value = _hostPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }

            val res = socialRepository.toggleLike(contentType = "post", contentId = post.id, currentIsLiked = currentLiked)
            if (!res.isSuccess) {
                // Revert on failure
                _feedPosts.value = _feedPosts.value.map {
                    if (it.id == post.id) it.copy(isLiked = currentLiked, likesCount = currentCount) else it
                }
            }
        }
    }

    fun toggleFollowUser(targetUserId: String, currentIsFollowing: Boolean) {
        viewModelScope.launch {
            val newFollowing = !currentIsFollowing

            // Optimistic update
            _selectedUserProfile.value?.let { current ->
                if (current.userId == targetUserId) {
                    val followers = current.followersCount ?: 0
                    _selectedUserProfile.value = current.copy(
                        isFollowing = newFollowing,
                        followersCount = if (newFollowing) followers + 1 else maxOf(0, followers - 1)
                    )
                }
            }
            _searchResult.value?.let { current ->
                if (current.userId == targetUserId) {
                    val followers = current.followersCount ?: 0
                    _searchResult.value = current.copy(
                        isFollowing = newFollowing,
                        followersCount = if (newFollowing) followers + 1 else maxOf(0, followers - 1)
                    )
                }
            }
            _feedPosts.value = _feedPosts.value.map {
                if (it.userId == targetUserId) it.copy(isFollowing = newFollowing) else it
            }

            val res = socialRepository.toggleFollow(targetUserId, currentIsFollowing)
            if (!res.isSuccess) {
                // Revert on failure
                _selectedUserProfile.value?.let { current ->
                    if (current.userId == targetUserId) {
                        _selectedUserProfile.value = current.copy(isFollowing = currentIsFollowing)
                    }
                }
                _feedPosts.value = _feedPosts.value.map {
                    if (it.userId == targetUserId) it.copy(isFollowing = currentIsFollowing) else it
                }
            }
        }
    }

    fun openComments(postId: String) {
        _activeCommentPostId.value = postId
        _comments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            val res = socialRepository.getComments(contentId = postId)
            _isLoadingComments.value = false
            if (res.isSuccess) {
                _comments.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    fun closeComments() {
        _activeCommentPostId.value = null
        _comments.value = emptyList()
    }

    fun postComment(commentText: String) {
        val postId = _activeCommentPostId.value ?: return
        if (commentText.isBlank()) return

        viewModelScope.launch {
            _isPostingComment.value = true
            val res = socialRepository.addComment(contentType = "post", contentId = postId, commentText = commentText)
            _isPostingComment.value = false
            if (res.isSuccess) {
                // Reload comments
                val refreshComments = socialRepository.getComments(contentId = postId)
                if (refreshComments.isSuccess) {
                    _comments.value = refreshComments.getOrNull() ?: emptyList()
                }
                // Update comment count in feed
                _feedPosts.value = _feedPosts.value.map {
                    if (it.id == postId) it.copy(commentsCount = (it.commentsCount ?: 0) + 1) else it
                }
                _selectedUserPosts.value = _selectedUserPosts.value.map {
                    if (it.id == postId) it.copy(commentsCount = (it.commentsCount ?: 0) + 1) else it
                }
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to post comment"
            }
        }
    }

    fun openStoryViewer(storiesList: List<SocialStoryModel>, initialIndex: Int = 0) {
        if (storiesList.isEmpty()) return
        _activeStoryViewerList.value = storiesList
        _activeStoryViewerIndex.value = initialIndex.coerceIn(0, storiesList.size - 1)

        val story = storiesList.getOrNull(_activeStoryViewerIndex.value)
        if (story != null) {
            recordContentView("story", story.id)
        }
    }

    fun nextStory() {
        val list = _activeStoryViewerList.value ?: return
        val nextIdx = _activeStoryViewerIndex.value + 1
        if (nextIdx < list.size) {
            _activeStoryViewerIndex.value = nextIdx
            recordContentView("story", list[nextIdx].id)
        } else {
            closeStoryViewer()
        }
    }

    fun prevStory() {
        val list = _activeStoryViewerList.value ?: return
        val prevIdx = _activeStoryViewerIndex.value - 1
        if (prevIdx >= 0) {
            _activeStoryViewerIndex.value = prevIdx
            recordContentView("story", list[prevIdx].id)
        }
    }

    fun closeStoryViewer() {
        _activeStoryViewerList.value = null
        _activeStoryViewerIndex.value = 0
    }

    fun recordContentView(contentType: String, contentId: String) {
        viewModelScope.launch {
            socialRepository.viewContent(contentType = contentType, contentId = contentId)
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}

class SocialViewModelFactory(
    private val application: Application
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocialViewModel::class.java)) {
            return SocialViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
