package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

fun isUuid(str: String?): Boolean {
    if (str == null) return false
    val trimmed = str.trim()
    return trimmed.length == 36 && trimmed.count { it == '-' } == 4
}

fun formatSocialHandle(signupUserId: String?, username: String?, displayName: String?): String {
    val candidate = signupUserId?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: username?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: "user"
    return "@${candidate.removePrefix("@")}"
}

@JsonClass(generateAdapter = true)
data class SocialProfileModel(
    @Json(name = "user_id") val userId: String,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "hobbies") val hobbies: String? = null,
    @Json(name = "social_avatar_url") val socialAvatarUrl: String? = null,
    @Json(name = "followers_count") val followersCount: Int? = 0,
    @Json(name = "following_count") val followingCount: Int? = 0,
    @Json(name = "total_likes") val totalLikes: Int? = 0,
    @Json(name = "total_views") val totalViews: Int? = 0,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "profiles") val profile: Profile? = null
) {
    val handle: String
        get() = formatSocialHandle(
            signupUserId = profile?.userId,
            username = profile?.username,
            displayName = profile?.displayName
        )
}

@JsonClass(generateAdapter = true)
data class SocialPostModel(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String? = null,
    @Json(name = "user_id") val legacyUserId: String? = null,
    @Json(name = "media_path") val mediaPath: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "published_at") val publishedAt: String? = null,
    @Json(name = "visible_until") val visibleUntil: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "likes_count") val likesCount: Int? = 0,
    @Json(name = "comments_count") val commentsCount: Int? = 0,
    @Json(name = "views_count") val viewsCount: Int? = 0,
    @Json(name = "profiles") val profile: Profile? = null,
    @Json(name = "social_profiles") val socialProfile: SocialProfileModel? = null,
    @Json(name = "is_liked") val isLiked: Boolean? = false,
    @Json(name = "is_following") val isFollowing: Boolean? = false
) {
    val userId: String
        get() = ownerId ?: legacyUserId ?: ""
}

@JsonClass(generateAdapter = true)
data class SocialStoryModel(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String? = null,
    @Json(name = "user_id") val legacyUserId: String? = null,
    @Json(name = "media_path") val mediaPath: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "is_active") val isActive: Boolean? = true,
    @Json(name = "expires_at") val expiresAt: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "likes_count") val likesCount: Int? = 0,
    @Json(name = "views_count") val viewsCount: Int? = 0,
    @Json(name = "profiles") val profile: Profile? = null,
    @Json(name = "social_profiles") val socialProfile: SocialProfileModel? = null,
    @Json(name = "is_liked") val isLiked: Boolean? = false,
    @Json(name = "is_viewed") val isViewed: Boolean? = false
) {
    val userId: String
        get() = ownerId ?: legacyUserId ?: ""
}

@JsonClass(generateAdapter = true)
data class SocialContentStatsModel(
    @Json(name = "content_type") val contentType: String? = null,
    @Json(name = "content_id") val contentId: String,
    @Json(name = "owner_id") val ownerId: String? = null,
    @Json(name = "view_count") val viewCount: Int? = 0,
    @Json(name = "like_count") val likeCount: Int? = 0,
    @Json(name = "comment_count") val commentCount: Int? = 0
)

@JsonClass(generateAdapter = true)
data class SocialCommentModel(
    @Json(name = "id") val id: String,
    @Json(name = "content_type") val contentType: String? = null,
    @Json(name = "content_id") val contentId: String? = null,
    @Json(name = "post_id") val legacyPostId: String? = null,
    @Json(name = "story_id") val legacyStoryId: String? = null,
    @Json(name = "author_id") val authorId: String? = null,
    @Json(name = "user_id") val legacyUserId: String? = null,
    @Json(name = "comment") val comment: String? = null,
    @Json(name = "comment_text") val legacyCommentText: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "profiles") val profile: Profile? = null
) {
    val userId: String
        get() = authorId ?: legacyUserId ?: ""
    val text: String
        get() = comment ?: legacyCommentText ?: ""
}

@JsonClass(generateAdapter = true)
data class SocialLikeModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "content_type") val contentType: String? = null,
    @Json(name = "content_id") val contentId: String? = null,
    @Json(name = "user_id") val userId: String,
    @Json(name = "post_id") val legacyPostId: String? = null,
    @Json(name = "story_id") val legacyStoryId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialFollowModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "follower_id") val followerId: String,
    @Json(name = "following_id") val followingId: String,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialEarningsModel(
    @Json(name = "total") val total: Double? = 0.0,
    @Json(name = "total_social_earnings") val totalSocialEarnings: Double? = 0.0,
    @Json(name = "view_earnings") val viewEarnings: Double? = 0.0,
    @Json(name = "like_earnings") val likeEarnings: Double? = 0.0,
    @Json(name = "comment_earnings") val commentEarnings: Double? = 0.0,
    @Json(name = "unlock_earnings") val unlockEarnings: Double? = 0.0,
    @Json(name = "story_view") val storyView: Double? = 0.0,
    @Json(name = "post_unlock") val postUnlock: Double? = 0.0,
    @Json(name = "story_like") val storyLike: Double? = 0.0,
    @Json(name = "post_like") val postLike: Double? = 0.0,
    @Json(name = "story_reply") val storyReply: Double? = 0.0,
    @Json(name = "post_comment") val postComment: Double? = 0.0
)

@JsonClass(generateAdapter = true)
data class SocialSearchResult(
    @Json(name = "user_id") val userId: String,
    @Json(name = "signup_user_id") val signupUserId: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "username") val username: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "social_avatar_url") val socialAvatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "hobbies") val hobbies: String? = null,
    @Json(name = "followers_count") val followersCount: Int? = 0,
    @Json(name = "following_count") val followingCount: Int? = 0,
    @Json(name = "total_likes") val totalLikes: Int? = 0,
    @Json(name = "total_views") val totalViews: Int? = 0,
    @Json(name = "is_host") val isHost: Boolean? = false,
    @Json(name = "is_partner") val isPartner: Boolean? = false,
    @Json(name = "is_following") val isFollowing: Boolean? = false
) {
    val handle: String
        get() = formatSocialHandle(
            signupUserId = signupUserId,
            username = username,
            displayName = displayName
        )
}

// RPC Param models
@JsonClass(generateAdapter = true)
data class SocialEnsureProfileParams(
    @Json(name = "_dummy") val dummy: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialIsHostParams(
    @Json(name = "p_user_id") val pUserId: String
)

@JsonClass(generateAdapter = true)
data class SocialRoleParams(
    @Json(name = "p_user_id") val pUserId: String
)

@JsonClass(generateAdapter = true)
data class SocialSearchProfileParams(
    @Json(name = "p_target_user_id") val pTargetUserId: String
)

@JsonClass(generateAdapter = true)
data class SocialUpdateProfileParams(
    @Json(name = "p_bio") val pBio: String? = null,
    @Json(name = "p_hobbies") val pHobbies: String? = null,
    @Json(name = "p_avatar_url") val pAvatarUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialFollowToggleParams(
    @Json(name = "p_target_user_id") val pTargetUserId: String
)

@JsonClass(generateAdapter = true)
data class SocialUnlockPostParams(
    @Json(name = "p_post_id") val pPostId: String
)

@JsonClass(generateAdapter = true)
data class SocialCreateContentParams(
    @Json(name = "p_type") val pType: String,
    @Json(name = "p_media_path") val pMediaPath: String,
    @Json(name = "p_caption") val pCaption: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialViewContentParams(
    @Json(name = "p_content_type") val pContentType: String,
    @Json(name = "p_content_id") val pContentId: String
)

@JsonClass(generateAdapter = true)
data class SocialToggleLikeParams(
    @Json(name = "p_content_type") val pContentType: String? = "post",
    @Json(name = "p_content_id") val pContentId: String
)

@JsonClass(generateAdapter = true)
data class SocialAddCommentParams(
    @Json(name = "p_content_type") val pContentType: String? = "post",
    @Json(name = "p_content_id") val pContentId: String,
    @Json(name = "p_comment") val pComment: String
)
