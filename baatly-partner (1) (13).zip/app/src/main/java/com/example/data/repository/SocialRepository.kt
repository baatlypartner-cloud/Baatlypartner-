package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SocialRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "SocialRepository"

    /**
     * Ensures the social profile exists for the current logged-in host via authoritative RPC:
     * social_ensure_profile()
     * Then fetches and returns the social_profiles record combined with profiles.
     */
    suspend fun getHostSocialProfile(): Result<SocialProfileModel> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))

            // 1. Authoritative RPC: social_ensure_profile()
            try {
                supabaseClient.restService.socialEnsureProfile()
            } catch (e: Exception) {
                Log.w(TAG, "social_ensure_profile RPC call note: ${e.message}")
            }

            // 2. Fetch social_profiles for current user
            val socialRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$authUuid")
            val socialProfile = socialRes.body()?.firstOrNull()

            // 3. Fetch main profile
            val profileRes = supabaseClient.restService.getProfile(idFilter = "eq.$authUuid")
            val profile = profileRes.body()?.firstOrNull()

            val combined = SocialProfileModel(
                userId = authUuid,
                bio = socialProfile?.bio ?: profile?.bio,
                hobbies = socialProfile?.hobbies,
                socialAvatarUrl = socialProfile?.socialAvatarUrl ?: profile?.avatarUrl,
                followersCount = socialProfile?.followersCount ?: profile?.followersCount ?: 0,
                followingCount = socialProfile?.followingCount ?: profile?.followingCount ?: 0,
                totalLikes = socialProfile?.totalLikes ?: 0,
                totalViews = socialProfile?.totalViews ?: 0,
                createdAt = socialProfile?.createdAt ?: profile?.createdAt,
                updatedAt = socialProfile?.updatedAt ?: profile?.updatedAt,
                profile = profile
            )

            Result.success(combined)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getHostSocialProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Updates the host social profile using authoritative RPC:
     * social_update_profile(p_bio, p_hobbies, p_avatar_url)
     */
    suspend fun updateHostSocialProfile(
        bio: String?,
        hobbies: String?,
        avatarFile: File? = null
    ): Result<SocialProfileModel> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            var socialAvatarUrl: String? = null

            if (avatarFile != null && avatarFile.exists()) {
                val filename = "social_avatar_${System.currentTimeMillis()}.jpg"
                val storagePath = "$authUuid/$filename"
                val body = avatarFile.asRequestBody("image/jpeg".toMediaTypeOrNull())

                var uploadRes = supabaseClient.storageService.uploadObject(
                    bucket = "social-media",
                    path = storagePath,
                    contentType = "image/jpeg",
                    body = body
                )

                if (!uploadRes.isSuccessful) {
                    // Fallback bucket
                    uploadRes = supabaseClient.storageService.uploadObject(
                        bucket = "profile-media",
                        path = storagePath,
                        contentType = "image/jpeg",
                        body = body
                    )
                    if (uploadRes.isSuccessful) {
                        socialAvatarUrl = "profile-media/$storagePath"
                    }
                } else {
                    socialAvatarUrl = "social-media/$storagePath"
                }
            }

            // Authoritative RPC: social_update_profile
            val rpcRes = supabaseClient.restService.socialUpdateProfile(
                SocialUpdateProfileParams(
                    pBio = bio?.trim(),
                    pHobbies = hobbies?.trim(),
                    pAvatarUrl = socialAvatarUrl
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                getHostSocialProfile()
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to update social profile"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in updateHostSocialProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Search User Social Profile using authoritative RPC:
     * social_search_profile(p_target_user_id)
     *
     * HOST SEARCH RULE:
     * - Host can search/view ONLY User Social Profiles.
     * - Host cannot search/view another Host Social Profile.
     */
    suspend fun searchUserProfile(targetUserId: String): Result<SocialSearchResult> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val cleanQuery = targetUserId.trim()
            if (cleanQuery.isBlank()) {
                return@withContext Result.failure(Exception("Please enter a User ID to search"))
            }

            var searchResult: SocialSearchResult? = null

            // 1. Authoritative RPC: social_search_profile
            val rpcRes = supabaseClient.restService.socialSearchProfile(
                SocialSearchProfileParams(pTargetUserId = cleanQuery)
            )

            if (rpcRes.isSuccessful) {
                val rawBody = rpcRes.body()?.string()?.trim().orEmpty()
                if (rawBody.isNotBlank()) {
                    try {
                        val json = if (rawBody.startsWith("[")) {
                            val arr = JSONArray(rawBody)
                            if (arr.length() > 0) arr.getJSONObject(0) else null
                        } else if (rawBody.startsWith("{")) {
                            JSONObject(rawBody)
                        } else null

                        if (json != null) {
                            val isHost = json.optBoolean("is_host", false) ||
                                    json.optBoolean("is_partner", false) ||
                                    json.optString("account_type", "").equals("partner", ignoreCase = true) ||
                                    json.optString("role", "").equals("partner", ignoreCase = true) ||
                                    json.optString("role", "").equals("host", ignoreCase = true)

                            // Check is_host via authoritative RPC if needed
                            val targetId = json.optString("user_id", json.optString("id", ""))
                            var verifiedIsHost = isHost

                            if (!verifiedIsHost && targetId.isNotBlank()) {
                                verifiedIsHost = checkIsHost(targetId)
                            }

                            // STRICT RULE: HOST -> may NOT search/view HOST profiles.
                            if (verifiedIsHost) {
                                return@withContext Result.failure(Exception("HOST_PROFILE_RESTRICTED: You cannot search or view other Host profiles. Only User profiles can be viewed."))
                            }

                            searchResult = SocialSearchResult(
                                userId = targetId,
                                signupUserId = json.optString("signup_user_id", json.optString("username", null)),
                                displayName = json.optString("display_name", "Baatly User"),
                                username = json.optString("username", null),
                                avatarUrl = json.optString("avatar_url", null),
                                socialAvatarUrl = json.optString("social_avatar_url", null),
                                bio = json.optString("bio", null),
                                hobbies = json.optString("hobbies", null),
                                followersCount = json.optInt("followers_count", 0),
                                followingCount = json.optInt("following_count", 0),
                                totalLikes = json.optInt("total_likes", 0),
                                totalViews = json.optInt("total_views", 0),
                                isHost = false,
                                isPartner = false,
                                isFollowing = json.optBoolean("is_following", false)
                            )
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing search RPC response: ${e.message}")
                    }
                }
            }

            // Fallback via profiles table if search RPC didn't match
            if (searchResult == null) {
                val profilesRes = supabaseClient.restService.getProfile(idFilter = "eq.$cleanQuery")
                var profile = profilesRes.body()?.firstOrNull()

                if (profile == null) {
                    val searchByUserId = supabaseClient.restService.getProfile(idFilter = "ilike.*$cleanQuery*")
                    profile = searchByUserId.body()?.firstOrNull()
                }

                if (profile == null) {
                    return@withContext Result.failure(Exception("No user found with ID: $cleanQuery"))
                }

                // Check if target is a Host
                val isHost = checkIsHost(profile.id)
                if (isHost) {
                    return@withContext Result.failure(Exception("HOST_PROFILE_RESTRICTED: You cannot search or view other Host profiles. Only User profiles can be viewed."))
                }

                // Fetch social_profiles
                val socialRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.${profile.id}")
                val socialProfile = socialRes.body()?.firstOrNull()

                // Check follow status
                val followRes = supabaseClient.restService.getSocialFollows(
                    followerIdFilter = "eq.$authUuid",
                    followingIdFilter = "eq.${profile.id}"
                )
                val isFollowing = followRes.isSuccessful && !followRes.body().isNullOrEmpty()

                searchResult = SocialSearchResult(
                    userId = profile.id,
                    signupUserId = profile.userId ?: profile.username,
                    displayName = profile.displayName ?: profile.username ?: "Baatly User",
                    username = profile.username,
                    avatarUrl = profile.avatarUrl,
                    socialAvatarUrl = socialProfile?.socialAvatarUrl ?: profile.avatarUrl,
                    bio = socialProfile?.bio ?: profile.bio,
                    hobbies = socialProfile?.hobbies,
                    followersCount = socialProfile?.followersCount ?: profile.followersCount ?: 0,
                    followingCount = socialProfile?.followingCount ?: profile.followingCount ?: 0,
                    totalLikes = socialProfile?.totalLikes ?: 0,
                    totalViews = socialProfile?.totalViews ?: 0,
                    isHost = false,
                    isPartner = false,
                    isFollowing = isFollowing
                )
            }

            Result.success(searchResult)
        } catch (e: Exception) {
            Log.e(TAG, "Error in searchUserProfile", e)
            Result.failure(e)
        }
    }

    /**
     * Checks if a user is a host using authoritative RPCs:
     * social_is_host(p_user_id) or social_role(p_user_id) or partner_profiles table.
     */
    private suspend fun checkIsHost(userId: String): Boolean {
        // 1. Try social_is_host RPC
        try {
            val res = supabaseClient.restService.socialIsHost(SocialIsHostParams(pUserId = userId))
            if (res.isSuccessful) {
                val bodyStr = res.body()?.string()?.trim().orEmpty().lowercase()
                if (bodyStr == "true" || bodyStr.contains("true")) return true
                if (bodyStr == "false" || bodyStr.contains("false")) return false
            }
        } catch (_: Exception) {}

        // 2. Try social_role RPC
        try {
            val roleRes = supabaseClient.restService.socialRole(SocialRoleParams(pUserId = userId))
            if (roleRes.isSuccessful) {
                val roleStr = roleRes.body()?.string()?.trim().orEmpty().lowercase()
                if (roleStr.contains("host") || roleStr.contains("partner")) return true
                if (roleStr.contains("user") || roleStr.contains("client")) return false
            }
        } catch (_: Exception) {}

        // 3. Check partner_profiles table
        try {
            val partnerRes = supabaseClient.restService.getPartnerProfile(userIdFilter = "eq.$userId")
            if (partnerRes.isSuccessful) {
                val pp = partnerRes.body()?.firstOrNull()
                if (pp?.isPartner == true || pp?.approvalStatus?.equals("approved", ignoreCase = true) == true) {
                    return true
                }
            }
        } catch (_: Exception) {}

        return false
    }

    /**
     * Fetches feed posts from social_posts table:
     * Columns: id, owner_id, media_path, caption, published_at, visible_until, created_at, updated_at
     */
    suspend fun getFeedPosts(): Result<List<SocialPostModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val postsRes = supabaseClient.restService.getSocialPosts()

            if (!postsRes.isSuccessful) {
                return@withContext Result.failure(Exception(postsRes.errorBody()?.string()))
            }

            val rawPosts = postsRes.body() ?: emptyList()
            if (rawPosts.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            // Collect unique owner IDs
            val ownerIds = rawPosts.mapNotNull { it.ownerId ?: it.legacyUserId }.filter { it.isNotBlank() }.distinct()

            // Fetch Profiles & SocialProfiles for authors
            val profileMap = mutableMapOf<String, Profile>()
            val socialProfileMap = mutableMapOf<String, SocialProfileModel>()

            for (ownerId in ownerIds) {
                try {
                    val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$ownerId")
                    pRes.body()?.firstOrNull()?.let { profileMap[ownerId] = it }

                    val spRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$ownerId")
                    spRes.body()?.firstOrNull()?.let { socialProfileMap[ownerId] = it }
                } catch (_: Exception) {}
            }

            // Fetch Stats from social_content_stats
            val statsMap = mutableMapOf<String, SocialContentStatsModel>()
            for (post in rawPosts) {
                try {
                    val stRes = supabaseClient.restService.getSocialContentStats(
                        contentIdFilter = "eq.${post.id}",
                        contentTypeFilter = "eq.post"
                    )
                    stRes.body()?.firstOrNull()?.let { statsMap[post.id] = it }
                } catch (_: Exception) {}
            }

            // Fetch user's likes
            val likesRes = supabaseClient.restService.getSocialLikes(userIdFilter = "eq.$authUuid")
            val likedContentIds = if (likesRes.isSuccessful) {
                likesRes.body()?.mapNotNull { it.contentId ?: it.legacyPostId }?.toSet() ?: emptySet()
            } else emptySet()

            // Fetch user's follows
            val followsRes = supabaseClient.restService.getSocialFollows(followerIdFilter = "eq.$authUuid")
            val followingUserIds = if (followsRes.isSuccessful) {
                followsRes.body()?.map { it.followingId }?.toSet() ?: emptySet()
            } else emptySet()

            val enriched = rawPosts.map { post ->
                val authorId = post.ownerId ?: post.legacyUserId ?: ""
                val stats = statsMap[post.id]
                val prof = profileMap[authorId]
                val sp = socialProfileMap[authorId]

                post.copy(
                    profile = prof,
                    socialProfile = sp,
                    likesCount = stats?.likeCount ?: post.likesCount ?: 0,
                    commentsCount = stats?.commentCount ?: post.commentsCount ?: 0,
                    viewsCount = stats?.viewCount ?: post.viewsCount ?: 0,
                    isLiked = likedContentIds.contains(post.id),
                    isFollowing = followingUserIds.contains(authorId)
                )
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getFeedPosts", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches posts for a specific user from social_posts table:
     * Filter: owner_id = eq.$userId
     */
    suspend fun getUserPosts(userId: String): Result<List<SocialPostModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val postsRes = supabaseClient.restService.getSocialPostsByOwner(ownerIdFilter = "eq.$userId")

            if (!postsRes.isSuccessful) {
                return@withContext Result.failure(Exception(postsRes.errorBody()?.string()))
            }

            val rawPosts = postsRes.body() ?: emptyList()
            if (rawPosts.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            // Fetch Profile & SocialProfile for the author
            val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$userId")
            val profile = pRes.body()?.firstOrNull()

            val spRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$userId")
            val socialProfile = spRes.body()?.firstOrNull()

            // Fetch user's likes
            val likesRes = supabaseClient.restService.getSocialLikes(userIdFilter = "eq.$authUuid")
            val likedContentIds = if (likesRes.isSuccessful) {
                likesRes.body()?.mapNotNull { it.contentId ?: it.legacyPostId }?.toSet() ?: emptySet()
            } else emptySet()

            // Fetch stats for each post
            val enriched = rawPosts.map { post ->
                var likeCount = post.likesCount ?: 0
                var commentCount = post.commentsCount ?: 0
                var viewCount = post.viewsCount ?: 0

                try {
                    val stRes = supabaseClient.restService.getSocialContentStats(
                        contentIdFilter = "eq.${post.id}",
                        contentTypeFilter = "eq.post"
                    )
                    stRes.body()?.firstOrNull()?.let {
                        likeCount = it.likeCount ?: likeCount
                        commentCount = it.commentCount ?: commentCount
                        viewCount = it.viewCount ?: viewCount
                    }
                } catch (_: Exception) {}

                post.copy(
                    profile = profile,
                    socialProfile = socialProfile,
                    likesCount = likeCount,
                    commentsCount = commentCount,
                    viewsCount = viewCount,
                    isLiked = likedContentIds.contains(post.id)
                )
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getUserPosts", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches active stories from social_stories table:
     * Columns: id, owner_id, media_path, caption, created_at, expires_at, is_active
     */
    suspend fun getActiveStories(): Result<List<SocialStoryModel>> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val storiesRes = supabaseClient.restService.getSocialStories()

            if (!storiesRes.isSuccessful) {
                return@withContext Result.failure(Exception(storiesRes.errorBody()?.string()))
            }

            val rawStories = storiesRes.body() ?: emptyList()
            if (rawStories.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            val ownerIds = rawStories.mapNotNull { it.ownerId ?: it.legacyUserId }.filter { it.isNotBlank() }.distinct()
            val profileMap = mutableMapOf<String, Profile>()
            val socialProfileMap = mutableMapOf<String, SocialProfileModel>()

            for (ownerId in ownerIds) {
                try {
                    val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$ownerId")
                    pRes.body()?.firstOrNull()?.let { profileMap[ownerId] = it }

                    val spRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$ownerId")
                    spRes.body()?.firstOrNull()?.let { socialProfileMap[ownerId] = it }
                } catch (_: Exception) {}
            }

            val enriched = rawStories.map { story ->
                val authorId = story.ownerId ?: story.legacyUserId ?: ""
                story.copy(
                    profile = profileMap[authorId],
                    socialProfile = socialProfileMap[authorId]
                )
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getActiveStories", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches stories for a specific user:
     * Filter: owner_id = eq.$userId
     */
    suspend fun getUserStories(userId: String): Result<List<SocialStoryModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getSocialStoriesByOwner(ownerIdFilter = "eq.$userId")
            if (!res.isSuccessful) {
                return@withContext Result.failure(Exception(res.errorBody()?.string()))
            }

            val rawStories = res.body() ?: emptyList()
            if (rawStories.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$userId")
            val profile = pRes.body()?.firstOrNull()

            val spRes = supabaseClient.restService.getSocialProfiles(userIdFilter = "eq.$userId")
            val socialProfile = spRes.body()?.firstOrNull()

            val enriched = rawStories.map { story ->
                story.copy(
                    profile = profile,
                    socialProfile = socialProfile
                )
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getUserStories", e)
            Result.failure(e)
        }
    }

    /**
     * Creates a post or story using authoritative RPC:
     * social_create_content(p_type, p_media_path, p_caption)
     *
     * Post: p_type = "post"
     * Story: p_type = "story"
     */
    suspend fun createContent(
        type: String,
        mediaFile: File,
        caption: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: return@withContext Result.failure(Exception("Not logged in"))
            val extension = mediaFile.extension.ifBlank { "jpg" }
            val mimeType = if (extension.equals("mp4", ignoreCase = true)) "video/mp4" else "image/jpeg"
            val filename = "${type}_${System.currentTimeMillis()}.$extension"
            val storagePath = "$authUuid/$filename"

            val body = mediaFile.asRequestBody(mimeType.toMediaTypeOrNull())

            var uploadRes = supabaseClient.storageService.uploadObject(
                bucket = "social-media",
                path = storagePath,
                contentType = mimeType,
                body = body
            )

            var finalPath = "social-media/$storagePath"
            if (!uploadRes.isSuccessful) {
                uploadRes = supabaseClient.storageService.uploadObject(
                    bucket = "profile-media",
                    path = storagePath,
                    contentType = mimeType,
                    body = body
                )
                if (uploadRes.isSuccessful) {
                    finalPath = "profile-media/$storagePath"
                } else {
                    val err = uploadRes.errorBody()?.string() ?: "Media upload failed"
                    return@withContext Result.failure(Exception("Failed to upload media: $err"))
                }
            }

            // Authoritative RPC: social_create_content
            val rpcRes = supabaseClient.restService.socialCreateContent(
                SocialCreateContentParams(
                    pType = type.lowercase(),
                    pMediaPath = finalPath,
                    pCaption = caption?.trim()
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                Result.success(Unit)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to create social content"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in createContent", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches Host Social Earnings via authoritative RPC:
     * social_get_earnings()
     *
     * Displays backend-returned:
     * - total
     * - view_earnings
     * - like_earnings
     * - comment_earnings
     * - any breakdown
     * Never calculate or hardcode amounts.
     */
    suspend fun getHostSocialEarnings(): Result<SocialEarningsModel> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetEarnings()
            if (res.isSuccessful) {
                val rawBody = res.body()?.string()?.trim().orEmpty()
                val json = if (rawBody.startsWith("[")) {
                    val arr = JSONArray(rawBody)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else if (rawBody.startsWith("{")) {
                    JSONObject(rawBody)
                } else JSONObject()

                val earnings = SocialEarningsModel(
                    total = json.optDouble("total", json.optDouble("total_social_earnings", 0.0)),
                    totalSocialEarnings = json.optDouble("total_social_earnings", json.optDouble("total", 0.0)),
                    viewEarnings = json.optDouble("view_earnings", 0.0),
                    likeEarnings = json.optDouble("like_earnings", 0.0),
                    commentEarnings = json.optDouble("comment_earnings", 0.0),
                    unlockEarnings = json.optDouble("unlock_earnings", 0.0),
                    storyView = json.optDouble("story_view", 0.0),
                    postUnlock = json.optDouble("post_unlock", 0.0),
                    storyLike = json.optDouble("story_like", 0.0),
                    postLike = json.optDouble("post_like", 0.0),
                    storyReply = json.optDouble("story_reply", 0.0),
                    postComment = json.optDouble("post_comment", 0.0)
                )
                Result.success(earnings)
            } else {
                val err = res.errorBody()?.string() ?: "Failed to fetch social earnings"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getHostSocialEarnings", e)
            Result.failure(e)
        }
    }

    /**
     * Records content view via authoritative RPC:
     * social_view_content(p_content_type, p_content_id)
     */
    suspend fun viewContent(contentType: String, contentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialViewContent(
                SocialViewContentParams(pContentType = contentType, pContentId = contentId)
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Toggles like on content via authoritative RPC:
     * social_toggle_like(p_content_type, p_content_id)
     *
     * Host Like on User content is FREE.
     */
    suspend fun toggleLike(contentType: String, contentId: String, currentIsLiked: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rpcRes = supabaseClient.restService.socialToggleLike(
                SocialToggleLikeParams(pContentType = contentType, pContentId = contentId)
            )

            if (rpcRes.isSuccessful) {
                Result.success(!currentIsLiked)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to toggle like"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in toggleLike", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches comments for a piece of content from social_comments table:
     * Columns: id, content_type, content_id, author_id, comment, created_at
     */
    suspend fun getComments(contentId: String): Result<List<SocialCommentModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getSocialComments(contentIdFilter = "eq.$contentId")
            if (!res.isSuccessful) {
                return@withContext Result.failure(Exception(res.errorBody()?.string()))
            }

            val rawComments = res.body() ?: emptyList()
            if (rawComments.isEmpty()) {
                return@withContext Result.success(emptyList())
            }

            // Fetch authors
            val authorIds = rawComments.mapNotNull { it.authorId ?: it.legacyUserId }.filter { it.isNotBlank() }.distinct()
            val profileMap = mutableMapOf<String, Profile>()

            for (authorId in authorIds) {
                try {
                    val pRes = supabaseClient.restService.getProfile(idFilter = "eq.$authorId")
                    pRes.body()?.firstOrNull()?.let { profileMap[authorId] = it }
                } catch (_: Exception) {}
            }

            val enriched = rawComments.map { comment ->
                val authorId = comment.authorId ?: comment.legacyUserId ?: ""
                comment.copy(profile = profileMap[authorId])
            }

            Result.success(enriched)
        } catch (e: Exception) {
            Log.e(TAG, "Error in getComments", e)
            Result.failure(e)
        }
    }

    /**
     * Adds a comment via authoritative RPC:
     * social_add_comment(p_content_type, p_content_id, p_comment)
     *
     * Host Comment on User content is FREE.
     */
    suspend fun addComment(contentType: String, contentId: String, commentText: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val cleanText = commentText.trim()
            if (cleanText.isBlank()) return@withContext Result.failure(Exception("Comment cannot be empty"))

            val rpcRes = supabaseClient.restService.socialAddComment(
                SocialAddCommentParams(
                    pContentType = contentType,
                    pContentId = contentId,
                    pComment = cleanText
                )
            )

            if (rpcRes.isSuccessful || rpcRes.code() in 200..299) {
                Result.success(Unit)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to post comment"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in addComment", e)
            Result.failure(e)
        }
    }

    /**
     * Toggles follow via authoritative RPC:
     * social_follow_toggle(p_target_user_id)
     */
    suspend fun toggleFollow(targetUserId: String, currentIsFollowing: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rpcRes = supabaseClient.restService.socialFollowToggle(
                SocialFollowToggleParams(pTargetUserId = targetUserId)
            )
            if (rpcRes.isSuccessful) {
                Result.success(!currentIsFollowing)
            } else {
                val err = rpcRes.errorBody()?.string() ?: "Failed to toggle follow"
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in toggleFollow", e)
            Result.failure(e)
        }
    }
}
