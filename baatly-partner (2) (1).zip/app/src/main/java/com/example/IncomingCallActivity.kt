package com.example

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.lifecycleScope
import com.example.data.api.CallRealtimeManager
import com.example.data.audio.IncomingCallAudioManager
import com.example.data.models.CallModel
import com.example.data.models.Profile
import com.example.ui.screens.call.IncomingCallScreen
import com.example.ui.theme.BaatlyPartnerTheme
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class IncomingCallActivity : ComponentActivity() {

    private val TAG = "IncomingCallActivity"
    private var callRealtimeManager: CallRealtimeManager? = null
    private var realtimeSubscription: com.example.data.api.RealtimeSubscription? = null
    private var timeoutJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen and wake screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val app = application as BaatlyApp
        val callId = intent.getStringExtra("call_id") ?: intent.getStringExtra("callId").orEmpty()
        val senderId = intent.getStringExtra("sender_id") ?: intent.getStringExtra("senderId") ?: intent.getStringExtra("caller_id").orEmpty()
        val senderName = intent.getStringExtra("sender_name") ?: intent.getStringExtra("caller_name") ?: "User"
        val senderAvatar = intent.getStringExtra("sender_avatar") ?: intent.getStringExtra("avatar_url") ?: intent.getStringExtra("sender_avatar")
        val callType = intent.getStringExtra("call_type") ?: intent.getStringExtra("callType") ?: "audio"

        Log.d(TAG, "onCreate: callId=$callId senderId=$senderId senderName=$senderName type=$callType")

        if (callId.isBlank()) {
            Log.e(TAG, "No call_id passed to IncomingCallActivity. Finishing.")
            finish()
            return
        }

        com.example.data.notification.NotificationRouter.currentVisibleCallId = callId

        val action = intent.getStringExtra("action")
        if (action == "decline_call") {
            handleDecline(app, callId)
            return
        }

        // Play foreground ringtone
        IncomingCallAudioManager.startRingtone(this)

        // 30-second UI timeout
        timeoutJob = lifecycleScope.launch {
            delay(30000)
            Log.d(TAG, "Ringing timed out after 30s. Declining and finishing.")
            handleDecline(app, callId)
        }

        // Fetch the authoritative call in background
        val callState = mutableStateOf<CallModel?>(null)
        val userClassState = mutableStateOf<String?>(null)
        val isLoadingClassificationState = mutableStateOf(true)

        lifecycleScope.launch {
            try {
                val result = app.callRepository.getCallById(callId)
                if (result.isSuccess && result.getOrNull() != null) {
                    val freshCall = result.getOrNull()!!
                    callState.value = freshCall

                    // If call is already in an ended/connected state, auto-exit
                    if (freshCall.status in listOf("missed", "rejected", "cancelled", "completed", "ended")) {
                        Log.w(TAG, "Fetched call status is already ended: ${freshCall.status}. Finishing.")
                        cleanAndFinish()
                        return@launch
                    }

                    // Authoritatively load the user class
                    val fetchedClass = app.callRepository.getHostCallSessionUserClass(callId)
                    userClassState.value = fetchedClass
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching call detail or classification", e)
            } finally {
                isLoadingClassificationState.value = false
            }
        }

        // Subscribe to real-time status updates of the call
        try {
            callRealtimeManager = CallRealtimeManager(app.sessionManager)
            realtimeSubscription = callRealtimeManager?.subscribeToCall(callId) { status, _ ->
                Log.d(TAG, "Realtime status update: $status")
                if (status in listOf("missed", "rejected", "cancelled", "completed", "ended")) {
                    Log.d(TAG, "Call was terminated/cancelled by remote user. Closing IncomingCallActivity.")
                    runOnUiThread {
                        cleanAndFinish()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to subscribe to realtime call updates", e)
        }

        setContent {
            BaatlyPartnerTheme {
                val call = callState.value
                val finalName = call?.userProfile?.displayName ?: call?.userProfile?.username ?: senderName
                val finalAvatar = call?.userProfile?.avatarUrl ?: senderAvatar
                val isVideo = (call?.callType ?: callType).equals("video", ignoreCase = true)

                val userClass = userClassState.value
                val normalizedClass = userClass?.trim()?.lowercase()
                val classificationLabel: String? = when (normalizedClass) {
                    "new" -> "NEW USER"
                    "repeat" -> "REPEAT USER"
                    else -> null
                }
                val isLoadingClassification = isLoadingClassificationState.value

                IncomingCallScreen(
                    callerName = finalName,
                    callerAvatarUrl = finalAvatar,
                    isVideoCall = isVideo,
                    onAccept = {
                        handleAccept(app, callId, finalName, finalAvatar, isVideo)
                    },
                    onDecline = {
                        handleDecline(app, callId)
                    },
                    classificationLabel = classificationLabel,
                    isLoadingClassification = isLoadingClassification
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val action = intent.getStringExtra("action")
        val callId = intent.getStringExtra("call_id") ?: intent.getStringExtra("callId").orEmpty()
        val app = application as BaatlyApp
        if (action == "accept_call" && callId.isNotBlank()) {
            val name = intent.getStringExtra("sender_name") ?: intent.getStringExtra("caller_name") ?: "User"
            val avatar = intent.getStringExtra("sender_avatar") ?: intent.getStringExtra("avatar_url")
            val isVideo = intent.getStringExtra("call_type")?.equals("video", ignoreCase = true) == true
            handleAccept(app, callId, name, avatar, isVideo)
        } else if (action == "decline_call" && callId.isNotBlank()) {
            handleDecline(app, callId)
        }
    }

    private fun handleAccept(app: BaatlyApp, callId: String, name: String, avatar: String?, isVideo: Boolean) {
        Log.d(TAG, "Accept tapped.")
        timeoutJob?.cancel()
        IncomingCallAudioManager.stopRingtone()

        // Cancel notification
        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(this, callId)

        lifecycleScope.launch {
            try {
                // Fetch latest call row from backend BEFORE accepting
                val freshRes = app.callRepository.getCallById(callId)
                val freshCall = freshRes.getOrNull()
                val terminalStatuses = listOf("cancelled", "rejected", "missed", "failed", "completed", "ended")
                if (freshCall != null && (freshCall.status in terminalStatuses || freshCall.endedAt != null)) {
                    Log.w(TAG, "Call was already cancelled or ended (${freshCall.status}). Aborting accept safely.")
                    cleanAndFinish()
                    return@launch
                }

                // Launch MainActivity to process Agora join and transition to active call
                val acceptIntent = Intent(this@IncomingCallActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("notification_type", "incoming_call")
                    putExtra("call_id", callId)
                    putExtra("action", "accept_call")
                    putExtra("sender_name", name)
                    if (avatar != null) putExtra("sender_avatar", avatar)
                    putExtra("call_type", if (isVideo) "video" else "audio")
                }
                startActivity(acceptIntent)
                cleanAndFinish()
            } catch (e: Exception) {
                Log.e(TAG, "Error validating call before accept", e)
                cleanAndFinish()
            }
        }
    }

    private fun handleDecline(app: BaatlyApp, callId: String) {
        Log.d(TAG, "Decline tapped.")
        timeoutJob?.cancel()
        IncomingCallAudioManager.stopRingtone()

        // Cancel notification
        com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(this, callId)

        // Reject on backend
        lifecycleScope.launch {
            try {
                app.callRepository.rejectCall(callId)
            } catch (e: Exception) {
                Log.e(TAG, "Error declining call on backend", e)
            } finally {
                cleanAndFinish()
            }
        }
    }

    private fun cleanAndFinish() {
        timeoutJob?.cancel()
        IncomingCallAudioManager.stopRingtone()
        val callId = intent.getStringExtra("call_id") ?: intent.getStringExtra("callId").orEmpty()
        if (callId.isNotBlank()) {
            if (com.example.data.notification.NotificationRouter.currentVisibleCallId == callId) {
                com.example.data.notification.NotificationRouter.currentVisibleCallId = null
            }
            com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(this, callId)
        }
        finish()
    }

    override fun onDestroy() {
        timeoutJob?.cancel()
        IncomingCallAudioManager.stopRingtone()
        val callId = intent.getStringExtra("call_id") ?: intent.getStringExtra("callId").orEmpty()
        if (callId.isNotBlank() && com.example.data.notification.NotificationRouter.currentVisibleCallId == callId) {
            com.example.data.notification.NotificationRouter.currentVisibleCallId = null
        }
        realtimeSubscription?.close()
        super.onDestroy()
    }
}
