package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AuthSignUpRequest(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String
)

@JsonClass(generateAdapter = true)
data class AuthSignInRequest(
    @Json(name = "email") val email: String,
    @Json(name = "password") val password: String
)

@JsonClass(generateAdapter = true)
data class AuthResponse(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "token_type") val tokenType: String? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "user") val user: AuthUser? = null
)

@JsonClass(generateAdapter = true)
data class AuthUser(
    @Json(name = "id") val id: String,
    @Json(name = "email") val email: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class Profile(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "username") val username: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "account_status") val accountStatus: String? = null,
    @Json(name = "is_online") val isOnline: Boolean? = null,
    @Json(name = "last_seen_at") val lastSeenAt: String? = null,
    @Json(name = "last_heartbeat_at") val lastHeartbeatAt: String? = null,
    @Json(name = "reviews_count") val reviewsCount: Int? = 0,
    @Json(name = "rating") val rating: Double? = 0.0,
    @Json(name = "mobile_number") val mobileNumber: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PartnerProfile(
    @Json(name = "user_id") val userId: String,
    @Json(name = "is_partner") val isPartner: Boolean? = false,
    @Json(name = "partner_display_name") val partnerDisplayName: String? = null,
    @Json(name = "approval_status") val approvalStatus: String? = "pending",
    @Json(name = "is_available") val isAvailable: Boolean? = false,
    @Json(name = "is_online") val isOnline: Boolean? = false,
    @Json(name = "voice_verified") val voiceVerified: Boolean? = false,
    @Json(name = "rating") val rating: Double? = 0.0,
    @Json(name = "total_calls") val totalCalls: Int? = 0,
    @Json(name = "total_call_minutes") val totalCallMinutes: Double? = 0.0,
    @Json(name = "total_chat_messages") val totalChatMessages: Int? = 0,
    @Json(name = "total_call_earnings") val totalCallEarnings: Double? = 0.0,
    @Json(name = "total_chat_earnings") val totalChatEarnings: Double? = 0.0,
    @Json(name = "total_gift_earnings") val totalGiftEarnings: Double? = 0.0,
    @Json(name = "total_earnings") val totalEarnings: Double? = 0.0,
    @Json(name = "last_active_at") val lastActiveAt: String? = null,
    @Json(name = "audio_enabled") val audioEnabled: Boolean? = false,
    @Json(name = "chat_enabled") val chatEnabled: Boolean? = false,
    @Json(name = "video_call_access") val videoCallAccess: Boolean? = false,
    @Json(name = "video_enabled") val videoEnabled: Boolean? = false,
    @Json(name = "age") val age: Int? = null,
    @Json(name = "hobbies") val hobbies: String? = null,
    @Json(name = "mobile_number") val mobileNumber: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PartnerApplication(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "status") val status: String? = "pending",
    @Json(name = "submitted_at") val submittedAt: String? = null,
    @Json(name = "reviewed_at") val reviewedAt: String? = null,
    @Json(name = "reviewed_by") val reviewedBy: String? = null,
    @Json(name = "rejection_reason") val rejectionReason: String? = null,
    @Json(name = "resubmission_reason") val resubmissionReason: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class VoiceVerification(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "application_id") val applicationId: String? = null,
    @Json(name = "audio_url") val audioUrl: String? = null,
    @Json(name = "status") val status: String? = "pending",
    @Json(name = "submitted_at") val submittedAt: String? = null,
    @Json(name = "reviewed_at") val reviewedAt: String? = null,
    @Json(name = "reviewed_by") val reviewedBy: String? = null,
    @Json(name = "rejection_reason") val rejectionReason: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)
