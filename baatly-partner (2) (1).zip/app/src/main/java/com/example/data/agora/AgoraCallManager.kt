package com.example.data.agora

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.example.BaatlyApp
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.video.VideoCanvas
import io.agora.rtc2.video.VideoEncoderConfiguration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

sealed class AgoraCallState {
    object Idle : AgoraCallState()
    object Initializing : AgoraCallState()
    object Joining : AgoraCallState()
    data class Joined(val channelName: String, val uid: Int) : AgoraCallState()
    data class UserConnected(val remoteUid: Int) : AgoraCallState()
    data class UserDisconnected(val remoteUid: Int) : AgoraCallState()
    data class Error(val errorCode: Int, val message: String) : AgoraCallState()
    object Left : AgoraCallState()
}

class AgoraCallManager(context: Context? = null) {
    private val TAG = "AgoraCallManager"
    private val TAG_NET = "BAATLY_AGORA_NETWORK"
    private val TAG_AUDIO = "BAATLY_AGORA_AUDIO"
    private val TAG_CONN = "BAATLY_AGORA_CONNECTION"

    private var appContext: Context? = context?.applicationContext ?: context ?: runCatching { BaatlyApp.instance.applicationContext }.getOrNull() ?: runCatching { BaatlyApp.instance }.getOrNull()

    private var rtcEngine: RtcEngine? = null

    var lastErrorMessage: String? = null
        private set

    private val _callState = MutableStateFlow<AgoraCallState>(AgoraCallState.Idle)
    val callState: StateFlow<AgoraCallState> = _callState.asStateFlow()

    private val _isSpeakerphoneOn = MutableStateFlow(true)
    val isSpeakerphoneOn: StateFlow<Boolean> = _isSpeakerphoneOn.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isVideoCall = MutableStateFlow(false)
    val isVideoCall: StateFlow<Boolean> = _isVideoCall.asStateFlow()

    private val _remoteVideoUid = MutableStateFlow<Int?>(null)
    val remoteVideoUid: StateFlow<Int?> = _remoteVideoUid.asStateFlow()

    private val _isCameraMuted = MutableStateFlow(false)
    val isCameraMuted: StateFlow<Boolean> = _isCameraMuted.asStateFlow()

    // Throttled logging timestamps to avoid spamming logcat during high-frequency callbacks
    private val lastNetQualityLogTime = AtomicLong(0L)
    private val lastRtcStatsLogTime = AtomicLong(0L)
    private val lastRemoteAudioStatsLogTime = AtomicLong(0L)
    private val lastLocalAudioStatsLogTime = AtomicLong(0L)

    private fun getValidContext(): Context? {
        return appContext?.applicationContext
            ?: appContext
            ?: runCatching { BaatlyApp.instance.applicationContext }.getOrNull()
            ?: runCatching { BaatlyApp.instance }.getOrNull()
    }

    fun attachContext(ctx: Context) {
        val resolved = ctx.applicationContext ?: ctx
        this.appContext = resolved
    }

    private fun qualityToString(quality: Int): String {
        return when (quality) {
            Constants.QUALITY_EXCELLENT -> "EXCELLENT"
            Constants.QUALITY_GOOD -> "GOOD"
            Constants.QUALITY_POOR -> "POOR"
            Constants.QUALITY_BAD -> "BAD"
            Constants.QUALITY_VBAD -> "VERY_BAD"
            Constants.QUALITY_DOWN -> "DOWN"
            Constants.QUALITY_DETECTING -> "DETECTING"
            Constants.QUALITY_UNKNOWN -> "UNKNOWN"
            else -> "QUALITY_$quality"
        }
    }

    private fun connStateToString(state: Int): String {
        return when (state) {
            Constants.CONNECTION_STATE_DISCONNECTED -> "DISCONNECTED"
            Constants.CONNECTION_STATE_CONNECTING -> "CONNECTING"
            Constants.CONNECTION_STATE_CONNECTED -> "CONNECTED"
            Constants.CONNECTION_STATE_RECONNECTING -> "RECONNECTING"
            Constants.CONNECTION_STATE_FAILED -> "FAILED"
            else -> "STATE_$state"
        }
    }

    private fun connReasonToString(reason: Int): String {
        return when (reason) {
            Constants.CONNECTION_CHANGED_CONNECTING -> "CONNECTING"
            Constants.CONNECTION_CHANGED_JOIN_SUCCESS -> "JOIN_SUCCESS"
            Constants.CONNECTION_CHANGED_INTERRUPTED -> "INTERRUPTED"
            Constants.CONNECTION_CHANGED_BANNED_BY_SERVER -> "BANNED_BY_SERVER"
            Constants.CONNECTION_CHANGED_JOIN_FAILED -> "JOIN_FAILED"
            Constants.CONNECTION_CHANGED_LEAVE_CHANNEL -> "LEAVE_CHANNEL"
            Constants.CONNECTION_CHANGED_INVALID_APP_ID -> "INVALID_APP_ID"
            Constants.CONNECTION_CHANGED_INVALID_CHANNEL_NAME -> "INVALID_CHANNEL_NAME"
            Constants.CONNECTION_CHANGED_INVALID_TOKEN -> "INVALID_TOKEN"
            Constants.CONNECTION_CHANGED_TOKEN_EXPIRED -> "TOKEN_EXPIRED"
            Constants.CONNECTION_CHANGED_REJECTED_BY_SERVER -> "REJECTED_BY_SERVER"
            Constants.CONNECTION_CHANGED_SETTING_PROXY_SERVER -> "SETTING_PROXY_SERVER"
            Constants.CONNECTION_CHANGED_RENEW_TOKEN -> "RENEW_TOKEN"
            Constants.CONNECTION_CHANGED_CLIENT_IP_ADDRESS_CHANGED -> "CLIENT_IP_ADDRESS_CHANGED"
            Constants.CONNECTION_CHANGED_KEEP_ALIVE_TIMEOUT -> "KEEP_ALIVE_TIMEOUT"
            else -> "REASON_$reason"
        }
    }

    private fun remoteAudioStateToString(state: Int): String {
        return when (state) {
            Constants.REMOTE_AUDIO_STATE_STOPPED -> "STOPPED"
            Constants.REMOTE_AUDIO_STATE_STARTING -> "STARTING"
            Constants.REMOTE_AUDIO_STATE_DECODING -> "DECODING"
            Constants.REMOTE_AUDIO_STATE_FROZEN -> "FROZEN"
            Constants.REMOTE_AUDIO_STATE_FAILED -> "FAILED"
            else -> "STATE_$state"
        }
    }

    private fun remoteAudioReasonToString(reason: Int): String {
        return when (reason) {
            Constants.REMOTE_AUDIO_REASON_INTERNAL -> "INTERNAL"
            Constants.REMOTE_AUDIO_REASON_NETWORK_CONGESTION -> "NETWORK_CONGESTION"
            Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY -> "NETWORK_RECOVERY"
            Constants.REMOTE_AUDIO_REASON_LOCAL_MUTED -> "LOCAL_MUTED"
            Constants.REMOTE_AUDIO_REASON_LOCAL_UNMUTED -> "LOCAL_UNMUTED"
            Constants.REMOTE_AUDIO_REASON_REMOTE_MUTED -> "REMOTE_MUTED"
            Constants.REMOTE_AUDIO_REASON_REMOTE_UNMUTED -> "REMOTE_UNMUTED"
            Constants.REMOTE_AUDIO_REASON_REMOTE_OFFLINE -> "REMOTE_OFFLINE"
            else -> "REASON_$reason"
        }
    }

    private fun localAudioStateToString(state: Int): String {
        return when (state) {
            Constants.LOCAL_AUDIO_STREAM_STATE_STOPPED -> "STOPPED"
            Constants.LOCAL_AUDIO_STREAM_STATE_RECORDING -> "RECORDING"
            Constants.LOCAL_AUDIO_STREAM_STATE_ENCODING -> "ENCODING"
            Constants.LOCAL_AUDIO_STREAM_STATE_FAILED -> "FAILED"
            else -> "STATE_$state"
        }
    }

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.d(TAG_CONN, "ON_JOIN_CHANNEL_SUCCESS: channel=$channel, uid=$uid, elapsed=$elapsed")
            lastErrorMessage = null
            _callState.value = AgoraCallState.Joined(channel ?: "", uid)
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.d(TAG_AUDIO, "REMOTE_USER_JOINED: remoteUid=$uid, elapsed=$elapsed")
            rtcEngine?.muteRemoteAudioStream(uid, false)
            _remoteVideoUid.value = uid
            _callState.value = AgoraCallState.UserConnected(uid)
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            Log.d(TAG_CONN, "REMOTE_USER_OFFLINE: remoteUid=$uid, reason=$reason")
            if (_remoteVideoUid.value == uid) {
                _remoteVideoUid.value = null
            }
            _callState.value = AgoraCallState.UserDisconnected(uid)
        }

        override fun onFirstRemoteVideoDecoded(uid: Int, width: Int, height: Int, elapsed: Int) {
            Log.d(TAG, "ON_FIRST_REMOTE_VIDEO_DECODED: uid=$uid, ${width}x${height}, elapsed=$elapsed")
            _remoteVideoUid.value = uid
        }

        override fun onConnectionStateChanged(state: Int, reason: Int) {
            val stateName = connStateToString(state)
            val reasonName = connReasonToString(reason)
            Log.d(TAG_CONN, "CONNECTION_STATE_CHANGED: state=$state ($stateName), reason=$reason ($reasonName)")

            when (state) {
                Constants.CONNECTION_STATE_RECONNECTING -> {
                    Log.w(TAG_CONN, "Temporary network fluctuation: Agora reconnecting in background. Preserving call session.")
                }
                Constants.CONNECTION_STATE_CONNECTED -> {
                    Log.d(TAG_CONN, "Agora connection active and stable.")
                }
                Constants.CONNECTION_STATE_FAILED -> {
                    Log.e(TAG_CONN, "Agora connection failed: reason=$reasonName")
                }
            }
        }

        override fun onConnectionLost() {
            Log.w(TAG_CONN, "CONNECTION_LOST: Agora connection temporarily lost. Automatic reconnect underway.")
        }

        override fun onConnectionInterrupted() {
            Log.w(TAG_CONN, "CONNECTION_INTERRUPTED: Network interrupted temporarily.")
        }

        override fun onNetworkQuality(uid: Int, txQuality: Int, rxQuality: Int) {
            val now = System.currentTimeMillis()
            if (now - lastNetQualityLogTime.get() > 5000L || txQuality >= Constants.QUALITY_BAD || rxQuality >= Constants.QUALITY_BAD) {
                lastNetQualityLogTime.set(now)
                Log.d(TAG_NET, "NETWORK_QUALITY: uid=$uid, uplink=${qualityToString(txQuality)}, downlink=${qualityToString(rxQuality)}")
            }
        }

        override fun onRtcStats(stats: RtcStats?) {
            if (stats == null) return
            val now = System.currentTimeMillis()
            if (now - lastRtcStatsLogTime.get() > 8000L || stats.rxPacketLossRate > 10 || stats.txPacketLossRate > 10) {
                lastRtcStatsLogTime.set(now)
                Log.d(TAG_NET, "RTC_STATS: rtt=${stats.gatewayRtt}ms, rxLoss=${stats.rxPacketLossRate}%, txLoss=${stats.txPacketLossRate}%, rxAudio=${stats.rxAudioKBitRate}kbps, txAudio=${stats.txAudioKBitRate}kbps")
            }
        }

        override fun onRemoteAudioStats(stats: RemoteAudioStats?) {
            if (stats == null) return
            val now = System.currentTimeMillis()
            if (now - lastRemoteAudioStatsLogTime.get() > 8000L || stats.audioLossRate > 10 || stats.frozenRate > 5) {
                lastRemoteAudioStatsLogTime.set(now)
                Log.d(TAG_AUDIO, "REMOTE_AUDIO_STATS: remoteUid=${stats.uid}, delay=${stats.networkTransportDelay}ms, jitterDelay=${stats.jitterBufferDelay}ms, loss=${stats.audioLossRate}%, frozenRate=${stats.frozenRate}%")
            }
        }

        override fun onLocalAudioStats(stats: LocalAudioStats?) {
            if (stats == null) return
            val now = System.currentTimeMillis()
            if (now - lastLocalAudioStatsLogTime.get() > 8000L || stats.txPacketLossRate > 10) {
                lastLocalAudioStatsLogTime.set(now)
                Log.d(TAG_AUDIO, "LOCAL_AUDIO_STATS: sentBitrate=${stats.sentBitrate}kbps, txLoss=${stats.txPacketLossRate}%")
            }
        }

        override fun onRemoteAudioStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            val stateName = remoteAudioStateToString(state)
            val reasonName = remoteAudioReasonToString(reason)
            Log.d(TAG_AUDIO, "REMOTE_AUDIO_STATE_CHANGED: uid=$uid, state=$state ($stateName), reason=$reason ($reasonName), elapsed=${elapsed}ms")

            when (state) {
                Constants.REMOTE_AUDIO_STATE_STARTING -> {
                    Log.d(TAG_AUDIO, "Remote audio stream starting for uid=$uid")
                }
                Constants.REMOTE_AUDIO_STATE_DECODING -> {
                    if (reason == Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY) {
                        Log.d(TAG_AUDIO, "RECOVERY_SUCCESS: Remote voice recovered after network degradation for uid=$uid")
                    } else {
                        Log.d(TAG_AUDIO, "Remote voice playing normally for uid=$uid")
                    }
                }
                Constants.REMOTE_AUDIO_STATE_STOPPED -> {
                    Log.d(TAG_AUDIO, "Remote audio stopped for uid=$uid (reason=$reasonName)")
                    // Ensure remote audio is unmuted on our side
                    if (reason == Constants.REMOTE_AUDIO_REASON_REMOTE_UNMUTED || reason == Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY) {
                        rtcEngine?.muteRemoteAudioStream(uid, false)
                    }
                }
                Constants.REMOTE_AUDIO_STATE_FROZEN -> {
                    Log.w(TAG_AUDIO, "NETWORK_CONGESTION: Remote audio temporarily frozen due to packet loss/jitter (reason=$reasonName). Awaiting NetEQ adaptive recovery.")
                }
                Constants.REMOTE_AUDIO_STATE_FAILED -> {
                    Log.w(TAG_AUDIO, "Remote audio failed temporarily (reason=$reasonName). Preserving channel.")
                }
            }
        }

        override fun onLocalAudioStateChanged(state: Int, error: Int) {
            val stateName = localAudioStateToString(state)
            Log.d(TAG_AUDIO, "LOCAL_AUDIO_STATE_CHANGED: state=$state ($stateName), error=$error")
            when (state) {
                Constants.LOCAL_AUDIO_STREAM_STATE_STOPPED -> {
                    Log.d(TAG_AUDIO, "LOCAL_AUDIO_STATE: stopped, error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_RECORDING -> {
                    Log.d(TAG_AUDIO, "LOCAL_AUDIO_STATE: recording, error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_ENCODING -> {
                    Log.d(TAG_AUDIO, "LOCAL_AUDIO_STATE: encoding/streaming, error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_FAILED -> {
                    Log.e(TAG_AUDIO, "LOCAL_AUDIO_STATE: mic failed, error=$error")
                }
            }
        }

        override fun onAudioRouteChanged(routing: Int) {
            Log.d(TAG_AUDIO, "SPEAKERPHONE_STATE: audio route changed to $routing")
            _isSpeakerphoneOn.value = (routing == Constants.AUDIO_ROUTE_SPEAKERPHONE || routing == 3)
        }

        override fun onLeaveChannel(stats: RtcStats?) {
            Log.d(TAG_CONN, "onLeaveChannel")
            _callState.value = AgoraCallState.Left
        }

        override fun onTokenPrivilegeWillExpire(token: String?) {
            Log.w(TAG_CONN, "TOKEN_PRIVILEGE_WILL_EXPIRE: Agora token nearing expiration")
        }

        override fun onError(err: Int) {
            Log.e(TAG_CONN, "AGORA_ERROR: Agora onError code=$err")
            // Non-fatal network errors should not abort active calls
            val errStr = "AGORA_ERROR: Agora error code $err"
            lastErrorMessage = errStr
            if (err != Constants.ERR_OK && err != 0) {
                _callState.value = AgoraCallState.Error(err, errStr)
            }
        }
    }

    fun initialize(appId: String, isVideo: Boolean = false): Boolean {
        val trimmedAppId = appId.trim()

        // 1. Context validation & diagnostic logging
        val targetContext = getValidContext()
        val isContextValid = targetContext != null
        val finalAppContext = targetContext?.applicationContext ?: targetContext
        val isAppContextValid = finalAppContext != null

        Log.d(TAG, "AGORA_CONTEXT_CHECK: context valid = $isContextValid, applicationContext valid = $isAppContextValid")

        if (finalAppContext == null) {
            Log.e(TAG, "Cannot initialize Agora: Application Context is null")
            val err = "Android Context is null. Cannot initialize Agora RTC engine."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-3, err)
            safeRelease()
            return false
        }

        // 2. Check microphone permission
        val hasMicPermission = ContextCompat.checkSelfPermission(
            finalAppContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMicPermission) {
            Log.e(TAG, "Cannot initialize Agora: Microphone permission (RECORD_AUDIO) not granted")
            val err = "Microphone permission (RECORD_AUDIO) not granted. Please grant microphone access."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-2, err)
            safeRelease()
            return false
        }

        if (isVideo) {
            val hasCameraPermission = ContextCompat.checkSelfPermission(
                finalAppContext,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasCameraPermission) {
                Log.e(TAG, "Cannot initialize Agora: Camera permission (CAMERA) not granted")
                val err = "Camera permission (CAMERA) not granted. Please grant camera access."
                lastErrorMessage = err
                _callState.value = AgoraCallState.Error(-2, err)
                safeRelease()
                return false
            }
        }

        // 3. Validate App ID
        if (trimmedAppId.isBlank()) {
            Log.e(TAG, "Cannot initialize Agora: App ID is blank")
            val err = "Agora App ID is missing or blank"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        if (trimmedAppId.contains("placeholder", ignoreCase = true) ||
            trimmedAppId.contains("fake", ignoreCase = true) ||
            trimmedAppId.length < 10
        ) {
            Log.e(TAG, "Cannot initialize Agora: Invalid or placeholder App ID detected")
            val err = "Invalid or placeholder Agora App ID configured"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        Log.d(TAG, "AGORA_APP_ID_VALIDATED: Agora App ID configured = true, Agora App ID valid = true")

        if (rtcEngine != null) {
            Log.d(TAG, "Agora RtcEngine already initialized")
            return true
        }

        _callState.value = AgoraCallState.Initializing
        _isVideoCall.value = isVideo
        _remoteVideoUid.value = null
        _isCameraMuted.value = false

        val config = RtcEngineConfig().apply {
            mContext = finalAppContext
            mAppId = trimmedAppId
            mEventHandler = rtcEventHandler
            mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
            mAudioScenario = Constants.AUDIO_SCENARIO_DEFAULT
        }

        // 4. Isolate RtcEngine.create
        Log.d(TAG, "RTC_ENGINE_CREATE_START")
        val engine: RtcEngine = try {
            RtcEngine.create(config) ?: throw IllegalStateException("RtcEngine.create returned null")
        } catch (t: Throwable) {
            Log.e(TAG, "RTC_ENGINE_CREATE_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "RtcEngine.create failed: ${t.javaClass.simpleName}: ${t.message ?: "unknown error"}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        rtcEngine = engine
        Log.d(TAG, "RTC_ENGINE_CREATE_SUCCESS: Agora initialized successfully")
        Log.d(TAG, "AUDIO_ENGINE_CREATED: success")

        // 5. Enable Audio
        Log.d(TAG, "ENABLE_AUDIO_START")
        val audioRes = try {
            engine.enableAudio()
        } catch (t: Throwable) {
            Log.e(TAG, "ENABLE_AUDIO_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "enableAudio failed: ${t.javaClass.simpleName}: ${t.message}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }
        Log.d(TAG, "ENABLE_AUDIO_RESULT: code=$audioRes")
        if (audioRes != Constants.ERR_OK && audioRes != 0) {
            Log.e(TAG, "ENABLE_AUDIO_FAILED: Agora error code $audioRes")
            val err = "enableAudio failed with Agora error code: $audioRes"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(audioRes, err)
            safeRelease()
            return false
        }
        Log.d(TAG, "ENABLE_AUDIO_SUCCESS")

        // 6. Configure Audio Profile for Speech Communication & Resilience
        // AUDIO_PROFILE_SPEECH_STANDARD is optimized for voice calls with high network resilience
        try {
            engine.setAudioProfile(Constants.AUDIO_PROFILE_SPEECH_STANDARD, Constants.AUDIO_SCENARIO_DEFAULT)
            Log.d(TAG_AUDIO, "AUDIO_PROFILE_CONFIGURED: SPEECH_STANDARD, SCENARIO_DEFAULT")
        } catch (t: Throwable) {
            Log.w(TAG_AUDIO, "Failed configuring audio profile: ${t.message}")
        }

        // 7. Advanced VoIP & Network Resilience Parameters
        try {
            // Keep audio session active across screen lock and app backgrounding
            engine.setParameters("{\"che.audio.keep.audiosession\": true}")
            // Enable Audio Forward Error Correction (FEC) to recover packets over weak mobile networks
            engine.setParameters("{\"che.audio.network.audio_fec_enable\": true}")
            engine.setParameters("{\"che.audio.neteq.enable_fec\": true}")
            // Enable 3A hardware/software speech processing
            engine.setParameters("{\"che.audio.enable.aec\": true}")
            engine.setParameters("{\"che.audio.enable.agc\": true}")
            engine.setParameters("{\"che.audio.enable.ans\": true}")
            Log.d(TAG_AUDIO, "AGORA_VOIP_PARAMETERS_CONFIGURED: FEC=true, KeepSession=true, 3A=true")
        } catch (t: Throwable) {
            Log.w(TAG_AUDIO, "Failed setting audio parameters: ${t.message}")
        }

        // 8. Configure Audio Recording, Playback, and Volume
        val localAudioRes = engine.enableLocalAudio(true)
        Log.d(TAG_AUDIO, "LOCAL_AUDIO_ENABLED: true, result=$localAudioRes")

        val unMuteLocalRes = engine.muteLocalAudioStream(false)
        Log.d(TAG_AUDIO, "LOCAL_AUDIO_MUTED: false, result=$unMuteLocalRes")

        engine.muteAllRemoteAudioStreams(false)
        engine.adjustRecordingSignalVolume(100)
        engine.adjustPlaybackSignalVolume(100)

        // 9. Video configuration
        if (isVideo) {
            Log.d(TAG, "ENABLE_VIDEO_START")
            try {
                engine.enableVideo()
                engine.startPreview()
                engine.setVideoEncoderConfiguration(
                    VideoEncoderConfiguration(
                        VideoEncoderConfiguration.VD_1280x720,
                        VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,
                        VideoEncoderConfiguration.STANDARD_BITRATE,
                        VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_ADAPTIVE
                    )
                )
                Log.d(TAG, "ENABLE_VIDEO_SUCCESS")
            } catch (t: Throwable) {
                Log.w(TAG, "ENABLE_VIDEO_NON_FATAL: ${t.javaClass.simpleName}: ${t.message}")
            }
        } else {
            Log.d(TAG, "DISABLE_VIDEO_START")
            try {
                val videoRes = engine.disableVideo()
                if (videoRes == Constants.ERR_OK || videoRes == 0) {
                    Log.d(TAG, "DISABLE_VIDEO_SUCCESS")
                } else {
                    Log.w(TAG, "DISABLE_VIDEO_NON_FATAL: returned code $videoRes (expected for audio-only profile)")
                }
            } catch (t: Throwable) {
                Log.w(TAG, "DISABLE_VIDEO_NON_FATAL: exception ignored for audio-only: ${t.javaClass.simpleName}: ${t.message}")
            }
        }

        // 10. Enable Speakerphone
        Log.d(TAG, "SPEAKERPHONE_START")
        engine.setDefaultAudioRoutetoSpeakerphone(true)
        val speakerRes = try {
            engine.setEnableSpeakerphone(true)
        } catch (t: Throwable) {
            Log.e(TAG, "SPEAKERPHONE_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "setEnableSpeakerphone failed: ${t.javaClass.simpleName}: ${t.message}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }
        if (speakerRes != Constants.ERR_OK && speakerRes != 0) {
            Log.w(TAG, "SPEAKERPHONE_WARNING: returned Agora code $speakerRes")
        }
        Log.d(TAG, "SPEAKERPHONE_STATE: enabled=true, result=$speakerRes")

        _isSpeakerphoneOn.value = true
        _isMuted.value = false
        lastErrorMessage = null
        return true
    }

    fun joinChannel(token: String, channelName: String, uid: Int = 0, isVideo: Boolean = false): Boolean {
        val targetContext = getValidContext()
        val finalAppContext = targetContext?.applicationContext ?: targetContext

        val hasMicPermission = finalAppContext != null && ContextCompat.checkSelfPermission(
            finalAppContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        Log.d(TAG_CONN, "LOCAL_MIC_PERMISSION: granted=$hasMicPermission")

        if (!hasMicPermission) {
            Log.e(TAG_CONN, "Cannot join Agora channel: Microphone permission (RECORD_AUDIO) not granted")
            val err = "Microphone permission (RECORD_AUDIO) not granted. Cannot join voice channel."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-2, err)
            return false
        }

        if (isVideo) {
            val hasCameraPermission = finalAppContext != null && ContextCompat.checkSelfPermission(
                finalAppContext,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasCameraPermission) {
                Log.e(TAG_CONN, "Cannot join Agora channel: Camera permission (CAMERA) not granted")
                val err = "Camera permission (CAMERA) not granted. Cannot join video channel."
                lastErrorMessage = err
                _callState.value = AgoraCallState.Error(-2, err)
                return false
            }
        }

        val engine = rtcEngine
        if (engine == null) {
            Log.e(TAG_CONN, "RtcEngine not initialized when joining channel")
            val err = "RtcEngine not initialized when joining channel"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            return false
        }

        if (channelName.isBlank()) {
            Log.e(TAG_CONN, "Cannot join Agora channel: channelName is blank")
            val err = "Agora channelName is blank"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            return false
        }

        // Ensure local audio is active and unmuted before joining
        engine.enableLocalAudio(true)
        engine.muteLocalAudioStream(false)
        engine.muteAllRemoteAudioStreams(false)

        if (isVideo) {
            engine.enableLocalVideo(true)
            engine.muteLocalVideoStream(false)
            engine.muteAllRemoteVideoStreams(false)
        }

        _callState.value = AgoraCallState.Joining
        Log.d(TAG_CONN, "JOIN_CHANNEL_START: channel=$channelName, uid=$uid, isVideo=$isVideo")
        return try {
            val options = ChannelMediaOptions().apply {
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
                enableAudioRecordingOrPlayout = true
                autoSubscribeVideo = isVideo
                publishCameraTrack = isVideo
            }
            val res = engine.joinChannel(token, channelName, uid, options)
            Log.d(TAG_CONN, "JOIN_CHANNEL_RESULT: code=$res")
            if (res == Constants.ERR_OK || res == 0) {
                lastErrorMessage = null
                true
            } else {
                Log.e(TAG_CONN, "AGORA_ERROR: joinChannel failed with Agora error code: $res")
                val err = "joinChannel failed with Agora error code: $res"
                lastErrorMessage = err
                _callState.value = AgoraCallState.Error(res, err)
                false
            }
        } catch (t: Throwable) {
            Log.e(TAG_CONN, "AGORA_ERROR: joinChannel exception: ${t.javaClass.name}: ${t.message}", t)
            val err = "joinChannel failed: ${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            false
        }
    }

    fun setupLocalVideo(surfaceView: SurfaceView) {
        rtcEngine?.setupLocalVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0))
    }

    fun setupRemoteVideo(surfaceView: SurfaceView, uid: Int) {
        rtcEngine?.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid))
    }

    fun switchCamera() {
        rtcEngine?.switchCamera()
    }

    fun setCameraMuted(muted: Boolean) {
        rtcEngine?.muteLocalVideoStream(muted)
        _isCameraMuted.value = muted
    }

    fun toggleCameraMute() {
        val next = !_isCameraMuted.value
        setCameraMuted(next)
    }

    fun setSpeakerphone(enabled: Boolean) {
        val res = rtcEngine?.setEnableSpeakerphone(enabled)
        _isSpeakerphoneOn.value = enabled
        Log.d(TAG_AUDIO, "SPEAKERPHONE_STATE: enabled=$enabled, result=$res")
    }

    fun toggleSpeakerphone() {
        val next = !_isSpeakerphoneOn.value
        setSpeakerphone(next)
    }

    fun setMute(muted: Boolean) {
        val res = rtcEngine?.muteLocalAudioStream(muted)
        _isMuted.value = muted
        Log.d(TAG_AUDIO, "LOCAL_AUDIO_MUTED: muted=$muted, result=$res")
    }

    fun toggleMute() {
        val next = !_isMuted.value
        setMute(next)
    }

    fun leaveChannel() {
        try {
            rtcEngine?.leaveChannel()
        } catch (e: Exception) {
            Log.e(TAG_CONN, "Error leaving channel", e)
        }
        _callState.value = AgoraCallState.Idle
    }

    private fun safeRelease() {
        try {
            rtcEngine?.leaveChannel()
        } catch (_: Exception) {}
        try {
            RtcEngine.destroy()
        } catch (_: Exception) {}
        rtcEngine = null
        _isSpeakerphoneOn.value = false
        _isMuted.value = false
    }

    fun release() {
        try {
            safeRelease()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing Agora engine", e)
        }
        _callState.value = AgoraCallState.Idle
    }
}


