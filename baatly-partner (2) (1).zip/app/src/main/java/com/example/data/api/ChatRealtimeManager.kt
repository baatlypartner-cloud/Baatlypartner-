package com.example.data.api

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.models.MessageModel
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages an authenticated Supabase Realtime WebSocket subscription for postgres_changes
 * on public.messages for a specific conversation ID.
 * Handles INSERT, UPDATE (delivery/seen status changes), and DELETE events.
 */
class ChatRealtimeManager(
    private val sessionManager: SessionManager
) {
    private val TAG = "ChatRealtimeManager"

    private var webSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val isClosed = AtomicBoolean(false)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Indefinite read timeout for WebSocket
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun subscribeToConversation(
        conversationId: String,
        onMessageInsert: (MessageModel) -> Unit,
        onMessageUpdate: (MessageModel) -> Unit,
        onMessageDelete: (String) -> Unit = {}
    ): RealtimeSubscription {
        isClosed.set(false)
        val baseUrl = sessionManager.getSupabaseUrl().trim().removeSuffix("/")
        val wsBaseUrl = when {
            baseUrl.startsWith("https://") -> baseUrl.replaceFirst("https://", "wss://")
            baseUrl.startsWith("http://") -> baseUrl.replaceFirst("http://", "ws://")
            else -> "wss://$baseUrl"
        }

        val apiKey = sessionManager.getSupabasePublishableKey()
        val token = sessionManager.accessToken.value
        val wsUrl = "$wsBaseUrl/realtime/v1/websocket?apikey=$apiKey&vsn=1.0.0"

        val channelTopic = "realtime:messages_$conversationId"

        Log.d(TAG, "Connecting to Supabase Realtime for conversationId=$conversationId topic=$channelTopic")

        val requestBuilder = Request.Builder()
            .url(wsUrl)
            .addHeader("apikey", apiKey)

        if (!token.isNullOrBlank()) {
            requestBuilder.addHeader("Authorization", "Bearer $token")
        }

        val request = requestBuilder.build()

        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(TAG, "Supabase Realtime WebSocket OPEN for conversationId=$conversationId")
                if (isClosed.get()) {
                    webSocket.close(1000, "Already closed")
                    return
                }

                try {
                    val joinPayload = JSONObject().apply {
                        put("topic", channelTopic)
                        put("event", "phx_join")
                        put("payload", JSONObject().apply {
                            put("config", JSONObject().apply {
                                put("postgres_changes", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "messages")
                                        put("filter", "conversation_id=eq.$conversationId")
                                    })
                                })
                            })
                            put("access_token", token)
                        })
                        put("ref", "1")
                    }
                    webSocket.send(joinPayload.toString())
                    Log.d(TAG, "Sent phx_join for conversationId=$conversationId")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to send phx_join for conversationId=$conversationId", e)
                }

                startHeartbeat(webSocket)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (isClosed.get()) return
                try {
                    val json = JSONObject(text)
                    val event = json.optString("event")
                    val payload = json.optJSONObject("payload")

                    if (event == "postgres_changes" && payload != null) {
                        val dataObj = payload.optJSONObject("data")
                        val changeType = dataObj?.optString("type")
                            ?: payload.optString("type", "")
                        val record = dataObj?.optJSONObject("record")
                            ?: payload.optJSONObject("record")
                            ?: dataObj?.optJSONObject("new")
                            ?: payload.optJSONObject("new")

                        val oldRecord = dataObj?.optJSONObject("old_record")
                            ?: payload.optJSONObject("old_record")

                        if (record != null) {
                            val msg = parseMessageModel(record, conversationId)
                            if (msg != null) {
                                when (changeType.uppercase()) {
                                    "INSERT" -> onMessageInsert(msg)
                                    "UPDATE" -> onMessageUpdate(msg)
                                    "DELETE" -> onMessageDelete(msg.id)
                                    else -> {
                                        // Default fallback based on record existence
                                        onMessageUpdate(msg)
                                    }
                                }
                            }
                        } else if (changeType.equals("DELETE", ignoreCase = true) && oldRecord != null) {
                            val deletedId = oldRecord.optString("id", "")
                            if (deletedId.isNotBlank()) {
                                onMessageDelete(deletedId)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error parsing realtime message: ${e.message}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "Supabase Realtime WebSocket failure for conversationId=$conversationId: ${t.message}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Supabase Realtime WebSocket closed ($code, $reason)")
            }
        }

        webSocket = okHttpClient.newWebSocket(request, listener)

        return RealtimeSubscription {
            unsubscribe(channelTopic)
        }
    }

    private fun parseMessageModel(record: JSONObject, defaultConversationId: String): MessageModel? {
        val id = record.optString("id", "")
        if (id.isBlank()) return null

        val convId = record.optString("conversation_id", defaultConversationId)
        val senderId = record.optString("sender_id", "")
        val receiverId = record.optString("receiver_id", "")
        val messageType = record.optString("message_type", "text")

        val messageText = if (record.has("message_text") && !record.isNull("message_text")) record.getString("message_text") else null
        val mediaUrl = if (record.has("media_url") && !record.isNull("media_url")) record.getString("media_url") else null
        val duration = if (record.has("media_duration_seconds") && !record.isNull("media_duration_seconds")) record.optInt("media_duration_seconds") else null
        val createdAt = if (record.has("created_at") && !record.isNull("created_at")) record.getString("created_at") else null
        val isRead = record.optBoolean("is_read", false)
        val deliveredAt = if (record.has("delivered_at") && !record.isNull("delivered_at")) {
            val s = record.optString("delivered_at", "")
            if (s.isBlank() || s.equals("null", ignoreCase = true)) null else s
        } else null
        val seenAt = if (record.has("seen_at") && !record.isNull("seen_at")) {
            val s = record.optString("seen_at", "")
            if (s.isBlank() || s.equals("null", ignoreCase = true)) null else s
        } else null

        return MessageModel(
            id = id,
            conversationId = convId,
            senderId = senderId,
            receiverId = receiverId,
            messageType = messageType,
            messageText = messageText,
            mediaUrl = mediaUrl,
            mediaDurationSeconds = duration,
            createdAt = createdAt,
            isRead = isRead,
            deliveredAt = deliveredAt,
            seenAt = seenAt
        )
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && !isClosed.get()) {
                delay(25_000)
                try {
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", "hb_${System.currentTimeMillis()}")
                    }
                    ws.send(hb.toString())
                } catch (e: Exception) {
                    Log.w(TAG, "Heartbeat send error: ${e.message}")
                }
            }
        }
    }

    fun unsubscribe(channelTopic: String? = null) {
        isClosed.set(true)
        heartbeatJob?.cancel()
        heartbeatJob = null
        try {
            if (channelTopic != null && webSocket != null) {
                val leavePayload = JSONObject().apply {
                    put("topic", channelTopic)
                    put("event", "phx_leave")
                    put("payload", JSONObject())
                    put("ref", "leave")
                }
                webSocket?.send(leavePayload.toString())
            }
        } catch (_: Exception) {}

        try {
            webSocket?.close(1000, "Unsubscribed")
        } catch (_: Exception) {}
        webSocket = null
    }
}
