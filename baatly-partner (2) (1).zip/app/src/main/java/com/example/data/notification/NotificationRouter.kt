package com.example.data.notification

import android.content.Intent
import android.os.Bundle
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

sealed class NotificationDestination {
    data class Chat(
        val conversationId: String,
        val senderId: String,
        val senderName: String
    ) : NotificationDestination()

    data class Call(
        val callId: String,
        val callerId: String? = null,
        val callerName: String? = null
    ) : NotificationDestination()

    data class Gift(
        val conversationId: String?,
        val senderId: String?,
        val senderName: String?
    ) : NotificationDestination()

    data class Admin(
        val notificationId: String?
    ) : NotificationDestination()
}

object NotificationRouter {
    private const val TAG = "NotificationRouter"

    private val _pendingDestination = MutableStateFlow<NotificationDestination?>(null)
    val pendingDestination: StateFlow<NotificationDestination?> = _pendingDestination.asStateFlow()

    // Foreground tracking to avoid duplicate in-app alerts
    @Volatile
    var currentVisibleConversationId: String? = null

    @Volatile
    var currentVisibleCallId: String? = null

    fun setDestination(dest: NotificationDestination) {
        Log.d(TAG, "Setting pending notification destination: $dest")
        _pendingDestination.value = dest
    }

    fun consumeDestination(): NotificationDestination? {
        val dest = _pendingDestination.value
        if (dest != null) {
            _pendingDestination.value = null
        }
        return dest
    }

    fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val extras = intent.extras ?: return

        Log.d(TAG, "Handling intent extras for notification tap: ${extras.keySet()}")

        val dest = parseIntentExtras(extras)
        if (dest != null) {
            Log.d(TAG, "Resolved notification tap destination: $dest")
            _pendingDestination.value = dest
        }
    }

    fun parseIntentExtras(extras: Bundle): NotificationDestination? {
        val type = extras.getString("notification_type")
            ?: extras.getString("type")
            ?: extras.getString("event_type")

        val conversationId = extras.getString("conversation_id")
            ?: extras.getString("conversationId")
            ?: extras.getString("conv_id")

        val callId = extras.getString("call_id")
            ?: extras.getString("callId")

        val senderId = extras.getString("sender_id")
            ?: extras.getString("senderId")
            ?: extras.getString("caller_id")
            ?: ""

        val senderName = extras.getString("sender_name")
            ?: extras.getString("caller_name")
            ?: extras.getString("title")
            ?: "Baatly User"

        val giftId = extras.getString("gift_id")
            ?: extras.getString("giftId")

        val notificationId = extras.getString("notification_id")
            ?: extras.getString("notificationId")

        // Also check if entire payload was passed as a json string in "data"
        val rawDataStr = extras.getString("data")
        var jsonType = type
        var jsonConvId = conversationId
        var jsonCallId = callId
        var jsonSenderId = senderId
        var jsonSenderName = senderName
        var jsonNotifId = notificationId

        if (!rawDataStr.isNullOrBlank()) {
            try {
                val json = JSONObject(rawDataStr)
                if (jsonType.isNullOrBlank()) jsonType = json.optString("notification_type", json.optString("type"))
                if (jsonConvId.isNullOrBlank()) jsonConvId = json.optString("conversation_id", json.optString("conversationId"))
                if (jsonCallId.isNullOrBlank()) jsonCallId = json.optString("call_id", json.optString("callId"))
                if (jsonSenderId.isBlank()) jsonSenderId = json.optString("sender_id", json.optString("caller_id"))
                if (jsonSenderName.isBlank() || jsonSenderName == "Baatly User") {
                    val nameInJson = json.optString("sender_name", json.optString("caller_name"))
                    if (nameInJson.isNotBlank()) jsonSenderName = nameInJson
                }
                if (jsonNotifId.isNullOrBlank()) jsonNotifId = json.optString("notification_id", json.optString("id"))
            } catch (e: Exception) {
                Log.w(TAG, "Failed parsing raw data json in extras", e)
            }
        }

        return when (jsonType?.lowercase()?.trim()) {
            "chat_message", "message", "chat" -> {
                if (!jsonConvId.isNullOrBlank()) {
                    NotificationDestination.Chat(
                        conversationId = jsonConvId,
                        senderId = jsonSenderId,
                        senderName = jsonSenderName
                    )
                } else null
            }
            "incoming_call", "call" -> {
                if (!jsonCallId.isNullOrBlank()) {
                    NotificationDestination.Call(
                        callId = jsonCallId,
                        callerId = jsonSenderId.takeIf { it.isNotBlank() },
                        callerName = jsonSenderName
                    )
                } else null
            }
            "gift_received", "gift" -> {
                NotificationDestination.Gift(
                    conversationId = jsonConvId,
                    senderId = jsonSenderId.takeIf { it.isNotBlank() },
                    senderName = jsonSenderName
                )
            }
            "admin", "system", "announcement" -> {
                NotificationDestination.Admin(
                    notificationId = jsonNotifId
                )
            }
            else -> {
                // Fallback inference if type is missing/unknown - only audio/video call or chat
                if (!jsonCallId.isNullOrBlank()) {
                    NotificationDestination.Call(callId = jsonCallId, callerId = jsonSenderId, callerName = jsonSenderName)
                } else if (!jsonConvId.isNullOrBlank()) {
                    NotificationDestination.Chat(conversationId = jsonConvId, senderId = jsonSenderId, senderName = jsonSenderName)
                } else {
                    null
                }
            }
        }
    }
}
