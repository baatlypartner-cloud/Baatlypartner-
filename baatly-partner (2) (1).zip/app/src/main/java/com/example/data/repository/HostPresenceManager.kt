package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages two completely independent presence tracking systems:
 * 1. Host Call Presence (host_start_presence, host_presence_heartbeat, host_end_presence)
 * 2. Host Chat Presence (host_start_chat_presence, host_chat_heartbeat, host_end_chat_presence)
 *
 * Adheres strictly to Rules #9, #10, #11, and #12.
 */
class HostPresenceManager(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "HostPresenceManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Call Presence tracking state
    private var callHeartbeatJob: Job? = null
    private var isCallSessionActive = false
    private val _isCallPresenceActive = MutableStateFlow(false)
    val isCallPresenceActive: StateFlow<Boolean> = _isCallPresenceActive.asStateFlow()

    // Chat Presence tracking state
    private var chatHeartbeatJob: Job? = null
    private var isChatSessionActive = false
    private val _isChatPresenceActive = MutableStateFlow(false)
    val isChatPresenceActive: StateFlow<Boolean> = _isChatPresenceActive.asStateFlow()

    val isPresenceActive: StateFlow<Boolean>
        get() = _isCallPresenceActive

    /**
     * Updates call and chat presence independently based on availability toggles.
     * Rule #10: NEVER model call+chat as one session.
     * If Call Online = ON: start host presence.
     * If Call Online = OFF: end host presence.
     * If Chat Online = ON: start chat presence.
     * If Chat Online = OFF: end chat presence.
     * If BOTH are ON: TWO independent backend sessions must be active.
     */
    fun updatePresenceForAvailability(
        isCallOnline: Boolean,
        isChatOnline: Boolean,
        isSuspended: Boolean
    ) {
        if (isSuspended) {
            Log.w(TAG, "Host is suspended; ending all presence sessions immediately")
            endAllPresence()
            return
        }

        val authUuid = sessionManager.authUuid.value
        if (authUuid.isNullOrBlank()) {
            Log.w(TAG, "Cannot manage presence: Host is not authenticated")
            endAllPresence()
            return
        }

        // 1. Manage Host Call Presence
        if (isCallOnline) {
            if (!isCallSessionActive) {
                startCallPresence()
            }
        } else {
            if (isCallSessionActive) {
                endCallPresence()
            }
        }

        // 2. Manage Host Chat Presence
        if (isChatOnline) {
            if (!isChatSessionActive) {
                startChatPresence()
            }
        } else {
            if (isChatSessionActive) {
                endChatPresence()
            }
        }
    }

    /**
     * Starts Host Call Presence session and launches its independent 30s heartbeat loop.
     */
    fun startCallPresence() {
        val authUuid = sessionManager.authUuid.value
        if (authUuid.isNullOrBlank()) return

        isCallSessionActive = true
        _isCallPresenceActive.value = true
        Log.d(TAG, "Starting host call presence")

        scope.launch {
            try {
                val res = supabaseClient.restService.hostStartPresence()
                if (res.isSuccessful) {
                    Log.i(TAG, "host_start_presence successful")
                } else {
                    Log.w(TAG, "host_start_presence returned ${res.code()}: ${res.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception in host_start_presence", e)
            }
        }

        startCallHeartbeatLoop()
    }

    /**
     * Ends Host Call Presence session and cancels its heartbeat loop.
     */
    fun endCallPresence(reason: String = "user_toggled_off") {
        Log.d(TAG, "Ending host call presence with reason: $reason")
        isCallSessionActive = false
        _isCallPresenceActive.value = false
        callHeartbeatJob?.cancel()
        callHeartbeatJob = null

        scope.launch {
            try {
                val res = supabaseClient.restService.hostEndPresence(mapOf("p_reason" to reason, "reason" to reason))
                if (res.isSuccessful) {
                    Log.i(TAG, "host_end_presence successful")
                } else {
                    Log.w(TAG, "host_end_presence returned ${res.code()}: ${res.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception in host_end_presence", e)
            }
        }
    }

    private fun startCallHeartbeatLoop() {
        callHeartbeatJob?.cancel()
        callHeartbeatJob = scope.launch {
            while (isActive && isCallSessionActive) {
                delay(30_000)
                if (!isActive || !isCallSessionActive) break

                try {
                    val res = supabaseClient.restService.hostPresenceHeartbeat()
                    if (!res.isSuccessful) {
                        Log.w(TAG, "host_presence_heartbeat returned ${res.code()}")
                    } else {
                        Log.v(TAG, "host_presence_heartbeat acknowledged")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Exception during host_presence_heartbeat", e)
                }
            }
        }
    }

    /**
     * Starts Host Chat Presence session and launches its independent 30s heartbeat loop.
     */
    fun startChatPresence() {
        val authUuid = sessionManager.authUuid.value
        if (authUuid.isNullOrBlank()) return

        isChatSessionActive = true
        _isChatPresenceActive.value = true
        Log.d(TAG, "Starting host chat presence")

        scope.launch {
            try {
                val res = supabaseClient.restService.hostStartChatPresence()
                if (res.isSuccessful) {
                    Log.i(TAG, "host_start_chat_presence successful")
                } else {
                    Log.w(TAG, "host_start_chat_presence returned ${res.code()}: ${res.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception in host_start_chat_presence", e)
            }
        }

        startChatHeartbeatLoop()
    }

    /**
     * Ends Host Chat Presence session and cancels its heartbeat loop.
     */
    fun endChatPresence(reason: String = "user_toggled_off") {
        Log.d(TAG, "Ending host chat presence with reason: $reason")
        isChatSessionActive = false
        _isChatPresenceActive.value = false
        chatHeartbeatJob?.cancel()
        chatHeartbeatJob = null

        scope.launch {
            try {
                val res = supabaseClient.restService.hostEndChatPresence(mapOf("p_reason" to reason, "reason" to reason))
                if (res.isSuccessful) {
                    Log.i(TAG, "host_end_chat_presence successful")
                } else {
                    Log.w(TAG, "host_end_chat_presence returned ${res.code()}: ${res.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception in host_end_chat_presence", e)
            }
        }
    }

    private fun startChatHeartbeatLoop() {
        chatHeartbeatJob?.cancel()
        chatHeartbeatJob = scope.launch {
            while (isActive && isChatSessionActive) {
                delay(30_000)
                if (!isActive || !isChatSessionActive) break

                try {
                    val res = supabaseClient.restService.hostChatHeartbeat()
                    if (!res.isSuccessful) {
                        Log.w(TAG, "host_chat_heartbeat returned ${res.code()}")
                    } else {
                        Log.v(TAG, "host_chat_heartbeat acknowledged")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Exception during host_chat_heartbeat", e)
                }
            }
        }
    }

    /**
     * Ends all active presence sessions immediately. Called on logout or suspension.
     */
    fun endPresence() {
        endAllPresence()
    }

    fun endAllPresence() {
        if (isCallSessionActive) {
            endCallPresence()
        } else {
            callHeartbeatJob?.cancel()
            callHeartbeatJob = null
        }

        if (isChatSessionActive) {
            endChatPresence()
        } else {
            chatHeartbeatJob?.cancel()
            chatHeartbeatJob = null
        }
    }
}
