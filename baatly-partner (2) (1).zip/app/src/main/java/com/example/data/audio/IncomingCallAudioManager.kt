package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log

object IncomingCallAudioManager {
    private const val TAG = "IncomingCallAudio"
    private var ringtone: Ringtone? = null

    @Synchronized
    fun startRingtone(context: Context) {
        if (ringtone?.isPlaying == true) {
            Log.d(TAG, "Ringtone is already playing.")
            return
        }
        try {
            val ringtoneUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            
            val r = RingtoneManager.getRingtone(context.applicationContext, ringtoneUri)
            if (r != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    r.audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                }
                r.play()
                ringtone = r
                Log.d(TAG, "Ringtone started successfully.")
            } else {
                Log.w(TAG, "Failed to get ringtone from RingtoneManager.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing ringtone", e)
        }
    }

    @Synchronized
    fun stopRingtone() {
        try {
            ringtone?.let {
                if (it.isPlaying) {
                    it.stop()
                    Log.d(TAG, "Ringtone stopped.")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping ringtone", e)
        } finally {
            ringtone = null
        }
    }
}
