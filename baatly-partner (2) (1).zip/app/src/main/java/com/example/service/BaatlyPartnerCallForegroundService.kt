package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.BaatlyApp
import com.example.MainActivity
import com.example.R

/**
 * Dedicated foreground service for active Agora voice calls.
 * Maintains microphone access, CPU partial wake lock, and VoIP audio session
 * while the Partner app is backgrounded, locked, or another app is opened.
 */
class BaatlyPartnerCallForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val TAG = "BaatlyCallFgService"
        const val ACTION_START = "com.example.service.action.START_CALL_FOREGROUND"
        const val ACTION_STOP = "com.example.service.action.STOP_CALL_FOREGROUND"
        const val EXTRA_CALL_ID = "extra_call_id"
        const val EXTRA_CALLER_NAME = "extra_caller_name"

        private const val NOTIFICATION_ID = 9001
        private const val CHANNEL_ID = "baatly_partner_active_call_channel"
        private const val CHANNEL_NAME = "Baatly Active Call"

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var activeCallId: String? = null
            private set

        fun start(context: Context, callId: String, callerName: String? = null) {
            Log.d(TAG, "START_SERVICE_REQUEST: callId=$callId")
            activeCallId = callId
            val intent = Intent(context, BaatlyPartnerCallForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_CALL_ID, callId)
                if (!callerName.isNullOrBlank()) {
                    putExtra(EXTRA_CALLER_NAME, callerName)
                }
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ContextCompat.startForegroundService(context, intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start foreground service: ${e.message}", e)
            }
        }

        fun stop(context: Context) {
            Log.d(TAG, "STOP_SERVICE_REQUEST")
            activeCallId = null
            isServiceRunning = false
            val intent = Intent(context, BaatlyPartnerCallForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to send stop intent: ${e.message}")
                try {
                    context.stopService(Intent(context, BaatlyPartnerCallForegroundService::class.java))
                } catch (_: Exception) {}
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        Log.d(TAG, "onStartCommand: action=$action")

        if (action == ACTION_STOP) {
            stopCallService()
            return START_NOT_STICKY
        }

        if (action == ACTION_START) {
            val callId = intent.getStringExtra(EXTRA_CALL_ID)
            val callerName = intent.getStringExtra(EXTRA_CALLER_NAME)
            activeCallId = callId
            isServiceRunning = true

            acquireWakeLock()
            startCallForegroundNotification(callerName)
            return START_STICKY
        }

        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            try {
                val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "BaatlyPartner:ActiveCallWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                    acquire(2 * 60 * 60 * 1000L) // 2 hours max safety timeout
                }
                Log.d(TAG, "WakeLock acquired for active call")
            } catch (e: Exception) {
                Log.w(TAG, "Could not acquire WakeLock: ${e.message}")
            }
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                Log.d(TAG, "WakeLock released")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing wake lock: ${e.message}")
        } finally {
            wakeLock = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (notificationManager?.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Baatly Partner active voice call indicator"
                    setShowBadge(false)
                    enableLights(false)
                    enableVibration(false)
                    setSound(null, null)
                }
                notificationManager?.createNotificationChannel(channel)
                Log.d(TAG, "Active call notification channel created: $CHANNEL_ID")
            }
        }
    }

    private fun startCallForegroundNotification(callerName: String?) {
        createNotificationChannel()

        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Baatly Partner call")
            .setContentText("Voice call in progress")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(pendingIntent)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                var fgType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                val hasCamera = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (hasCamera) {
                    fgType = fgType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    fgType
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            Log.d(TAG, "Foreground service started with MICROPHONE/CAMERA type")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting foreground notification: ${e.message}", e)
        }
    }

    private fun stopCallService() {
        Log.d(TAG, "stopCallService called")
        releaseWakeLock()
        isServiceRunning = false
        activeCallId = null
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping foreground: ${e.message}")
        }
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")
        releaseWakeLock()
        isServiceRunning = false
        activeCallId = null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.d(TAG, "onTaskRemoved: app task swiped away")
        try {
            BaatlyApp.instance.agoraCallManager.leaveChannel()
        } catch (_: Exception) {}
        stopCallService()
    }
}
