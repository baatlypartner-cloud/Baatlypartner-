package com.example.service

import android.util.Log
import com.example.BaatlyApp
import com.example.data.notification.NotificationHelper
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class BaatlyFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM Token received from Firebase: $token")

        try {
            val app = application as? BaatlyApp ?: BaatlyApp.instance
            app.sessionManager.saveFcmToken(token)

            serviceScope.launch {
                try {
                    val result = app.notificationRepository.syncFcmToken(force = true)
                    if (result.isSuccess) {
                        Log.d(TAG, "FCM token successfully registered with Supabase from onNewToken")
                    } else {
                        Log.w(TAG, "FCM token sync deferred/pending: ${result.exceptionOrNull()?.message}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error syncing FCM token in onNewToken", e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed processing onNewToken", e)
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message received from: ${remoteMessage.from}")

        val data = remoteMessage.data.toMutableMap()
        val notifTitle = remoteMessage.notification?.title
        val notifBody = remoteMessage.notification?.body

        Log.d(TAG, "FCM Data payload: $data")
        Log.d(TAG, "FCM Notification payload: title=$notifTitle, body=$notifBody")

        val type = (data["notification_type"] ?: data["type"] ?: data["event_type"] ?: "").lowercase().trim()
        if (type == "incoming_call" || type == "call") {
            Log.d(TAG, "Handling incoming call FCM via showIncomingCallNotification")
            NotificationHelper.showIncomingCallNotification(
                context = applicationContext,
                data = data
            )
        } else {
            NotificationHelper.showNotification(
                context = applicationContext,
                data = data,
                notificationTitle = notifTitle,
                notificationBody = notifBody
            )
        }
    }

    companion object {
        private const val TAG = "BaatlyFCMService"
    }
}
