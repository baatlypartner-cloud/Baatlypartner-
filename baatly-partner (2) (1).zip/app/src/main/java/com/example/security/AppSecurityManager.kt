package com.example.security

import android.app.Activity
import android.app.Application
import android.util.Log
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy

/**
 * Security manager for Baatly Partner App.
 * Manages application lifecycle hooks and dialog presentation properties.
 */
object AppSecurityManager {
    private const val TAG = "AppSecurityManager"

    /**
     * Initializes global Application lifecycle hooks.
     */
    fun init(application: Application) {
        Log.i(TAG, "AppSecurityManager initialized.")
    }

    /**
     * No-op stub maintained for compatibility.
     */
    fun applySecureFlag(activity: Activity?) {
        // No-op: Window security flag enforcement removed completely from Baatly Partner App
    }

    /**
     * DialogProperties builder using standard securePolicy inheritance.
     */
    fun secureDialogProperties(
        dismissOnBackPress: Boolean = true,
        dismissOnClickOutside: Boolean = true,
        usePlatformDefaultWidth: Boolean = true,
        decorFitsSystemWindows: Boolean = true
    ): DialogProperties {
        return DialogProperties(
            dismissOnBackPress = dismissOnBackPress,
            dismissOnClickOutside = dismissOnClickOutside,
            securePolicy = SecureFlagPolicy.Inherit,
            usePlatformDefaultWidth = usePlatformDefaultWidth,
            decorFitsSystemWindows = decorFitsSystemWindows
        )
    }
}
