package com.example.ui.screens.rules

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FrameNiyamScreen(onBack: () -> Unit) {
    val rules = listOf(
        "1. Call Duration & Quality" to "Call kamai platform duration aur quality standards ke anusaar compute hoti hai.",
        "2. Call Earnings Settlement" to "Calls automatically complete hote hi server dwara settle hokar wallet mein credit hoti hain.",
        "3. Chat Earning" to "Paid 1-to-1 chats par host earning automatically wallet ledger mein add hoti hai.",
        "4. Gift Earnings" to "Users se mile digital gifts ki host earning directly wallet mein credit hoti hai.",
        "5. Host Gift Sending" to "Hosts users ko gifts send nahi kar sakte.",
        "6. No Personal Number Sharing" to "Call ya chat mein WhatsApp, phone number ya personal contacts share karna sakht mana hai.",
        "7. No Direct Payment/UPI" to "Personal Google Pay, PhonePe, Paytm ya bank details mangna ya dena mana hai.",
        "8. Respectful Language" to "Gali-galoch ya abusive bhasha ka prayog turant account ban kar sakta hai.",
        "9. Real Voice Verification" to "Voice sample host ka apna aur real hona chahiye.",
        "10. Safety First" to "Kisi bhi offline meeting ki baat na karein.",
        "11. Silence Penalty" to "Call connect karke mute par baithne ya empty call chalane par call disqualify ho sakti hai.",
        "12. Multiple Accounts" to "Ek host ek se jyada accounts nahi chala sakta.",
        "13. Payout Processing" to "Wallet se withdrawal request admin approval ke baad process ki jaati hai.",
        "14. User Balance Limit" to "User balance limit reach hone par call automatically safely end ho jaati hai.",
        "15. Simultaneous Chat & Call" to "Call ke dauran host chat screen open karke message dekh aur bhej sakti hai bina call disconnect kiye.",
        "16. Independent Availability" to "Call aur Chat availability ko alag-alag on/off kiya jaa sakta hai.",
        "17. Accurate Profile Details" to "Display name aur age sachchi honi chahiye.",
        "18. Platform Moderation" to "Baatly team platform compliance ke liye automated aur manual review karti hai."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Frame Niyam (Rules)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("frame_niyam_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(BaatlyPrimaryLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MenuBook, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "BAATLY HOST CONDUCT & EARNING NIYAM",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(14.dp))

            rules.forEach { (title, description) ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = title, color = BaatlyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = description, color = TextSecondaryLight, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StrikeNiyamScreen(onBack: () -> Unit) {
    val strikePolicies = listOf(
        Triple("1st Strike (Warning)", "Yellow Card warning notification aur 24 ghante ke liye account monitoring.", BaatlyGold),
        Triple("2nd Strike (Temporary Ban)", "3 dinon ke liye Call & Chat services temporary suspend.", BaatlyRed),
        Triple("3rd Strike (Permanent Ban)", "Permanent account termination aur baaki wallet balance forfeit.", BaatlyRed)
    )

    val violations = listOf(
        "Phone number / Instagram / WhatsApp / Social media handle share karna",
        "Direct UPI ya cash mangna",
        "Abusive, vulgar ya inappropriate aawaz / baatein karna",
        "Fake voice ya doosre vyakti ki aawaz use karna",
        "Call connect karke intentionally mute ya phone chhod dena"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Strike Niyam & Policy", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("strike_niyam_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(BaatlyRedLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "STRIKE SYSTEM & ENFORCEMENT",
                    color = TextPrimaryLight,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            strikePolicies.forEach { (tier, detail, color) ->
                val bg = if (color == BaatlyGold) BaatlyGoldLight else BaatlyRedLight
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(bg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(tier, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(detail, color = TextSecondaryLight, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("STRIKE HONE KE KAARAN (VIOLATIONS)", color = BaatlyRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    violations.forEachIndexed { idx, v ->
                        Row(modifier = Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                            Text("• ", color = BaatlyRed, fontWeight = FontWeight.Bold)
                            Text(v, color = TextPrimaryLight, fontSize = 13.sp, lineHeight = 18.sp)
                        }
                        if (idx < violations.size - 1) {
                            Divider(color = BaatlyLightBorder)
                        }
                    }
                }
            }
        }
    }
}
