package com.example.ui

import android.os.Bundle
import androidx.activity.ComponentActivity

/**
 * Base activity for Activities in Baatly Partner App.
 */
abstract class BaseSecureActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
    }
}
