package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.TransactionModel
import com.example.data.models.WalletModel
import com.example.data.models.WithdrawalModel
import com.example.data.repository.TodayEarningsBreakdown
import com.example.data.repository.WalletRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WalletUiState(
    val wallet: WalletModel? = null,
    val walletSummary: com.example.data.models.WalletSummaryModel? = null,
    val todayBreakdown: TodayEarningsBreakdown = TodayEarningsBreakdown(),
    val transactions: List<TransactionModel> = emptyList(),
    val withdrawals: List<WithdrawalModel> = emptyList(),
    val isLoading: Boolean = false,
    val isSubmittingWithdrawal: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class WalletViewModel(
    private val walletRepository: WalletRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(WalletUiState())
    val uiState: StateFlow<WalletUiState> = _uiState.asStateFlow()

    init {
        loadWalletData()
    }

    fun loadWalletData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            val summaryRes = walletRepository.getWalletSummary()
            val breakdownRes = walletRepository.getTodayEarningsBreakdown()
            val txRes = walletRepository.getTransactions()
            val withRes = walletRepository.getWithdrawals()

            val summary = summaryRes.getOrNull()

            _uiState.value = _uiState.value.copy(
                walletSummary = summary,
                todayBreakdown = breakdownRes.getOrNull() ?: TodayEarningsBreakdown(
                    totalToday = summary?.todayEarningsRupees ?: 0.0,
                    callEarningsToday = summary?.callEarningsToday ?: 0.0,
                    chatEarningsToday = summary?.chatEarningsToday ?: 0.0,
                    giftEarningsToday = summary?.giftEarningsToday ?: 0.0
                ),
                transactions = txRes.getOrNull() ?: emptyList(),
                withdrawals = withRes.getOrNull() ?: emptyList(),
                isLoading = false,
                errorMessage = null
            )
        }
    }

    fun submitWithdrawal(
        accountHolderName: String,
        accountNumber: String,
        ifscCode: String,
        amount: Double,
        onSuccess: () -> Unit
    ) {
        val currentBalance = _uiState.value.walletSummary?.effectiveAvailableBalance ?: 0.0

        if (amount <= 0.0) {
            _uiState.value = _uiState.value.copy(errorMessage = "Withdrawal amount must be greater than ₹0.")
            return
        }

        if (amount > currentBalance) {
            _uiState.value = _uiState.value.copy(errorMessage = "Withdrawal amount cannot exceed available balance (₹${String.format(java.util.Locale.US, "%.2f", currentBalance)}).")
            return
        }

        if (accountHolderName.trim().isBlank() || accountNumber.trim().isBlank() || ifscCode.trim().isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Please fill in all bank details (Account Holder, Account Number, IFSC).")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSubmittingWithdrawal = true, errorMessage = null)
            val res = walletRepository.requestWithdrawal(
                amount = amount,
                accountHolderName = accountHolderName.trim(),
                accountNumber = accountNumber.trim(),
                ifscCode = ifscCode.trim().uppercase()
            )

            if (res.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isSubmittingWithdrawal = false,
                    successMessage = "Withdrawal request submitted successfully."
                )
                loadWalletData()
                onSuccess()
            } else {
                _uiState.value = _uiState.value.copy(
                    isSubmittingWithdrawal = false,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to submit withdrawal request"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun clearSuccessMessage() {
        _uiState.value = _uiState.value.copy(successMessage = null)
    }
}

class WalletViewModelFactory(
    private val walletRepository: WalletRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WalletViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WalletViewModel(walletRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
