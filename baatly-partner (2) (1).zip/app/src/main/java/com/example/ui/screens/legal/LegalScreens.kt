package com.example.ui.screens.legal

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

// Centralized external legal URL constants (changeable in one place)
const val PRIVACY_POLICY_URL = "https://REPLACE_WITH_BAATLY_PARTNER_PRIVACY_URL"
const val CHILD_SAFETY_URL = "https://REPLACE_WITH_BAATLY_PARTNER_CHILD_SAFETY_URL"
const val BAATLY_SAFETY_CONTACT_EMAIL = "baatly72@gmail.com"

private fun openBrowserUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open external link", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Screen 1: Partner Privacy Policy Screen
 * Comprehensive, transparent disclosure of data collection, usage, third-party providers,
 * security, retention, account deletion, adult audience restrictions, and host rights.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartnerPrivacyPolicyScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Privacy Policy",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("privacy_policy_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { openBrowserUrl(context, PRIVACY_POLICY_URL) },
                        modifier = Modifier.testTag("privacy_policy_web_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Open Web Version",
                            tint = BaatlyPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Header Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BaatlyPrimaryBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(BaatlyPrimaryLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = BaatlyPrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "Baatly Partner Privacy Policy",
                            color = TextPrimaryLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Host Data Governance & Transparency Guidelines",
                            color = TextSecondaryLight,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Web link notice pill
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = BaatlyBlueLight,
                border = BorderStroke(1.dp, BaatlyBlue.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = BaatlyBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Official Web Version Available",
                            color = BaatlyBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    TextButton(
                        onClick = { openBrowserUrl(context, PRIVACY_POLICY_URL) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "View on Web",
                            color = BaatlyPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 1: About this Privacy Policy
            LegalSectionCard(
                title = "1. About this Privacy Policy",
                icon = Icons.Default.Info,
                iconTint = BaatlyPrimary
            ) {
                Text(
                    text = "This Privacy Policy describes how Baatly Partner (\"we\", \"our\", or \"the platform\") collects, uses, stores, processes, and protects personal and account information when an authorized host or partner (\"you\") accesses and uses the Baatly Partner Android application.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Baatly Partner is built exclusively for registered adult hosts who provide conversational, companionship, and voice-entertainment services to platform users. By registering, logging in, or using the application, you acknowledge the data handling practices outlined in this policy.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 2: Information We Collect
            LegalSectionCard(
                title = "2. Information We Collect",
                icon = Icons.Default.Inventory,
                iconTint = BaatlyTertiary
            ) {
                Text(
                    text = "In strict accordance with the features implemented in the Baatly Partner application, we collect only the categories of data necessary to provide and manage host operations:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                LegalBulletItem("Account & Authentication Information", "Internal user identifier, email authentication credentials, encrypted session tokens, and Supabase auth UID (auth.uid()).")
                LegalBulletItem("Profile & Identity Details", "Partner display name, Indian mobile number, verified host age, biographical description (bio), and profile avatar image.")
                LegalBulletItem("Availability & Activity Status", "Real-time Call Availability toggle state, Chat Availability toggle state, online/offline presence records, and periodic heartbeat timestamps.")
                LegalBulletItem("Partner Onboarding & Voice Verification", "Voice verification audio sample (m4a recording) submitted during initial host onboarding for human identity verification and anti-fraud approval.")
                LegalBulletItem("Text Chat Messages", "Content of text messages exchanged between hosts and users within the partner chat module.")
                LegalBulletItem("Media & Voice Messages", "Private image attachments and voice note audio recordings shared within chat conversations.")
                LegalBulletItem("Voice Call Session Records", "Call session IDs, caller/receiver identifiers, call start/connect/end timestamps, call duration (in seconds), and completion/cancellation status records.")
                LegalBulletItem("Gifts & Virtual Items", "Records of virtual gifts received from users during calls and chats.")
                LegalBulletItem("Device & Push Notification Data", "Firebase Cloud Messaging (FCM) device registration tokens required strictly for delivering incoming call alerts, message notifications, and urgent platform updates.")
                LegalBulletItem("Earnings & Wallet History", "Granular records of call earnings, chat compensation, digital gift earnings, wallet transactions, and current ledger balances.")
                LegalBulletItem("Withdrawal & Payout Details", "Withdrawal requests, payout history, and host-submitted settlement details (Bank Account Number, IFSC code, Account Holder Name, or UPI ID).")

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = BaatlySlateLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Note: The Baatly Partner app does NOT collect GPS coordinates, background physical locations, phone contact address books, biometric templates, or debit/credit card credentials.",
                        color = TextSecondaryLight,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 3: How We Use Information
            LegalSectionCard(
                title = "3. How We Use Information",
                icon = Icons.Default.Rule,
                iconTint = BaatlyGreen
            ) {
                Text(
                    text = "We use the collected information solely for legitimate operational and compliance purposes, including:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LegalBulletItem("Authentication & Access", "Authenticating host login sessions and preventing unauthorized account takeover.")
                LegalBulletItem("Host Verification", "Reviewing host voice recordings and profile accuracy to ensure authentic community standards.")
                LegalBulletItem("Real-Time Communications", "Connecting real-time Agora audio voice calls and facilitating responsive text and media chat.")
                LegalBulletItem("Gift Rewards", "Facilitating virtual gift reception and credited earnings.")
                LegalBulletItem("Notification Dispatch", "Sending incoming call notifications, ring alerts, chat pings, and administrative notices.")
                LegalBulletItem("Earnings & Payout Settlement", "Accurately computing call and chat earnings, gift rewards, maintaining ledger balances, and processing approved bank withdrawals.")
                LegalBulletItem("Fraud & Abuse Prevention", "Enforcing Frame Niyam and Strike Niyam, detecting multiple account misuse, silence gaming, and toxic behaviors.")
                LegalBulletItem("Host Support", "Addressing technical or financial inquiries through our in-app AI assistant (Neha) and dedicated support channels.")
                LegalBulletItem("Legal Compliance", "Satisfying statutory obligations, preventing illegal conduct, and complying with valid law enforcement inquiries.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 4: Third-Party Service Providers
            LegalSectionCard(
                title = "4. Third-Party Service Providers",
                icon = Icons.Default.CloudSync,
                iconTint = BaatlyPrimary
            ) {
                Text(
                    text = "Baatly Partner integrates with a limited number of industry-leading infrastructure providers strictly required to operate application services:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                LegalBulletItem("Supabase Inc.", "Provides core backend database infrastructure, authenticated user management, edge API functions, and encrypted object storage for avatars and private chat media.")
                LegalBulletItem("Agora (Agora RTC)", "Provides real-time interactive audio streaming infrastructure enabling high-fidelity, low-latency host-to-user voice calling.")
                LegalBulletItem("Firebase Cloud Messaging (Google LLC)", "Delivers background push notification infrastructure for incoming call wake-ups, chat message notifications, and operational alerts.")

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "No advertising SDKs, behavioural ad networks, or data-broker tracking tools are integrated into the Baatly Partner application.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 5: Data Storage and Security
            LegalSectionCard(
                title = "5. Data Storage and Security",
                icon = Icons.Default.Lock,
                iconTint = BaatlyGold
            ) {
                Text(
                    text = "Host data is stored on secured cloud infrastructure managed by Supabase, protected by database Row-Level Security (RLS) policies and HTTPS/TLS encryption during transit.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Access to sensitive administrative records, withdrawal payout queues, and voice samples is strictly restricted to authorized operational staff with role-based credentials.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "While we employ standard technical, administrative, and organizational safeguards, please note that no method of internet transmission or electronic cloud storage is 100% invulnerable.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 6: Data Sharing
            LegalSectionCard(
                title = "6. Data Sharing",
                icon = Icons.Default.Share,
                iconTint = BaatlyPurple
            ) {
                Text(
                    text = "Baatly does NOT sell, rent, or trade your personal information to third parties as a business practice.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Data is shared only in the following strictly limited contexts:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                LegalBulletItem("Infrastructure Providers", "With Supabase, Agora, and Firebase as required to host, route, and deliver core features.")
                LegalBulletItem("Public Host Profile Visibility", "Your chosen display name, avatar, bio, and age are visible to users across the Baatly ecosystem.")
                LegalBulletItem("Legal & Regulatory Requirements", "When compelled by court orders, subpoenas, statutory tax compliance, or urgent public safety imperatives.")
                LegalBulletItem("Protection & Enforcement", "To enforce platform policies, investigate financial fraud, combat chargeback abuse, or address severe safety violations.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 7: Data Retention
            LegalSectionCard(
                title = "7. Data Retention",
                icon = Icons.Default.History,
                iconTint = BaatlySlate
            ) {
                Text(
                    text = "We retain host data for as long as your partner account remains active or as reasonably necessary to fulfill platform operations, support requests, and financial settlements.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Certain records—including withdrawal transactions, bank payout confirmations, fraud investigation logs, and compliance audits—are retained for statutory retention periods prescribed by financial and tax regulations.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 8: Account and Data Deletion
            LegalSectionCard(
                title = "8. Account and Data Deletion",
                icon = Icons.Default.DeleteForever,
                iconTint = BaatlyRed
            ) {
                Text(
                    text = "Baatly Partner provides an in-app Account Deletion Request mechanism accessible in the Host Profile screen under \"Delete Account\".",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Upon confirming account deletion, an authenticated request is submitted directly to the backend system via the request_account_deletion RPC. Deletion is initiated following review and settlement of any active balances.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Please note: Submitting a request initiates the review process; immediate automatic destruction of all records does not occur where legal, accounting, tax, or fraud-prevention retention mandates apply.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 9: Children's Safety / Age Safety
            LegalSectionCard(
                title = "9. Children's Safety / Age Safety",
                icon = Icons.Default.Shield,
                iconTint = BaatlyRed
            ) {
                Text(
                    text = "Baatly Partner is strictly reserved for adult hosts who are 18 years of age or older. We do not knowingly permit minors to register or operate as partners.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "We maintain an absolute zero-tolerance policy against child sexual abuse material (CSAM), child sexual exploitation and abuse (CSAE), minor grooming, or any solicitation of underage individuals. Any partner engaging in or facilitating child exploitation will be terminated immediately and reported to authorities.",
                    color = BaatlyRed,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 10: User Privacy Rights
            LegalSectionCard(
                title = "10. User Privacy Rights",
                icon = Icons.Default.VerifiedUser,
                iconTint = BaatlyPrimary
            ) {
                Text(
                    text = "Depending on applicable local privacy laws, hosts maintain specific rights regarding their personal information:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LegalBulletItem("Right to Access", "You may view your profile, calling logs, earnings history, and wallet ledgers directly in the app.")
                LegalBulletItem("Right to Correction", "You can update your display name, bio, and avatar via the \"Edit Profile\" screen at any time.")
                LegalBulletItem("Right to Request Deletion", "You can submit an account deletion request using the in-app Delete Account feature.")
                LegalBulletItem("Inquiries & Grievances", "You may contact our designated privacy contact for any questions regarding your stored information.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 11: Policy Changes
            LegalSectionCard(
                title = "11. Policy Changes",
                icon = Icons.Default.Update,
                iconTint = BaatlyCyan
            ) {
                Text(
                    text = "We may revise or update this Privacy Policy from time to time to reflect modifications in platform features, operational practices, or legal requirements.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "When changes occur, the updated policy will be made available inside the app and on the official legal web page. Your continued use of the platform constitutes acknowledgment of the updated terms.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 12: Contact Information
            LegalSectionCard(
                title = "12. Contact Us",
                icon = Icons.Default.Email,
                iconTint = BaatlyGreen
            ) {
                Text(
                    text = "If you have questions, feedback, or privacy-related requests regarding this Privacy Policy, please reach out to our designated contact:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = BaatlyGreenLight,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BaatlyGreenBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Baatly Privacy & Child Safety Contact",
                            color = BaatlyGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = BAATLY_SAFETY_CONTACT_EMAIL,
                            color = TextPrimaryLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

/**
 * Screen 2: Partner Child Safety Standards Screen
 * Comprehensive child safety standards with zero-tolerance rules, prohibited conduct,
 * enforcement mechanisms, reporting guidelines without uploading CSAM, and authority cooperation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartnerChildSafetyScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Child Safety Standards",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("child_safety_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { openBrowserUrl(context, CHILD_SAFETY_URL) },
                        modifier = Modifier.testTag("child_safety_web_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Open Web Version",
                            tint = BaatlyGreen
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Header Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BaatlyGreenBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(BaatlyGreenLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = BaatlyGreen,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "Baatly Partner Child Safety Standards",
                            color = TextPrimaryLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Zero Tolerance Policy Against Child Abuse & Exploitation",
                            color = TextSecondaryLight,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Web notice banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = BaatlyGreenLight,
                border = BorderStroke(1.dp, BaatlyGreenBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = BaatlyGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Official Web Version Available",
                            color = BaatlyGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    TextButton(
                        onClick = { openBrowserUrl(context, CHILD_SAFETY_URL) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "View on Web",
                            color = BaatlyPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 1: Zero Tolerance for CSAE and CSAM
            LegalSectionCard(
                title = "1. Zero Tolerance for CSAE and CSAM",
                icon = Icons.Default.Gavel,
                iconTint = BaatlyRed
            ) {
                Text(
                    text = "Baatly enforces an absolute, unconditional zero-tolerance policy against any form of Child Sexual Abuse and Exploitation (CSAE) and Child Sexual Abuse Material (CSAM).",
                    color = BaatlyRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "The following activities are strictly prohibited across all partner communications and platform features without exception:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LegalBulletItem("Child Sexual Abuse and Exploitation (CSAE)", "Any act, communication, or behavior that sexually abuses, exploits, harms, or endangers a minor (any person under 18 years of age).")
                LegalBulletItem("Child Sexual Abuse Material (CSAM)", "Creating, producing, requesting, possessing, storing, sharing, uploading, or transmitting any visual, audio, or textual media depicting child sexual abuse or sexually explicit content involving a minor.")
                LegalBulletItem("Grooming & Manipulation", "Building emotional rapport, gaining trust, or manipulating a minor for sexual exploitation, illicit conversations, or abusive purposes.")
                LegalBulletItem("Sexual Solicitation of Minors", "Requesting, encouraging, or coercing minors to engage in sexual discussions, provide explicit images/audio, or perform sexual acts.")
                LegalBulletItem("Sextortion & Trafficking", "Blackmailing, extorting, coercing, or facilitating the commercial or non-commercial exploitation or trafficking of children.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 2: Prohibited Conduct
            LegalSectionCard(
                title = "2. Prohibited Conduct for Partners",
                icon = Icons.Default.Block,
                iconTint = BaatlyRed
            ) {
                Text(
                    text = "As an adult host on Baatly Partner, you must NEVER use your account, voice calls, or chats to:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LegalBulletItem("Target Underage Individuals", "Initiate, encourage, or entertain sexual or inappropriate conversations with any user who states, implies, or is suspected to be a minor.")
                LegalBulletItem("Solicit Content From Minors", "Ask for personal photos, voice clips, private phone numbers, or social media handles from minors.")
                LegalBulletItem("Facilitate Child Exploitation", "Assist, encourage, or collaborate with any third party in facilitating child exploitation or abuse.")
                LegalBulletItem("Off-Platform Redirection", "Attempt to lure minors to third-party messaging apps (WhatsApp, Telegram, Instagram) or propose offline meetings.")
                LegalBulletItem("Falsify Age or Verification", "Allow underage individuals to operate a partner account, use a minor's voice, or falsify host age during onboarding.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 3: Safety and Enforcement
            LegalSectionCard(
                title = "3. Safety & Enforcement Actions",
                icon = Icons.Default.Warning,
                iconTint = BaatlyGold
            ) {
                Text(
                    text = "Upon detecting or receiving any report or credible indicator of child safety violations, Baatly executes rapid and decisive enforcement measures:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LegalBulletItem("Immediate Content Purge", "All offending messages, media, photos, and voice notes are permanently removed.")
                LegalBulletItem("Feature Revocation", "Real-time termination of voice calling, chat sending, and profile visibility privileges.")
                LegalBulletItem("Permanent Account Ban", "Immediate permanent termination of the partner account with no opportunity for reinstatement.")
                LegalBulletItem("Earnings Forfeiture", "Immediate cancellation and forfeiture of all accrued wallet balances and pending withdrawal requests.")
                LegalBulletItem("Evidence Preservation", "Systematic preservation of relevant account logs, IP addresses, session data, and records in accordance with statutory requirements.")
                LegalBulletItem("Law Enforcement Referral", "Immediate formal escalation to law enforcement agencies and specialized child protection bureaus.")
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 4: Reporting Child Safety Concerns
            LegalSectionCard(
                title = "4. Reporting Child Safety Concerns",
                icon = Icons.Default.Report,
                iconTint = BaatlyPrimary
            ) {
                Text(
                    text = "If you encounter any behavior, user, or communication that threatens the safety of a child or involves potential child exploitation, report it immediately to our designated team:",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = BaatlyPrimaryLight,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BaatlyPrimaryBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Designated Child Safety Reporting Email",
                            color = BaatlyPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = BAATLY_SAFETY_CONTACT_EMAIL,
                            color = TextPrimaryLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // CRITICAL SAFETY NOTICE: Do not upload illegal CSAM
                Surface(
                    color = Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFFECDD3)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = BaatlyRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CRITICAL INSTRUCTION FOR REPORTS",
                                color = BaatlyRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "DO NOT attach, forward, upload, or email illegal CSAM itself. Your report should contain only factual descriptions, user display names, conversation IDs, dates, and timestamps. Transmitting CSAM even for reporting purposes is strictly prohibited by law.",
                                color = Color(0xFF991B1B),
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 5: Cooperation With Authorities
            LegalSectionCard(
                title = "5. Cooperation With Authorities",
                icon = Icons.Default.AccountBalance,
                iconTint = BaatlyTertiary
            ) {
                Text(
                    text = "Baatly maintains full and proactive cooperation with certified law enforcement agencies, cybercrime investigation divisions, and statutory child protection authorities.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "In compliance with applicable domestic and international laws, we respond promptly to lawful requests, assist in criminal investigations, preserve audit logs, and report detected instances of child sexual abuse to competent authorities.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 6: Scope and Applicability
            LegalSectionCard(
                title = "6. Scope and Applicability",
                icon = Icons.Default.FactCheck,
                iconTint = BaatlyGreen
            ) {
                Text(
                    text = "These Child Safety Standards apply universally to all registered Baatly Partner hosts, partners, onboarding applicants, and any interaction, audio call, text message, or media upload conducted on or through the Baatly platform.",
                    color = TextPrimaryLight,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Adherence to these standards is a mandatory condition of partner onboarding and ongoing account authorization. Violations will result in immediate termination, earnings forfeiture, and legal referral.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

/**
 * Reusable card for legal policy sections
 */
@Composable
private fun LegalSectionCard(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BaatlyLightBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    color = TextPrimaryLight,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

/**
 * Reusable bullet item for legal policy sections
 */
@Composable
private fun LegalBulletItem(title: String, description: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "• ",
            color = BaatlyPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Column {
            Text(
                text = title,
                color = TextPrimaryLight,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = description,
                color = TextSecondaryLight,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}
