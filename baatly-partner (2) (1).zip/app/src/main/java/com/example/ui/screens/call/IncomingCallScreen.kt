package com.example.ui.screens.call

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.theme.*

@Composable
fun IncomingCallScreen(
    callerName: String,
    callerAvatarUrl: String?,
    isVideoCall: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    classificationLabel: String? = null,
    isLoadingClassification: Boolean = false
) {
    val privateMediaRepo = BaatlyApp.instance.privateMediaRepository
    val resolvedAvatar by rememberProfileAvatarUrl(callerAvatarUrl, privateMediaRepo)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // 1. Caller profile photo fills entire screen
        if (!resolvedAvatar.isNullOrBlank()) {
            Image(
                painter = rememberAsyncImagePainter(model = resolvedAvatar),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(16.dp), // 12-18dp soft blur keeps caller photo visible
                contentScale = ContentScale.Crop
            )
        } else {
            // fallback if avatar cannot be loaded: show warm light gray
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF1F5F9))
            )
        }

        // 2. Light translucent overlay (0.35 alpha)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White.copy(alpha = 0.35f))
        )

        // 3. Content layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Info
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                Text(
                    text = if (isVideoCall) "INCOMING VIDEO CALL" else "INCOMING AUDIO CALL",
                    color = if (isVideoCall) Color(0xFF7C3AED) else BaatlyPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(32.dp))

                // Avatar in Center
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(pulseScale),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer ring
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(if (isVideoCall) Color(0xFFD8B4FE).copy(alpha = 0.4f) else BaatlyPrimary.copy(alpha = 0.2f))
                    )
                    // Inner Avatar
                    if (!resolvedAvatar.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(model = resolvedAvatar),
                            contentDescription = "Caller Avatar",
                            modifier = Modifier
                                .size(116.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(116.dp)
                                .clip(CircleShape)
                                .background(if (isVideoCall) Color(0xFF7C3AED) else BaatlyPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = callerName.take(1).uppercase(),
                                color = Color.White,
                                fontSize = 44.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = callerName,
                    color = Color(0xFF1E293B),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )

                if (classificationLabel != null || isLoadingClassification) {
                    Spacer(modifier = Modifier.height(12.dp))
                    if (classificationLabel != null) {
                        val isRepeat = classificationLabel == "REPEAT USER"
                        val badgeBg = if (isRepeat) BaatlyGreenLight else BaatlyPrimaryLight
                        val badgeBorder = if (isRepeat) BaatlyGreenBorder else BaatlyPrimaryBorder
                        val badgeColor = if (isRepeat) Color(0xFF059669) else BaatlyPrimary
                        val badgeIcon = if (isRepeat) Icons.Outlined.Autorenew else Icons.Outlined.PersonAdd

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = badgeBg,
                            border = BorderStroke(1.dp, badgeBorder),
                            modifier = Modifier.testTag("caller_classification_badge")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = badgeIcon,
                                    contentDescription = null,
                                    tint = badgeColor,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = classificationLabel,
                                    color = badgeColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    } else if (isLoadingClassification) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.testTag("caller_classification_loading")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = BaatlyPrimary,
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Checking user record...",
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Buttons (Accept / Decline)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 48.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Decline Button (Red)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(
                        onClick = onDecline,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("decline_call_button"),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "Decline",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Decline",
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Accept Button (Green)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(
                        onClick = onAccept,
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyGreen),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("accept_call_button"),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Accept",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Accept",
                        color = BaatlyGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
