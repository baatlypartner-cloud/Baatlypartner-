package com.example.ui.screens.home

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.screens.performance.HomePerformanceCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

data class HostShortcutItem(
    val title: String,
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconTintColor: Color,
    val route: String
)

@Composable
fun HomeScreen(
    mainViewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val uiData by mainViewModel.uiData.collectAsState()

    val shortcuts = listOf(
        HostShortcutItem("SCORES", Icons.Default.Speed, BaatlyCyanLight, BaatlyCyan, "performance_daily"),
        HostShortcutItem("HISTORY", Icons.Default.History, BaatlyPrimaryLight, BaatlyPrimary, "recent_calls"),
        HostShortcutItem("WALLET", Icons.Default.AccountBalanceWallet, BaatlyGreenLight, BaatlyGreen, "wallet"),
        HostShortcutItem("RULES", Icons.Default.MenuBook, BaatlyGoldLight, BaatlyGold, "frame_niyam"),
        HostShortcutItem("BLOCKS", Icons.Default.Block, BaatlyRedLight, BaatlyRed, "blocked_users"),
        HostShortcutItem("KAMAI", Icons.Default.MonetizationOn, BaatlyGoldLight, BaatlyGold, "call_kamai"),
        HostShortcutItem("SKILLS", Icons.Default.Psychology, BaatlyBlueLight, BaatlyBlue, "skills"),
        HostShortcutItem("LEARN", Icons.Default.PlayCircle, BaatlyCyanLight, BaatlyCyan, "training"),
        HostShortcutItem("STRIKE", Icons.Default.Gavel, BaatlyRedLight, BaatlyRed, "strike_niyam"),
        HostShortcutItem("REFER", Icons.Default.Share, BaatlyPurpleLight, BaatlyPurple, "refer")
    )

    val avgMinutes = uiData.averageCallDurationSeconds / 60
    val avgSeconds = uiData.averageCallDurationSeconds % 60
    val avgDurationStr = String.format("%02d:%02d", avgMinutes, avgSeconds)

    val hostId = uiData.profile?.userId?.uppercase() ?: if (uiData.isLoading) "..." else "BAATLY_HOST"
    val displayName = uiData.partnerProfile?.partnerDisplayName ?: uiData.profile?.displayName ?: if (uiData.isLoading) "Loading..." else "Baatly Host"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BaatlyLightBackground)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Creator Header Bar with Glowing Avatar & Status Indicator
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    val avatarUrl = uiData.profile?.avatarUrl
                    val privateMediaRepo = (LocalContext.current.applicationContext as BaatlyApp).privateMediaRepository
                    val resolvedAvatarUrl by rememberProfileAvatarUrl(avatarUrl, privateMediaRepo)

                    // Modern Avatar with glowing gradient ring
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFFD946EF), Color(0xFF8B5CF6), Color(0xFFEC4899))
                                )
                            )
                            .padding(2.5.dp)
                            .clip(CircleShape)
                    ) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                contentDescription = "Host Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = displayName.take(1).uppercase(),
                                    color = Color(0xFFC026D3),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = displayName,
                                color = Color(0xFF0F172A),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Host ID Pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF1F5F9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "ID: $hostId",
                                    color = Color(0xFF475569),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.5.sp
                                )
                            }

                            // Quick Online Status Indicator
                            val isAnyOnline = uiData.isCallOnline || uiData.isChatOnline
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isAnyOnline) Color(0xFFECFDF5) else Color(0xFFF8FAFC))
                                    .border(
                                        1.dp,
                                        if (isAnyOnline) Color(0xFFA7F3D0) else Color(0xFFE2E8F0),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isAnyOnline) "● Online" else "○ Offline",
                                    color = if (isAnyOnline) Color(0xFF059669) else Color(0xFF94A3B8),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Refresh Button
                IconButton(
                    onClick = { mainViewModel.loadAllData() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFAF5FF))
                        .border(1.dp, Color(0xFFF3E8FF), CircleShape)
                        .testTag("refresh_home_button")
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = Color(0xFF9333EA),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Content Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            // Vibrant Pink + Purple + Magenta Creator Hero Earnings Card (Exactly 4 Segments)
            Card(
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("wallet") }
                    .testTag("today_earnings_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF7C3AED), // Deep Vibrant Purple
                                    Color(0xFFC026D3), // Vibrant Magenta
                                    Color(0xFFEC4899)  // Rich Pink
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "TODAY'S EARNINGS",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.22f))
                                    .padding(horizontal = 9.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "LIVE",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (uiData.isLoading && uiData.partnerProfile == null) {
                            Box(modifier = Modifier.padding(vertical = 6.dp)) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(26.dp),
                                    strokeWidth = 2.5.dp
                                )
                            }
                        } else {
                            Text(
                                text = "₹${String.format(java.util.Locale.US, "%.2f", uiData.todayEarnings.totalToday)}",
                                color = Color.White,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Glassmorphic separator
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color.White.copy(alpha = 0.22f))
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 3 Earning Segments: CALLS, CHATS, GIFTS
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // 1. CALLS
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "CALLS",
                                    color = Color.White.copy(alpha = 0.82f),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "₹${String.format(java.util.Locale.US, "%.2f", uiData.todayEarnings.callEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            // Divider
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(28.dp)
                                    .background(Color.White.copy(alpha = 0.22f))
                            )

                            // 2. CHATS
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "CHATS",
                                    color = Color.White.copy(alpha = 0.82f),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "₹${String.format(java.util.Locale.US, "%.2f", uiData.todayEarnings.chatEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            // Divider
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(28.dp)
                                    .background(Color.White.copy(alpha = 0.22f))
                            )

                            // 3. GIFTS
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "GIFTS",
                                    color = Color.White.copy(alpha = 0.82f),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "₹${String.format(java.util.Locale.US, "%.2f", uiData.todayEarnings.giftEarningsToday)}",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }
            }

            if (uiData.isSuspended) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(listOf(Color(0xFFF87171), Color(0xFFEF4444)))
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("host_suspended_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = "Suspended",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Account Suspended",
                                color = Color(0xFF991B1B),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Your host account has been suspended by administration. Calling and chat services are locked.",
                                color = Color(0xFFB91C1C),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Service Availability Controls (Grid 3 cols: AUDIO CALL, VIDEO CALL, CHAT SERVICE)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. Audio Call Service Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mainViewModel.toggleCallAvailability(!uiData.isCallOnline) }
                        .testTag("call_service_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Switch Pill
                        Box(
                            modifier = Modifier
                                .width(44.dp)
                                .height(24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (uiData.isCallOnline) BaatlyGreen else Color(0xFFCBD5E1))
                                .padding(2.5.dp),
                            contentAlignment = if (uiData.isCallOnline) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(19.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .shadow(2.dp, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "AUDIO CALL",
                            color = TextPrimaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (uiData.isCallOnline) "ONLINE" else "OFFLINE",
                            color = if (uiData.isCallOnline) BaatlyGreen else TextSecondaryLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 2. Video Call Service Card
                val isVideoApproved = uiData.isVideoAccessApproved
                val videoStatus = uiData.videoAccessStatus.lowercase()
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            if (isVideoApproved) {
                                mainViewModel.toggleVideoAvailability(!uiData.isVideoOnline)
                            } else {
                                onNavigate("video_access_request")
                            }
                        }
                        .testTag("video_service_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (isVideoApproved) {
                            // Switch Pill for approved hosts
                            Box(
                                modifier = Modifier
                                    .width(44.dp)
                                    .height(24.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (uiData.isVideoOnline) Color(0xFF7C3AED) else Color(0xFFCBD5E1))
                                    .padding(2.5.dp),
                                contentAlignment = if (uiData.isVideoOnline) Alignment.CenterEnd else Alignment.CenterStart
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(19.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .shadow(2.dp, CircleShape)
                                )
                            }
                        } else {
                            // Badge Icon for unapproved / pending / rejected states
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (videoStatus) {
                                            "pending" -> Color(0xFFFEF3C7)
                                            "rejected" -> Color(0xFFFEE2E2)
                                            else -> Color(0xFFF1F5F9)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (videoStatus) {
                                        "pending" -> Icons.Default.HourglassTop
                                        "rejected" -> Icons.Default.Cancel
                                        else -> Icons.Default.Lock
                                    },
                                    contentDescription = null,
                                    tint = when (videoStatus) {
                                        "pending" -> Color(0xFFD97706)
                                        "rejected" -> Color(0xFFDC2626)
                                        else -> Color(0xFF64748B)
                                    },
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "VIDEO CALL",
                            color = TextPrimaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (isVideoApproved) {
                                if (uiData.isVideoOnline) "ONLINE" else "OFFLINE"
                            } else {
                                when (videoStatus) {
                                    "pending" -> "PENDING"
                                    "rejected" -> "REJECTED"
                                    else -> "GET ACCESS"
                                }
                            },
                            color = if (isVideoApproved) {
                                if (uiData.isVideoOnline) Color(0xFF7C3AED) else TextSecondaryLight
                            } else {
                                when (videoStatus) {
                                    "pending" -> Color(0xFFD97706)
                                    "rejected" -> Color(0xFFDC2626)
                                    else -> Color(0xFF6366F1)
                                }
                            },
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 3. Chat Service Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { mainViewModel.toggleChatAvailability(!uiData.isChatOnline) }
                        .testTag("chat_service_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Switch Pill
                        Box(
                            modifier = Modifier
                                .width(44.dp)
                                .height(24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (uiData.isChatOnline) BaatlyBlue else Color(0xFFCBD5E1))
                                .padding(2.5.dp),
                            contentAlignment = if (uiData.isChatOnline) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(19.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .shadow(2.dp, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "CHAT SERVICE",
                            color = TextPrimaryLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (uiData.isChatOnline) "ONLINE" else "OFFLINE",
                            color = if (uiData.isChatOnline) BaatlyBlue else TextSecondaryLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Average Call Duration Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BaatlyGoldLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                tint = BaatlyGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Avg. Call Duration",
                                color = TextPrimaryLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Last 30 completed calls",
                                color = TextSecondaryLight,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Text(
                        text = avgDurationStr,
                        color = BaatlyGold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Phase 3 & 4: Performance Card (Authoritative scores, speedometer meter, daily/weekly toggle, compact metrics, warnings, guidance)
            HomePerformanceCard(
                dailyScore = uiData.dailyPerformanceScore,
                weeklyScore = uiData.weeklyPerformanceScore,
                thresholds = uiData.performanceThresholds,
                lastUpdatedText = "Server Data",
                isRefreshing = uiData.isRefreshingPerformance,
                onRefresh = { mainViewModel.refreshPerformance() },
                onViewDailyDetails = { onNavigate("performance_daily") },
                onViewWeeklyDetails = { onNavigate("performance_weekly") },
                onViewHistory = { onNavigate("performance_history") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Professional Polish Action Grid (4 Columns)
            val chunkedShortcuts = shortcuts.chunked(4)
            chunkedShortcuts.forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowItems.forEach { item ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(88.dp)
                                .padding(vertical = 4.dp)
                                .clickable {
                                    if (item.route == "refer") {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Join Baatly Partner App as an Audio Jockey Host! Register here: https://baatly.com/partner")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, "Share Baatly Partner"))
                                    } else {
                                        onNavigate(item.route)
                                    }
                                }
                                .testTag("shortcut_${item.route}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(item.iconBgColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        item.icon,
                                        contentDescription = item.title,
                                        tint = item.iconTintColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.title,
                                    color = TextSecondaryLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 11.sp
                                )
                            }
                        }
                    }
                    // Pad empty spots if incomplete row
                    for (i in 0 until (4 - rowItems.size)) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Need Help / WhatsApp Support Banner
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = BaatlyPrimaryLight),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyPrimaryBorder, BaatlyPrimaryBorder))),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val url = "https://wa.me/8744048708?text=Hello%20Baatly%20Support,%20I%20need%20assistance"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    }
                    .testTag("shortcut_support")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.HeadsetMic,
                                contentDescription = null,
                                tint = BaatlyPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Need Help?",
                                color = Color(0xFF312E81), // Indigo 900
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Contact Support via WhatsApp",
                                color = BaatlyPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BaatlyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = "Contact WhatsApp",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
