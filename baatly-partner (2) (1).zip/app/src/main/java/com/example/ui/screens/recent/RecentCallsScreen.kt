package com.example.ui.screens.recent

import com.example.data.models.isUuid
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.models.CallModel
import com.example.data.models.UserRatingModel
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.components.PostCallRatingSection
import com.example.ui.components.ReportUserDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.CallViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecentCallsScreen(
    callViewModel: CallViewModel
) {
    val context = LocalContext.current
    val app = context.applicationContext as BaatlyApp
    val partnerRepo = app.partnerRepository
    val privateMediaRepo = app.privateMediaRepository

    val recentCalls by callViewModel.recentCalls.collectAsState()
    val isLoading by callViewModel.isLoadingRecent.collectAsState()

    var selectedCallForDetails by remember { mutableStateOf<CallModel?>(null) }
    var showReportDialogForUser by remember { mutableStateOf<Pair<String, String>?>(null) } // (userId, userName)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Call Itihas (Recent Calls)", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(
                        onClick = { callViewModel.loadRecentCalls() },
                        modifier = Modifier.testTag("refresh_recent_calls_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (recentCalls.isEmpty() && !isLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.PhoneMissed, contentDescription = null, tint = TextSecondaryLight, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Koi Call Record Nahi Hai", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Jab aap calls receive karenge, unka itihas yahan dikhega.", color = TextSecondaryLight, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    items(recentCalls) { call ->
                        val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                            ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                            ?: "User"
                        val duration = call.durationSeconds ?: 0
                        val min = duration / 60
                        val sec = duration % 60
                        val durationStr = String.format(java.util.Locale.US, "%02d:%02d", min, sec)
                        val earning = call.partnerEarningRupees ?: 0.0

                        val isCompleted = call.status == "completed"
                        val statusBg = when (call.status) {
                            "completed" -> BaatlyGreenLight
                            "rejected" -> BaatlyRedLight
                            "missed" -> BaatlyGoldLight
                            else -> BaatlyLightSurfaceVariant
                        }
                        val statusColor = when (call.status) {
                            "completed" -> BaatlyGreen
                            "rejected" -> BaatlyRed
                            "missed" -> BaatlyGold
                            else -> TextSecondaryLight
                        }

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { selectedCallForDetails = call }
                                .testTag("call_item_${call.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(statusBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isCompleted) Icons.Default.CallReceived else Icons.Default.CallEnd,
                                            contentDescription = null,
                                            tint = statusColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(callerName, color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("Duration: $durationStr", color = TextSecondaryLight, fontSize = 12.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    if (earning > 0) {
                                        Text("+₹${String.format("%.2f", earning)}", color = BaatlyGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    } else {
                                        Text("₹0.00", color = TextSecondaryLight, fontSize = 12.sp)
                                    }
                                    Text(call.status.uppercase(), color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                CircularProgressIndicator(
                    color = BaatlyPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Call Details Bottom Sheet
        val activeCall = selectedCallForDetails
        if (activeCall != null) {
            val callerUserId = activeCall.userId ?: activeCall.userProfile?.id ?: ""
            val callerName = activeCall.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: activeCall.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: "User"
            val resolvedCallerAvatar by rememberProfileAvatarUrl(activeCall.userProfile?.avatarUrl, privateMediaRepo)

            var userRating by remember(callerUserId) { mutableStateOf<UserRatingModel?>(null) }
            var isLoadingRating by remember(callerUserId) { mutableStateOf(callerUserId.isNotBlank()) }

            LaunchedEffect(callerUserId) {
                if (callerUserId.isNotBlank()) {
                    isLoadingRating = true
                    val res = partnerRepo.getPublicUserRating(callerUserId)
                    userRating = res.getOrNull()
                    isLoadingRating = false
                }
            }

            ModalBottomSheet(
                onDismissRequest = { selectedCallForDetails = null },
                containerColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!resolvedCallerAvatar.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(model = resolvedCallerAvatar),
                            contentDescription = "Caller Avatar",
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = callerName.take(1).uppercase(),
                                color = BaatlyPrimary,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = callerName,
                        color = TextPrimaryLight,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // User Public Rating Display
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = BaatlyGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        val avg = userRating?.averageRating ?: 5.0
                        val cnt = userRating?.ratingCount ?: 0
                        Text(
                            text = String.format("%.1f", avg),
                            color = TextPrimaryLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (cnt > 0) "($cnt ratings)" else "(New user)",
                            color = TextSecondaryLight,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Call summary stats
                    Surface(
                        color = BaatlyLightBackground,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            val duration = activeCall.durationSeconds ?: 0
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = String.format("%02d:%02d", duration / 60, duration % 60),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimaryLight
                                )
                                Text("Duration", fontSize = 11.sp, color = TextSecondaryLight)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "₹${String.format(java.util.Locale.US, "%.2f", activeCall.partnerEarningRupees ?: 0.0)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BaatlyGreen
                                )
                                Text("Earning", fontSize = 11.sp, color = TextSecondaryLight)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = activeCall.status.uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (activeCall.status == "completed") BaatlyGreen else BaatlyRed
                                )
                                Text("Status", fontSize = 11.sp, color = TextSecondaryLight)
                            }
                        }
                    }

                    // Rating Section if call is eligible
                    if (activeCall.status == "completed" && callerUserId.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        PostCallRatingSection(
                            callId = activeCall.id,
                            userId = callerUserId,
                            userName = callerName,
                            onRatingSubmitted = {},
                            onRequestReport = {
                                showReportDialogForUser = Pair(callerUserId, callerName)
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Report User Button
                    OutlinedButton(
                        onClick = {
                            if (callerUserId.isNotBlank()) {
                                showReportDialogForUser = Pair(callerUserId, callerName)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BaatlyRed),
                        border = BorderStroke(1.dp, BaatlyRedLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_user_from_call_button")
                    ) {
                        Icon(Icons.Default.Report, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Report This User", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        val reportUserTarget = showReportDialogForUser
        if (reportUserTarget != null) {
            ReportUserDialog(
                reportedUserId = reportUserTarget.first,
                userName = reportUserTarget.second,
                callId = selectedCallForDetails?.id,
                onDismiss = { showReportDialogForUser = null },
                onReportSubmitted = {
                    showReportDialogForUser = null
                    selectedCallForDetails = null
                }
            )
        }
    }
}
