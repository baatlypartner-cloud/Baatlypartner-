package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.ChatRealtimeManager
import com.example.data.api.RealtimeSubscription
import com.example.data.audio.AudioPlayerHelper
import com.example.data.audio.AudioRecorderHelper
import com.example.data.local.SessionManager
import com.example.data.models.ConversationModel
import com.example.data.models.ConversationParticipantProfile
import com.example.data.models.GiftModel
import com.example.data.models.GiftTransactionModel
import com.example.data.models.MessageModel
import com.example.data.repository.ChatRepository
import com.example.data.repository.PrivateMediaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val sessionManager: SessionManager,
    private val chatRealtimeManager: ChatRealtimeManager,
    val audioRecorderHelper: AudioRecorderHelper,
    val audioPlayerHelper: AudioPlayerHelper,
    val privateMediaRepository: PrivateMediaRepository
) : ViewModel() {

    private val TAG = "ChatViewModel"

    private val _conversations = MutableStateFlow<List<ConversationModel>>(emptyList())
    val conversations: StateFlow<List<ConversationModel>> = _conversations.asStateFlow()

    private val _activeMessages = MutableStateFlow<List<MessageModel>>(emptyList())
    val activeMessages: StateFlow<List<MessageModel>> = _activeMessages.asStateFlow()

    private val messagesCache = ConcurrentHashMap<String, List<MessageModel>>()

    private val deliveredAcknowledgedIds = ConcurrentHashMap.newKeySet<String>()
    private val seenAcknowledgedIds = ConcurrentHashMap.newKeySet<String>()

    private val _gifts = MutableStateFlow<List<GiftModel>>(emptyList())
    val gifts: StateFlow<List<GiftModel>> = _gifts.asStateFlow()

    private val _receivedGifts = MutableStateFlow<List<GiftTransactionModel>>(emptyList())
    val receivedGifts: StateFlow<List<GiftTransactionModel>> = _receivedGifts.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _activeParticipantProfile = MutableStateFlow<ConversationParticipantProfile?>(null)
    val activeParticipantProfile: StateFlow<ConversationParticipantProfile?> = _activeParticipantProfile.asStateFlow()

    private var messagePollerJob: Job? = null
    private var conversationPollerJob: Job? = null
    private var realtimeSubscription: RealtimeSubscription? = null
    private var currentConversationId: String? = null
    private var currentParticipantId: String? = null

    val currentAuthUuid: String?
        get() = sessionManager.authUuid.value

    init {
        loadConversations()
        loadGifts()
        loadReceivedGifts()
        startConversationPoller()
    }

    private fun startConversationPoller() {
        conversationPollerJob?.cancel()
        conversationPollerJob = viewModelScope.launch {
            while (isActive) {
                delay(5000)
                val res = chatRepository.getConversations()
                if (res.isSuccess) {
                    val newConvs = res.getOrNull() ?: emptyList()
                    val currentMap = _conversations.value.associateBy { it.id }
                    _conversations.value = newConvs.map { newC ->
                        val oldC = currentMap[newC.id]
                        if (oldC?.lastMessage != null && newC.lastMessage != null && oldC.lastMessage.id == newC.lastMessage.id) {
                            val mergedLastMsg = mergeMessage(oldC.lastMessage, newC.lastMessage)
                            newC.copy(lastMessage = mergedLastMsg)
                        } else newC
                    }
                }
            }
        }
    }

    private fun mergeMessage(old: MessageModel, new: MessageModel): MessageModel {
        val finalSeenAt = if (!new.seenAt.isNullOrBlank()) new.seenAt else old.seenAt
        val finalDeliveredAt = when {
            !new.deliveredAt.isNullOrBlank() -> new.deliveredAt
            !old.deliveredAt.isNullOrBlank() -> old.deliveredAt
            !finalSeenAt.isNullOrBlank() -> finalSeenAt
            else -> null
        }
        val finalIsRead = (new.isRead == true) || (old.isRead == true) || !finalSeenAt.isNullOrBlank()

        return new.copy(
            deliveredAt = finalDeliveredAt,
            seenAt = finalSeenAt,
            isRead = finalIsRead,
            messageText = if (!new.messageText.isNullOrBlank()) new.messageText else old.messageText,
            mediaUrl = if (!new.mediaUrl.isNullOrBlank()) new.mediaUrl else old.mediaUrl
        )
    }

    private fun mergeMessageLists(existingList: List<MessageModel>, newList: List<MessageModel>): List<MessageModel> {
        if (existingList.isEmpty()) return newList
        if (newList.isEmpty()) return existingList

        val existingMap = existingList.associateBy { it.id }
        val result = mutableListOf<MessageModel>()
        val processedIds = mutableSetOf<String>()

        for (newMsg in newList) {
            val oldMsg = existingMap[newMsg.id]
            if (oldMsg != null) {
                result.add(mergeMessage(oldMsg, newMsg))
                processedIds.add(newMsg.id)
            } else {
                val tempMatchIndex = existingList.indexOfFirst {
                    it.id.startsWith("temp_") &&
                    it.senderId == newMsg.senderId &&
                    it.messageText == newMsg.messageText
                }
                if (tempMatchIndex != -1) {
                    val tempOld = existingList[tempMatchIndex]
                    result.add(mergeMessage(tempOld, newMsg))
                    processedIds.add(tempOld.id)
                } else {
                    result.add(newMsg)
                }
            }
        }

        for (oldMsg in existingList) {
            if (oldMsg.id.startsWith("temp_") && !processedIds.contains(oldMsg.id)) {
                val textMatched = newList.any { it.senderId == oldMsg.senderId && it.messageText == oldMsg.messageText }
                if (!textMatched) {
                    result.add(oldMsg)
                }
            }
        }

        return result
    }

    fun loadConversations() {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.getConversations()
            if (res.isSuccess) {
                _conversations.value = res.getOrNull() ?: emptyList()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message
            }
            _isLoading.value = false
        }
    }

    fun openConversation(conversationId: String, participantId: String? = null) {
        currentConversationId = conversationId
        currentParticipantId = participantId
        _activeParticipantProfile.value = null

        val cached = messagesCache[conversationId]
        if (!cached.isNullOrEmpty()) {
            _activeMessages.value = cached
        }

        val conv = _conversations.value.find { it.id == conversationId }
        val targetParticipantId = participantId ?: conv?.userId

        if (!targetParticipantId.isNullOrBlank()) {
            viewModelScope.launch {
                val pRes = chatRepository.getParticipantProfile(conversationId, targetParticipantId)
                if (pRes.isSuccess) {
                    _activeParticipantProfile.value = pRes.getOrNull()
                }
            }
        }

        // Connect Realtime subscription for instant INSERT/UPDATE/DELETE events
        realtimeSubscription?.close()
        realtimeSubscription = chatRealtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onMessageInsert = { newMsg ->
                handleIncomingMessageInsert(newMsg)
            },
            onMessageUpdate = { updatedMsg ->
                handleMessageUpdate(updatedMsg)
            },
            onMessageDelete = { deletedId ->
                handleMessageDelete(deletedId)
            }
        )

        loadMessages(conversationId)
        startMessagePoller(conversationId)

        // Reset unread count locally for this conversation in the list
        _conversations.value = _conversations.value.map { c ->
            if (c.id == conversationId) {
                c.copy(unreadCount = 0)
            } else c
        }
    }

    private fun handleIncomingMessageInsert(msg: MessageModel) {
        val convId = msg.conversationId.ifBlank { currentConversationId ?: return }
        val currentAuth = currentAuthUuid
        val isIncoming = msg.receiverId == currentAuth
        val isOutgoing = msg.senderId == currentAuth

        val currentList = _activeMessages.value
        val updatedList = if (isOutgoing) {
            val tempIndex = currentList.indexOfFirst { it.id.startsWith("temp_") && it.messageText == msg.messageText }
            if (tempIndex != -1) {
                currentList.toMutableList().apply { set(tempIndex, mergeMessage(currentList[tempIndex], msg)) }
            } else if (currentList.none { it.id == msg.id }) {
                currentList + msg
            } else {
                currentList.map { if (it.id == msg.id) mergeMessage(it, msg) else it }
            }
        } else {
            if (currentList.none { it.id == msg.id }) {
                currentList + msg
            } else {
                currentList.map { if (it.id == msg.id) mergeMessage(it, msg) else it }
            }
        }

        _activeMessages.value = updatedList
        messagesCache[convId] = updatedList

        // Acknowledge delivery if incoming for this partner and not acknowledged yet
        if (isIncoming && !deliveredAcknowledgedIds.contains(msg.id)) {
            deliveredAcknowledgedIds.add(msg.id)
            viewModelScope.launch {
                val res = chatRepository.markMessagesDelivered(convId, listOf(msg.id))
                if (res.isFailure) {
                    deliveredAcknowledgedIds.remove(msg.id)
                }
            }
        }

        // Update conversation list item
        _conversations.value = _conversations.value.map { c ->
            if (c.id == convId) {
                val newUnread = if (isIncoming && currentConversationId != convId) (c.unreadCount ?: 0) + 1 else 0
                val mergedLastMsg = if (c.lastMessage?.id == msg.id) mergeMessage(c.lastMessage!!, msg) else msg
                c.copy(lastMessage = mergedLastMsg, lastMessageAt = msg.createdAt, unreadCount = newUnread)
            } else c
        }
    }

    private fun handleMessageUpdate(updatedMsg: MessageModel) {
        val convId = updatedMsg.conversationId.ifBlank { currentConversationId ?: return }

        // Update only the affected message, strictly preserving existing non-null timestamps
        val currentList = _activeMessages.value
        var changed = false
        val updatedList = currentList.map { current ->
            if (current.id == updatedMsg.id) {
                changed = true
                mergeMessage(current, updatedMsg)
            } else current
        }

        if (changed) {
            _activeMessages.value = updatedList
            messagesCache[convId] = updatedList
        } else {
            val cached = messagesCache[convId]
            if (!cached.isNullOrEmpty()) {
                val updatedCache = cached.map { current ->
                    if (current.id == updatedMsg.id) mergeMessage(current, updatedMsg) else current
                }
                messagesCache[convId] = updatedCache
            }
        }

        // Update lastMessage in conversations if matching
        _conversations.value = _conversations.value.map { c ->
            if (c.id == convId && c.lastMessage?.id == updatedMsg.id) {
                c.copy(
                    lastMessage = mergeMessage(c.lastMessage!!, updatedMsg)
                )
            } else c
        }
    }

    private fun handleMessageDelete(deletedId: String) {
        val convId = currentConversationId ?: return
        val currentList = _activeMessages.value
        val filtered = currentList.filter { it.id != deletedId }
        if (filtered.size != currentList.size) {
            _activeMessages.value = filtered
            messagesCache[convId] = filtered
        }
    }

    fun markVisibleMessagesSeen(conversationId: String, visibleIncomingMessageIds: List<String>) {
        if (visibleIncomingMessageIds.isEmpty()) return
        val currentAuth = currentAuthUuid ?: return

        // Filter for incoming messages that have not yet been marked seen
        val newlySeen = visibleIncomingMessageIds.filter { id ->
            !seenAcknowledgedIds.contains(id) &&
            _activeMessages.value.any { it.id == id && it.receiverId == currentAuth && it.seenAt.isNullOrBlank() }
        }.distinct()

        if (newlySeen.isEmpty()) return
        seenAcknowledgedIds.addAll(newlySeen)

        viewModelScope.launch {
            val res = chatRepository.markMessagesSeen(conversationId, newlySeen)
            if (res.isFailure) {
                Log.w(TAG, "Failed to mark visible messages seen: ${res.exceptionOrNull()?.message}")
                seenAcknowledgedIds.removeAll(newlySeen.toSet())
            } else {
                val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }.format(java.util.Date())

                val updatedList = _activeMessages.value.map { msg ->
                    if (newlySeen.contains(msg.id)) {
                        msg.copy(
                            seenAt = msg.seenAt ?: nowIso,
                            deliveredAt = msg.deliveredAt ?: nowIso,
                            isRead = true
                        )
                    } else msg
                }
                _activeMessages.value = updatedList
                messagesCache[conversationId] = updatedList

                _conversations.value = _conversations.value.map { c ->
                    if (c.id == conversationId) {
                        c.copy(unreadCount = 0)
                    } else c
                }
                chatRepository.markConversationRead(conversationId)
            }
        }
    }

    fun closeConversation() {
        messagePollerJob?.cancel()
        messagePollerJob = null
        realtimeSubscription?.close()
        realtimeSubscription = null
        audioPlayerHelper.stopAudio()
        currentConversationId?.let { id ->
            if (_activeMessages.value.isNotEmpty()) {
                messagesCache[id] = _activeMessages.value
            }
        }
        currentConversationId = null
        currentParticipantId = null
        _activeParticipantProfile.value = null
    }

    fun loadMessages(conversationId: String) {
        viewModelScope.launch {
            val conv = _conversations.value.find { it.id == conversationId }
            val res = chatRepository.getMessages(conversationId, conv?.partnerClearedAt, conv?.userClearedAt)
            if (res.isSuccess) {
                val list = res.getOrNull() ?: emptyList()
                if (list.isNotEmpty()) {
                    val currentActive = if (currentConversationId == conversationId) _activeMessages.value else (messagesCache[conversationId] ?: emptyList())
                    val mergedList = mergeMessageLists(currentActive, list)
                    messagesCache[conversationId] = mergedList
                    if (currentConversationId == conversationId) {
                        _activeMessages.value = mergedList
                    }

                    val currentAuth = currentAuthUuid
                    // Batch acknowledge delivery for incoming messages that have no deliveredAt
                    val newlyReceivedUndelivered = mergedList.filter {
                        it.receiverId == currentAuth && it.deliveredAt.isNullOrBlank() && !deliveredAcknowledgedIds.contains(it.id)
                    }.map { it.id }.distinct()

                    if (newlyReceivedUndelivered.isNotEmpty()) {
                        deliveredAcknowledgedIds.addAll(newlyReceivedUndelivered)
                        launch {
                            val delRes = chatRepository.markMessagesDelivered(conversationId, newlyReceivedUndelivered)
                            if (delRes.isFailure) {
                                Log.w(TAG, "Failed to mark messages delivered: ${delRes.exceptionOrNull()?.message}")
                                deliveredAcknowledgedIds.removeAll(newlyReceivedUndelivered.toSet())
                            }
                        }
                    }
                } else {
                    val cached = messagesCache[conversationId]
                    if (cached.isNullOrEmpty() && currentConversationId == conversationId) {
                        _activeMessages.value = emptyList()
                    }
                }
            }
        }
    }

    private fun startMessagePoller(conversationId: String) {
        messagePollerJob?.cancel()
        messagePollerJob = viewModelScope.launch {
            while (isActive) {
                delay(3000)
                val conv = _conversations.value.find { it.id == conversationId }
                val res = chatRepository.getMessages(conversationId, conv?.partnerClearedAt, conv?.userClearedAt)
                if (res.isSuccess) {
                    val list = res.getOrNull() ?: emptyList()
                    if (list.isNotEmpty()) {
                        val currentActive = if (currentConversationId == conversationId) _activeMessages.value else (messagesCache[conversationId] ?: emptyList())
                        val mergedList = mergeMessageLists(currentActive, list)
                        messagesCache[conversationId] = mergedList
                        if (currentConversationId == conversationId) {
                            _activeMessages.value = mergedList
                        }

                        val currentAuth = currentAuthUuid

                        // Check for newly delivered incoming messages
                        val newlyReceivedUndelivered = mergedList.filter {
                            it.receiverId == currentAuth && it.deliveredAt.isNullOrBlank() && !deliveredAcknowledgedIds.contains(it.id)
                        }.map { it.id }.distinct()

                        if (newlyReceivedUndelivered.isNotEmpty()) {
                            deliveredAcknowledgedIds.addAll(newlyReceivedUndelivered)
                            launch {
                                val delRes = chatRepository.markMessagesDelivered(conversationId, newlyReceivedUndelivered)
                                if (delRes.isFailure) {
                                    deliveredAcknowledgedIds.removeAll(newlyReceivedUndelivered.toSet())
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    fun sendTextMessage(conversationId: String, receiverId: String, text: String) {
        if (text.trim().isBlank()) return
        val currentAuth = currentAuthUuid ?: ""
        val optimisticMsg = MessageModel(
            id = "temp_${System.currentTimeMillis()}",
            conversationId = conversationId,
            senderId = currentAuth,
            receiverId = receiverId,
            messageType = "text",
            messageText = text.trim(),
            createdAt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())
        )
        val updated = _activeMessages.value + optimisticMsg
        _activeMessages.value = updated
        messagesCache[conversationId] = updated

        viewModelScope.launch {
            val res = chatRepository.sendTextMessage(conversationId, receiverId, text.trim())
            if (res.isSuccess) {
                loadMessages(conversationId)
                loadConversations()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send message"
            }
        }
    }

    fun sendImageMessage(conversationId: String, receiverId: String, imageFile: File) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.sendImageMessage(conversationId, receiverId, imageFile)
            if (res.isSuccess) {
                loadMessages(conversationId)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send image"
            }
            _isLoading.value = false
        }
    }

    fun sendVoiceMessage(conversationId: String, receiverId: String, audioFile: File, durationSeconds: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.sendVoiceMessage(conversationId, receiverId, audioFile, durationSeconds)
            if (res.isSuccess) {
                loadMessages(conversationId)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to send voice message"
            }
            _isLoading.value = false
        }
    }

    fun playVoiceMessage(rawMediaUrl: String) {
        viewModelScope.launch {
            val resolved = privateMediaRepository.loadChatVoice(rawMediaUrl) ?: rawMediaUrl
            audioPlayerHelper.playAudio(resolved)
        }
    }

    fun loadGifts() {
        viewModelScope.launch {
            val res = chatRepository.getGifts()
            if (res.isSuccess) {
                _gifts.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    fun loadReceivedGifts() {
        viewModelScope.launch {
            val res = chatRepository.getReceivedGiftTransactions()
            if (res.isSuccess) {
                _receivedGifts.value = res.getOrNull() ?: emptyList()
            }
        }
    }



    fun clearConversation(conversationId: String, onCleared: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            // Immediately clear local UI and cached messages
            messagesCache[conversationId] = emptyList()
            if (currentConversationId == conversationId) {
                _activeMessages.value = emptyList()
            }
            val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())

            _conversations.value = _conversations.value.map { conv ->
                if (conv.id == conversationId) {
                    conv.copy(
                        lastMessage = null,
                        lastMessageAt = null,
                        unreadCount = 0,
                        partnerClearedAt = nowIso,
                        userClearedAt = nowIso
                    )
                } else conv
            }

            val res = chatRepository.clearConversation(conversationId)
            if (res.isSuccess) {
                messagesCache.remove(conversationId)
                _activeMessages.value = emptyList()
                loadConversations()
                onCleared()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to clear chat"
            }
            _isLoading.value = false
        }
    }

    fun blockUser(userId: String, onBlocked: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.blockUser(userId)
            if (res.isSuccess) {
                _conversations.value = _conversations.value.map { conv ->
                    if (conv.userId == userId) {
                        conv.copy(partnerBlocked = true)
                    } else conv
                }
                loadConversations()
                onBlocked()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to block user"
            }
            _isLoading.value = false
        }
    }

    fun unblockUser(userId: String, onUnblocked: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = chatRepository.unblockUser(userId)
            if (res.isSuccess) {
                _conversations.value = _conversations.value.map { conv ->
                    if (conv.userId == userId) {
                        conv.copy(partnerBlocked = false, userBlocked = false)
                    } else conv
                }
                loadConversations()
                onUnblocked()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to unblock user"
            }
            _isLoading.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        messagePollerJob?.cancel()
        conversationPollerJob?.cancel()
        realtimeSubscription?.close()
        realtimeSubscription = null
        audioPlayerHelper.stopAudio()
    }
}

class ChatViewModelFactory(
    private val chatRepository: ChatRepository,
    private val sessionManager: SessionManager,
    private val chatRealtimeManager: ChatRealtimeManager,
    private val audioRecorderHelper: AudioRecorderHelper,
    private val audioPlayerHelper: AudioPlayerHelper,
    private val privateMediaRepository: PrivateMediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(chatRepository, sessionManager, chatRealtimeManager, audioRecorderHelper, audioPlayerHelper, privateMediaRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

