package com.example.security

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy

/**
 * Centralized, production-grade security manager for Baatly Partner App.
 *
 * Enforces strict, zero-leak screenshot and screen recording protection (FLAG_SECURE)
 * globally across all current and future Activities, Windows, Dialogs, Overlays,
 * and Recent App multitasking previews.
 */
object AppSecurityManager {
    private const val TAG = "AppSecurityManager"

    /**
     * Initializes global Activity lifecycle tracking to automatically apply FLAG_SECURE
     * to every Activity created, started, or resumed in the application process.
     */
    fun init(application: Application) {
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                applySecureFlag(activity)
            }

            override fun onActivityStarted(activity: Activity) {
                applySecureFlag(activity)
            }

            override fun onActivityResumed(activity: Activity) {
                applySecureFlag(activity)
            }

            override fun onActivityPaused(activity: Activity) {
                // Ensure secure flag remains enforced during app switcher / recent apps transition
                applySecureFlag(activity)
            }

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
        Log.i(TAG, "Global ActivityLifecycleCallbacks registered for automatic FLAG_SECURE enforcement.")
    }

    /**
     * Directly applies WindowManager.LayoutParams.FLAG_SECURE to an Activity window.
     */
    fun applySecureFlag(activity: Activity?) {
        if (activity == null) return
        applySecureFlag(activity.window)
    }

    /**
     * Directly applies WindowManager.LayoutParams.FLAG_SECURE to an arbitrary Window.
     */
    fun applySecureFlag(window: Window?) {
        if (window == null) return
        try {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply FLAG_SECURE to window", e)
        }
    }

    /**
     * Production DialogProperties builder that explicitly enforces SecureFlagPolicy.SecureOn.
     * Guarantees that any Compose Dialog window blocks screenshots and screen recordings.
     */
    fun secureDialogProperties(
        dismissOnBackPress: Boolean = true,
        dismissOnClickOutside: Boolean = true,
        usePlatformDefaultWidth: Boolean = true,
        decorFitsSystemWindows: Boolean = true
    ): DialogProperties {
        return DialogProperties(
            dismissOnBackPress = dismissOnBackPress,
            dismissOnClickOutside = dismissOnClickOutside,
            securePolicy = SecureFlagPolicy.SecureOn,
            usePlatformDefaultWidth = usePlatformDefaultWidth,
            decorFitsSystemWindows = decorFitsSystemWindows
        )
    }
}
