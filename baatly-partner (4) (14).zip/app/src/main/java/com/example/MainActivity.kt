package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.notification.NotificationRouter
import com.example.security.AppSecurityManager
import com.example.ui.BaseSecureActivity
import com.example.ui.MainApp
import com.example.ui.theme.BaatlyPartnerTheme

class MainActivity : BaseSecureActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Explicitly enforce FLAG_SECURE on cold start and recreation before setting content
    AppSecurityManager.applySecureFlag(this)
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Handle notification intent on cold start
    NotificationRouter.handleIntent(intent)

    val baatlyApp = application as BaatlyApp
    setContent {
      BaatlyPartnerTheme {
        MainApp(app = baatlyApp)
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    // Handle notification intent when app is already running in background / foreground
    NotificationRouter.handleIntent(intent)
  }
}


