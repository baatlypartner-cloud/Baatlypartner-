package com.example.data.api

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.models.CallModel
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages an authenticated Supabase Realtime WebSocket subscription for postgres_changes
 * on public.calls specifically filtered for a given call ID.
 */
class CallRealtimeManager(
    private val sessionManager: SessionManager
) {
    private val TAG = "CallRealtimeManager"

    private var webSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val isClosed = AtomicBoolean(false)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Indefinite read timeout for WebSocket
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun subscribeToCall(
        callId: String,
        onStatusChange: (status: String, recordJson: JSONObject?) -> Unit
    ): RealtimeSubscription {
        isClosed.set(false)
        val baseUrl = sessionManager.getSupabaseUrl().trim().removeSuffix("/")
        val wsBaseUrl = when {
            baseUrl.startsWith("https://") -> baseUrl.replaceFirst("https://", "wss://")
            baseUrl.startsWith("http://") -> baseUrl.replaceFirst("http://", "ws://")
            else -> "wss://$baseUrl"
        }

        val apiKey = sessionManager.getSupabasePublishableKey()
        val token = sessionManager.accessToken.value ?: apiKey
        val wsUrl = "$wsBaseUrl/realtime/v1/websocket?apikey=$apiKey&vsn=1.0.0"

        val channelTopic = "realtime:calls_$callId"

        Log.d(TAG, "Connecting to Supabase Realtime for callId=$callId topic=$channelTopic")

        val request = Request.Builder()
            .url(wsUrl)
            .addHeader("apikey", apiKey)
            .addHeader("Authorization", "Bearer $token")
            .build()

        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(TAG, "Supabase Realtime WebSocket OPEN for callId=$callId")
                if (isClosed.get()) {
                    webSocket.close(1000, "Already closed")
                    return
                }

                // 1. Join Postgres Changes channel for public.calls filtered by id
                try {
                    val joinPayload = JSONObject().apply {
                        put("topic", channelTopic)
                        put("event", "phx_join")
                        put("payload", JSONObject().apply {
                            put("config", JSONObject().apply {
                                put("postgres_changes", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "calls")
                                        put("filter", "id=eq.$callId")
                                    })
                                })
                            })
                            put("access_token", token)
                        })
                        put("ref", "1")
                    }
                    webSocket.send(joinPayload.toString())
                    Log.d(TAG, "Sent phx_join for callId=$callId")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to send phx_join for callId=$callId", e)
                }

                // 2. Start heartbeat
                startHeartbeat(webSocket)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (isClosed.get()) return
                try {
                    val json = JSONObject(text)
                    val event = json.optString("event")
                    val payload = json.optJSONObject("payload")

                    if (event == "postgres_changes" && payload != null) {
                        Log.d(TAG, "Received postgres_changes on callId=$callId: $text")
                        val dataObj = payload.optJSONObject("data")
                        val record = dataObj?.optJSONObject("record") ?: payload.optJSONObject("record")

                        if (record != null) {
                            val status = record.optString("status", "")
                            val endedAt = record.optString("ended_at", "")
                            if (status.isNotBlank() || endedAt.isNotBlank()) {
                                onStatusChange(status, record)
                            }
                        }
                    } else if (payload != null) {
                        // Check if payload directly contains status change
                        val record = payload.optJSONObject("record")
                        if (record != null) {
                            val status = record.optString("status", "")
                            if (status.isNotBlank()) {
                                onStatusChange(status, record)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error parsing realtime message: ${e.message}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "Supabase Realtime WebSocket failure for callId=$callId: ${t.message}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Supabase Realtime WebSocket closed ($code, $reason)")
            }
        }

        webSocket = okHttpClient.newWebSocket(request, listener)

        return RealtimeSubscription {
            unsubscribe(channelTopic)
        }
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && !isClosed.get()) {
                delay(25_000)
                try {
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", "hb_${System.currentTimeMillis()}")
                    }
                    ws.send(hb.toString())
                } catch (e: Exception) {
                    Log.w(TAG, "Heartbeat send error: ${e.message}")
                }
            }
        }
    }

    fun unsubscribe(channelTopic: String? = null) {
        isClosed.set(true)
        heartbeatJob?.cancel()
        heartbeatJob = null
        try {
            if (channelTopic != null && webSocket != null) {
                val leavePayload = JSONObject().apply {
                    put("topic", channelTopic)
                    put("event", "phx_leave")
                    put("payload", JSONObject())
                    put("ref", "leave")
                }
                webSocket?.send(leavePayload.toString())
            }
        } catch (_: Exception) {}

        try {
            webSocket?.close(1000, "Unsubscribed")
        } catch (_: Exception) {}
        webSocket = null
    }
}

fun interface RealtimeSubscription {
    fun close()
}
