package com.example.data.api

import android.util.Log
import com.example.data.local.SessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.Route
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class SupabaseClient(private val sessionManager: SessionManager) {

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val builder = original.newBuilder()

        val apiKey = sessionManager.getSupabasePublishableKey()
        if (apiKey.isNotBlank()) {
            builder.header("apikey", apiKey)
        }

        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        } else if (apiKey.isNotBlank()) {
            builder.header("Authorization", "Bearer $apiKey")
        }

        chain.proceed(builder.build())
    }

    private val tokenAuthenticator = Authenticator { _: Route?, response: Response ->
        if (responseCount(response) >= 3) {
            return@Authenticator null
        }
        val path = response.request.url.encodedPath
        if (path.contains("auth/v1/token") || path.contains("auth/v1/signup") || path.contains("auth/v1/logout")) {
            return@Authenticator null
        }

        val refreshToken = sessionManager.getRefreshToken() ?: return@Authenticator null
        val baseUrl = sessionManager.getSupabaseUrl().let { if (it.endsWith("/")) it else "$it/" }
        val publishableKey = sessionManager.getSupabasePublishableKey()

        synchronized(this) {
            val currentAccessToken = sessionManager.accessToken.value
            val requestAuthHeader = response.request.header("Authorization")
            if (!currentAccessToken.isNullOrBlank() && requestAuthHeader != "Bearer $currentAccessToken") {
                return@Authenticator response.request.newBuilder()
                    .header("Authorization", "Bearer $currentAccessToken")
                    .build()
            }

            try {
                val refreshUrl = "${baseUrl}auth/v1/token?grant_type=refresh_token"
                val jsonPayload = org.json.JSONObject().apply {
                    put("refresh_token", refreshToken)
                }.toString()

                val refreshRequest = Request.Builder()
                    .url(refreshUrl)
                    .post(jsonPayload.toRequestBody("application/json".toMediaTypeOrNull()))
                    .header("apikey", publishableKey)
                    .header("Authorization", "Bearer $publishableKey")
                    .build()

                val directClient = OkHttpClient.Builder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .build()

                val refreshResponse = directClient.newCall(refreshRequest).execute()
                if (refreshResponse.isSuccessful) {
                    val bodyString = refreshResponse.body?.string() ?: ""
                    val jsonObj = org.json.JSONObject(bodyString)
                    val newAccessToken = jsonObj.optString("access_token")
                    val newRefreshToken = jsonObj.optString("refresh_token", refreshToken)
                    if (!newAccessToken.isNullOrBlank()) {
                        sessionManager.updateTokens(newAccessToken, newRefreshToken)
                        Log.d("SupabaseClient", "Token refreshed successfully via Authenticator")
                        return@Authenticator response.request.newBuilder()
                            .header("Authorization", "Bearer $newAccessToken")
                            .build()
                    }
                } else {
                    Log.w("SupabaseClient", "Authenticator token refresh failed: ${refreshResponse.code}")
                }
            } catch (e: Exception) {
                Log.e("SupabaseClient", "Error during token refresh", e)
            }
        }
        null
    }

    private fun responseCount(response: Response): Int {
        var result = 1
        var prior = response.priorResponse
        while (prior != null) {
            result++
            prior = prior.priorResponse
        }
        return result
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .authenticator(tokenAuthenticator)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var cachedBaseUrl: String? = null
    private var cachedRetrofit: Retrofit? = null

    private fun getRetrofit(): Retrofit {
        val currentBaseUrl = sessionManager.getSupabaseUrl().let {
            if (it.endsWith("/")) it else "$it/"
        }
        if (cachedRetrofit == null || cachedBaseUrl != currentBaseUrl) {
            cachedBaseUrl = currentBaseUrl
            cachedRetrofit = Retrofit.Builder()
                .baseUrl(currentBaseUrl)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
                .build()
        }
        return cachedRetrofit!!
    }

    val authService: SupabaseAuthService
        get() = getRetrofit().create(SupabaseAuthService::class.java)

    val restService: SupabaseRestService
        get() = getRetrofit().create(SupabaseRestService::class.java)

    val storageService: SupabaseStorageService
        get() = getRetrofit().create(SupabaseStorageService::class.java)

    val edgeService: SupabaseEdgeService
        get() = getRetrofit().create(SupabaseEdgeService::class.java)

    fun getAuthenticatedStorageUrl(bucket: String, path: String): String {
        val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
        val cleanedPath = path.removePrefix("$bucket/").removePrefix("/")
        return "$baseUrl/storage/v1/object/authenticated/$bucket/$cleanedPath"
    }

    fun getPublicStorageUrl(bucket: String, path: String): String {
        val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
        val cleanedPath = path.removePrefix("$bucket/").removePrefix("/")
        return "$baseUrl/storage/v1/object/public/$bucket/$cleanedPath"
    }
}
