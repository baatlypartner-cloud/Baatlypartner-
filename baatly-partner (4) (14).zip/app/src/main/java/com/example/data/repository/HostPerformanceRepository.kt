package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.HostDailyScoreModel
import com.example.data.models.HostScoreThresholdModel
import com.example.data.models.HostWeeklyScoreModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class HostPerformanceRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "HostPerformanceRepo"

    private val _todayDailyScore = MutableStateFlow<HostDailyScoreModel?>(null)
    val todayDailyScore: StateFlow<HostDailyScoreModel?> = _todayDailyScore.asStateFlow()

    private val _weeklyScores = MutableStateFlow<List<HostWeeklyScoreModel>>(emptyList())
    val weeklyScores: StateFlow<List<HostWeeklyScoreModel>> = _weeklyScores.asStateFlow()

    private val _scoreHistory = MutableStateFlow<List<HostDailyScoreModel>>(emptyList())
    val scoreHistory: StateFlow<List<HostDailyScoreModel>> = _scoreHistory.asStateFlow()

    private val _thresholds = MutableStateFlow<List<HostScoreThresholdModel>>(emptyList())
    val thresholds: StateFlow<List<HostScoreThresholdModel>> = _thresholds.asStateFlow()

    private val _lastUpdatedMillis = MutableStateFlow<Long>(0L)
    val lastUpdatedMillis: StateFlow<Long> = _lastUpdatedMillis.asStateFlow()

    /**
     * Fetches the host's authoritative daily score record for today from `host_daily_scores`.
     */
    suspend fun getTodayDailyScore(forceRefresh: Boolean = false): Result<HostDailyScoreModel?> = withContext(Dispatchers.IO) {
        try {
            val hostId = sessionManager.authUuid.value
            if (hostId.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Host not logged in"))
            }

            var response = supabaseClient.restService.getHostDailyScores(
                hostIdFilter = "eq.$hostId",
                order = "score_date.desc",
                limit = 1
            )

            if (!response.isSuccessful && response.code() in 400..404) {
                response = supabaseClient.restService.getHostDailyScores(
                    partnerIdFilter = "eq.$hostId",
                    order = "score_date.desc",
                    limit = 1
                )
            }
            if (!response.isSuccessful && response.code() in 400..404) {
                response = supabaseClient.restService.getHostDailyScores(
                    userIdFilter = "eq.$hostId",
                    order = "score_date.desc",
                    limit = 1
                )
            }

            if (response.isSuccessful) {
                val score = response.body()?.firstOrNull()
                _todayDailyScore.value = score
                _lastUpdatedMillis.value = System.currentTimeMillis()
                Log.d(TAG, "Fetched today's daily score: band=${score?.scoreBand}, weightedScore=${score?.weightedScore}")
                Result.success(score)
            } else {
                val err = response.errorBody()?.string() ?: "HTTP ${response.code()}"
                Log.w(TAG, "Failed to query host_daily_scores: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in getTodayDailyScore", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches the host's authoritative weekly scores from `host_weekly_scores`.
     */
    suspend fun getWeeklyScores(limit: Int = 10): Result<List<HostWeeklyScoreModel>> = withContext(Dispatchers.IO) {
        try {
            val hostId = sessionManager.authUuid.value
            if (hostId.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Host not logged in"))
            }

            var response = supabaseClient.restService.getHostWeeklyScores(
                hostIdFilter = "eq.$hostId",
                order = "week_end.desc",
                limit = limit
            )

            if (!response.isSuccessful && response.code() in 400..404) {
                response = supabaseClient.restService.getHostWeeklyScores(
                    partnerIdFilter = "eq.$hostId",
                    order = "week_end.desc",
                    limit = limit
                )
            }
            if (!response.isSuccessful && response.code() in 400..404) {
                response = supabaseClient.restService.getHostWeeklyScores(
                    userIdFilter = "eq.$hostId",
                    order = "week_end.desc",
                    limit = limit
                )
            }

            if (response.isSuccessful) {
                val list = response.body() ?: emptyList()
                _weeklyScores.value = list
                Log.d(TAG, "Fetched weekly scores count=${list.size}")
                Result.success(list)
            } else {
                val err = response.errorBody()?.string() ?: "HTTP ${response.code()}"
                Log.w(TAG, "Failed to query host_weekly_scores: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in getWeeklyScores", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches the host's past daily performance score history.
     */
    suspend fun getScoreHistory(limit: Int = 30): Result<List<HostDailyScoreModel>> = withContext(Dispatchers.IO) {
        try {
            val hostId = sessionManager.authUuid.value
            if (hostId.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Host not logged in"))
            }

            var response = supabaseClient.restService.getHostDailyScores(
                hostIdFilter = "eq.$hostId",
                order = "score_date.desc",
                limit = limit
            )

            if (!response.isSuccessful && response.code() in 400..404) {
                response = supabaseClient.restService.getHostDailyScores(
                    partnerIdFilter = "eq.$hostId",
                    order = "score_date.desc",
                    limit = limit
                )
            }

            if (response.isSuccessful) {
                val list = response.body() ?: emptyList()
                _scoreHistory.value = list
                Log.d(TAG, "Fetched score history count=${list.size}")
                Result.success(list)
            } else {
                val err = response.errorBody()?.string() ?: "HTTP ${response.code()}"
                Log.w(TAG, "Failed to query score history: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in getScoreHistory", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches metric thresholds from `host_score_thresholds`.
     */
    suspend fun getScoreThresholds(): Result<List<HostScoreThresholdModel>> = withContext(Dispatchers.IO) {
        try {
            val response = supabaseClient.restService.getHostScoreThresholds()
            if (response.isSuccessful) {
                val list = response.body() ?: emptyList()
                _thresholds.value = list
                Result.success(list)
            } else {
                Result.failure(Exception("HTTP ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
