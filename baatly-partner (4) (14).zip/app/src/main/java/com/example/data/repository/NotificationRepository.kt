package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.NotificationItemModel
import com.example.data.models.RegisterFcmTokenParams
import com.example.data.models.TokenActionParams
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class NotificationRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    companion object {
        private const val TAG = "NotificationRepository"
    }

    private fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    /**
     * Obtains the FCM token and synchronizes it with the authenticated Supabase partner profile.
     */
    suspend fun syncFcmToken(force: Boolean = false): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = try {
                FirebaseMessaging.getInstance().token.await()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to retrieve Firebase FCM token: ${e.message}")
                sessionManager.getStoredFcmToken()
            }

            if (token.isNullOrBlank()) {
                Log.w(TAG, "FCM token is not available yet")
                return@withContext Result.failure(IllegalStateException("FCM Token not available"))
            }

            sessionManager.saveFcmToken(token)

            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
            if (authUuid.isNullOrBlank()) {
                Log.d(TAG, "Partner not yet authenticated, FCM token safely stored locally for post-login sync")
                return@withContext Result.failure(IllegalStateException("Partner not authenticated yet"))
            }

            val lastRegisteredToken = sessionManager.getLastRegisteredFcmToken()
            val lastRegisteredAuth = sessionManager.getLastRegisteredAuthUuid()

            if (!force && token == lastRegisteredToken && authUuid == lastRegisteredAuth) {
                Log.d(TAG, "FCM token already synchronized for current partner account")
                return@withContext Result.success(token)
            }

            Log.d(TAG, "Registering FCM token for partner $authUuid...")
            val deviceId = sessionManager.getDeviceId()
            val deviceInfo = sessionManager.getDeviceInfo()

            val resp = supabaseClient.restService.registerFcmToken(
                RegisterFcmTokenParams(
                    pToken = token,
                    pPlatform = "android",
                    pDeviceId = deviceId,
                    pDeviceInfo = deviceInfo
                )
            )

            if (resp.isSuccessful) {
                Log.d(TAG, "Successfully registered FCM token via RPC register_fcm_token")
                sessionManager.setLastRegisteredFcmToken(token, authUuid)
                Result.success(token)
            } else {
                val errorBody = resp.errorBody()?.string()
                Log.w(TAG, "RPC register_fcm_token failed with code ${resp.code()}: $errorBody")
                Result.failure(Exception("Failed to register FCM token with Supabase (code ${resp.code()}): $errorBody"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "syncFcmToken unexpected error", e)
            Result.failure(e)
        }
    }

    /**
     * Deactivates/unregisters this device's FCM token upon logout.
     */
    suspend fun deactivateFcmToken(): Result<Unit> = withContext(Dispatchers.IO) {
        val token = sessionManager.getStoredFcmToken() ?: return@withContext Result.success(Unit)
        Log.d(TAG, "Deactivating FCM token for current device...")

        try {
            try {
                val resp = supabaseClient.restService.deactivateFcmToken(TokenActionParams(pToken = token))
                if (!resp.isSuccessful) {
                    supabaseClient.restService.unregisterFcmToken(TokenActionParams(pToken = token))
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error invoking deactivate_fcm_token / unregister_fcm_token: ${e.message}")
            }

            sessionManager.setLastRegisteredFcmToken(null, null)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "deactivateFcmToken error", e)
            sessionManager.setLastRegisteredFcmToken(null, null)
            Result.success(Unit)
        }
    }

    /**
     * Fetches notifications for current partner from Supabase backend.
     */
    suspend fun getNotifications(): Result<List<NotificationItemModel>> = withContext(Dispatchers.IO) {
        val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
            ?: return@withContext Result.failure(IllegalStateException("Not logged in"))

        try {
            val resp = supabaseClient.restService.getNotifications(userIdFilter = "eq.$authUuid")
            if (resp.isSuccessful && resp.body() != null) {
                Result.success(resp.body()!!)
            } else {
                Result.failure(Exception("Failed to fetch notifications: ${resp.code()}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "getNotifications error", e)
            Result.failure(e)
        }
    }

    /**
     * Marks a specific notification as read in Supabase.
     */
    suspend fun markNotificationAsRead(notificationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (notificationId.isBlank()) return@withContext Result.success(Unit)

        try {
            val resp = supabaseClient.restService.markNotificationAsRead(
                idFilter = "eq.$notificationId",
                body = mapOf(
                    "is_read" to true
                )
            )
            if (resp.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to mark notification as read: ${resp.code()}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "markNotificationAsRead error", e)
            Result.failure(e)
        }
    }
}
