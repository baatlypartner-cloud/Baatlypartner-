package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import org.json.JSONArray

@JsonClass(generateAdapter = true)
data class HostDailyScoreModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "host_id") val hostId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "score_date") val scoreDate: String? = null,
    @Json(name = "new_user_avg_call_minutes") val newUserAvgCallMinutes: Double? = 0.0,
    @Json(name = "old_user_avg_call_minutes") val oldUserAvgCallMinutes: Double? = 0.0,
    @Json(name = "repeat_user_calls_count") val repeatUserCallsCount: Int? = 0,
    @Json(name = "messages_received_count") val messagesReceivedCount: Int? = 0,
    @Json(name = "call_online_hours") val callOnlineHours: Double? = 0.0,
    @Json(name = "chat_online_hours") val chatOnlineHours: Double? = 0.0,
    @Json(name = "new_user_score") val newUserScore: Double? = 0.0,
    @Json(name = "old_user_score") val oldUserScore: Double? = 0.0,
    @Json(name = "repeat_user_score") val repeatUserScore: Double? = 0.0,
    @Json(name = "messages_score") val messagesScore: Double? = 0.0,
    @Json(name = "call_online_score") val callOnlineScore: Double? = 0.0,
    @Json(name = "chat_online_score") val chatOnlineScore: Double? = 0.0,
    @Json(name = "weighted_score") val weightedScore: Double? = 0.0,
    @Json(name = "overall_score") val overallScore: Double? = 0.0,
    @Json(name = "score_band") val scoreBand: String? = null,
    @Json(name = "warning_flag") val warningFlag: Boolean? = false,
    @Json(name = "warning_level") val warningLevel: String? = null,
    @Json(name = "warning_reasons") val warningReasonsRaw: Any? = null,
    @Json(name = "missed_calls_count") val missedCallsCount: Int? = 0,
    @Json(name = "connected_calls_count") val connectedCallsCount: Int? = 0,
    @Json(name = "total_calls_count") val totalCallsCount: Int? = 0,
    @Json(name = "calculated_at") val calculatedAt: String? = null
) {
    val resolvedHostId: String
        get() = hostId ?: partnerId ?: userId ?: ""

    // Direct compatibility accessors matching backend field names
    val score_date: String? get() = scoreDate
    val new_user_avg_call_minutes: Double? get() = newUserAvgCallMinutes
    val old_user_avg_call_minutes: Double? get() = oldUserAvgCallMinutes
    val repeat_user_calls_count: Int? get() = repeatUserCallsCount
    val messages_received_count: Int? get() = messagesReceivedCount
    val call_online_hours: Double? get() = callOnlineHours
    val chat_online_hours: Double? get() = chatOnlineHours
    val new_user_score: Double? get() = newUserScore
    val old_user_score: Double? get() = oldUserScore
    val repeat_user_score: Double? get() = repeatUserScore
    val messages_score: Double? get() = messagesScore
    val call_online_score: Double? get() = callOnlineScore
    val chat_online_score: Double? get() = chatOnlineScore
    val weighted_score: Double? get() = weightedScore
    val overall_score: Double? get() = overallScore ?: weightedScore
    val score_band: String? get() = scoreBand
    val warning_level: String? get() = warningLevel
    val warning_flag: Boolean? get() = warningFlag

    val hasWarning: Boolean
        get() = warningFlag == true || (!warningLevel.isNullOrBlank() && !warningLevel.equals("none", ignoreCase = true))

    val parsedWarningReasons: List<String>
        get() {
            return when (val r = warningReasonsRaw) {
                is List<*> -> r.mapNotNull { it?.toString() }
                is String -> {
                    if (r.isBlank()) emptyList()
                    else if (r.startsWith("[") && r.endsWith("]")) {
                        try {
                            val arr = JSONArray(r)
                            (0 until arr.length()).map { arr.getString(it) }
                        } catch (_: Exception) {
                            listOf(r)
                        }
                    } else {
                        r.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    }
                }
                else -> emptyList()
            }
        }
}

@JsonClass(generateAdapter = true)
data class HostWeeklyScoreModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "host_id") val hostId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "week_start") val weekStart: String? = null,
    @Json(name = "week_end") val weekEnd: String? = null,
    @Json(name = "days_scored") val daysScored: Int? = 0,
    @Json(name = "new_user_avg_call_minutes") val newUserAvgCallMinutes: Double? = 0.0,
    @Json(name = "old_user_avg_call_minutes") val oldUserAvgCallMinutes: Double? = 0.0,
    @Json(name = "repeat_user_calls_avg") val repeatUserCallsAvg: Double? = 0.0,
    @Json(name = "messages_received_avg") val messagesReceivedAvg: Double? = 0.0,
    @Json(name = "call_online_hours_avg") val callOnlineHoursAvg: Double? = 0.0,
    @Json(name = "chat_online_hours_avg") val chatOnlineHoursAvg: Double? = 0.0,
    @Json(name = "new_user_score") val newUserScore: Double? = 0.0,
    @Json(name = "old_user_score") val oldUserScore: Double? = 0.0,
    @Json(name = "repeat_user_score") val repeatUserScore: Double? = 0.0,
    @Json(name = "messages_score") val messagesScore: Double? = 0.0,
    @Json(name = "call_online_score") val callOnlineScore: Double? = 0.0,
    @Json(name = "chat_online_score") val chatOnlineScore: Double? = 0.0,
    @Json(name = "weighted_score") val weightedScore: Double? = 0.0,
    @Json(name = "overall_score") val overallScore: Double? = 0.0,
    @Json(name = "score_band") val scoreBand: String? = null,
    @Json(name = "warning_flag") val warningFlag: Boolean? = false,
    @Json(name = "warning_level") val warningLevel: String? = null,
    @Json(name = "warning_reasons") val warningReasonsRaw: Any? = null,
    @Json(name = "missed_calls_count_avg") val missedCallsCountAvg: Double? = 0.0,
    @Json(name = "connected_calls_count_avg") val connectedCallsCountAvg: Double? = 0.0,
    @Json(name = "total_calls_count_avg") val totalCallsCountAvg: Double? = 0.0,
    @Json(name = "calculated_at") val calculatedAt: String? = null
) {
    val resolvedHostId: String
        get() = hostId ?: partnerId ?: userId ?: ""

    // Direct compatibility accessors matching backend field names
    val week_start: String? get() = weekStart
    val week_end: String? get() = weekEnd
    val days_scored: Int? get() = daysScored
    val avg_new_user_call_minutes: Double? get() = newUserAvgCallMinutes
    val avg_old_user_call_minutes: Double? get() = oldUserAvgCallMinutes
    val total_repeat_user_calls_count: Int? get() = (repeatUserCallsAvg ?: 0.0).toInt()
    val repeat_user_calls_avg: Double? get() = repeatUserCallsAvg
    val total_messages_received_count: Int? get() = (messagesReceivedAvg ?: 0.0).toInt()
    val messages_received_avg: Double? get() = messagesReceivedAvg
    val avg_call_online_hours: Double? get() = callOnlineHoursAvg
    val avg_chat_online_hours: Double? get() = chatOnlineHoursAvg
    val new_user_score: Double? get() = newUserScore
    val old_user_score: Double? get() = oldUserScore
    val repeat_user_score: Double? get() = repeatUserScore
    val messages_score: Double? get() = messagesScore
    val call_online_score: Double? get() = callOnlineScore
    val chat_online_score: Double? get() = chatOnlineScore
    val weighted_score: Double? get() = weightedScore
    val overall_score: Double? get() = overallScore ?: weightedScore
    val score_band: String? get() = scoreBand
    val warning_level: String? get() = warningLevel
    val warning_flag: Boolean? get() = warningFlag

    val hasWarning: Boolean
        get() = warningFlag == true || (!warningLevel.isNullOrBlank() && !warningLevel.equals("none", ignoreCase = true))

    val parsedWarningReasons: List<String>
        get() {
            return when (val r = warningReasonsRaw) {
                is List<*> -> r.mapNotNull { it?.toString() }
                is String -> {
                    if (r.isBlank()) emptyList()
                    else if (r.startsWith("[") && r.endsWith("]")) {
                        try {
                            val arr = JSONArray(r)
                            (0 until arr.length()).map { arr.getString(it) }
                        } catch (_: Exception) {
                            listOf(r)
                        }
                    } else {
                        r.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    }
                }
                else -> emptyList()
            }
        }
}

@JsonClass(generateAdapter = true)
data class HostScoreThresholdModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "metric_key") val metricKey: String? = null,
    @Json(name = "metric_name") val metricName: String? = null,
    @Json(name = "low_threshold") val lowThreshold: Double? = null,
    @Json(name = "average_threshold") val averageThreshold: Double? = null,
    @Json(name = "good_threshold") val goodThreshold: Double? = null,
    @Json(name = "weight_percentage") val weightPercentage: Double? = null
)

/**
 * Authoritative host call session record from `host_call_sessions` table.
 * Contains host-specific caller classification: `user_class` ("new" or "repeat").
 */
@JsonClass(generateAdapter = true)
data class HostCallSessionModel(
    @Json(name = "id") val id: String? = null,
    @Json(name = "call_id") val callId: String? = null,
    @Json(name = "host_id") val hostId: String? = null,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "user_class") val userClass: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

