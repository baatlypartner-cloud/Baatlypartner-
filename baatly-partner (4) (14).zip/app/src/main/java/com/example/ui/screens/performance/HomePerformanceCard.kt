package com.example.ui.screens.performance

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HostDailyScoreModel
import com.example.data.models.HostScoreThresholdModel
import com.example.data.models.HostWeeklyScoreModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomePerformanceCard(
    dailyScore: HostDailyScoreModel?,
    weeklyScore: HostWeeklyScoreModel? = null,
    thresholds: List<HostScoreThresholdModel> = emptyList(),
    lastUpdatedText: String,
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    onViewDailyDetails: () -> Unit,
    onViewWeeklyDetails: () -> Unit,
    onViewHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: TODAY (default), 1: WEEK
    val currentDate = rememberFormattedDate()

    val dScore = dailyScore ?: HostDailyScoreModel()
    val dailyWeightedScore = dScore.weightedScore ?: 0.0
    val dailyScoreBand = dScore.scoreBand
    val dailyWarningLevel = dScore.warningLevel
    val dailyWarningReasons = dScore.parsedWarningReasons
    val dailyWarningFlag = dScore.hasWarning

    val wScore = weeklyScore ?: HostWeeklyScoreModel()
    val weeklyWeightedScore = wScore.weightedScore ?: 0.0
    val weeklyScoreBand = wScore.scoreBand
    val weeklyWarningLevel = wScore.warningLevel
    val weeklyWarningReasons = wScore.parsedWarningReasons
    val weeklyWarningFlag = wScore.hasWarning

    // Build actionable guidance strictly derived from weak metrics and server warnings per Rule #7
    val todayGuidance = remember(dScore, dailyWarningReasons) {
        buildTodayGuidance(dScore, dailyWarningReasons)
    }

    val weekGuidance = remember(wScore, weeklyWarningReasons) {
        buildWeeklyGuidance(wScore, weeklyWarningReasons)
    }

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("home_performance_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Segmented Tab (TODAY / WEEK) & Refresh
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // DAILY / WEEKLY TOGGLE
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(3.dp)
                        .testTag("performance_period_toggle")
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (selectedTab == 0) Color.White else Color.Transparent)
                            .clickable { selectedTab = 0 }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                            .testTag("toggle_today_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "TODAY",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTab == 0) Color(0xFF4F46E5) else Color(0xFF64748B)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (selectedTab == 1) Color.White else Color.Transparent)
                            .clickable { selectedTab = 1 }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                            .testTag("toggle_week_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "WEEK",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTab == 1) Color(0xFF4F46E5) else Color(0xFF64748B)
                        )
                    }
                }

                // Refresh Button & Status
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (selectedTab == 0) currentDate else if (!wScore.week_start.isNullOrBlank() && !wScore.week_end.isNullOrBlank()) "${wScore.week_start} - ${wScore.week_end}" else "Current Week",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("refresh_performance_button")
                    ) {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF4F46E5)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Scores",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ==========================================
            // TODAY TAB CONTENT
            // MANDATORY ORDER (RULE #5):
            // 1. Performance Meter & Score Band
            // 2. Targets / Benchmarks
            // 3. Metric Details (Call Online, Chat Online, New User, Old User, Repeat, Messages)
            // 4. Warning Card (if warning exists)
            // 5. Improvement Guidance (only if weak / warning exists)
            // ==========================================
            if (selectedTab == 0) {
                // 1. Performance Meter & Score Band
                PremiumSpeedometerScoreMeter(
                    score = dailyWeightedScore,
                    scoreBand = dailyScoreBand,
                    hasScore = dailyScore != null
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Targets / Benchmarks (RULE #6)
                PerformanceTargetsSection(thresholds = thresholds)

                Spacer(modifier = Modifier.height(14.dp))

                // 3. Metric Details in Mandatory Order (RULE #5)
                Text(
                    text = "METRIC DETAILS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF475569),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Row 1: Call Online Hours, Chat Online Hours
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val isCallOnlineWeak = (dScore.call_online_score ?: 100.0) < 40.0
                    val callHours = dScore.call_online_hours ?: 0.0
                    CompactMetricItem(
                        title = "Call Online",
                        value = if (dailyScore != null) String.format("%.1fh", callHours) else "—",
                        subtitle = if (dailyScore != null) "${dScore.call_online_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.PhoneInTalk,
                        isWarning = isCallOnlineWeak,
                        modifier = Modifier.weight(1f)
                    )

                    val isChatOnlineWeak = (dScore.chat_online_score ?: 100.0) < 40.0
                    val chatHours = dScore.chat_online_hours ?: 0.0
                    CompactMetricItem(
                        title = "Chat Online",
                        value = if (dailyScore != null) String.format("%.1fh", chatHours) else "—",
                        subtitle = if (dailyScore != null) "${dScore.chat_online_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.Chat,
                        isWarning = isChatOnlineWeak,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Row 2: New User Avg Call Minutes, Old User Avg Call Minutes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val isNewUserWeak = (dScore.new_user_score ?: 100.0) < 40.0
                    val newMinutes = dScore.new_user_avg_call_minutes ?: 0.0
                    CompactMetricItem(
                        title = "New User Avg Call",
                        value = if (dailyScore != null) String.format("%.1fm", newMinutes) else "—",
                        subtitle = if (dailyScore != null) "${dScore.new_user_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.PersonAdd,
                        isWarning = isNewUserWeak,
                        modifier = Modifier.weight(1f)
                    )

                    val isOldUserWeak = (dScore.old_user_score ?: 100.0) < 40.0
                    val oldMinutes = dScore.old_user_avg_call_minutes ?: 0.0
                    CompactMetricItem(
                        title = "Old User Avg Call",
                        value = if (dailyScore != null) String.format("%.1fm", oldMinutes) else "—",
                        subtitle = if (dailyScore != null) "${dScore.old_user_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.History,
                        isWarning = isOldUserWeak,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Row 3: Repeat User Calls Count, Messages Received Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val isRepeatWeak = (dScore.repeat_user_score ?: 100.0) < 40.0
                    val repeatCalls = dScore.repeat_user_calls_count ?: 0
                    CompactMetricItem(
                        title = "Repeat User Calls",
                        value = if (dailyScore != null) "$repeatCalls" else "—",
                        subtitle = if (dailyScore != null) "${dScore.repeat_user_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.People,
                        isWarning = isRepeatWeak,
                        modifier = Modifier.weight(1f)
                    )

                    val isMsgWeak = (dScore.messages_score ?: 100.0) < 40.0
                    val msgCount = dScore.messages_received_count ?: 0
                    CompactMetricItem(
                        title = "Messages Received",
                        value = if (dailyScore != null) "$msgCount" else "—",
                        subtitle = if (dailyScore != null) "${dScore.messages_score?.toInt() ?: 0} pts" else "No data",
                        icon = Icons.Outlined.MailOutline,
                        isWarning = isMsgWeak,
                        modifier = Modifier.weight(1f)
                    )
                }

                // 4. Server Warning Card (if warning exists)
                if (dailyWarningFlag) {
                    Spacer(modifier = Modifier.height(12.dp))
                    ImprovementWarningCard(
                        warningLevel = dailyWarningLevel ?: "Warning",
                        reasons = dailyWarningReasons
                    )
                }

                // 5. Actionable Guidance (only if weak metrics exist)
                if (todayGuidance.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    ActionableGuidancePanel(guidanceItems = todayGuidance)
                }

            } else {
                // ==========================================
                // WEEK TAB CONTENT
                // MANDATORY ORDER (RULE #5):
                // 1. Performance Meter & Score Band
                // 2. Targets / Benchmarks
                // 3. Weekly Metric Details
                // 4. Warning Card (if warning exists)
                // 5. Improvement Guidance (only if weak / warning exists)
                // ==========================================
                PremiumSpeedometerScoreMeter(
                    score = weeklyWeightedScore,
                    scoreBand = weeklyScoreBand,
                    hasScore = weeklyScore != null
                )

                Spacer(modifier = Modifier.height(14.dp))

                PerformanceTargetsSection(thresholds = thresholds)

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "WEEKLY METRIC DETAILS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF475569),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Row 1: Call Online, Chat Online
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val avgCallHours = wScore.avg_call_online_hours ?: 0.0
                    CompactMetricItem(
                        title = "Call Online",
                        value = if (weeklyScore != null) String.format("%.1fh", avgCallHours) else "—",
                        subtitle = "Daily Avg",
                        icon = Icons.Outlined.PhoneInTalk,
                        isWarning = avgCallHours < 4.0,
                        modifier = Modifier.weight(1f)
                    )

                    val avgChatHours = wScore.avg_chat_online_hours ?: 0.0
                    CompactMetricItem(
                        title = "Chat Online",
                        value = if (weeklyScore != null) String.format("%.1fh", avgChatHours) else "—",
                        subtitle = "Daily Avg",
                        icon = Icons.Outlined.Chat,
                        isWarning = avgChatHours < 4.0,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Row 2: New User Avg Call, Old User Avg Call
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val avgNewMin = wScore.avg_new_user_call_minutes ?: 0.0
                    CompactMetricItem(
                        title = "New User Avg Call",
                        value = if (weeklyScore != null) String.format("%.1fm", avgNewMin) else "—",
                        subtitle = "Avg Duration",
                        icon = Icons.Outlined.PersonAdd,
                        isWarning = avgNewMin < 3.0,
                        modifier = Modifier.weight(1f)
                    )

                    val avgOldMin = wScore.avg_old_user_call_minutes ?: 0.0
                    CompactMetricItem(
                        title = "Old User Avg Call",
                        value = if (weeklyScore != null) String.format("%.1fm", avgOldMin) else "—",
                        subtitle = "Avg Duration",
                        icon = Icons.Outlined.History,
                        isWarning = avgOldMin < 3.0,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Row 3: Repeat User Calls, Messages Received
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val repeatCallsAvg = wScore.repeat_user_calls_avg ?: ((wScore.total_repeat_user_calls_count ?: 0).toDouble() / maxOf(1, wScore.days_scored ?: 1))
                    CompactMetricItem(
                        title = "Repeat User Calls",
                        value = if (weeklyScore != null) String.format("%.1f", repeatCallsAvg) else "—",
                        subtitle = "Daily Avg",
                        icon = Icons.Outlined.People,
                        isWarning = repeatCallsAvg < 2.0,
                        modifier = Modifier.weight(1f)
                    )

                    val totalMsgs = wScore.total_messages_received_count ?: 0
                    CompactMetricItem(
                        title = "Messages Received",
                        value = if (weeklyScore != null) "$totalMsgs" else "—",
                        subtitle = "Total Received",
                        icon = Icons.Outlined.MailOutline,
                        isWarning = totalMsgs < 50,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (weeklyWarningFlag) {
                    Spacer(modifier = Modifier.height(12.dp))
                    ImprovementWarningCard(
                        warningLevel = weeklyWarningLevel ?: "Warning",
                        reasons = weeklyWarningReasons
                    )
                }

                if (weekGuidance.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    ActionableGuidancePanel(guidanceItems = weekGuidance)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Actions Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = lastUpdatedText,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = onViewDailyDetails,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("view_daily_performance_button")
                    ) {
                        Text(
                            text = "Daily",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF4F46E5)
                        )
                    }

                    TextButton(
                        onClick = onViewWeeklyDetails,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("view_weekly_performance_button")
                    ) {
                        Text(
                            text = "Weekly",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                    }

                    TextButton(
                        onClick = onViewHistory,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("view_performance_history_button")
                    ) {
                        Text(
                            text = "History",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}

private fun rememberFormattedDate(): String {
    val cal = Calendar.getInstance()
    val sdf = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
    return sdf.format(cal.time)
}
