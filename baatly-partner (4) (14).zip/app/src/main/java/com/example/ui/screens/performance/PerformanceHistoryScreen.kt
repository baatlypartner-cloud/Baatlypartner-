package com.example.ui.screens.performance

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HostDailyScoreModel
import com.example.ui.viewmodel.PerformanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceHistoryScreen(
    viewModel: PerformanceViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val historyList = uiState.scoreHistory
    var selectedDayScore by remember { mutableStateOf<HostDailyScoreModel?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Score History",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("history_perf_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.loadAllPerformanceData(isRefresh = true) },
                        modifier = Modifier.testTag("history_perf_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color(0xFF4F46E5)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { paddingValues ->
        if (historyList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No score history records available",
                        fontSize = 14.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.loadAllPerformanceData(isRefresh = true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                    ) {
                        Text("Refresh History")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(historyList) { item ->
                    HistoryItemCard(
                        score = item,
                        onClick = { selectedDayScore = item }
                    )
                }
            }
        }

        // Details Modal Bottom Sheet strictly adhering to Rule #5
        if (selectedDayScore != null) {
            val day = selectedDayScore!!
            val dayGuidance = remember(day) {
                buildTodayGuidance(day, day.parsedWarningReasons)
            }

            ModalBottomSheet(
                onDismissRequest = { selectedDayScore = null },
                containerColor = Color.White,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Score Details: ${day.score_date ?: "Historical Day"}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        IconButton(onClick = { selectedDayScore = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // ==================================================
                    // RULE #5 — MANDATORY ORDER OF DISPLAY:
                    // 1. Performance Meter
                    // 2. Score Band
                    // 3. Targets / Benchmarks
                    // 4. Metric Details
                    // 5. Improvement Guidance (only if weak / warning exists)
                    // ==================================================

                    // 1. Performance Meter & 2. Score Band
                    PremiumSpeedometerScoreMeter(
                        score = day.weightedScore ?: 0.0,
                        scoreBand = day.scoreBand ?: "AVERAGE",
                        hasScore = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. Targets / Benchmarks (RULE #6)
                    PerformanceTargetsSection(thresholds = uiState.thresholds)

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4. Metric Details
                    Text(
                        text = "METRIC DETAILS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569),
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 1: Call Online Hours & Chat Online Hours
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val callHours = day.call_online_hours ?: 0.0
                        CompactMetricItem(
                            title = "Call Online",
                            value = String.format("%.1fh", callHours),
                            subtitle = "${day.call_online_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.PhoneInTalk,
                            isWarning = (day.call_online_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )

                        val chatHours = day.chat_online_hours ?: 0.0
                        CompactMetricItem(
                            title = "Chat Online",
                            value = String.format("%.1fh", chatHours),
                            subtitle = "${day.chat_online_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.Chat,
                            isWarning = (day.chat_online_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Row 2: New User Avg Call Minutes & Old User Avg Call Minutes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val newMin = day.new_user_avg_call_minutes ?: 0.0
                        CompactMetricItem(
                            title = "New User Avg Call",
                            value = String.format("%.1fm", newMin),
                            subtitle = "${day.new_user_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.PersonAdd,
                            isWarning = (day.new_user_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )

                        val oldMin = day.old_user_avg_call_minutes ?: 0.0
                        CompactMetricItem(
                            title = "Old User Avg Call",
                            value = String.format("%.1fm", oldMin),
                            subtitle = "${day.old_user_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.History,
                            isWarning = (day.old_user_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Row 3: Repeat User Calls Count & Messages Received Count
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val repeatCalls = day.repeat_user_calls_count ?: 0
                        CompactMetricItem(
                            title = "Repeat User Calls",
                            value = "$repeatCalls",
                            subtitle = "${day.repeat_user_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.People,
                            isWarning = (day.repeat_user_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )

                        val msgCount = day.messages_received_count ?: 0
                        CompactMetricItem(
                            title = "Messages Received",
                            value = "$msgCount",
                            subtitle = "${day.messages_score?.toInt() ?: 0} pts",
                            icon = Icons.Outlined.MailOutline,
                            isWarning = (day.messages_score ?: 100.0) < 40.0,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (day.hasWarning) {
                        Spacer(modifier = Modifier.height(12.dp))
                        ImprovementWarningCard(
                            warningLevel = day.warning_level ?: "Warning",
                            reasons = day.parsedWarningReasons
                        )
                    }

                    if (dayGuidance.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        ActionableGuidancePanel(guidanceItems = dayGuidance)
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(
    score: HostDailyScoreModel,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("history_item_${score.score_date ?: score.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = score.score_date ?: "Past Date",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Call: ${String.format("%.1fh", score.call_online_hours ?: 0.0)}  •  Chat: ${String.format("%.1fh", score.chat_online_hours ?: 0.0)}  •  Repeat: ${score.repeat_user_calls_count ?: 0}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${(score.weightedScore ?: 0.0).toInt()} / 100",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = getScoreColor(score.weightedScore ?: 0.0)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    ScoreBandBadge(band = score.scoreBand)
                }

                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
