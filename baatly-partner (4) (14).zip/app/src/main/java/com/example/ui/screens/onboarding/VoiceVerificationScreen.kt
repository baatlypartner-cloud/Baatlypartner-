package com.example.ui.screens.onboarding

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import com.example.ui.viewmodel.VoiceVerificationState
import com.example.ui.viewmodel.VoiceVerificationViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceVerificationScreen(
    displayName: String,
    applicationId: String?,
    voiceViewModel: VoiceVerificationViewModel,
    onVerificationSuccess: () -> Unit
) {
    val context = LocalContext.current
    val state by voiceViewModel.state.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            voiceViewModel.startRecording()
        }
    }

    LaunchedEffect(state) {
        if (state is VoiceVerificationState.SubmittedSuccess) {
            onVerificationSuccess()
        }
    }

    // Pulse animation for recording
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BaatlyLightBackground)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(16.dp))

                // Step Indicator Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = BaatlyPrimaryLight,
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyPrimaryBorder, BaatlyPrimaryBorder)))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Step 2 of 2: Voice Verification",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BaatlyPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Record Voice Sample",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Aapki aawaz ka ek sample record karein (10-30 seconds). Hamari team aawaz verify karegi.",
                    fontSize = 13.sp,
                    color = TextSecondaryLight,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Script Prompt Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = BaatlyPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sample Script to Read:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BaatlyPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "\"Namaste! Mera naam $displayName hai. Main Baatly par Audio Jockey Host banna chahti hoon aur positive baatein karna pasand karti hoon.\"",
                            fontSize = 14.sp,
                            color = TextPrimaryLight,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            // Center Recording / Playback Controls
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 28.dp)
            ) {
                when (val currentState = state) {
                    is VoiceVerificationState.Idle -> {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimary)
                                .testTag("start_record_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(
                                onClick = {
                                    if (hasMicPermission) {
                                        voiceViewModel.startRecording()
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = "Start Recording",
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Tap mic to start recording",
                            color = TextSecondaryLight,
                            fontSize = 13.sp
                        )
                    }

                    is VoiceVerificationState.Recording -> {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(BaatlyRed)
                                .testTag("stop_record_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(
                                onClick = { voiceViewModel.stopRecording() },
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(
                                    Icons.Default.Stop,
                                    contentDescription = "Stop Recording",
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Recording: ${currentState.durationSeconds}s",
                            color = BaatlyRed,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap to stop recording",
                            color = TextSecondaryLight,
                            fontSize = 12.sp
                        )
                    }

                    is VoiceVerificationState.Recorded -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            // Play / Pause Button
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimary)
                                    .testTag("play_recording_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(
                                    onClick = {
                                        if (currentState.isPlaying) {
                                            voiceViewModel.stopAudioPlayback()
                                        } else {
                                            voiceViewModel.playRecordedAudio()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (currentState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }

                            // Re-record Button
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyLightSurfaceVariant)
                                    .testTag("rerecord_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                IconButton(onClick = { voiceViewModel.reRecord() }) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Re-record",
                                        tint = TextPrimaryLight,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Recorded sample (${currentState.durationSeconds}s)",
                            color = BaatlyGreen,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    is VoiceVerificationState.Submitting -> {
                        CircularProgressIndicator(
                            color = BaatlyPrimary,
                            modifier = Modifier.size(48.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Uploading voice & submitting application...",
                            color = TextPrimaryLight,
                            fontSize = 13.sp
                        )
                    }

                    is VoiceVerificationState.Error -> {
                        Text(
                            text = currentState.message,
                            color = BaatlyRed,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { voiceViewModel.clearError() },
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                        ) {
                            Text("Try Again")
                        }
                    }

                    else -> {}
                }
            }

            // Bottom Submit Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val isRecorded = state is VoiceVerificationState.Recorded
                Button(
                    onClick = {
                        voiceViewModel.submitVoiceVerification(
                            displayName = displayName,
                            applicationId = applicationId
                        )
                    },
                    enabled = isRecorded && state !is VoiceVerificationState.Submitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_voice_verification_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BaatlyPrimary,
                        disabledContainerColor = BaatlyPrimary.copy(alpha = 0.3f)
                    )
                ) {
                    Text(
                        text = "Submit Voice for Approval",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
