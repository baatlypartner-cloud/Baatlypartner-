package com.example.ui.screens.performance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HostDailyScoreModel
import com.example.ui.viewmodel.PerformanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyPerformanceScreen(
    viewModel: PerformanceViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val score = uiState.dailyScore ?: HostDailyScoreModel()
    val scrollState = rememberScrollState()

    val weightedScore = score.weightedScore ?: 0.0
    val scoreBand = score.scoreBand
    val warningLevel = score.warningLevel
    val warningReasons = score.parsedWarningReasons
    val warningFlag = score.hasWarning

    val guidanceItems = remember(score, warningReasons) {
        buildTodayGuidance(score, warningReasons)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Daily Performance",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("daily_perf_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshDailyScore() },
                        modifier = Modifier.testTag("daily_perf_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color(0xFF4F46E5)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // ==================================================
            // RULE #5 — MANDATORY ORDER OF DISPLAY:
            // 1. Performance Meter
            // 2. Score Band
            // 3. Targets / Benchmarks
            // 4. Metric Details
            //    - Call Online Hours
            //    - Chat Online Hours
            //    - New User Avg Call Minutes
            //    - Old User Avg Call Minutes
            //    - Repeat User Calls Count
            //    - Messages Received Count
            // 5. Improvement Guidance (only if weak / warning exists)
            // ==================================================

            // 1. Performance Meter & 2. Score Band Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("daily_hero_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "OVERALL DAILY SCORE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        letterSpacing = 0.5.sp
                    )

                    if (!score.score_date.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = score.score_date ?: "",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    PremiumSpeedometerScoreMeter(
                        score = weightedScore,
                        scoreBand = scoreBand,
                        hasScore = uiState.dailyScore != null
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = viewModel.getFormattedLastUpdated(),
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Targets / Benchmarks Section (RULE #6)
            PerformanceTargetsSection(thresholds = uiState.thresholds)

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Metric Details Section (RULE #5)
            Text(
                text = "METRIC DETAILS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF475569),
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            // 1. Call Online Hours & 2. Chat Online Hours
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val callHours = score.call_online_hours ?: 0.0
                val isCallWeak = (score.call_online_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "Call Online",
                    value = if (uiState.dailyScore != null) String.format("%.1fh", callHours) else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.call_online_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.PhoneInTalk,
                    isWarning = isCallWeak,
                    modifier = Modifier.weight(1f)
                )

                val chatHours = score.chat_online_hours ?: 0.0
                val isChatWeak = (score.chat_online_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "Chat Online",
                    value = if (uiState.dailyScore != null) String.format("%.1fh", chatHours) else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.chat_online_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.Chat,
                    isWarning = isChatWeak,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3. New User Avg Call Minutes & 4. Old User Avg Call Minutes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val newMin = score.new_user_avg_call_minutes ?: 0.0
                val isNewWeak = (score.new_user_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "New User Avg Call",
                    value = if (uiState.dailyScore != null) String.format("%.1fm", newMin) else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.new_user_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.PersonAdd,
                    isWarning = isNewWeak,
                    modifier = Modifier.weight(1f)
                )

                val oldMin = score.old_user_avg_call_minutes ?: 0.0
                val isOldWeak = (score.old_user_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "Old User Avg Call",
                    value = if (uiState.dailyScore != null) String.format("%.1fm", oldMin) else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.old_user_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.History,
                    isWarning = isOldWeak,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 5. Repeat User Calls Count & 6. Messages Received Count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val repeatCalls = score.repeat_user_calls_count ?: 0
                val isRepeatWeak = (score.repeat_user_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "Repeat User Calls",
                    value = if (uiState.dailyScore != null) "$repeatCalls" else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.repeat_user_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.People,
                    isWarning = isRepeatWeak,
                    modifier = Modifier.weight(1f)
                )

                val msgCount = score.messages_received_count ?: 0
                val isMsgWeak = (score.messages_score ?: 100.0) < 40.0
                CompactMetricItem(
                    title = "Messages Received",
                    value = if (uiState.dailyScore != null) "$msgCount" else "—",
                    subtitle = if (uiState.dailyScore != null) "${score.messages_score?.toInt() ?: 0} pts" else "No data",
                    icon = Icons.Outlined.MailOutline,
                    isWarning = isMsgWeak,
                    modifier = Modifier.weight(1f)
                )
            }

            // Improvement Warning Card if warning exists
            if (warningFlag) {
                Spacer(modifier = Modifier.height(16.dp))
                ImprovementWarningCard(
                    warningLevel = warningLevel ?: "Warning",
                    reasons = warningReasons
                )
            }

            // 5. Improvement Guidance (only if weak / warning exists)
            if (guidanceItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                ActionableGuidancePanel(guidanceItems = guidanceItems)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
