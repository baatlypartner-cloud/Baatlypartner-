package com.example.ui.screens.performance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HostScoreThresholdModel
import com.example.data.models.HostWeeklyScoreModel
import com.example.ui.viewmodel.PerformanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyPerformanceScreen(
    viewModel: PerformanceViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val weeklyList = uiState.weeklyScores

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Weekly Performance",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("weekly_perf_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.loadAllPerformanceData(isRefresh = true) },
                        modifier = Modifier.testTag("weekly_perf_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color(0xFF4F46E5)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { paddingValues ->
        if (weeklyList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No weekly performance data recorded yet",
                        fontSize = 14.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.loadAllPerformanceData(isRefresh = true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                    ) {
                        Text("Refresh")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                items(weeklyList) { week ->
                    WeeklyScoreCard(
                        week = week,
                        thresholds = uiState.thresholds
                    )
                }
            }
        }
    }
}

/**
 * Weekly score card strictly structured according to RULE #5 & RULE #6 & RULE #7.
 */
@Composable
fun WeeklyScoreCard(
    week: HostWeeklyScoreModel,
    thresholds: List<HostScoreThresholdModel> = emptyList(),
    modifier: Modifier = Modifier
) {
    val weightedScore = week.weightedScore ?: 0.0
    val scoreBand = week.scoreBand
    val warningLevel = week.warningLevel
    val warningReasons = week.parsedWarningReasons
    val warningFlag = week.hasWarning
    val dateRange = formatDateRange(week.week_start, week.week_end)

    val guidanceItems = remember(week, warningReasons) {
        buildWeeklyGuidance(week, warningReasons)
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("weekly_score_card_${week.id ?: week.week_end}")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header: Date range & Days Scored
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WEEKLY SUMMARY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = dateRange,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }

                Box(
                    modifier = Modifier
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${week.days_scored ?: 0} / 7 Days Scored",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF475569)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ==================================================
            // RULE #5 — MANDATORY ORDER OF DISPLAY:
            // 1. Performance Meter
            // 2. Score Band
            // 3. Targets / Benchmarks
            // 4. Metric Details
            // 5. Improvement Guidance (only if weak / warning exists)
            // ==================================================

            // 1. Performance Meter & 2. Score Band
            PremiumSpeedometerScoreMeter(
                score = weightedScore,
                scoreBand = scoreBand,
                hasScore = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Targets / Benchmarks (RULE #6)
            PerformanceTargetsSection(thresholds = thresholds)

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Metric Details
            Text(
                text = "WEEKLY METRIC DETAILS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF475569),
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Row 1: Call Online & Chat Online
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val avgCallHours = week.avg_call_online_hours ?: 0.0
                CompactMetricItem(
                    title = "Call Online",
                    value = String.format("%.1fh", avgCallHours),
                    subtitle = "Daily Avg",
                    icon = Icons.Outlined.PhoneInTalk,
                    isWarning = avgCallHours < 4.0,
                    modifier = Modifier.weight(1f)
                )

                val avgChatHours = week.avg_chat_online_hours ?: 0.0
                CompactMetricItem(
                    title = "Chat Online",
                    value = String.format("%.1fh", avgChatHours),
                    subtitle = "Daily Avg",
                    icon = Icons.Outlined.Chat,
                    isWarning = avgChatHours < 4.0,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Row 2: New User Avg Call & Old User Avg Call
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val avgNewMin = week.avg_new_user_call_minutes ?: 0.0
                CompactMetricItem(
                    title = "New User Avg Call",
                    value = String.format("%.1fm", avgNewMin),
                    subtitle = "Avg Duration",
                    icon = Icons.Outlined.PersonAdd,
                    isWarning = avgNewMin < 3.0,
                    modifier = Modifier.weight(1f)
                )

                val avgOldMin = week.avg_old_user_call_minutes ?: 0.0
                CompactMetricItem(
                    title = "Old User Avg Call",
                    value = String.format("%.1fm", avgOldMin),
                    subtitle = "Avg Duration",
                    icon = Icons.Outlined.History,
                    isWarning = avgOldMin < 3.0,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Row 3: Repeat User Calls & Messages Received
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val repeatCallsAvg = week.repeat_user_calls_avg ?: ((week.total_repeat_user_calls_count ?: 0).toDouble() / maxOf(1, week.days_scored ?: 1))
                CompactMetricItem(
                    title = "Repeat User Calls",
                    value = String.format("%.1f", repeatCallsAvg),
                    subtitle = "Daily Avg",
                    icon = Icons.Outlined.People,
                    isWarning = repeatCallsAvg < 2.0,
                    modifier = Modifier.weight(1f)
                )

                val totalMsgs = week.total_messages_received_count ?: 0
                CompactMetricItem(
                    title = "Messages Received",
                    value = "$totalMsgs",
                    subtitle = "Week Total",
                    icon = Icons.Outlined.MailOutline,
                    isWarning = totalMsgs < 50,
                    modifier = Modifier.weight(1f)
                )
            }

            // Warning if any
            if (warningFlag) {
                Spacer(modifier = Modifier.height(12.dp))
                ImprovementWarningCard(
                    warningLevel = warningLevel ?: "Warning",
                    reasons = warningReasons
                )
            }

            // 5. Actionable Guidance (only if weak metrics exist)
            if (guidanceItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                ActionableGuidancePanel(guidanceItems = guidanceItems)
            }
        }
    }
}

private fun formatDateRange(start: String?, end: String?): String {
    if (start.isNullOrBlank() && end.isNullOrBlank()) return "Recent Week"
    return "${start ?: ""} — ${end ?: ""}"
}
