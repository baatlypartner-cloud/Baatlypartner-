package com.example.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.security.AppSecurityManager

/**
 * Base activity providing default FLAG_SECURE enforcement for any Activity in Baatly Partner App.
 * Ensures the window is protected from the very beginning of onCreate and onResume.
 */
abstract class BaseSecureActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSecurityManager.applySecureFlag(this)
    }

    override fun onResume() {
        super.onResume()
        AppSecurityManager.applySecureFlag(this)
    }
}
