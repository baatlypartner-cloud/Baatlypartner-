package com.example.ui.screens.recent

import com.example.data.models.isUuid
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.CallViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecentCallsScreen(
    callViewModel: CallViewModel
) {
    val recentCalls by callViewModel.recentCalls.collectAsState()
    val isLoading by callViewModel.isLoadingRecent.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Call Itihas (Recent Calls)", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(
                        onClick = { callViewModel.loadRecentCalls() },
                        modifier = Modifier.testTag("refresh_recent_calls_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (recentCalls.isEmpty() && !isLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.PhoneMissed, contentDescription = null, tint = TextSecondaryLight, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Koi Call Record Nahi Hai", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Jab aap calls receive karenge, unka itihas yahan dikhega.", color = TextSecondaryLight, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    items(recentCalls) { call ->
                        val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                            ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                            ?: "User"
                        val duration = call.durationSeconds ?: 0
                        val min = duration / 60
                        val sec = duration % 60
                        val durationStr = String.format("%02d:%02d", min, sec)
                        val earning = call.partnerEarning ?: 0.0

                        val isCompleted = call.status == "completed"
                        val statusBg = when (call.status) {
                            "completed" -> BaatlyGreenLight
                            "rejected" -> BaatlyRedLight
                            "missed" -> BaatlyGoldLight
                            else -> BaatlyLightSurfaceVariant
                        }
                        val statusColor = when (call.status) {
                            "completed" -> BaatlyGreen
                            "rejected" -> BaatlyRed
                            "missed" -> BaatlyGold
                            else -> TextSecondaryLight
                        }

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("call_item_${call.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(statusBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isCompleted) Icons.Default.CallReceived else Icons.Default.CallEnd,
                                            contentDescription = null,
                                            tint = statusColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(callerName, color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("Duration: $durationStr", color = TextSecondaryLight, fontSize = 12.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    if (earning > 0) {
                                        Text("+₹${String.format("%.2f", earning)}", color = BaatlyGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    } else {
                                        Text("₹0.00", color = TextSecondaryLight, fontSize = 12.sp)
                                    }
                                    Text(call.status.uppercase(), color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                CircularProgressIndicator(
                    color = BaatlyPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}
