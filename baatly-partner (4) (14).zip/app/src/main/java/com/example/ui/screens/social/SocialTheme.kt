package com.example.ui.screens.social

import androidx.compose.animation.core.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object SocialColors {
    val Pink = Color(0xFFEC4899)
    val Magenta = Color(0xFFD946EF)
    val Purple = Color(0xFF8B5CF6)
    val Violet = Color(0xFF7C3AED)
    val Blue = Color(0xFF3B82F6)
    val Cyan = Color(0xFF06B6D4)
    val Rose = Color(0xFFF43F5E)
    val Amber = Color(0xFFF59E0B)

    // Soft Pastels & Highlights
    val PinkLight = Color(0xFFFDF2F8)
    val PurpleLight = Color(0xFFF5F3FF)
    val BlueLight = Color(0xFFEFF6FF)
    val RoseLight = Color(0xFFFFF1F2)
    val SlateSurface = Color(0xFFF8FAFC)
    val CardBorder = Color(0xFFE2E8F0)
}

object SocialGradients {
    // Vibrant Instagram-Style Story Ring Gradient
    val StoryRing = Brush.linearGradient(
        colors = listOf(
            Color(0xFFFF007A),
            Color(0xFFFF5E36),
            Color(0xFF9D00FF),
            Color(0xFF00D2FF)
        )
    )

    // Hero Header Gradient
    val Hero = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF8B5CF6),
            Color(0xFFEC4899),
            Color(0xFFF43F5E)
        )
    )

    // Primary CTA Button Gradient
    val PrimaryCta = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF7C3AED),
            Color(0xFFEC4899)
        )
    )

    // Create Post Card Gradient Accent
    val CreateCardAccent = Brush.linearGradient(
        colors = listOf(
            Color(0xFFFDF2F8),
            Color(0xFFF5F3FF),
            Color(0xFFEFF6FF)
        )
    )

    // Glowing subtle border
    val GlowBorder = Brush.linearGradient(
        colors = listOf(
            Color(0x66EC4899),
            Color(0x668B5CF6),
            Color(0x663B82F6)
        )
    )

    // Like Heart Gradient
    val LikeHeart = Brush.linearGradient(
        colors = listOf(
            Color(0xFFFF1493),
            Color(0xFFFF4500)
        )
    )

    // Host Badge Gradient
    val HostBadge = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFFF59E0B),
            Color(0xFFEC4899)
        )
    )

    // Empty State Background
    val EmptyStateBg = Brush.radialGradient(
        colors = listOf(
            Color(0xFFFAF5FF),
            Color(0xFFFDF2F8),
            Color(0xFFF8FAFC)
        )
    )
}

@Composable
fun rememberShimmerBrush(): Brush {
    val shimmerColors = listOf(
        Color(0xFFF1F5F9),
        Color(0xFFE2E8F0),
        Color(0xFFF1F5F9)
    )
    val transition = rememberInfiniteTransition(label = "shimmer_transition")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_anim"
    )
    return Brush.linearGradient(
        colors = shimmerColors,
        start = Offset.Zero,
        end = Offset(x = translateAnim, y = translateAnim)
    )
}
