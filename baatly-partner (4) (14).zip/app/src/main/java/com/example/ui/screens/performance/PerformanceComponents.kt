package com.example.ui.screens.performance

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

// Performance Color Scheme
val ScoreCriticalRed = Color(0xFFDC2626)
val ScoreAverageAmber = Color(0xFFD97706)
val ScoreGoodBlue = Color(0xFF2563EB)
val ScoreExcellentGreen = Color(0xFF059669)
val GaugeTrackColor = Color(0xFFF1F5F9)

fun getScoreColor(score: Double): Color {
    return when {
        score >= 80.0 -> ScoreExcellentGreen
        score >= 60.0 -> ScoreGoodBlue
        score >= 40.0 -> ScoreAverageAmber
        else -> ScoreCriticalRed
    }
}

fun getScoreBandColor(band: String?): Color {
    return when (band?.trim()?.uppercase()) {
        "EXCELLENT" -> ScoreExcellentGreen
        "GOOD" -> ScoreGoodBlue
        "AVERAGE" -> ScoreAverageAmber
        "CRITICAL", "LOW" -> ScoreCriticalRed
        else -> Color(0xFF64748B)
    }
}

fun getScoreBandText(score: Double, serverBand: String? = null): String {
    val raw = serverBand?.trim()
    if (!raw.isNullOrBlank()) {
        return when (raw.uppercase()) {
            "CRITICAL", "LOW" -> "Critical"
            "AVERAGE" -> "Average"
            "GOOD" -> "Good"
            "EXCELLENT" -> "Excellent"
            else -> raw.lowercase().replaceFirstChar { it.uppercase() }
        }
    }
    return when {
        score >= 80.0 -> "Excellent"
        score >= 60.0 -> "Good"
        score >= 40.0 -> "Average"
        else -> "Critical"
    }
}

/**
 * Premium Half-Circle Speedometer / Clock Score Meter.
 * - Semi-circle gauge (0 to 100 range)
 * - Gauge mapping: 0 = far-left (180°), 50 = center (270° / top), 100 = far-right (360° / 0°)
 * - One physical-looking needle/pin with sharp pointer and metallic pivot hub
 * - Pin points accurately to current score
 * - Center/needle pivot is visually clear and distinct
 * - Score number shown prominently: "XX / 100" (or "Awaiting Data" if no score row exists yet)
 * - Score band shown below/near the number
 * - Smooth needle animation when score loads or changes
 * - Mathematically derived from 0-100 score, stable after animation
 */
@Composable
fun PremiumSpeedometerScoreMeter(
    score: Double,
    scoreBand: String?,
    hasScore: Boolean = true,
    modifier: Modifier = Modifier
) {
    val cleanScore = if (hasScore) score.coerceIn(0.0, 100.0) else 0.0
    val normalizedScore = (cleanScore / 100.0).toFloat()

    val animatedProgress by animateFloatAsState(
        targetValue = normalizedScore,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "speedometer_needle_anim"
    )

    val cleanBand = if (hasScore) getScoreBandText(cleanScore, scoreBand) else "Awaiting Data"
    val bandColor = if (hasScore) getScoreBandColor(cleanBand) else Color(0xFF94A3B8)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 8.dp)
            .testTag("speedometer_score_meter")
    ) {
        // Semi-circle gauge container
        Box(
            modifier = Modifier
                .width(260.dp)
                .height(145.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokePx = 16.dp.toPx()
                val diameter = size.width - strokePx
                val radius = diameter / 2f
                val topLeft = Offset(strokePx / 2f, size.height - radius)
                val arcSize = Size(diameter, diameter)

                // 1. Background Arc (Full 180° semi-circle from 180° to 360°)
                drawArc(
                    color = GaugeTrackColor,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                // 2. Multi-Zone Colored Track Segments matching exact backend bands:
                // 0-39: CRITICAL (180° to 250.2° -> sweep 70.2°)
                drawArc(
                    color = Color(0xFFFEE2E2),
                    startAngle = 180f,
                    sweepAngle = 70.2f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx * 0.45f, cap = StrokeCap.Butt)
                )
                // 40-59: AVERAGE (250.2° to 286.2° -> sweep 36.0°)
                drawArc(
                    color = Color(0xFFFEF3C7),
                    startAngle = 250.2f,
                    sweepAngle = 36.0f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx * 0.45f, cap = StrokeCap.Butt)
                )
                // 60-79: GOOD (286.2° to 322.2° -> sweep 36.0°)
                drawArc(
                    color = Color(0xFFDBEAFE),
                    startAngle = 286.2f,
                    sweepAngle = 36.0f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx * 0.45f, cap = StrokeCap.Butt)
                )
                // 80-100: EXCELLENT (322.2° to 360° -> sweep 37.8°)
                drawArc(
                    color = Color(0xFFD1FAE5),
                    startAngle = 322.2f,
                    sweepAngle = 37.8f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx * 0.45f, cap = StrokeCap.Butt)
                )

                // 3. Active Score Progress Gradient Arc
                val activeSweep = 180f * animatedProgress
                if (activeSweep > 0.5f && hasScore) {
                    drawArc(
                        brush = Brush.horizontalGradient(
                            listOf(
                                ScoreCriticalRed,
                                ScoreAverageAmber,
                                ScoreGoodBlue,
                                ScoreExcellentGreen
                            )
                        ),
                        startAngle = 180f,
                        sweepAngle = activeSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }

                // 4. Tick marks at 0, 50, 100
                val center = Offset(size.width / 2f, size.height)
                val tickFractions = listOf(0.0f, 0.50f, 1.0f)
                tickFractions.forEach { frac ->
                    val tickAngleRad = Math.toRadians((180.0 + (180.0 * frac)))
                    val innerTickR = radius - (strokePx * 1.1f)
                    val outerTickR = radius - (strokePx * 0.2f)
                    val p1 = Offset(
                        x = (center.x + innerTickR * cos(tickAngleRad)).toFloat(),
                        y = (center.y + innerTickR * sin(tickAngleRad)).toFloat()
                    )
                    val p2 = Offset(
                        x = (center.x + outerTickR * cos(tickAngleRad)).toFloat(),
                        y = (center.y + outerTickR * sin(tickAngleRad)).toFloat()
                    )
                    drawLine(
                        color = Color(0xFF94A3B8),
                        start = p1,
                        end = p2,
                        strokeWidth = if (frac == 0.5f) 2.5.dp.toPx() else 1.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }

                // 5. Physical-looking Needle / Pin
                // Angle mathematically derived: 0 score = 180° (far left), 50 = 270° (straight up), 100 = 360° (far right)
                val needleAngleDeg = 180.0 + (180.0 * animatedProgress.toDouble())
                val needleAngleRad = Math.toRadians(needleAngleDeg)
                val needleLength = radius - (strokePx * 0.95f)

                // Needle Tip point
                val needleTip = Offset(
                    x = (center.x + needleLength * cos(needleAngleRad)).toFloat(),
                    y = (center.y + needleLength * sin(needleAngleRad)).toFloat()
                )

                // Perpendicular offset for needle base width
                val perpAngleRad = needleAngleRad + Math.PI / 2.0
                val baseHalfWidth = 3.5.dp.toPx()
                val needleBaseLeft = Offset(
                    x = (center.x + baseHalfWidth * cos(perpAngleRad)).toFloat(),
                    y = (center.y + baseHalfWidth * sin(perpAngleRad)).toFloat()
                )
                val needleBaseRight = Offset(
                    x = (center.x - baseHalfWidth * cos(perpAngleRad)).toFloat(),
                    y = (center.y - baseHalfWidth * sin(perpAngleRad)).toFloat()
                )

                // Draw needle body polygon
                val needlePath = Path().apply {
                    moveTo(needleBaseLeft.x, needleBaseLeft.y)
                    lineTo(needleTip.x, needleTip.y)
                    lineTo(needleBaseRight.x, needleBaseRight.y)
                    close()
                }
                drawPath(
                    path = needlePath,
                    color = Color(0xFF1E293B)
                )

                // Draw accent color line on needle tip
                val accentTipStart = Offset(
                    x = (center.x + (needleLength * 0.65f) * cos(needleAngleRad)).toFloat(),
                    y = (center.y + (needleLength * 0.65f) * sin(needleAngleRad)).toFloat()
                )
                drawLine(
                    color = if (hasScore) bandColor else Color(0xFF94A3B8),
                    start = accentTipStart,
                    end = needleTip,
                    strokeWidth = 2.5.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // 6. Visually Clear Center Needle Pivot Hub
                // Outer chrome bezel
                drawCircle(
                    color = Color(0xFF334155),
                    radius = 12.dp.toPx(),
                    center = center
                )
                // Middle metallic hub
                drawCircle(
                    color = if (hasScore) bandColor else Color(0xFF64748B),
                    radius = 8.5.dp.toPx(),
                    center = center
                )
                // Center metallic jewel cap
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = center
                )
            }
        }

        // Ticks labels below arc (0 at left, 50 at center, 100 at right)
        Row(
            modifier = Modifier
                .width(260.dp)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("0", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
            Text("50", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
            Text("100", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Prominent Score Display (or "Awaiting Data" if no score row exists)
        if (hasScore) {
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "${cleanScore.toInt()}",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    color = bandColor,
                    letterSpacing = (-1).sp
                )
                Text(
                    text = " / 100",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(bottom = 5.dp, start = 2.dp)
                )
            }
        } else {
            Text(
                text = "Awaiting Data",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // Score Band Display
        if (hasScore) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Band: ",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = cleanBand,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = bandColor
                )
            }
        }
    }
}

/**
 * Benchmark & Target section immediately below the meter as mandated by Rule #5 and Rule #6.
 * Displays the six exact target lines.
 */
@Composable
fun PerformanceTargetsSection(
    thresholds: List<com.example.data.models.HostScoreThresholdModel> = emptyList(),
    modifier: Modifier = Modifier
) {
    val thMap = thresholds.associateBy { it.metricKey ?: "" }

    val callOnlineLow = thMap["call_online_hours"]?.lowThreshold?.toInt() ?: 4
    val callOnlineAvg = thMap["call_online_hours"]?.averageThreshold?.toInt() ?: 6
    val callOnlineGood = thMap["call_online_hours"]?.goodThreshold?.toInt() ?: 8

    val chatOnlineLow = thMap["chat_online_hours"]?.lowThreshold?.toInt() ?: 4
    val chatOnlineAvg = thMap["chat_online_hours"]?.averageThreshold?.toInt() ?: 5
    val chatOnlineGood = thMap["chat_online_hours"]?.goodThreshold?.toInt() ?: 7

    val newUserLow = thMap["new_user_avg_call_minutes"]?.lowThreshold?.toInt() ?: 3
    val newUserAvg = thMap["new_user_avg_call_minutes"]?.averageThreshold?.toInt() ?: 5
    val newUserGood = thMap["new_user_avg_call_minutes"]?.goodThreshold?.toInt() ?: 8

    val oldUserLow = thMap["old_user_avg_call_minutes"]?.lowThreshold?.toInt() ?: 3
    val oldUserAvg = thMap["old_user_avg_call_minutes"]?.averageThreshold?.toInt() ?: 8
    val oldUserGood = thMap["old_user_avg_call_minutes"]?.goodThreshold?.toInt() ?: 15

    val repeatCallsLow = thMap["repeat_user_calls_count"]?.lowThreshold?.toInt() ?: 2
    val repeatCallsAvg = thMap["repeat_user_calls_count"]?.averageThreshold?.toInt() ?: 5
    val repeatCallsGood = thMap["repeat_user_calls_count"]?.goodThreshold?.toInt() ?: 8

    val messagesLow = thMap["messages_received_count"]?.lowThreshold?.toInt() ?: 50
    val messagesAvg = thMap["messages_received_count"]?.averageThreshold?.toInt() ?: 100
    val messagesGood = thMap["messages_received_count"]?.goodThreshold?.toInt() ?: 200

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("target_benchmark_section")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "TARGETS & BENCHMARKS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF475569),
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Daily Goals",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 6 Exact Target Lines
            BenchmarkTargetRow(
                metricName = "CALL ONLINE",
                low = "${callOnlineLow}h",
                average = "${callOnlineAvg}h",
                good = "${callOnlineGood}h"
            )
            androidx.compose.material3.Divider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f), thickness = 0.5.dp)

            BenchmarkTargetRow(
                metricName = "CHAT ONLINE",
                low = "${chatOnlineLow}h",
                average = "${chatOnlineAvg}h",
                good = "${chatOnlineGood}h"
            )
            androidx.compose.material3.Divider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f), thickness = 0.5.dp)

            BenchmarkTargetRow(
                metricName = "NEW USER AVG CALL",
                low = "${newUserLow}m",
                average = "${newUserAvg}m",
                good = "${newUserGood}m"
            )
            androidx.compose.material3.Divider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f), thickness = 0.5.dp)

            BenchmarkTargetRow(
                metricName = "OLD/REPEAT AVG CALL",
                low = "${oldUserLow}m",
                average = "${oldUserAvg}m",
                good = "${oldUserGood}m"
            )
            androidx.compose.material3.Divider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f), thickness = 0.5.dp)

            BenchmarkTargetRow(
                metricName = "REPEAT USER CALLS",
                low = "$repeatCallsLow",
                average = "$repeatCallsAvg",
                good = "$repeatCallsGood"
            )
            androidx.compose.material3.Divider(color = Color(0xFFE2E8F0).copy(alpha = 0.6f), thickness = 0.5.dp)

            BenchmarkTargetRow(
                metricName = "MESSAGES RECEIVED",
                low = "$messagesLow",
                average = "$messagesAvg",
                good = "$messagesGood"
            )
        }
    }
}

@Composable
private fun BenchmarkTargetRow(
    metricName: String,
    low: String,
    average: String,
    good: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = metricName,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Low ",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Medium
            )
            Text(
                text = low,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFEF4444)
            )
            Text(
                text = "  •  Avg ",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Medium
            )
            Text(
                text = average,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD97706)
            )
            Text(
                text = "  •  Good ",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Medium
            )
            Text(
                text = good,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF059669)
            )
        }
    }
}

/**
 * Compact Metric Tile for Call Online, Chat Online, New User Calls, Repeat User Calls, Messages, Missed Calls.
 */
@Composable
fun CompactMetricItem(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWarning) Color(0xFFFEF2F2) else Color(0xFFF8FAFC)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isWarning) Color(0xFFFCA5A5) else Color(0xFFE2E8F0)
            )
        ),
        modifier = modifier
            .padding(3.dp)
            .testTag("metric_${title.replace(" ", "_").lowercase()}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isWarning) Color(0xFFB91C1C) else Color(0xFF64748B),
                    maxLines = 1
                )
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isWarning) Color(0xFFDC2626) else Color(0xFF6366F1),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (isWarning) Color(0xFFDC2626) else Color(0xFF0F172A)
            )

            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

/**
 * Actionable Improvement Guidance panel.
 * Derived strictly from metric health and server warning state.
 * Only shown when metrics are weak; hidden when healthy.
 */
@Composable
fun ActionableGuidancePanel(
    guidanceItems: List<Pair<String, String>>,
    modifier: Modifier = Modifier
) {
    if (guidanceItems.isEmpty()) return

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("improvement_guidance_panel")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Lightbulb,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Improvement Guidance",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            guidanceItems.forEach { (metricIssue, actionText) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = metricIssue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "→",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6366F1)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "\"$actionText\"",
                        fontSize = 12.sp,
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

/**
 * Improvement Warning Card showing warning level and actual server-provided warning reasons.
 */
@Composable
fun ImprovementWarningCard(
    warningLevel: String?,
    reasons: List<String>,
    modifier: Modifier = Modifier
) {
    if (warningLevel.isNullOrBlank() || warningLevel.equals("none", ignoreCase = true)) {
        return
    }

    val isSevere = warningLevel.equals("severe", ignoreCase = true) || warningLevel.equals("critical", ignoreCase = true)
    val bgColor = if (isSevere) Color(0xFFFEF2F2) else Color(0xFFFFFBEB)
    val borderColor = if (isSevere) Color(0xFFFCA5A5) else Color(0xFFFDE68A)
    val contentColor = if (isSevere) Color(0xFFB91C1C) else Color(0xFFB45309)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(14.dp)
            .testTag("performance_warning_panel")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isSevere) Icons.Default.Warning else Icons.Default.Info,
                contentDescription = "Warning",
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Performance needs improvement",
                color = contentColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (reasons.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            reasons.forEach { reason ->
                Row(
                    modifier = Modifier.padding(vertical = 2.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 6.dp, end = 6.dp)
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(contentColor)
                    )
                    Text(
                        text = reason,
                        color = contentColor.copy(alpha = 0.95f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

/**
 * Score Band Pill Badge (e.g. "Excellent", "Average", "Critical").
 */
@Composable
fun ScoreBandBadge(
    band: String?,
    modifier: Modifier = Modifier
) {
    val cleanBand = band?.ifBlank { "Average" } ?: "Average"
    val color = getScoreBandColor(cleanBand)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = cleanBand.uppercase(),
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

/**
 * Legacy HalfCircleGauge kept for detail breakdown screens.
 */
@Composable
fun HalfCircleGauge(
    score: Double,
    label: String,
    modifier: Modifier = Modifier,
    maxScore: Double = 100.0,
    sizeDp: Dp = 105.dp,
    strokeWidthDp: Dp = 9.dp
) {
    val normalizedScore = (score / maxScore).coerceIn(0.0, 1.0).toFloat()
    val animatedProgress by animateFloatAsState(
        targetValue = normalizedScore,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "gauge_needle_anim"
    )

    val color = getScoreColor(score)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .testTag("gauge_${label.replace(" ", "_").lowercase()}")
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(sizeDp, sizeDp * 0.65f),
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokePx = strokeWidthDp.toPx()
                val diameter = size.width - strokePx
                val radius = diameter / 2f
                val topLeft = Offset(strokePx / 2f, size.height - radius)
                val arcSize = Size(diameter, diameter)

                drawArc(
                    color = GaugeTrackColor,
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                val sweep = 180f * animatedProgress
                if (sweep > 0f) {
                    drawArc(
                        brush = Brush.horizontalGradient(
                            listOf(color.copy(alpha = 0.8f), color)
                        ),
                        startAngle = 180f,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }

                val center = Offset(size.width / 2f, size.height)
                val needleAngleRad = Math.toRadians((180.0 + (180.0 * animatedProgress)))
                val needleLength = radius - (strokePx * 0.9f)
                val needleEnd = Offset(
                    x = (center.x + needleLength * cos(needleAngleRad)).toFloat(),
                    y = (center.y + needleLength * sin(needleAngleRad)).toFloat()
                )

                drawLine(
                    color = Color(0xFF1E293B),
                    start = center,
                    end = needleEnd,
                    strokeWidth = 2.5.dp.toPx(),
                    cap = StrokeCap.Round
                )

                drawCircle(color = color, radius = 4.5.dp.toPx(), center = center)
                drawCircle(color = Color.White, radius = 2.dp.toPx(), center = center)
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Text(
                    text = "${score.toInt()}",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF475569),
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp
        )
    }
}

/**
 * Call Statistics Summary row.
 */
@Composable
fun PerformanceCallStatsRow(
    totalCalls: Int,
    connectedCalls: Int,
    missedCalls: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatItem(
            label = "TOTAL CALLS",
            value = totalCalls.toString(),
            color = Color(0xFF334155),
            modifier = Modifier.weight(1f)
        )
        StatItem(
            label = "CONNECTED",
            value = connectedCalls.toString(),
            color = Color(0xFF059669),
            modifier = Modifier.weight(1f)
        )
        StatItem(
            label = "MISSED",
            value = missedCalls.toString(),
            color = if (missedCalls > 0) Color(0xFFDC2626) else Color(0xFF64748B),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatItem(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF64748B),
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

/**
 * Builds actionable improvement guidance strictly derived from weak metrics and server warning state (Rule #7).
 * - call online hours low -> 'Increase your available call time.'
 * - messages low -> 'Respond consistently and remain available for chats.'
 * - repeat users low -> 'Focus on maintaining conversations and building repeat engagement.'
 * - new-user call duration low -> 'Improve engagement with new users.'
 * - old-user call duration low -> 'Keep regular callers engaged longer.'
 * - chat online hours low -> 'Keep chat availability active during peak hours.'
 */
fun buildTodayGuidance(score: com.example.data.models.HostDailyScoreModel, warningReasons: List<String>): List<Pair<String, String>> {
    val items = mutableListOf<Pair<String, String>>()
    val reasonsJoined = warningReasons.joinToString(" ").lowercase()

    // 1. Call online hours low
    if ((score.call_online_score ?: 100.0) < 40.0 || (score.call_online_hours ?: 10.0) < 4.0 || reasonsJoined.contains("call online")) {
        items.add("Call online hours low" to "Increase your available call time.")
    }

    // 2. Chat online hours low
    if ((score.chat_online_score ?: 100.0) < 40.0 || (score.chat_online_hours ?: 10.0) < 4.0 || reasonsJoined.contains("chat online")) {
        items.add("Chat online hours low" to "Keep chat availability active during peak hours.")
    }

    // 3. Messages low
    if ((score.messages_score ?: 100.0) < 40.0 || (score.messages_received_count ?: 100) < 50 || reasonsJoined.contains("message")) {
        items.add("Messages received low" to "Respond consistently and remain available for chats.")
    }

    // 4. Repeat user calls low (NEVER Repeat Users)
    if ((score.repeat_user_score ?: 100.0) < 40.0 || (score.repeat_user_calls_count ?: 10) < 2 || reasonsJoined.contains("repeat")) {
        items.add("Repeat user calls low" to "Focus on maintaining conversations and building repeat engagement.")
    }

    // 5. New-user call duration low
    if ((score.new_user_score ?: 100.0) < 40.0 || (score.new_user_avg_call_minutes ?: 10.0) < 3.0 || reasonsJoined.contains("new user")) {
        items.add("New-user call duration low" to "Improve engagement with new users.")
    }

    // 6. Old-user call duration low
    if ((score.old_user_score ?: 100.0) < 40.0 || (score.old_user_avg_call_minutes ?: 15.0) < 3.0 || reasonsJoined.contains("old user")) {
        items.add("Old-user call duration low" to "Keep regular callers engaged longer.")
    }

    return items
}

/**
 * Builds actionable improvement guidance for weekly view.
 */
fun buildWeeklyGuidance(week: com.example.data.models.HostWeeklyScoreModel, warningReasons: List<String>): List<Pair<String, String>> {
    val items = mutableListOf<Pair<String, String>>()
    val reasonsJoined = warningReasons.joinToString(" ").lowercase()

    if ((week.avg_call_online_hours ?: 10.0) < 4.0 || reasonsJoined.contains("call online")) {
        items.add("Call online hours low" to "Increase your available call time.")
    }
    if ((week.avg_chat_online_hours ?: 10.0) < 4.0 || reasonsJoined.contains("chat online")) {
        items.add("Chat online hours low" to "Keep chat availability active during peak hours.")
    }
    if ((week.total_messages_received_count ?: 100) < 50 || reasonsJoined.contains("message")) {
        items.add("Messages received low" to "Respond consistently and remain available for chats.")
    }
    if ((week.total_repeat_user_calls_count ?: 10) < 5 || (week.repeat_user_calls_avg ?: 10.0) < 2.0 || reasonsJoined.contains("repeat")) {
        items.add("Repeat user calls low" to "Focus on maintaining conversations and building repeat engagement.")
    }
    if ((week.avg_new_user_call_minutes ?: 10.0) < 3.0 || reasonsJoined.contains("new user")) {
        items.add("New-user call duration low" to "Improve engagement with new users.")
    }
    if ((week.avg_old_user_call_minutes ?: 15.0) < 3.0 || reasonsJoined.contains("old user")) {
        items.add("Old-user call duration low" to "Keep regular callers engaged longer.")
    }

    return items
}


