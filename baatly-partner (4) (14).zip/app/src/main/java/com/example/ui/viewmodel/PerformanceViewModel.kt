package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.HostDailyScoreModel
import com.example.data.models.HostWeeklyScoreModel
import com.example.data.repository.HostPerformanceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PerformanceUiState(
    val dailyScore: HostDailyScoreModel? = null,
    val weeklyScores: List<HostWeeklyScoreModel> = emptyList(),
    val scoreHistory: List<HostDailyScoreModel> = emptyList(),
    val thresholds: List<com.example.data.models.HostScoreThresholdModel> = emptyList(),
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val errorMessage: String? = null,
    val lastUpdatedMillis: Long = 0L
)

class PerformanceViewModel(
    private val performanceRepository: HostPerformanceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PerformanceUiState())
    val uiState: StateFlow<PerformanceUiState> = _uiState.asStateFlow()

    init {
        loadAllPerformanceData()
    }

    fun loadAllPerformanceData(isRefresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = !isRefresh,
                isRefreshing = isRefresh,
                errorMessage = null
            )

            val dailyRes = performanceRepository.getTodayDailyScore(forceRefresh = isRefresh)
            val weeklyRes = performanceRepository.getWeeklyScores()
            val historyRes = performanceRepository.getScoreHistory()
            val thresholdRes = performanceRepository.getScoreThresholds()

            val daily = dailyRes.getOrNull() ?: _uiState.value.dailyScore
            val weekly = weeklyRes.getOrNull() ?: _uiState.value.weeklyScores
            val history = historyRes.getOrNull() ?: _uiState.value.scoreHistory
            val thresholds = thresholdRes.getOrNull() ?: _uiState.value.thresholds

            _uiState.value = _uiState.value.copy(
                dailyScore = daily,
                weeklyScores = weekly,
                scoreHistory = history,
                thresholds = thresholds,
                isLoading = false,
                isRefreshing = false,
                lastUpdatedMillis = System.currentTimeMillis()
            )
        }
    }

    fun refreshDailyScore() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRefreshing = true)
            val res = performanceRepository.getTodayDailyScore(forceRefresh = true)
            _uiState.value = _uiState.value.copy(
                dailyScore = res.getOrNull() ?: _uiState.value.dailyScore,
                isRefreshing = false,
                lastUpdatedMillis = System.currentTimeMillis()
            )
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun getFormattedLastUpdated(): String {
        val millis = _uiState.value.lastUpdatedMillis
        if (millis <= 0L) return "Not updated yet"
        val diffSeconds = (System.currentTimeMillis() - millis) / 1000
        return when {
            diffSeconds < 60 -> "Updated just now"
            diffSeconds < 3600 -> "Updated ${diffSeconds / 60}m ago"
            else -> "Updated ${diffSeconds / 3600}h ago"
        }
    }
}

class PerformanceViewModelFactory(
    private val performanceRepository: HostPerformanceRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PerformanceViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PerformanceViewModel(performanceRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
