package com.example.ui.screens.social

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.example.data.models.*
import com.example.data.repository.PrivateMediaRepository
import com.example.data.repository.rememberPrivateStorageUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.SocialViewModel
import java.io.File
import java.io.FileOutputStream

// -------------------------------------------------------------------------------------------------
// 1. DEDICATED FULL-SCREEN SOCIAL SEARCH
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialSearchScreen(
    socialViewModel: SocialViewModel,
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val searchQuery by socialViewModel.searchQuery.collectAsState()
    val isSearching by socialViewModel.isSearching.collectAsState()
    val searchResult by socialViewModel.searchResult.collectAsState()
    val searchError by socialViewModel.searchError.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Search Users",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("search_back_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
                .testTag("social_search_screen")
        ) {
            // Search Input Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { socialViewModel.setSearchQuery(it) },
                    placeholder = { Text("Enter User ID to search...", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = SocialColors.Purple)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { socialViewModel.clearSearch() }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondaryLight)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SocialColors.Purple,
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("social_search_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .height(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .then(
                            if (searchQuery.isNotBlank() && !isSearching) Modifier.background(SocialGradients.PrimaryCta)
                            else Modifier.background(Color(0xFFE2E8F0))
                        )
                        .clickable(enabled = searchQuery.isNotBlank() && !isSearching) {
                            socialViewModel.performSearch()
                        }
                        .testTag("social_search_submit_button")
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSearching) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Search", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            // Error display
            if (searchError != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SocialColors.RoseLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = SocialColors.Rose, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = searchError ?: "",
                            color = SocialColors.Rose,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Search Result Card
            if (searchResult != null) {
                val result = searchResult!!
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(20.dp))
                        .testTag("searched_user_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = result.socialAvatarUrl ?: result.avatarUrl
                        val resolved = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.StoryRing)
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(1.5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolved.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolved,
                                        contentDescription = result.displayName,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (result.displayName ?: "U").take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple,
                                            fontSize = 22.sp
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = result.displayName ?: "Baatly User",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = result.handle,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = SocialColors.Purple
                            )
                            if (!result.bio.isNullOrBlank()) {
                                Text(
                                    text = result.bio,
                                    fontSize = 11.sp,
                                    color = TextSecondaryLight,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.Transparent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(SocialGradients.PrimaryCta)
                                .clickable { socialViewModel.openUserProfile(result) }
                                .testTag("view_searched_user_button")
                        ) {
                            Text(
                                text = "View",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 2. CREATE SOCIAL CONTENT SCREEN (Post vs Story Tabs with Gradient Picker & Share)
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateSocialContentScreen(
    defaultType: String,
    isPosting: Boolean,
    isUploadingStory: Boolean,
    onBack: () -> Unit,
    onCreatePost: (File, String?) -> Unit,
    onCreateStory: (File, String?) -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    var selectedContentType by remember { mutableStateOf(if (defaultType == "story") 1 else 0) } // 0: Post, 1: Story

    var postImageUri by remember { mutableStateOf<Uri?>(null) }
    var postCaption by remember { mutableStateOf("") }
    var postError by remember { mutableStateOf<String?>(null) }

    var storyImageUri by remember { mutableStateOf<Uri?>(null) }
    var storyCaption by remember { mutableStateOf("") }
    var storyError by remember { mutableStateOf<String?>(null) }

    val postPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        postImageUri = uri
        postError = null
    }

    val storyPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        storyImageUri = uri
        storyError = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (selectedContentType == 0) "New Post" else "New Story",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Content Type Tab Row
            TabRow(
                selectedTabIndex = selectedContentType,
                containerColor = Color.White,
                contentColor = SocialColors.Purple,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedContentType == 0,
                    onClick = { selectedContentType = 0 },
                    text = { Text("Photo Post", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = null) }
                )
                Tab(
                    selected = selectedContentType == 1,
                    onClick = { selectedContentType = 1 },
                    text = { Text("24h Story", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.HistoryToggleOff, contentDescription = null) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tab Content
            if (selectedContentType == 0) {
                // CREATE POST
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        // Image Picker Card
                        if (postImageUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.Black)
                                    .clickable { postPhotoPicker.launch("image/*") }
                            ) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = postImageUri),
                                    contentDescription = "Selected Post Image",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.Black.copy(alpha = 0.6f),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = "Tap to change",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SocialGradients.CreateCardAccent)
                                    .border(1.5.dp, SocialColors.Purple.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .clickable { postPhotoPicker.launch("image/*") }
                                    .testTag("select_post_photo_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(SocialGradients.Hero),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Select Photo from Gallery", fontWeight = FontWeight.Bold, color = SocialColors.Purple, fontSize = 14.sp)
                                    Text("Supports JPG, PNG", fontSize = 11.sp, color = TextSecondaryLight)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = postCaption,
                            onValueChange = { postCaption = it },
                            label = { Text("Write a Caption") },
                            placeholder = { Text("Share what's happening...") },
                            maxLines = 4,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SocialColors.Purple,
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("post_caption_input")
                        )

                        if (postError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(postError ?: "", color = SocialColors.Rose, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .then(
                                    if (!isPosting) Modifier.background(SocialGradients.PrimaryCta)
                                    else Modifier.background(Color(0xFFE2E8F0))
                                )
                                .clickable(enabled = !isPosting) {
                                    if (postImageUri == null) {
                                        postError = "Please select a photo for your post"
                                        return@clickable
                                    }
                                    val file = try {
                                        val inputStream = context.contentResolver.openInputStream(postImageUri!!)
                                        val tempFile = File(context.cacheDir, "post_${System.currentTimeMillis()}.jpg")
                                        val outputStream = FileOutputStream(tempFile)
                                        inputStream?.copyTo(outputStream)
                                        inputStream?.close()
                                        outputStream.close()
                                        tempFile
                                    } catch (e: Exception) {
                                        postError = "Failed to load image file"
                                        return@clickable
                                    }
                                    onCreatePost(file, postCaption.trim())
                                }
                                .testTag("submit_post_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isPosting) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                } else {
                                    Text("Share Post", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                // CREATE STORY
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Stories disappear automatically after 24 hours",
                            fontSize = 12.sp,
                            color = SocialColors.Purple,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (storyImageUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(280.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.Black)
                                    .clickable { storyPhotoPicker.launch("image/*") }
                            ) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = storyImageUri),
                                    contentDescription = "Selected Story Image",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.Black.copy(alpha = 0.6f),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = "Tap to change",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(SocialGradients.CreateCardAccent)
                                    .border(1.5.dp, SocialColors.Purple.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .clickable { storyPhotoPicker.launch("image/*") }
                                    .testTag("select_story_photo_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(SocialGradients.Hero),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Select Story Photo", fontWeight = FontWeight.Bold, color = SocialColors.Purple, fontSize = 14.sp)
                                    Text("Vertical photos look best", fontSize = 11.sp, color = TextSecondaryLight)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = storyCaption,
                            onValueChange = { storyCaption = it },
                            label = { Text("Story Caption (Optional)") },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SocialColors.Purple,
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("story_caption_input")
                        )

                        if (storyError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(storyError ?: "", color = SocialColors.Rose, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .then(
                                    if (!isUploadingStory) Modifier.background(SocialGradients.PrimaryCta)
                                    else Modifier.background(Color(0xFFE2E8F0))
                                )
                                .clickable(enabled = !isUploadingStory) {
                                    if (storyImageUri == null) {
                                        storyError = "Please select a photo for your story"
                                        return@clickable
                                    }
                                    val file = try {
                                        val inputStream = context.contentResolver.openInputStream(storyImageUri!!)
                                        val tempFile = File(context.cacheDir, "story_${System.currentTimeMillis()}.jpg")
                                        val outputStream = FileOutputStream(tempFile)
                                        inputStream?.copyTo(outputStream)
                                        inputStream?.close()
                                        outputStream.close()
                                        tempFile
                                    } catch (e: Exception) {
                                        storyError = "Failed to load image file"
                                        return@clickable
                                    }
                                    onCreateStory(file, storyCaption.trim().takeIf { it.isNotBlank() })
                                }
                                .testTag("submit_story_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isUploadingStory) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                } else {
                                    Text("Post Story", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 3. DEDICATED FULL-SCREEN POST VIEWER
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialPostViewerScreen(
    post: SocialPostModel,
    hostUserId: String = "",
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onDeleteClick: (() -> Unit)? = null
) {
    BackHandler { onBack() }

    val postMedia = post.mediaPath ?: post.mediaUrl
    val authorName = post.authorName.takeIf { it.isNotBlank() } ?: post.profile?.displayName ?: "Baatly User"
    val authorAvatar = post.authorAvatar ?: post.socialProfile?.socialAvatarUrl ?: post.profile?.avatarUrl
    val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = authorAvatar, privateMediaRepo = privateMediaRepo).value
    val isLiked = post.isLiked == true
    val isOwner = (post.userId == hostUserId || (post.ownerId != null && post.ownerId == hostUserId)) && hostUserId.isNotBlank()
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Post",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                actions = {
                    if (isOwner && onDeleteClick != null) {
                        IconButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.testTag("viewer_delete_post_button")
                        ) {
                            Icon(
                                Icons.Outlined.Delete,
                                contentDescription = "Delete post",
                                tint = SocialColors.Rose
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
                    .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(20.dp))
            ) {
                Column {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.StoryRing)
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(1.5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolvedAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatar,
                                        contentDescription = authorName,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = authorName.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = authorName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = post.authorHandle,
                                fontSize = 12.sp,
                                color = SocialColors.Purple
                            )
                        }

                        if (isOwner && onDeleteClick != null) {
                            IconButton(
                                onClick = { showDeleteConfirmation = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.Delete,
                                    contentDescription = "Delete post",
                                    tint = SocialColors.Rose,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Media
                    if (!postMedia.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp)
                        ) {
                            SocialMediaImage(
                                mediaPath = postMedia,
                                privateMediaRepo = privateMediaRepo,
                                contentDescription = post.caption,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    // Actions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onLikeClick) {
                            Icon(
                                imageVector = if (isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Like",
                                tint = if (isLiked) SocialColors.Rose else TextPrimaryLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            text = "${post.likesCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        IconButton(onClick = onCommentClick) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = "Comment",
                                tint = SocialColors.Purple,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Text(
                            text = "${post.commentsCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )

                        Spacer(modifier = Modifier.weight(1f))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SocialColors.PurpleLight
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Visibility,
                                    contentDescription = "Views",
                                    tint = SocialColors.Purple,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${post.viewsCount ?: 0} views",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SocialColors.Purple
                                )
                            }
                        }
                    }

                    // Caption
                    if (!post.caption.isNullOrBlank()) {
                        Text(
                            text = post.caption,
                            fontSize = 14.sp,
                            color = TextPrimaryLight,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = {
                Text(
                    text = "Delete post?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )
            },
            text = {
                Text(
                    text = "This post will be permanently deleted. Coins already spent by users will not be refunded.",
                    fontSize = 14.sp,
                    color = TextSecondaryLight,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmation = false
                        onDeleteClick?.invoke()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SocialColors.Rose,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_delete_post_button")
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirmation = false },
                    modifier = Modifier.testTag("cancel_delete_post_button")
                ) {
                    Text("Cancel", color = TextSecondaryLight, fontWeight = FontWeight.Medium)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }
}

// -------------------------------------------------------------------------------------------------
// 4. HOST SOCIAL PROFILE FULL SCREEN
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostSocialProfileFullScreen(
    hostProfile: SocialProfileModel?,
    hostPosts: List<SocialPostModel>,
    hostStories: List<SocialStoryModel>,
    hostEarnings: SocialEarningsModel?,
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit,
    onUpdateProfile: (bio: String?, hobbies: String?, avatarFile: File?, onComplete: () -> Unit) -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    onPostLike: (SocialPostModel) -> Unit,
    onPostComment: (SocialPostModel) -> Unit,
    onPostDelete: ((SocialPostModel) -> Unit)? = null
) {
    BackHandler { onBack() }

    var selectedTab by remember { mutableStateOf(0) } // 0: Posts, 1: Stories
    var selectedPostForDetail by remember { mutableStateOf<SocialPostModel?>(null) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showEarningsDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Partner Social Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("host_profile_back_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .testTag("host_social_profile_screen")
        ) {
            // Profile Card Header
            Card(
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Profile Header Row (Avatar + Stats)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
                        val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        Box(
                            modifier = Modifier
                                .size(82.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.StoryRing)
                                .padding(3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolvedAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatar,
                                        contentDescription = "Host Avatar",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (hostProfile?.profile?.displayName ?: "H").take(1).uppercase(),
                                            fontSize = 32.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Stats Row
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ProfileStatItem("Followers", hostProfile?.followersCount ?: 0)
                            ProfileStatItem("Following", hostProfile?.followingCount ?: 0)
                            ProfileStatItem("Likes", hostProfile?.totalLikes ?: 0)
                            ProfileStatItem("Views", hostProfile?.totalViews ?: 0)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = hostProfile?.profile?.displayName ?: "Host",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = hostProfile?.handle ?: "@host",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = SocialColors.Purple
                    )

                    if (!hostProfile?.bio.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = hostProfile?.bio ?: "",
                            fontSize = 13.sp,
                            color = TextPrimaryLight
                        )
                    }
                    if (!hostProfile?.hobbies.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hobbies: ${hostProfile?.hobbies}",
                            fontSize = 12.sp,
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showEditProfileDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, SocialColors.Purple),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("edit_social_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = SocialColors.Purple)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit Profile", fontWeight = FontWeight.Bold, color = SocialColors.Purple, fontSize = 13.sp)
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(SocialGradients.Hero)
                                .clickable { showEarningsDialog = true }
                                .testTag("social_earnings_button")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Social Earnings", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tabs: Posts vs Stories
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = SocialColors.Purple,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Posts (${hostPosts.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Stories (${hostStories.size})", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (selectedTab == 0) {
                if (hostPosts.isEmpty()) {
                    Text(
                        text = "No posts created yet",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .heightIn(max = 700.dp)
                            .fillMaxWidth()
                            .padding(6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(hostPosts) { post ->
                            val postMedia = post.mediaPath ?: post.mediaUrl

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedPostForDetail = post }
                            ) {
                                SocialMediaImage(
                                    mediaPath = postMedia,
                                    privateMediaRepo = privateMediaRepo,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            } else {
                if (hostStories.isEmpty()) {
                    Text(
                        text = "No active stories (Stories expire after 24h)",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(hostStories) { story ->
                            val media = story.mediaPath ?: story.mediaUrl

                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .size(width = 110.dp, height = 160.dp)
                                    .clickable { onStoryClick(hostStories, hostStories.indexOf(story)) }
                            ) {
                                SocialMediaImage(
                                    mediaPath = media,
                                    privateMediaRepo = privateMediaRepo,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        EditHostSocialProfileDialog(
            currentProfile = hostProfile,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { showEditProfileDialog = false },
            onSave = { bio, hobbies, avatarFile ->
                onUpdateProfile(bio, hobbies, avatarFile) {
                    showEditProfileDialog = false
                }
            }
        )
    }

    // Social Earnings Dialog
    if (showEarningsDialog) {
        HostSocialEarningsDialog(
            earnings = hostEarnings,
            onDismiss = { showEarningsDialog = false }
        )
    }

    // Detail dialog if tapping a post in host profile
    selectedPostForDetail?.let { post ->
        PostDetailDialog(
            post = post,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { selectedPostForDetail = null },
            onLikeClick = { onPostLike(post) },
            onCommentClick = {
                selectedPostForDetail = null
                onPostComment(post)
            },
            onDeleteClick = onPostDelete?.let { deleteFn ->
                {
                    selectedPostForDetail = null
                    deleteFn(post)
                }
            }
        )
    }
}

@Composable
fun ProfileStatItem(label: String, count: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = TextPrimaryLight
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondaryLight
        )
    }
}

// -------------------------------------------------------------------------------------------------
// 5. USER SOCIAL PROFILE FULL SCREEN
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSocialProfileFullScreen(
    user: SocialSearchResult,
    posts: List<SocialPostModel>,
    stories: List<SocialStoryModel>,
    privateMediaRepo: PrivateMediaRepository,
    onBack: () -> Unit,
    onFollowToggle: () -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    onPostLike: (SocialPostModel) -> Unit,
    onPostComment: (SocialPostModel) -> Unit
) {
    BackHandler { onBack() }

    var selectedTab by remember { mutableStateOf(0) }
    var selectedPostForDetail by remember { mutableStateOf<SocialPostModel?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = user.displayName ?: "User Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("user_profile_back_button")
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .testTag("user_social_profile_screen")
        ) {
            // Header Profile Card
            Card(
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val avatarUrl = user.socialAvatarUrl ?: user.avatarUrl
                        val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        Box(
                            modifier = Modifier
                                .size(82.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.StoryRing)
                                .padding(3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolvedAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatar,
                                        contentDescription = user.displayName,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (user.displayName ?: "U").take(1).uppercase(),
                                            fontSize = 32.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ProfileStatItem("Followers", user.followersCount ?: 0)
                            ProfileStatItem("Following", user.followingCount ?: 0)
                            ProfileStatItem("Likes", user.totalLikes ?: 0)
                            ProfileStatItem("Views", user.totalViews ?: 0)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = user.displayName ?: "Baatly User",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = user.handle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = SocialColors.Purple
                    )

                    if (!user.bio.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = user.bio,
                            fontSize = 13.sp,
                            color = TextPrimaryLight
                        )
                    }
                    if (!user.hobbies.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hobbies: ${user.hobbies}",
                            fontSize = 12.sp,
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Follow Toggle Button
                    val isFollowing = user.isFollowing == true
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isFollowing) Color(0xFFF1F5F9) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .then(
                                if (!isFollowing) Modifier.background(SocialGradients.PrimaryCta)
                                else Modifier
                            )
                            .clickable { onFollowToggle() }
                            .testTag("user_profile_follow_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isFollowing) "Following" else "Follow",
                                fontWeight = FontWeight.Bold,
                                color = if (isFollowing) TextPrimaryLight else Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Posts & Stories Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = SocialColors.Purple,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Posts (${posts.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Stories (${stories.size})", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (selectedTab == 0) {
                if (posts.isEmpty()) {
                    Text(
                        text = "No posts from this user",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .heightIn(max = 700.dp)
                            .fillMaxWidth()
                            .padding(6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(posts) { post ->
                            val postMedia = post.mediaPath ?: post.mediaUrl

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedPostForDetail = post }
                            ) {
                                SocialMediaImage(
                                    mediaPath = postMedia,
                                    privateMediaRepo = privateMediaRepo,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            } else {
                if (stories.isEmpty()) {
                    Text(
                        text = "No active stories",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(stories) { story ->
                            val media = story.mediaPath ?: story.mediaUrl

                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .size(width = 110.dp, height = 160.dp)
                                    .clickable { onStoryClick(stories, stories.indexOf(story)) }
                            ) {
                                SocialMediaImage(
                                    mediaPath = media,
                                    privateMediaRepo = privateMediaRepo,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    selectedPostForDetail?.let { post ->
        PostDetailDialog(
            post = post,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { selectedPostForDetail = null },
            onLikeClick = { onPostLike(post) },
            onCommentClick = {
                selectedPostForDetail = null
                onPostComment(post)
            }
        )
    }
}

// -------------------------------------------------------------------------------------------------
// 6. POST DETAIL DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun PostDetailDialog(
    post: SocialPostModel,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onDeleteClick: (() -> Unit)? = null
) {
    val postMedia = post.mediaPath ?: post.mediaUrl
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = com.example.security.AppSecurityManager.secureDialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 24.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = post.authorName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = post.authorHandle,
                            fontSize = 11.sp,
                            color = SocialColors.Purple
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (onDeleteClick != null) {
                            IconButton(
                                onClick = { showDeleteConfirmation = true },
                                modifier = Modifier.testTag("detail_delete_post_button")
                            ) {
                                Icon(
                                    Icons.Outlined.Delete,
                                    contentDescription = "Delete post",
                                    tint = SocialColors.Rose
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

                // Image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if (!postMedia.isNullOrBlank()) {
                        SocialMediaImage(
                            mediaPath = postMedia,
                            privateMediaRepo = privateMediaRepo,
                            contentDescription = post.caption,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val isLiked = post.isLiked == true
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onLikeClick() }
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = if (isLiked) "Unlike" else "Like",
                            tint = if (isLiked) SocialColors.Rose else TextPrimaryLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.likesCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onCommentClick() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "Comment",
                            tint = SocialColors.Purple,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.commentsCount ?: 0}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight
                        )
                    }
                }

                if (!post.caption.isNullOrBlank()) {
                    Text(
                        text = post.caption,
                        fontSize = 13.sp,
                        color = TextPrimaryLight,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = {
                Text(
                    text = "Delete post?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )
            },
            text = {
                Text(
                    text = "This post will be permanently deleted. Coins already spent by users will not be refunded.",
                    fontSize = 14.sp,
                    color = TextSecondaryLight,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmation = false
                        onDeleteClick?.invoke()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SocialColors.Rose,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_delete_post_button")
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirmation = false },
                    modifier = Modifier.testTag("cancel_delete_post_button")
                ) {
                    Text("Cancel", color = TextSecondaryLight, fontWeight = FontWeight.Medium)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(20.dp)
        )
    }
}

// -------------------------------------------------------------------------------------------------
// 7. EDIT HOST SOCIAL PROFILE DIALOG
// -------------------------------------------------------------------------------------------------

@Composable
fun EditHostSocialProfileDialog(
    currentProfile: SocialProfileModel?,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onSave: (bio: String?, hobbies: String?, avatarFile: File?) -> Unit
) {
    val context = LocalContext.current
    var editBio by remember { mutableStateOf(currentProfile?.bio ?: "") }
    var editHobbies by remember { mutableStateOf(currentProfile?.hobbies ?: "") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = com.example.security.AppSecurityManager.secureDialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Edit Social Profile",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryLight
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Identity from Baatly Signup (${currentProfile?.profile?.displayName ?: "Host"})",
                    fontSize = 12.sp,
                    color = TextSecondaryLight
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    contentAlignment = Alignment.BottomEnd,
                    modifier = Modifier.clickable { photoPicker.launch("image/*") }
                ) {
                    if (selectedImageUri != null) {
                        Image(
                            painter = rememberAsyncImagePainter(model = selectedImageUri),
                            contentDescription = "New Avatar",
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .border(2.5.dp, SocialColors.Purple, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        val avatarUrl = currentProfile?.socialAvatarUrl ?: currentProfile?.profile?.avatarUrl
                        val resolved = rememberPrivateStorageUrl(rawUrl = avatarUrl, privateMediaRepo = privateMediaRepo).value

                        if (!resolved.isNullOrBlank()) {
                            AsyncImage(
                                model = resolved,
                                contentDescription = "Current Avatar",
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .border(2.5.dp, SocialColors.Purple, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .background(SocialColors.PurpleLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = SocialColors.Purple, modifier = Modifier.size(40.dp))
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(SocialGradients.Hero),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Change photo", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                TextButton(onClick = { photoPicker.launch("image/*") }) {
                    Text("Change Social Avatar", color = SocialColors.Purple, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = editBio,
                    onValueChange = { editBio = it },
                    label = { Text("Bio") },
                    placeholder = { Text("Share something about yourself...") },
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SocialColors.Purple,
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_social_bio_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = editHobbies,
                    onValueChange = { editHobbies = it },
                    label = { Text("Hobbies") },
                    placeholder = { Text("e.g. Music, Traveling, Fitness") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SocialColors.Purple,
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_social_hobbies_input")
                )

                Spacer(modifier = Modifier.height(22.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .then(
                                if (!isSaving) Modifier.background(SocialGradients.PrimaryCta)
                                else Modifier.background(Color(0xFFE2E8F0))
                            )
                            .clickable(enabled = !isSaving) {
                                isSaving = true
                                val avatarFile = selectedImageUri?.let { uri ->
                                    try {
                                        val inputStream = context.contentResolver.openInputStream(uri)
                                        val tempFile = File(context.cacheDir, "social_avatar_${System.currentTimeMillis()}.jpg")
                                        val outputStream = FileOutputStream(tempFile)
                                        inputStream?.copyTo(outputStream)
                                        inputStream?.close()
                                        outputStream.close()
                                        tempFile
                                    } catch (_: Exception) { null }
                                }
                                onSave(editBio.trim(), editHobbies.trim(), avatarFile)
                            }
                            .testTag("save_social_profile_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isSaving) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                            } else {
                                Text("Save", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 8. HOST SOCIAL EARNINGS DIALOG (Host-Only Confidential)
// -------------------------------------------------------------------------------------------------

@Composable
fun HostSocialEarningsDialog(
    earnings: SocialEarningsModel?,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = com.example.security.AppSecurityManager.secureDialogProperties()
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("host_social_earnings_dialog")
        ) {
            Column(modifier = Modifier.padding(22.dp)) {
                // Header with Host Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Social Earnings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "Partner Confidential",
                            fontSize = 11.sp,
                            color = SocialColors.Purple,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Total Earnings Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(SocialGradients.Hero)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Total Social Revenue",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${String.format("%.2f", earnings?.total ?: earnings?.totalSocialEarnings ?: 0.0)}",
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Earnings Breakdown",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimaryLight
                )

                Spacer(modifier = Modifier.height(10.dp))

                EarningsRowItem(
                    title = "View Earnings",
                    amount = earnings?.viewEarnings ?: 0.0,
                    icon = Icons.Outlined.Visibility
                )
                HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

                EarningsRowItem(
                    title = "Like Earnings",
                    amount = earnings?.likeEarnings ?: 0.0,
                    icon = Icons.Outlined.FavoriteBorder
                )
                HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

                EarningsRowItem(
                    title = "Comment Earnings",
                    amount = earnings?.commentEarnings ?: 0.0,
                    icon = Icons.Outlined.ChatBubbleOutline
                )

                if ((earnings?.unlockEarnings ?: 0.0) > 0.0) {
                    HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                    EarningsRowItem(
                        title = "Post Unlock Earnings",
                        amount = earnings?.unlockEarnings ?: 0.0,
                        icon = Icons.Outlined.LockOpen
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SocialGradients.PrimaryCta)
                        .clickable { onDismiss() }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("Done", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun EarningsRowItem(title: String, amount: Double, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = SocialColors.Purple, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = title, fontSize = 13.sp, color = TextPrimaryLight)
        }
        Text(
            text = "₹${String.format("%.2f", amount)}",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF10B981)
        )
    }
}
