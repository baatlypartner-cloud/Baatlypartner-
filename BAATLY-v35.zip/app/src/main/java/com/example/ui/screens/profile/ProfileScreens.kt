package com.example.ui.screens.profile

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.models.BlockModel
import com.example.data.repository.PartnerRepository
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

data class ProfileMenuItem(
    val title: String,
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconColor: Color,
    val testTag: String? = null,
    val onClick: () -> Unit
)

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondaryLight
                )
            }
        }
    }
}

@Composable
fun ProfileMenuRow(
    item: ProfileMenuItem
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (item.testTag != null) Modifier.testTag(item.testTag) else Modifier)
            .clickable { item.onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(item.iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    item.icon,
                    contentDescription = null,
                    tint = item.iconColor,
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = item.title,
                color = TextPrimaryLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Icon(
            Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextSecondaryLight,
            modifier = Modifier.size(18.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    mainViewModel: MainViewModel,
    authViewModel: AuthViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val uiData by mainViewModel.uiData.collectAsState()
    val partner = uiData.partnerProfile
    val profile = uiData.profile
    val app = LocalContext.current.applicationContext as BaatlyApp
    val privateMediaRepo = app.privateMediaRepository
    val partnerRepo = app.partnerRepository
    val resolvedAvatarUrl by rememberProfileAvatarUrl(profile?.avatarUrl, privateMediaRepo)

    var publicRating by remember { mutableStateOf<com.example.data.models.UserRatingModel?>(null) }
    val targetRatingUserId = partner?.userId ?: profile?.id

    LaunchedEffect(targetRatingUserId) {
        if (!targetRatingUserId.isNullOrBlank()) {
            val res = partnerRepo.getPublicUserRating(targetRatingUserId)
            publicRating = res.getOrNull()
        }
    }

    var showEditProfileSheet by remember { mutableStateOf(false) }
    var editDisplayName by remember(partner, profile) {
        mutableStateOf(partner?.partnerDisplayName ?: profile?.displayName ?: "")
    }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isSavingProfile by remember { mutableStateOf(false) }
    var editErrorMessage by remember { mutableStateOf<String?>(null) }

    val isDeletingAccount by authViewModel.isDeletingAccount.collectAsState()
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deleteAccountErrorMessage by remember { mutableStateOf<String?>(null) }
    var deleteAccountSuccessMessage by remember { mutableStateOf<String?>(null) }
    var hasSubmittedDeletionRequest by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    val ruleItems = listOf(
        ProfileMenuItem("Frame Niyam (Platform Rules)", Icons.Default.MenuBook, BaatlyPrimaryLight, BaatlyPrimary) { onNavigate("frame_niyam") },
        ProfileMenuItem("Strike Niyam (Safety & Ban Policy)", Icons.Default.Gavel, BaatlyRedLight, BaatlyRed) { onNavigate("strike_niyam") },
        ProfileMenuItem("Host Training Guide", Icons.Default.PlayCircle, BaatlyGoldLight, BaatlyGold) { onNavigate("training") }
    )

    val supportItems = listOf(
        ProfileMenuItem("Baatly Support Agent (Neha AI)", Icons.Default.SmartToy, BaatlyPrimaryLight, BaatlyPrimary, "neha_support_profile_item") {
            onNavigate("neha_support_chat")
        },
        ProfileMenuItem("WhatsApp Support Manager", Icons.Default.HeadsetMic, BaatlyGreenLight, BaatlyGreen) {
            val url = "https://wa.me/8744048708?text=Hello%20Baatly%20Support,%20I%20am%20a%20Host"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        }
    )

    val policyItems = listOf(
        ProfileMenuItem("Blocked Users", Icons.Default.Block, BaatlyRoseOrRedLight(), BaatlyRed) { onNavigate("blocked_users") },
        ProfileMenuItem("Privacy Policy", Icons.Default.Security, BaatlyBlueLight, BaatlyBlue, "privacy_policy_menu_item") {
            onNavigate("privacy_policy")
        },
        ProfileMenuItem("Child Safety Standards", Icons.Default.Shield, BaatlyCyanLight, BaatlyCyan, "child_safety_menu_item") {
            onNavigate("child_safety")
        }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Host Profile", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                actions = {
                    IconButton(
                        onClick = { showEditProfileSheet = true },
                        modifier = Modifier.testTag("edit_profile_top_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = BaatlyPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // =========================================================================
            // 1. EXECUTIVE HOST HERO CARD
            // =========================================================================
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(
                        listOf(BaatlyGold.copy(alpha = 0.5f), BaatlyPrimary.copy(alpha = 0.3f))
                    )
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(CircleShape)
                                .border(3.dp, BaatlyGold.copy(alpha = 0.7f), CircleShape)
                                .padding(3.dp)
                        ) {
                            if (!resolvedAvatarUrl.isNullOrBlank()) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                    contentDescription = "Avatar",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(BaatlyPrimaryLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (partner?.partnerDisplayName ?: profile?.displayName ?: "H").take(1).uppercase(),
                                        color = BaatlyPrimary,
                                        fontSize = 34.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimary)
                                .clickable { showEditProfileSheet = true }
                                .padding(5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Change Photo", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Verified Badge Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(BaatlyGoldLight)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Icon(
                            Icons.Default.Verified,
                            contentDescription = "Verified Host",
                            tint = BaatlyGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "VERIFIED PARTNER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309),
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = partner?.partnerDisplayName ?: profile?.displayName ?: "Audio Jockey",
                        color = TextPrimaryLight,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "@${profile?.username ?: profile?.id?.take(8) ?: "host"}",
                        color = TextSecondaryLight,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showEditProfileSheet = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp), tint = BaatlyPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Profile", fontSize = 13.sp, color = BaatlyPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Divider(color = BaatlyLightBorder)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Host Key Stats Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${partner?.totalCalls ?: 0}", color = TextPrimaryLight, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Total Calls", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${String.format("%.0f", partner?.totalCallMinutes ?: 0.0)}m", color = TextPrimaryLight, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Call Minutes", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val displayRating = publicRating?.averageRating ?: partner?.rating ?: 5.0
                            val count = publicRating?.ratingCount ?: 0
                            Text("★ ${String.format("%.1f", displayRating)}", color = BaatlyGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(if (count > 0) "$count Ratings" else "Rating", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // =========================================================================
            // 2. QUICK ACTION SHORTCUTS
            // =========================================================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    title = "My Wallet",
                    subtitle = "Payouts & Kamai",
                    icon = Icons.Default.AccountBalanceWallet,
                    iconBg = BaatlyPrimaryLight,
                    iconTint = BaatlyPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("wallet") }
                )
                QuickActionCard(
                    title = "Neha Support",
                    subtitle = "24/7 AI Assistant",
                    icon = Icons.Default.SmartToy,
                    iconBg = BaatlyGreenLight,
                    iconTint = BaatlyGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate("neha_support_chat") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // =========================================================================
            // 3. HOST RULES & PLATFORM GUIDELINES
            // =========================================================================
            Text(
                text = "RULES & COMPLIANCE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryLight,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    ruleItems.forEachIndexed { idx, item ->
                        ProfileMenuRow(item = item)
                        if (idx < ruleItems.size - 1) {
                            Divider(color = BaatlyLightBorder, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // =========================================================================
            // 4. SUPPORT & ASSISTANCE SECTION
            // =========================================================================
            Text(
                text = "SUPPORT & HELP",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryLight,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    supportItems.forEachIndexed { idx, item ->
                        ProfileMenuRow(item = item)
                        if (idx < supportItems.size - 1) {
                            Divider(color = BaatlyLightBorder, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // =========================================================================
            // 5. SAFETY & LEGAL POLICIES
            // =========================================================================
            Text(
                text = "SAFETY & POLICIES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryLight,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    policyItems.forEachIndexed { idx, item ->
                        ProfileMenuRow(item = item)
                        if (idx < policyItems.size - 1) {
                            Divider(color = BaatlyLightBorder, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // =========================================================================
            // 6. DANGER ZONE / ACCOUNT ACTIONS
            // =========================================================================
            Button(
                onClick = { authViewModel.logout() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("profile_logout_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BaatlyRedLight)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = BaatlyRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out as Host", color = BaatlyRed, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = {
                    if (hasSubmittedDeletionRequest) {
                        deleteAccountSuccessMessage = "Your account deletion request has been submitted successfully and is pending review."
                    } else {
                        deleteAccountErrorMessage = null
                        showDeleteAccountDialog = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("profile_delete_account_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFFFFF1F2),
                    contentColor = BaatlyRed
                ),
                border = BorderStroke(1.dp, Color(0xFFFECDD3))
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = BaatlyRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (hasSubmittedDeletionRequest) "Deletion Request Submitted" else "Delete Account",
                    color = BaatlyRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(36.dp))
        }

        // Edit Profile Bottom Sheet
        if (showEditProfileSheet) {
            ModalBottomSheet(
                onDismissRequest = {
                    showEditProfileSheet = false
                    selectedImageUri = null
                    editErrorMessage = null
                },
                containerColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Edit Host Profile", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimaryLight)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Avatar Preview & Change button
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier.clickable { photoPickerLauncher.launch("image/*") }
                    ) {
                        if (selectedImageUri != null) {
                            Image(
                                painter = rememberAsyncImagePainter(model = selectedImageUri),
                                contentDescription = "Selected Avatar",
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else if (!resolvedAvatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                contentDescription = "Current Avatar",
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (editDisplayName.ifBlank { "H" }).take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimary)
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit photo", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    TextButton(onClick = { photoPickerLauncher.launch("image/*") }) {
                        Text("Change Profile Photo", color = BaatlyPrimary, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = editDisplayName,
                        onValueChange = { editDisplayName = it },
                        label = { Text("Display Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_display_name_input")
                    )

                    if (editErrorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(editErrorMessage ?: "", color = BaatlyRed, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (editDisplayName.trim().isBlank()) {
                                editErrorMessage = "Display name cannot be empty"
                                return@Button
                            }
                            isSavingProfile = true
                            editErrorMessage = null

                            val avatarFile = selectedImageUri?.let { uri ->
                                try {
                                    val inputStream = context.contentResolver.openInputStream(uri)
                                    val tempFile = java.io.File(context.cacheDir, "avatar_${System.currentTimeMillis()}.jpg")
                                    val outputStream = java.io.FileOutputStream(tempFile)
                                    inputStream?.copyTo(outputStream)
                                    inputStream?.close()
                                    outputStream.close()
                                    tempFile
                                } catch (_: Exception) {
                                    null
                                }
                            }

                            mainViewModel.updateProfile(
                                displayName = editDisplayName.trim(),
                                avatarFile = avatarFile
                            ) { success, err ->
                                isSavingProfile = false
                                if (success) {
                                    showEditProfileSheet = false
                                    selectedImageUri = null
                                } else {
                                    editErrorMessage = err ?: "Failed to save profile"
                                }
                            }
                        },
                        enabled = !isSavingProfile,
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_profile_button")
                    ) {
                        if (isSavingProfile) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // Delete Account Confirmation Dialog
        if (showDeleteAccountDialog) {
            AlertDialog(
                onDismissRequest = {
                    if (!isDeletingAccount) {
                        showDeleteAccountDialog = false
                        deleteAccountErrorMessage = null
                    }
                },
                title = {
                    Text(
                        text = "Delete Account",
                        fontWeight = FontWeight.Bold,
                        color = BaatlyRed,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "Your account deletion request will be submitted. This action cannot be undone.",
                            color = TextPrimaryLight,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                        if (!deleteAccountErrorMessage.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                color = Color(0xFFFEF2F2),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Info,
                                        contentDescription = null,
                                        tint = BaatlyRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = deleteAccountErrorMessage ?: "",
                                        color = Color(0xFF991B1B),
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (!isDeletingAccount && !hasSubmittedDeletionRequest) {
                                deleteAccountErrorMessage = null
                                authViewModel.requestAccountDeletion { success, message ->
                                    if (success) {
                                        hasSubmittedDeletionRequest = true
                                        showDeleteAccountDialog = false
                                        deleteAccountSuccessMessage = message
                                    } else {
                                        if (message.contains("already", ignoreCase = true) || message.contains("pending", ignoreCase = true)) {
                                            hasSubmittedDeletionRequest = true
                                            showDeleteAccountDialog = false
                                            deleteAccountSuccessMessage = message
                                        } else {
                                            deleteAccountErrorMessage = message
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !isDeletingAccount,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BaatlyRed,
                            disabledContainerColor = BaatlyRed.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("confirm_delete_account_button")
                    ) {
                        if (isDeletingAccount) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Submitting...", color = Color.White, fontSize = 13.sp)
                        } else {
                            Text(
                                text = "Delete Account",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showDeleteAccountDialog = false
                            deleteAccountErrorMessage = null
                        },
                        enabled = !isDeletingAccount,
                        modifier = Modifier.testTag("cancel_delete_account_button")
                    ) {
                        Text(
                            text = "Cancel",
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Medium
                        )
                    }
                },
                containerColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            )
        }

        // Delete Account Success Dialog
        if (!deleteAccountSuccessMessage.isNullOrBlank()) {
            AlertDialog(
                onDismissRequest = { deleteAccountSuccessMessage = null },
                icon = {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                },
                title = {
                    Text(
                        text = "Request Submitted",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight,
                        fontSize = 17.sp
                    )
                },
                text = {
                    Text(
                        text = deleteAccountSuccessMessage ?: "Your account deletion request has been submitted successfully.",
                        color = TextSecondaryLight,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { deleteAccountSuccessMessage = null },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("dismiss_deletion_success_button")
                    ) {
                        Text("OK", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

private fun BaatlyRoseOrRedLight(): Color = BaatlyRedLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockedUsersScreen(
    partnerRepository: PartnerRepository,
    onBack: UnitCallback
) {
    val coroutineScope = rememberCoroutineScope()
    var blockedList by remember { mutableStateOf<List<BlockModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    fun loadBlocks() {
        coroutineScope.launch {
            isLoading = true
            val res = partnerRepository.getBlockedUsers()
            if (res.isSuccess) {
                blockedList = res.getOrNull() ?: emptyList()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadBlocks()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Blocked Users", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("blocked_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (blockedList.isEmpty() && !isLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaatlyGreen, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Koi User Block Nahi Hai", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    items(blockedList) { block ->
                        val userName = block.blockedProfile?.displayName ?: block.blockedProfile?.username ?: "User #${block.blockedUserId.take(6)}"

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(userName, color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(block.reason ?: "Blocked by host", color = TextSecondaryLight, fontSize = 11.sp)
                                }
                                TextButton(
                                    onClick = {
                                        val targetUserId = block.blockedUserId
                                        blockedList = blockedList.filter { it.blockedUserId != targetUserId }
                                        coroutineScope.launch {
                                            partnerRepository.unblockUser(targetUserId)
                                            loadBlocks()
                                        }
                                    },
                                    modifier = Modifier.testTag("unblock_button_${block.blockedUserId}")
                                ) {
                                    Text("Unblock", color = BaatlyPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                CircularProgressIndicator(
                    color = BaatlyPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

typealias UnitCallback = () -> Unit
