package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.SessionManager
import com.example.data.models.PartnerAiMessageModel
import com.example.data.repository.PartnerAiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class PartnerAiMessageItem(
    val id: String,
    val senderType: String, // "partner" or "assistant"
    val content: String,
    val createdAt: String? = null,
    val isSending: Boolean = false,
    val error: String? = null,
    val intent: String? = null,
    val escalationLevel: String? = null
)

data class PartnerAiUiState(
    val conversationId: String? = null,
    val messages: List<PartnerAiMessageItem> = emptyList(),
    val isTyping: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)

class PartnerAiViewModel(
    private val partnerAiRepository: PartnerAiRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val TAG = "PartnerAiViewModel"

    private val _uiState = MutableStateFlow(PartnerAiUiState())
    val uiState: StateFlow<PartnerAiUiState> = _uiState.asStateFlow()

    init {
        loadConversationAndMessages()
    }

    /**
     * B. Exact time to load conversation history:
     * 1. Set the loading state.
     * 2. Fetch the current partner's active conversation (status='active').
     * 3. Distinguish:
     *    - Successful query with an active conversation -> load and render messages in chronological order.
     *    - Successful query with NO active conversation -> show empty welcome state (do not insert DB record).
     *    - FAILED query due to network/auth/backend -> keep previous data, show recoverable error and Retry button.
     */
    fun loadConversationAndMessages() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val convRes = partnerAiRepository.getActiveConversation()
                if (convRes.isSuccess) {
                    val conv = convRes.getOrNull()
                    val convId = conv?.id

                    if (!convId.isNullOrBlank()) {
                        val msgsRes = partnerAiRepository.getMessages(convId)
                        if (msgsRes.isSuccess) {
                            val remoteMsgs = msgsRes.getOrNull() ?: emptyList()
                            _uiState.value = _uiState.value.copy(
                                conversationId = convId,
                                messages = remoteMsgs.map { it.toItem() },
                                isLoading = false,
                                error = null
                            )
                        } else {
                            val err = msgsRes.exceptionOrNull()?.message ?: "Failed to load conversation history"
                            Log.w(TAG, "Failed to load messages for conversation $convId: $err")
                            _uiState.value = _uiState.value.copy(
                                conversationId = convId,
                                isLoading = false,
                                error = err
                            )
                        }
                    } else {
                        // Successful query returned genuinely NO active conversation. UI shows empty state.
                        _uiState.value = _uiState.value.copy(
                            conversationId = null,
                            messages = emptyList(),
                            isLoading = false,
                            error = null
                        )
                    }
                } else {
                    // Query genuinely failed due to network, auth or backend error
                    val err = convRes.exceptionOrNull()?.message ?: "Failed to load assistant conversation"
                    Log.w(TAG, "getActiveConversation failed: $err")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = err
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading active conversation", e)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load assistant conversation"
                )
            }
        }
    }

    /**
     * C. Send a message to partner-ai-chat-v2 Edge Function:
     * - Optimistically display the partner's message.
     * - Prevent multiple simultaneous sends.
     * - D. On success: validate conversation_id, reload persisted messages from Supabase,
     *   replacing the temporary message with real database records.
     * - E. On failure: show one failed item with retry option, without false AI replies.
     */
    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _uiState.value.isTyping) return

        val clientMsgId = UUID.randomUUID().toString()
        val nowIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date())

        val partnerItem = PartnerAiMessageItem(
            id = clientMsgId,
            senderType = "partner",
            content = trimmed,
            createdAt = nowIso,
            isSending = true,
            error = null
        )

        val currentMsgs = _uiState.value.messages.toMutableList()
        currentMsgs.add(partnerItem)
        _uiState.value = _uiState.value.copy(
            messages = currentMsgs,
            isTyping = true,
            error = null
        )

        executeSend(messageText = trimmed, clientMessageId = clientMsgId)
    }

    /**
     * E. Message Failure and Retry:
     * Re-sends a failed message reusing the exact same client UUID without creating duplicate bubbles.
     */
    fun retryMessage(item: PartnerAiMessageItem) {
        if (_uiState.value.isTyping) return

        // Update the existing failed message in place
        val updatedMsgs = _uiState.value.messages.map {
            if (it.id == item.id) it.copy(isSending = true, error = null) else it
        }
        _uiState.value = _uiState.value.copy(
            messages = updatedMsgs,
            isTyping = true,
            error = null
        )

        executeSend(messageText = item.content, clientMessageId = item.id)
    }

    private fun executeSend(messageText: String, clientMessageId: String) {
        viewModelScope.launch {
            try {
                val convId = _uiState.value.conversationId
                val res = partnerAiRepository.sendMessage(
                    message = messageText,
                    conversationId = convId,
                    idempotencyKey = clientMessageId
                )

                if (res.isSuccess) {
                    val response = res.getOrNull()
                    val newConvId = response?.conversationId

                    if (newConvId.isNullOrBlank()) {
                        // Response malformed / missing conversation_id
                        Log.e(TAG, "Edge function response missing valid conversationId")
                        val err = "Invalid response from support server"
                        val updatedMsgs = _uiState.value.messages.map {
                            if (it.id == clientMessageId) it.copy(isSending = false, error = err) else it
                        }
                        _uiState.value = _uiState.value.copy(
                            messages = updatedMsgs,
                            isTyping = false,
                            error = err
                        )
                        return@launch
                    }

                    // D. Exact Action After Successful V2 Response:
                    // 1. Store conversation_id
                    // 2. Reload actual persisted conversation messages from Supabase
                    // 3. Replace optimistic temporary messages with real database records
                    val msgsRes = partnerAiRepository.getMessages(newConvId)
                    if (msgsRes.isSuccess && !msgsRes.getOrNull().isNullOrEmpty()) {
                        val remoteMsgs = msgsRes.getOrNull() ?: emptyList()
                        _uiState.value = _uiState.value.copy(
                            conversationId = newConvId,
                            messages = remoteMsgs.map { it.toItem() },
                            isTyping = false,
                            error = null
                        )
                    } else {
                        // Persisted reload completed; if remote fetch is temporarily delayed,
                        // mark sending false and append the real reply from response payload
                        val updatedMsgs = _uiState.value.messages.map {
                            if (it.id == clientMessageId) it.copy(isSending = false, error = null) else it
                        }.toMutableList()

                        val replyText = response.reply
                        if (!replyText.isNullOrBlank()) {
                            updatedMsgs.add(
                                PartnerAiMessageItem(
                                    id = "msg_${System.currentTimeMillis()}",
                                    senderType = "assistant",
                                    content = replyText,
                                    createdAt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                                        timeZone = TimeZone.getTimeZone("UTC")
                                    }.format(Date()),
                                    intent = response.intent,
                                    escalationLevel = response.escalationLevel
                                )
                            )
                        }

                        _uiState.value = _uiState.value.copy(
                            conversationId = newConvId,
                            messages = updatedMsgs,
                            isTyping = false,
                            error = null
                        )
                    }
                } else {
                    val ex = res.exceptionOrNull()
                    val err = parseErrorMessage(ex)
                    Log.w(TAG, "sendMessage failed: $err", ex)

                    val updatedMsgs = _uiState.value.messages.map {
                        if (it.id == clientMessageId) it.copy(isSending = false, error = err) else it
                    }
                    _uiState.value = _uiState.value.copy(
                        messages = updatedMsgs,
                        isTyping = false,
                        error = err
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "executeSend exception", e)
                val err = parseErrorMessage(e)
                val updatedMsgs = _uiState.value.messages.map {
                    if (it.id == clientMessageId) it.copy(isSending = false, error = err) else it
                }
                _uiState.value = _uiState.value.copy(
                    messages = updatedMsgs,
                    isTyping = false,
                    error = err
                )
            }
        }
    }

    private fun parseErrorMessage(t: Throwable?): String {
        if (t == null) return "Failed to reach Neha Support"
        val msg = t.message.orEmpty()
        return when {
            t is java.net.UnknownHostException || t is java.io.IOException -> "Network error. Please check your connection and tap retry."
            msg.contains("401", ignoreCase = true) || msg.contains("Not logged in", ignoreCase = true) -> "Session expired. Please sign in again."
            msg.contains("429", ignoreCase = true) -> "Too many requests. Please wait a moment before retrying."
            msg.contains("50", ignoreCase = true) -> "Support service temporarily unavailable. Tap to retry."
            msg.isNotBlank() -> msg
            else -> "Failed to send message. Tap to retry."
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    private fun PartnerAiMessageModel.toItem() = PartnerAiMessageItem(
        id = id,
        senderType = senderType,
        content = content,
        createdAt = createdAt,
        intent = intent,
        escalationLevel = escalationLevel
    )
}

class PartnerAiViewModelFactory(
    private val partnerAiRepository: PartnerAiRepository,
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PartnerAiViewModel::class.java)) {
            return PartnerAiViewModel(partnerAiRepository, sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
