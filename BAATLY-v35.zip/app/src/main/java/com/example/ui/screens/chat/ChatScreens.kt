package com.example.ui.screens.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.example.data.models.isUuid
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.example.data.models.ConversationModel
import com.example.data.models.GiftTransactionModel
import com.example.data.models.MessageModel
import com.example.data.repository.rememberPrivateStorageUrl
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.components.ReportUserDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ChatViewModel
import java.io.File
import java.io.FileOutputStream

fun formatChatTime(rawIso: String?): String {
    if (rawIso.isNullOrBlank()) return ""
    return try {
        val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val cleanIso = if (rawIso.contains(".")) rawIso.substringBefore(".") else rawIso.replace("Z", "")
        val date = isoFormat.parse(cleanIso) ?: return ""

        val now = java.util.Calendar.getInstance()
        val msgCal = java.util.Calendar.getInstance().apply { time = date }

        if (now.get(java.util.Calendar.YEAR) == msgCal.get(java.util.Calendar.YEAR) &&
            now.get(java.util.Calendar.DAY_OF_YEAR) == msgCal.get(java.util.Calendar.DAY_OF_YEAR)) {
            val timeFormat = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
            timeFormat.format(date)
        } else if (now.get(java.util.Calendar.YEAR) == msgCal.get(java.util.Calendar.YEAR) &&
            now.get(java.util.Calendar.DAY_OF_YEAR) - msgCal.get(java.util.Calendar.DAY_OF_YEAR) == 1) {
            "Yesterday"
        } else {
            val dateFormat = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
            dateFormat.format(date)
        }
    } catch (_: Exception) {
        ""
    }
}

enum class ChatListFilter(val title: String) {
    ALL("All"),
    UNREAD("Unread"),
    UNREPLIED("Unreplied"),
    FAVOURITES("Favourites")
}

@Composable
fun ChatFilterChip(
    title: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    highlightCount: Boolean = false,
    testTag: String? = null
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) BaatlyPrimary else Color.White,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) BaatlyPrimary else BaatlyLightBorder
        ),
        modifier = Modifier
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimaryLight
            )
            if (count > 0) {
                Spacer(modifier = Modifier.width(5.dp))
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(
                            if (isSelected) Color.White.copy(alpha = 0.25f)
                            else if (highlightCount) BaatlyPrimary
                            else BaatlyLightBackground
                        )
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = if (count > 99) "99+" else "$count",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else if (highlightCount) Color.White else TextSecondaryLight
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatListScreen(
    chatViewModel: ChatViewModel,
    onOpenConversation: (String, String, String?) -> Unit,
    onOpenSupportChat: () -> Unit = {}
) {
    val conversations by chatViewModel.conversations.collectAsState()
    val receivedGifts by chatViewModel.receivedGifts.collectAsState()
    val favouriteIds by chatViewModel.favouriteConversationIds.collectAsState()
    val supportPreview by chatViewModel.latestSupportMessagePreview.collectAsState()
    val supportTime by chatViewModel.latestSupportMessageTime.collectAsState()
    val isLoading by chatViewModel.isLoading.collectAsState()

    var selectedFilter by remember { mutableStateOf(ChatListFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var showGiftsSheet by remember { mutableStateOf(false) }
    var longPressMenuTarget by remember { mutableStateOf<Triple<ConversationModel, String, String?>?>(null) } // (conv, userName, userAvatar)
    var showReportDialogForUser by remember { mutableStateOf<Pair<String, String>?>(null) } // (userId, userName)

    // Precalculate filter counts
    val currentAuthUuid = chatViewModel.currentAuthUuid
    val unreadCountTotal = remember(conversations, currentAuthUuid) {
        conversations.count { conv ->
            val unread = conv.unreadCount ?: 0
            val latest = conv.lastMessage
            unread > 0 || (latest != null && latest.senderId != currentAuthUuid && latest.seenAt.isNullOrBlank())
        }
    }
    val unrepliedCountTotal = remember(conversations, currentAuthUuid) {
        conversations.count { conv ->
            val latest = conv.lastMessage
            latest != null && latest.senderId != currentAuthUuid
        }
    }
    val favouritesCountTotal = remember(conversations, favouriteIds) {
        conversations.count { conv -> favouriteIds.contains(conv.id) }
    }

    // Filter conversations list
    val filteredConversations = remember(conversations, selectedFilter, searchQuery, favouriteIds, currentAuthUuid) {
        conversations.filter { conv ->
            // Search filter
            val name = conv.userProfile?.displayName ?: conv.userProfile?.username ?: ""
            val matchesSearch = searchQuery.isBlank() || name.contains(searchQuery, ignoreCase = true)
            if (!matchesSearch) return@filter false

            // Tab filter
            when (selectedFilter) {
                ChatListFilter.ALL -> true
                ChatListFilter.UNREAD -> {
                    val unread = conv.unreadCount ?: 0
                    val latest = conv.lastMessage
                    unread > 0 || (latest != null && latest.senderId != currentAuthUuid && latest.seenAt.isNullOrBlank())
                }
                ChatListFilter.UNREPLIED -> {
                    val latest = conv.lastMessage
                    latest != null && latest.senderId != currentAuthUuid
                }
                ChatListFilter.FAVOURITES -> favouriteIds.contains(conv.id)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Host Chats", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(
                            text = "${conversations.size} Conversations",
                            fontSize = 11.sp,
                            color = TextSecondaryLight
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            chatViewModel.loadConversations()
                            chatViewModel.loadFavourites()
                        },
                        modifier = Modifier.testTag("refresh_chats_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search Input Bar
            Surface(
                color = Color.White,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_chats_input"),
                        placeholder = {
                            Text("Search users or chats...", fontSize = 13.sp, color = TextSecondaryLight)
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondaryLight, modifier = Modifier.size(18.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondaryLight, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = BaatlyLightBackground,
                            unfocusedContainerColor = BaatlyLightBackground,
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Filter Chips Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ChatFilterChip(
                            title = "All",
                            count = conversations.size,
                            isSelected = selectedFilter == ChatListFilter.ALL,
                            onClick = { selectedFilter = ChatListFilter.ALL },
                            testTag = "filter_all"
                        )
                        ChatFilterChip(
                            title = "Unread",
                            count = unreadCountTotal,
                            highlightCount = unreadCountTotal > 0,
                            isSelected = selectedFilter == ChatListFilter.UNREAD,
                            onClick = { selectedFilter = ChatListFilter.UNREAD },
                            testTag = "filter_unread"
                        )
                        ChatFilterChip(
                            title = "Unreplied",
                            count = unrepliedCountTotal,
                            isSelected = selectedFilter == ChatListFilter.UNREPLIED,
                            onClick = { selectedFilter = ChatListFilter.UNREPLIED },
                            testTag = "filter_unreplied"
                        )
                        ChatFilterChip(
                            title = "Favourites",
                            count = favouritesCountTotal,
                            isSelected = selectedFilter == ChatListFilter.FAVOURITES,
                            onClick = { selectedFilter = ChatListFilter.FAVOURITES },
                            testTag = "filter_favourites"
                        )
                    }
                }
            }

            // Conversations List Area
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // =========================================================================
                    // 1. PINNED NEHA AI SUPPORT AGENT (ALWAYS FIRST & PRESENT IN ALL FILTERS)
                    // =========================================================================
                    item(key = "pinned_baatly_support_agent") {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.linearGradient(
                                    listOf(BaatlyPrimary.copy(alpha = 0.4f), BaatlyPurple.copy(alpha = 0.3f))
                                )
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onOpenSupportChat() }
                                .testTag("support_agent_conversation_item")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Neha Assistant Avatar with Online badge
                                Box(contentAlignment = Alignment.BottomEnd) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(BaatlyPrimary, BaatlyPurple)
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SmartToy,
                                            contentDescription = "Baatly Support Avatar",
                                            tint = Color.White,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(BaatlyGreen)
                                            .border(2.dp, Color.White, CircleShape)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f, fill = false)
                                        ) {
                                            Text(
                                                text = "Baatly Support Agent",
                                                color = TextPrimaryLight,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.Verified,
                                                contentDescription = "Verified Support",
                                                tint = BaatlyPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Text(
                                            text = supportTime ?: "Online",
                                            color = BaatlyGreen,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(3.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = supportPreview ?: "Namaste! Main Neha hoon, aapki Baatly Support Agent. Kaise madad kar sakti hoon?",
                                            color = TextSecondaryLight,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(BaatlyPrimaryLight)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "OFFICIAL",
                                                color = BaatlyPrimary,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = BaatlyPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Divider between Pinned Support Agent and User Chats
                    item(key = "support_user_divider") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "USER CONVERSATIONS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondaryLight,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Divider(
                                color = BaatlyLightBorder,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // =========================================================================
                    // 2. USER CONVERSATIONS LIST OR FILTERED EMPTY STATE
                    // =========================================================================
                    if (isLoading && conversations.isEmpty()) {
                        item(key = "loading_chats") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = BaatlyPrimary, modifier = Modifier.size(28.dp))
                            }
                        }
                    } else if (filteredConversations.isEmpty()) {
                        item(key = "empty_user_chats") {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        when (selectedFilter) {
                                            ChatListFilter.ALL -> Icons.Default.ChatBubbleOutline
                                            ChatListFilter.UNREAD -> Icons.Default.MarkChatRead
                                            ChatListFilter.UNREPLIED -> Icons.Default.QuestionAnswer
                                            ChatListFilter.FAVOURITES -> Icons.Default.StarOutline
                                        },
                                        contentDescription = null,
                                        tint = TextSecondaryLight,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = when (selectedFilter) {
                                            ChatListFilter.ALL -> if (searchQuery.isNotBlank()) "Koi Chat Match Nahi Hui" else "Koi User Chat Nahi Hai"
                                            ChatListFilter.UNREAD -> "Sabhi Messages Padhe Gaye Hain"
                                            ChatListFilter.UNREPLIED -> "Koi Unreplied Message Nahi Hai"
                                            ChatListFilter.FAVOURITES -> "Koi Favourite Chat Nahi Hai"
                                        },
                                        color = TextPrimaryLight,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = when (selectedFilter) {
                                            ChatListFilter.ALL -> "Jab users aapko message bhejenge, wo yahan dikhenge."
                                            ChatListFilter.UNREAD -> "Aapke paas koi unread messages bache nahi hain."
                                            ChatListFilter.UNREPLIED -> "Aapne sabhi users ke messages ka reply de diya hai."
                                            ChatListFilter.FAVOURITES -> "Kisi bhi chat par star tap karke use favourite banayein."
                                        },
                                        color = TextSecondaryLight,
                                        fontSize = 12.sp,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        items(filteredConversations, key = { it.id }) { conv ->
                            val userName = conv.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                                ?: conv.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                                ?: conv.userProfile?.mobileNumber?.takeIf { it.isNotBlank() && !isUuid(it) }
                                ?: "User"
                            val userAvatar = conv.userProfile?.avatarUrl
                            val resolvedUserAvatar by rememberProfileAvatarUrl(userAvatar, chatViewModel.privateMediaRepository)

                            val latestMsg = conv.lastMessage
                            val previewText = when {
                                latestMsg == null -> "Start conversation"
                                latestMsg.messageType == "image" -> "📷 Photo"
                                latestMsg.messageType == "voice" || latestMsg.messageType == "audio" -> "🎤 Voice note (${latestMsg.mediaDurationSeconds ?: 0}s)"
                                latestMsg.messageType == "gift" -> "🎁 Sent a gift: ${latestMsg.messageText ?: "Gift"}"
                                !latestMsg.messageText.isNullOrBlank() -> latestMsg.messageText!!
                                else -> "Start conversation"
                            }

                            val formattedTime = formatChatTime(latestMsg?.createdAt ?: conv.lastMessageAt ?: conv.updatedAt)
                            val unreadCount = conv.unreadCount ?: 0
                            val hasUnread = unreadCount > 0 || (latestMsg != null && latestMsg.senderId != currentAuthUuid && latestMsg.seenAt.isNullOrBlank())
                            val isFav = favouriteIds.contains(conv.id)

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))
                                ),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .combinedClickable(
                                        onClick = {
                                            onOpenConversation(conv.id, conv.userId, userName)
                                        },
                                        onLongClick = {
                                            longPressMenuTarget = Triple(conv, userName, resolvedUserAvatar)
                                        }
                                    )
                                    .testTag("conversation_item_${conv.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!resolvedUserAvatar.isNullOrBlank()) {
                                        Image(
                                            painter = rememberAsyncImagePainter(model = resolvedUserAvatar),
                                            contentDescription = "User Avatar",
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(BaatlyPrimaryLight),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = userName.take(1).uppercase(),
                                                color = BaatlyPrimary,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = userName,
                                                color = TextPrimaryLight,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (formattedTime.isNotBlank()) {
                                                Text(
                                                    text = formattedTime,
                                                    color = if (hasUnread) BaatlyPrimary else TextSecondaryLight,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (hasUnread) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(3.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (latestMsg != null && latestMsg.senderId == currentAuthUuid) {
                                                    MessageStatusTicks(
                                                        deliveredAt = latestMsg.deliveredAt,
                                                        seenAt = latestMsg.seenAt,
                                                        modifier = Modifier.padding(end = 4.dp)
                                                    )
                                                }
                                                Text(
                                                    text = previewText,
                                                    color = if (hasUnread) TextPrimaryLight else TextSecondaryLight,
                                                    fontSize = 13.sp,
                                                    fontWeight = if (hasUnread) FontWeight.SemiBold else FontWeight.Normal,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }

                                            if (hasUnread) {
                                                Spacer(modifier = Modifier.width(8.dp))
                                                if (unreadCount > 0) {
                                                    Box(
                                                        modifier = Modifier
                                                            .defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
                                                            .clip(CircleShape)
                                                            .background(BaatlyPrimary)
                                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = if (unreadCount > 99) "99+" else "$unreadCount",
                                                            color = Color.White,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                } else {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(10.dp)
                                                            .clip(CircleShape)
                                                            .background(BaatlyPrimary)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    // Favourite Star Button
                                    IconButton(
                                        onClick = { chatViewModel.toggleFavourite(conv.id) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .testTag("fav_btn_${conv.id}")
                                    ) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "Toggle Favourite",
                                            tint = if (isFav) BaatlyGold else BaatlySlate.copy(alpha = 0.5f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (isLoading) {
                    CircularProgressIndicator(
                        color = BaatlyPrimary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }

    if (showGiftsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showGiftsSheet = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BaatlyGoldLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = BaatlyGold)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Received Gifts History",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))

                if (receivedGifts.isEmpty()) {
                    Text(
                        text = "Abhi tak koi gift receive nahi hua.",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(receivedGifts) { giftTx ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BaatlyLightSurfaceVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(giftTx.gift?.name ?: "Digital Gift", color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Text("+₹${String.format("%.2f", giftTx.effectivePartnerEarning)}", color = BaatlyGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Long Press Conversation Context Actions Bottom Sheet
    val activeLongPressTarget = longPressMenuTarget
    if (activeLongPressTarget != null) {
        val (conv, userName, userAvatar) = activeLongPressTarget
        val isFav = favouriteIds.contains(conv.id)
        val targetUserId = conv.userId

        ModalBottomSheet(
            onDismissRequest = { longPressMenuTarget = null },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                // Header with User Avatar & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (!userAvatar.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(model = userAvatar),
                            contentDescription = userName,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = userName.take(1).uppercase(),
                                color = BaatlyPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = if (isFav) "Saved in Favourites" else "Standard Conversation",
                            fontSize = 12.sp,
                            color = if (isFav) BaatlyGold else TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Divider(color = BaatlyLightBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Action 1: Toggle Favourite
                Surface(
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            longPressMenuTarget = null
                            chatViewModel.toggleFavourite(conv.id)
                        }
                        .padding(vertical = 12.dp, horizontal = 8.dp)
                        .testTag("action_toggle_fav_${conv.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isFav) BaatlyGoldLight else BaatlyLightSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = if (isFav) BaatlyGold else TextSecondaryLight,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = if (isFav) "Remove from Favourites" else "Add to Favourites",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = if (isFav) "Star hatao aur regular list me rakho" else "Quick access ke liye star mark karo",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                // Action 2: Open Conversation
                Surface(
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            longPressMenuTarget = null
                            onOpenConversation(conv.id, conv.userId, userName)
                        }
                        .padding(vertical = 12.dp, horizontal = 8.dp)
                        .testTag("action_open_chat_${conv.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimaryLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = null,
                                tint = BaatlyPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Open Chat",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Direct conversation open karein",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                // Action 3: Report / Safety Action
                Surface(
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            longPressMenuTarget = null
                            showReportDialogForUser = Pair(targetUserId, userName)
                        }
                        .padding(vertical = 12.dp, horizontal = 8.dp)
                        .testTag("action_report_user_${conv.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(BaatlyRedLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReportProblem,
                                contentDescription = null,
                                tint = BaatlyRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Report User",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = BaatlyRed
                            )
                            Text(
                                text = "Rules violation ya inappropriate behavior report karein",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    val reportUserTarget = showReportDialogForUser
    if (reportUserTarget != null) {
        ReportUserDialog(
            reportedUserId = reportUserTarget.first,
            userName = reportUserTarget.second,
            onDismiss = { showReportDialogForUser = null },
            onReportSubmitted = { showReportDialogForUser = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChatDetailScreen(
    conversationId: String,
    receiverId: String,
    receiverName: String,
    chatViewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val messages by chatViewModel.activeMessages.collectAsState()
    val isPlaying by chatViewModel.audioPlayerHelper.isPlaying.collectAsState()
    val currentAudioPath by chatViewModel.audioPlayerHelper.currentPlayingPath.collectAsState()
    val isRecordingVoice by chatViewModel.audioRecorderHelper.isRecording.collectAsState()

    val participantProfile by chatViewModel.activeParticipantProfile.collectAsState()
    val displayName = participantProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: receiverName.takeIf { it.isNotBlank() && it != "User" && it != "Baatly User" && !isUuid(it) }
        ?: "User"
    val avatarUrl = participantProfile?.avatarUrl
    val resolvedAvatarUrl by rememberProfileAvatarUrl(avatarUrl, chatViewModel.privateMediaRepository)

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(conversationId, receiverId) {
        chatViewModel.openConversation(conversationId, receiverId)
    }

    DisposableEffect(Unit) {
        onDispose {
            chatViewModel.closeConversation()
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val isImeVisible = WindowInsets.isImeVisible
    LaunchedEffect(isImeVisible) {
        if (isImeVisible && messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val currentAuthUuid = chatViewModel.currentAuthUuid
    LaunchedEffect(listState, messages) {
        snapshotFlow {
            val visibleInfo = listState.layoutInfo.visibleItemsInfo
            if (visibleInfo.isEmpty()) return@snapshotFlow emptyList<String>()
            val firstIndex = visibleInfo.first().index
            val lastIndex = visibleInfo.last().index
            val visibleIds = mutableListOf<String>()
            for (i in firstIndex..lastIndex) {
                if (i in messages.indices) {
                    val msg = messages[i]
                    if (msg.receiverId == currentAuthUuid && msg.seenAt.isNullOrBlank()) {
                        visibleIds.add(msg.id)
                    }
                }
            }
            visibleIds
        }.collect { visibleIncomingIds ->
            if (visibleIncomingIds.isNotEmpty()) {
                chatViewModel.markVisibleMessagesSeen(conversationId, visibleIncomingIds)
            }
        }
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.cacheDir, "chat_${System.currentTimeMillis()}.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                chatViewModel.sendImageMessage(conversationId, receiverId, file)
            } catch (_: Exception) {}
        }
    }

    var showMicRationaleDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            chatViewModel.audioRecorderHelper.startRecording("chat_voice")
        } else {
            showMicRationaleDialog = true
        }
    }

    var showMenu by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showBlockConfirm by remember { mutableStateOf(false) }
    var showUnblockConfirm by remember { mutableStateOf(false) }
    var showGiftsSheet by remember { mutableStateOf(false) }
    var showReportUserDialog by remember { mutableStateOf(false) }
    var fullScreenImageUrl by remember { mutableStateOf<String?>(null) }
    val gifts by chatViewModel.gifts.collectAsState()

    val conversations by chatViewModel.conversations.collectAsState()
    val currentConv = conversations.find { it.id == conversationId || it.userId == receiverId }
    val isPartnerBlocked = currentConv?.partnerBlocked == true
    val isUserBlocked = currentConv?.userBlocked == true

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                contentDescription = "User Avatar",
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = displayName.take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = when {
                                    isPartnerBlocked -> "Blocked by you"
                                    isUserBlocked -> "Blocked"
                                    else -> "Active Chat Session"
                                },
                                fontSize = 11.sp,
                                color = if (isPartnerBlocked || isUserBlocked) BaatlyRed else TextSecondaryLight
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("chat_detail_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showGiftsSheet = true },
                        modifier = Modifier.testTag("chat_view_gifts_button")
                    ) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = "View Gifts", tint = BaatlyGold)
                    }

                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.testTag("chat_more_menu_button")
                        ) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More Options", tint = TextPrimaryLight)
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(Color.White)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Clear Chat", color = TextPrimaryLight) },
                                leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = TextSecondaryLight) },
                                onClick = {
                                    showMenu = false
                                    showClearConfirm = true
                                },
                                modifier = Modifier.testTag("menu_clear_chat")
                            )

                            if (isPartnerBlocked) {
                                DropdownMenuItem(
                                    text = { Text("Unblock User", color = BaatlyPrimary) },
                                    leadingIcon = { Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = BaatlyPrimary) },
                                    onClick = {
                                        showMenu = false
                                        showUnblockConfirm = true
                                    },
                                    modifier = Modifier.testTag("menu_unblock_user")
                                )
                            } else {
                                DropdownMenuItem(
                                    text = { Text("Block User", color = BaatlyRed) },
                                    leadingIcon = { Icon(Icons.Default.Block, contentDescription = null, tint = BaatlyRed) },
                                    onClick = {
                                        showMenu = false
                                        showBlockConfirm = true
                                    },
                                    modifier = Modifier.testTag("menu_block_user")
                                )
                            }

                            DropdownMenuItem(
                                text = { Text("Report User", color = BaatlyRed) },
                                leadingIcon = { Icon(Icons.Default.Report, contentDescription = null, tint = BaatlyRed) },
                                onClick = {
                                    showMenu = false
                                    showReportUserDialog = true
                                },
                                modifier = Modifier.testTag("menu_report_user")
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )

            if (showReportUserDialog) {
                ReportUserDialog(
                    reportedUserId = receiverId,
                    userName = displayName,
                    onDismiss = { showReportUserDialog = false },
                    onReportSubmitted = { showReportUserDialog = false }
                )
            }
        },
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = Color(0xFFEFEAE2)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .windowInsetsPadding(
                    WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom)
                )
        ) {
            // Blocked Banner if partner blocked
            if (isPartnerBlocked) {
                Surface(
                    color = BaatlyRedLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Aapne is user ko block kiya hua hai.",
                                color = BaatlyRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        TextButton(
                            onClick = { chatViewModel.unblockUser(receiverId) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("chat_unblock_banner_button")
                        ) {
                            Text("Unblock", color = BaatlyPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                // Safety Moderation Banner
                Surface(
                    color = BaatlyRedLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Phone number ya contact share karna sakht mana hai.",
                            color = BaatlyRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Messages List or Empty Placeholder
            if (messages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ChatBubbleOutline,
                            contentDescription = null,
                            tint = TextSecondaryLight,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Start chatting with ${if (receiverName.isNotBlank() && receiverName != "User") receiverName else "Baatly User"}",
                            color = TextSecondaryLight,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .imeNestedScroll()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    items(messages) { msg ->
                        val isMe = msg.senderId == chatViewModel.currentAuthUuid
                        val align = if (isMe) Alignment.End else Alignment.Start
                        val bubbleColor = if (isMe) Color(0xFFD9FDD3) else Color.White
                        val textColor = Color(0xFF111827)

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalAlignment = align
                        ) {
                            Card(
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isMe) 16.dp else 2.dp,
                                    bottomEnd = if (isMe) 2.dp else 16.dp
                                ),
                                colors = CardDefaults.cardColors(containerColor = bubbleColor),
                                border = if (!isMe) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFFE5E7EB), Color(0xFFE5E7EB)))) else null,
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.widthIn(max = 280.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    when (msg.messageType) {
                                        "text" -> {
                                            Text(
                                                text = msg.messageText ?: "",
                                                color = textColor,
                                                fontSize = 14.sp
                                            )
                                        }
                                        "image" -> {
                                            if (!msg.mediaUrl.isNullOrBlank()) {
                                                val resolvedImageUrl by rememberPrivateStorageUrl(msg.mediaUrl, chatViewModel.privateMediaRepository)
                                                val targetUrl = resolvedImageUrl ?: msg.mediaUrl
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .clickable { fullScreenImageUrl = targetUrl }
                                                        .testTag("chat_image_msg_${msg.id}")
                                                ) {
                                                    Image(
                                                        painter = rememberAsyncImagePainter(model = targetUrl),
                                                        contentDescription = "Image message - tap to enlarge",
                                                        modifier = Modifier
                                                            .widthIn(max = 240.dp)
                                                            .heightIn(max = 240.dp)
                                                            .clip(RoundedCornerShape(12.dp)),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .padding(6.dp)
                                                            .size(24.dp)
                                                            .clip(CircleShape)
                                                            .background(Color.Black.copy(alpha = 0.5f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.ZoomIn,
                                                            contentDescription = "Enlarge",
                                                            tint = Color.White,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        "voice", "audio" -> {
                                            val isCurrentPlaying = isPlaying && (currentAudioPath == msg.mediaUrl || currentAudioPath?.contains(msg.mediaUrl?.substringAfterLast("/") ?: "___") == true)
                                            val durationSec = msg.mediaDurationSeconds ?: 0
                                            val durationText = "${durationSec / 60}:${String.format(java.util.Locale.US, "%02d", durationSec % 60)}"

                                            Row(
                                                modifier = Modifier
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    .widthIn(min = 180.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        if (isCurrentPlaying) {
                                                            chatViewModel.audioPlayerHelper.stopAudio()
                                                        } else if (!msg.mediaUrl.isNullOrBlank()) {
                                                            chatViewModel.playVoiceMessage(msg.mediaUrl)
                                                        }
                                                    },
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isMe) Color(0xFF075E54) else BaatlyPrimary)
                                                        .testTag("play_voice_${msg.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = if (isCurrentPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                        contentDescription = if (isCurrentPlaying) "Pause voice note" else "Play voice note",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(22.dp)
                                                    )
                                                }

                                                Spacer(modifier = Modifier.width(10.dp))

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(20.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                                    ) {
                                                        val heights = listOf(6, 12, 18, 14, 8, 16, 20, 10, 14, 18, 12, 8, 16, 14, 10, 6)
                                                        heights.forEachIndexed { idx, barH ->
                                                            val isPast = isCurrentPlaying && (idx < heights.size / 2)
                                                            Box(
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .height(barH.dp)
                                                                    .clip(RoundedCornerShape(2.dp))
                                                                    .background(
                                                                        if (isPast) (if (isMe) Color(0xFF075E54) else BaatlyPrimary)
                                                                        else (if (isMe) Color(0xFF075E54).copy(alpha = 0.35f) else BaatlyPrimary.copy(alpha = 0.35f))
                                                                    )
                                                            )
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(4.dp))

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = if (isCurrentPlaying) "Playing..." else "Voice Note",
                                                            color = textColor.copy(alpha = 0.7f),
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                        Text(
                                                            text = durationText,
                                                            color = textColor,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        "gift" -> {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = BaatlyGold)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Received Gift: ${msg.messageText ?: "Gift"}",
                                                    color = Color(0xFFB45309),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    if (isMe) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.End)
                                                .padding(top = 2.dp)
                                        ) {
                                            MessageStatusTicks(
                                                deliveredAt = msg.deliveredAt,
                                                seenAt = msg.seenAt
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Input Bar
            Surface(
                color = Color.White,
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isPartnerBlocked) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Aapne is user ko block kiya hua hai. Message bhejne ke liye pehle unblock karein.",
                            color = TextSecondaryLight,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                } else if (isUserBlocked) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Is user ne aapko block kiya hua hai.",
                            color = TextSecondaryLight,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Image Send Button
                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier.testTag("chat_attach_image_button")
                        ) {
                            Icon(Icons.Default.Image, contentDescription = "Send Image", tint = BaatlyPrimary)
                        }

                        // Voice Note Record Button
                        IconButton(
                            onClick = {
                                if (isRecordingVoice) {
                                    val (file, duration) = chatViewModel.audioRecorderHelper.stopRecording()
                                    if (file != null && file.exists() && duration > 0) {
                                        chatViewModel.sendVoiceMessage(conversationId, receiverId, file, duration)
                                    }
                                } else {
                                    val hasMic = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED

                                    if (hasMic) {
                                        chatViewModel.audioRecorderHelper.startRecording("chat_voice")
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            modifier = Modifier.testTag("chat_record_voice_button")
                        ) {
                            Icon(
                                imageVector = if (isRecordingVoice) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = "Record Voice",
                                tint = if (isRecordingVoice) BaatlyRed else BaatlyGold
                            )
                        }

                        // Text Field
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Type a message...", fontSize = 13.sp, color = TextSecondaryLight) },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                                .testTag("chat_message_input"),
                            singleLine = false,
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BaatlyPrimary,
                                unfocusedBorderColor = BaatlyLightBorder,
                                focusedTextColor = TextPrimaryLight,
                                unfocusedTextColor = TextPrimaryLight,
                                cursorColor = BaatlyPrimary
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (inputText.isNotBlank()) {
                                        chatViewModel.sendTextMessage(conversationId, receiverId, inputText)
                                        inputText = ""
                                    }
                                }
                            )
                        )

                        // Send Button
                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    chatViewModel.sendTextMessage(conversationId, receiverId, inputText)
                                    inputText = ""
                                }
                            },
                            enabled = inputText.isNotBlank(),
                            modifier = Modifier.testTag("chat_send_button")
                        ) {
                            Icon(
                                Icons.Default.Send,
                                contentDescription = "Send",
                                tint = if (inputText.isNotBlank()) BaatlyPrimary else TextSecondaryLight
                            )
                        }
                    }
                }
            }
        }
    }

    if (fullScreenImageUrl != null) {
        Dialog(
            onDismissRequest = { fullScreenImageUrl = null },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .testTag("fullscreen_image_dialog")
            ) {
                Image(
                    painter = rememberAsyncImagePainter(model = fullScreenImageUrl),
                    contentDescription = "Full-screen Image",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentScale = ContentScale.Fit
                )

                IconButton(
                    onClick = { fullScreenImageUrl = null },
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(16.dp)
                        .align(Alignment.TopEnd)
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .testTag("fullscreen_image_close")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close full-screen image",
                        tint = Color.White
                    )
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Chat", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = { Text("Kya aap is conversation ke saare messages clear karna chahte hain?", color = TextSecondaryLight, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showClearConfirm = false
                        chatViewModel.clearConversation(conversationId) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyRed),
                    modifier = Modifier.testTag("confirm_clear_chat_button")
                ) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showBlockConfirm) {
        AlertDialog(
            onDismissRequest = { showBlockConfirm = false },
            title = { Text("Block User", fontWeight = FontWeight.Bold, color = BaatlyRed) },
            text = { Text("Kya aap is user ko block karna chahte hain? Block karne ke baad ye user aapko call ya message nahi kar sakega.", color = TextSecondaryLight, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showBlockConfirm = false
                        chatViewModel.blockUser(receiverId) {
                            onBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyRed),
                    modifier = Modifier.testTag("confirm_block_user_button")
                ) {
                    Text("Block")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBlockConfirm = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showUnblockConfirm) {
        AlertDialog(
            onDismissRequest = { showUnblockConfirm = false },
            title = { Text("Unblock User", fontWeight = FontWeight.Bold, color = BaatlyPrimary) },
            text = { Text("Kya aap is user ko unblock karna chahte hain?", color = TextSecondaryLight, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showUnblockConfirm = false
                        chatViewModel.unblockUser(receiverId)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("confirm_unblock_user_button")
                ) {
                    Text("Unblock")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnblockConfirm = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showGiftsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showGiftsSheet = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BaatlyGoldLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = BaatlyGold)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Available Digital Gifts",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Gifts received from users during voice calls and chats earn host wallet rewards.",
                    color = TextSecondaryLight,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                if (gifts.isEmpty()) {
                    Text(
                        text = "Koi active digital gift nahi mila.",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(gifts) { gift ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BaatlyLightSurfaceVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(gift.name, color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        if (!gift.category.isNullOrBlank()) {
                                            Text(gift.category, color = TextSecondaryLight, fontSize = 11.sp)
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        val price = gift.priceRupees ?: 0.0
                                        val earning = gift.partnerEarningRupees
                                            ?: if (gift.priceRupees != null && gift.partnerEarningPercent != null) {
                                                (gift.priceRupees * gift.partnerEarningPercent) / 100.0
                                            } else {
                                                0.0
                                            }
                                        Text(
                                            text = "Price: ₹${String.format(java.util.Locale.US, "%.2f", price)}",
                                            color = TextSecondaryLight,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "Earning: ₹${String.format(java.util.Locale.US, "%.2f", earning)}",
                                            color = BaatlyGreen,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showMicRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showMicRationaleDialog = false },
            title = { Text("Microphone Permission Required", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone access is required for voice calls and voice messages. Please grant microphone access to send voice notes.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMicRationaleDialog = false
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("grant_mic_permission_chat_dialog_button")
                ) {
                    Text("Grant Permission")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showMicRationaleDialog = false
                    showSettingsDialog = true
                }) {
                    Text("App Settings", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Open App Settings", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone permission is permanently denied. Please enable Microphone in App Settings to record voice messages.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSettingsDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                ) {
                    Text("Open Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }
}

/**
 * WhatsApp-style message status indicators for outgoing messages:
 * - Single grey tick: Stored/Sent to Supabase backend (null delivered_at & null seen_at)
 * - Double grey tick: Delivered to recipient device (delivered_at != null && null seen_at)
 * - Double blue tick: Read/Seen by recipient (seen_at != null)
 *
 * Incoming messages do not show status ticks.
 */
@Composable
fun MessageStatusTicks(
    deliveredAt: String?,
    seenAt: String?,
    modifier: Modifier = Modifier
) {
    val isSeen = !seenAt.isNullOrBlank()
    val isDelivered = !deliveredAt.isNullOrBlank() || isSeen

    val tickColor = if (isSeen) Color(0xFF53BDEB) else Color(0xFF8696A0)

    if (isDelivered || isSeen) {
        // Double tick
        Box(
            modifier = modifier,
            contentAlignment = Alignment.CenterStart
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = if (isSeen) "Seen" else "Delivered",
                tint = tickColor,
                modifier = Modifier.size(13.dp)
            )
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = tickColor,
                modifier = Modifier
                    .padding(start = 5.dp)
                    .size(13.dp)
            )
        }
    } else {
        // Single tick
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Sent",
            tint = tickColor,
            modifier = modifier.size(13.dp)
        )
    }
}
