package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.PartnerAiChatRequest
import com.example.data.models.PartnerAiChatResponse
import com.example.data.models.PartnerAiConversationModel
import com.example.data.models.PartnerAiMessageModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PartnerAiRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "PartnerAiRepository"

    suspend fun getActiveConversation(): Result<PartnerAiConversationModel?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
                ?: return@withContext Result.failure(Exception("Not logged in"))

            val res = supabaseClient.restService.getPartnerAiConversations(
                partnerIdFilter = "eq.$authUuid",
                statusFilter = "eq.active",
                order = "last_message_at.desc.nullslast",
                limit = 1
            )
            if (res.isSuccessful) {
                val conv = res.body()?.firstOrNull()
                Result.success(conv)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "getPartnerAiConversations error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "getActiveConversation exception", e)
            Result.failure(e)
        }
    }

    suspend fun getMessages(conversationId: String): Result<List<PartnerAiMessageModel>> = withContext(Dispatchers.IO) {
        if (conversationId.isBlank()) return@withContext Result.success(emptyList())
        try {
            val res = supabaseClient.restService.getPartnerAiMessages(
                conversationIdFilter = "eq.$conversationId",
                order = "created_at.asc",
                limit = 100
            )
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "getPartnerAiMessages error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "getMessages exception", e)
            Result.failure(e)
        }
    }

    suspend fun getLatestAssistantMessage(): Result<PartnerAiMessageModel?> = withContext(Dispatchers.IO) {
        try {
            val authUuid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
                ?: return@withContext Result.success(null)

            val convRes = supabaseClient.restService.getPartnerAiConversations(
                partnerIdFilter = "eq.$authUuid",
                statusFilter = "eq.active",
                order = "last_message_at.desc.nullslast",
                limit = 1
            )
            if (!convRes.isSuccessful) {
                return@withContext Result.success(null)
            }
            val conv = convRes.body()?.firstOrNull() ?: return@withContext Result.success(null)

            val msgRes = supabaseClient.restService.getLatestPartnerAiMessage(
                conversationIdFilter = "eq.${conv.id}",
                order = "created_at.desc",
                limit = 1
            )
            if (msgRes.isSuccessful) {
                Result.success(msgRes.body()?.firstOrNull())
            } else {
                Result.success(null)
            }
        } catch (e: Exception) {
            Log.w(TAG, "getLatestAssistantMessage exception: ${e.message}")
            Result.success(null)
        }
    }

    suspend fun sendMessage(
        message: String,
        conversationId: String?,
        idempotencyKey: String? = null
    ): Result<PartnerAiChatResponse> = withContext(Dispatchers.IO) {
        if (message.isBlank()) return@withContext Result.failure(Exception("Message cannot be empty"))
        try {
            val request = PartnerAiChatRequest(
                message = message.trim(),
                conversationId = conversationId?.takeIf { it.isNotBlank() },
                idempotencyKey = idempotencyKey,
                clientMessageId = idempotencyKey
            )
            val res = supabaseClient.edgeService.sendPartnerAiChat(request)
            if (res.isSuccessful) {
                val body = res.body()
                if (body != null) {
                    if (!body.error.isNullOrBlank()) {
                        Result.failure(Exception(body.error))
                    } else {
                        Result.success(body)
                    }
                } else {
                    Result.failure(Exception("Empty response from AI assistant"))
                }
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "sendPartnerAiChat error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "sendMessage exception", e)
            Result.failure(e)
        }
    }
}
