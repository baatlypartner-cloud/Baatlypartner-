package com.example.data.image

import android.net.Uri
import coil.key.Keyer
import coil.request.Options

/**
 * Stable Coil cache keys for profile-media objects. Signed query tokens are temporary;
 * the object path is stable. Deliberately excludes chat-media and verification audio so
 * private conversation attachments are not persisted under cross-token cache keys.
 */
class SupabaseStorageStringKeyer : Keyer<String> {
    override fun key(data: String, options: Options): String? {
        if (!isProfileMediaObject(data)) return null
        return data.substringBefore('?')
    }
}

class SupabaseStorageUriKeyer : Keyer<Uri> {
    override fun key(data: Uri, options: Options): String? {
        val value = data.toString()
        if (!isProfileMediaObject(value)) return null
        return value.substringBefore('?')
    }
}

private fun isProfileMediaObject(value: String): Boolean =
    value.contains("/storage/v1/object/sign/profile-media/") ||
        value.contains("/storage/v1/object/public/profile-media/")
