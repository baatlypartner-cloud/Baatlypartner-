-- Migration: Create partner_favourite_conversations table with RLS policies
-- Created: 2026-10-10
-- Purpose: Support Host Chats favourite conversations feature with strict partner ownership

CREATE TABLE IF NOT EXISTS public.partner_favourite_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    partner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT partner_favourite_conversations_partner_conv_uniq UNIQUE (partner_id, conversation_id)
);

-- Enable Row Level Security
ALTER TABLE public.partner_favourite_conversations ENABLE ROW LEVEL SECURITY;

-- 1. SELECT Policy: A partner can read only their own favourite records
DROP POLICY IF EXISTS partner_favourites_select_policy ON public.partner_favourite_conversations;
CREATE POLICY partner_favourites_select_policy ON public.partner_favourite_conversations
    FOR SELECT TO authenticated
    USING (partner_id = auth.uid());

-- 2. INSERT Policy: A partner can insert favourites only for themselves,
-- and only for conversations belonging to that same partner
DROP POLICY IF EXISTS partner_favourites_insert_policy ON public.partner_favourite_conversations;
CREATE POLICY partner_favourites_insert_policy ON public.partner_favourite_conversations
    FOR INSERT TO authenticated
    WITH CHECK (
        partner_id = auth.uid() AND
        EXISTS (
            SELECT 1 FROM public.conversations c
            WHERE c.id = conversation_id AND c.partner_id = auth.uid()
        )
    );

-- 3. DELETE Policy: A partner can delete only their own favourite records
DROP POLICY IF EXISTS partner_favourites_delete_policy ON public.partner_favourite_conversations;
CREATE POLICY partner_favourites_delete_policy ON public.partner_favourite_conversations
    FOR DELETE TO authenticated
    USING (partner_id = auth.uid());

-- Grant minimal necessary table permissions to authenticated role (SELECT, INSERT, DELETE only)
GRANT SELECT, INSERT, DELETE ON public.partner_favourite_conversations TO authenticated;

-- Create indexes for fast lookup by partner_id and composite pair
CREATE INDEX IF NOT EXISTS idx_partner_favourite_conversations_partner_id
    ON public.partner_favourite_conversations(partner_id);

CREATE INDEX IF NOT EXISTS idx_partner_favourite_conversations_composite
    ON public.partner_favourite_conversations(partner_id, conversation_id);
