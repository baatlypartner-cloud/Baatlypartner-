package com.example

import android.app.Application
import com.example.data.agora.AgoraCallManager
import com.example.data.api.SupabaseClient
import com.example.data.audio.AudioPlayerHelper
import com.example.data.audio.AudioRecorderHelper
import com.example.data.local.SessionManager
import com.example.data.repository.*

class BaatlyApp : Application() {

    lateinit var sessionManager: SessionManager
        private set
    lateinit var supabaseClient: SupabaseClient
        private set
    lateinit var agoraCallManager: AgoraCallManager
        private set
    lateinit var audioRecorderHelper: AudioRecorderHelper
        private set
    lateinit var audioPlayerHelper: AudioPlayerHelper
        private set

    lateinit var authRepository: AuthRepository
        private set
    lateinit var partnerRepository: PartnerRepository
        private set
    lateinit var callRepository: CallRepository
        private set
    lateinit var chatRepository: ChatRepository
        private set
    lateinit var chatRealtimeManager: com.example.data.api.ChatRealtimeManager
        private set
    lateinit var walletRepository: WalletRepository
        private set
    lateinit var privateMediaRepository: PrivateMediaRepository
        private set
    lateinit var notificationRepository: NotificationRepository
        private set
    lateinit var hostPerformanceRepository: HostPerformanceRepository
        private set
    lateinit var hostPresenceManager: HostPresenceManager
        private set
    lateinit var socialRepository: SocialRepository
        private set
    lateinit var partnerAiRepository: com.example.data.repository.PartnerAiRepository
        private set

    var isAppInForeground = false
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Track foreground state
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            private var resumedActivities = 0

            override fun onActivityCreated(activity: android.app.Activity, savedInstanceState: android.os.Bundle?) {}
            override fun onActivityStarted(activity: android.app.Activity) {}
            override fun onActivityResumed(activity: android.app.Activity) {
                resumedActivities++
                isAppInForeground = true
            }
            override fun onActivityPaused(activity: android.app.Activity) {
                resumedActivities--
                if (resumedActivities <= 0) {
                    isAppInForeground = false
                }
            }
            override fun onActivityStopped(activity: android.app.Activity) {}
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: android.os.Bundle) {}
            override fun onActivityDestroyed(activity: android.app.Activity) {}
        })

        // Enforce global screenshot & screen recording protection across all Activities and Windows
        com.example.security.AppSecurityManager.init(this)

        sessionManager = SessionManager(this)
        supabaseClient = SupabaseClient(sessionManager)
        agoraCallManager = AgoraCallManager(this)
        audioRecorderHelper = AudioRecorderHelper(this)
        audioPlayerHelper = AudioPlayerHelper()

        com.example.data.notification.NotificationHelper.createNotificationChannel(this)

        android.util.Log.d("BaatlyApp", "SUPABASE_URL configured = ${sessionManager.getSupabaseUrl().isNotBlank()}")
        android.util.Log.d("BaatlyApp", "SUPABASE_PUBLISHABLE_KEY configured = ${sessionManager.getSupabasePublishableKey().isNotBlank()}")
        android.util.Log.d("BaatlyApp", "AGORA_APP_ID configured = ${sessionManager.getAgoraAppId().isNotBlank()}")

        notificationRepository = NotificationRepository(supabaseClient, sessionManager)
        authRepository = AuthRepository(supabaseClient, sessionManager, notificationRepository)
        privateMediaRepository = PrivateMediaRepository(supabaseClient, sessionManager)
        partnerRepository = PartnerRepository(supabaseClient, sessionManager, privateMediaRepository)
        callRepository = CallRepository(supabaseClient, sessionManager, agoraCallManager)
        chatRepository = ChatRepository(supabaseClient, sessionManager)
        chatRealtimeManager = com.example.data.api.ChatRealtimeManager(sessionManager)
        walletRepository = WalletRepository(supabaseClient, sessionManager)
        socialRepository = SocialRepository(supabaseClient, sessionManager, privateMediaRepository)
        partnerAiRepository = com.example.data.repository.PartnerAiRepository(supabaseClient, sessionManager)
        hostPerformanceRepository = HostPerformanceRepository(supabaseClient, sessionManager)
        hostPresenceManager = HostPresenceManager(supabaseClient, sessionManager)
    }

    companion object {
        lateinit var instance: BaatlyApp
            private set
    }
}
