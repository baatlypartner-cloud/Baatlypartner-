package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BaatlyApp
import com.example.data.models.*
import com.example.data.repository.SocialRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface SocialDestination {
    object Home : SocialDestination
    object Search : SocialDestination
    data class UserProfile(val user: SocialSearchResult) : SocialDestination
    object HostProfile : SocialDestination
    data class CreateContent(val defaultType: String = "post") : SocialDestination
    data class PostViewer(val post: SocialPostModel) : SocialDestination
    data class StoryViewer(val stories: List<SocialStoryModel>, val initialIndex: Int) : SocialDestination
}

class SocialViewModel(application: Application) : AndroidViewModel(application) {
    private val socialRepository: SocialRepository =
        (application as BaatlyApp).socialRepository

    // Screen State / Navigation
    private val _currentDestination = MutableStateFlow<SocialDestination>(SocialDestination.Home)
    val currentDestination: StateFlow<SocialDestination> = _currentDestination.asStateFlow()

    private val destinationStack = mutableListOf<SocialDestination>(SocialDestination.Home)

    private val _feedPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val feedPosts: StateFlow<List<SocialPostModel>> = _feedPosts.asStateFlow()

    private val _stories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val stories: StateFlow<List<SocialStoryModel>> = _stories.asStateFlow()

    private val _hostSocialProfile = MutableStateFlow<SocialProfileModel?>(null)
    val hostSocialProfile: StateFlow<SocialProfileModel?> = _hostSocialProfile.asStateFlow()

    private val _hostSocialEarnings = MutableStateFlow<SocialEarningsModel?>(null)
    val hostSocialEarnings: StateFlow<SocialEarningsModel?> = _hostSocialEarnings.asStateFlow()

    private val _isLoadingFeed = MutableStateFlow(false)
    val isLoadingFeed: StateFlow<Boolean> = _isLoadingFeed.asStateFlow()

    private val _isPosting = MutableStateFlow(false)
    val isPosting: StateFlow<Boolean> = _isPosting.asStateFlow()

    private val _isUploadingStory = MutableStateFlow(false)
    val isUploadingStory: StateFlow<Boolean> = _isUploadingStory.asStateFlow()

    private val _isUpdatingProfile = MutableStateFlow(false)
    val isUpdatingProfile: StateFlow<Boolean> = _isUpdatingProfile.asStateFlow()

    private val _isDeletingPost = MutableStateFlow(false)
    val isDeletingPost: StateFlow<Boolean> = _isDeletingPost.asStateFlow()

    // Search state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchResult = MutableStateFlow<SocialSearchResult?>(null)
    val searchResult: StateFlow<SocialSearchResult?> = _searchResult.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // Active User Profile view
    private val _selectedUserProfile = MutableStateFlow<SocialSearchResult?>(null)
    val selectedUserProfile: StateFlow<SocialSearchResult?> = _selectedUserProfile.asStateFlow()

    private val _selectedUserPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val selectedUserPosts: StateFlow<List<SocialPostModel>> = _selectedUserPosts.asStateFlow()

    private val _selectedUserStories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val selectedUserStories: StateFlow<List<SocialStoryModel>> = _selectedUserStories.asStateFlow()

    // Host Profile Posts & Stories
    private val _hostPosts = MutableStateFlow<List<SocialPostModel>>(emptyList())
    val hostPosts: StateFlow<List<SocialPostModel>> = _hostPosts.asStateFlow()

    private val _hostStories = MutableStateFlow<List<SocialStoryModel>>(emptyList())
    val hostStories: StateFlow<List<SocialStoryModel>> = _hostStories.asStateFlow()

    // Comments Sheet State
    private val _activeCommentPostId = MutableStateFlow<String?>(null)
    val activeCommentPostId: StateFlow<String?> = _activeCommentPostId.asStateFlow()

    private val _comments = MutableStateFlow<List<SocialCommentModel>>(emptyList())
    val comments: StateFlow<List<SocialCommentModel>> = _comments.asStateFlow()

    private val _isLoadingComments = MutableStateFlow(false)
    val isLoadingComments: StateFlow<Boolean> = _isLoadingComments.asStateFlow()

    private val _isPostingComment = MutableStateFlow(false)
    val isPostingComment: StateFlow<Boolean> = _isPostingComment.asStateFlow()

    // Story Viewer State
    private val _activeStoryViewerList = MutableStateFlow<List<SocialStoryModel>?>(null)
    val activeStoryViewerList: StateFlow<List<SocialStoryModel>?> = _activeStoryViewerList.asStateFlow()

    private val _activeStoryViewerIndex = MutableStateFlow(0)
    val activeStoryViewerIndex: StateFlow<Int> = _activeStoryViewerIndex.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    init {
        loadInitialData()
    }

    fun loadInitialData() {
        refreshAllSocialData()
    }

    fun refreshAllSocialData() {
        viewModelScope.launch {
            _isLoadingFeed.value = true
            try {
                // 1. Reload feed posts
                val postsRes = socialRepository.getFeedPosts()
                if (postsRes.isSuccess) {
                    _feedPosts.value = postsRes.getOrNull() ?: emptyList()
                }

                // 2. Reload active stories
                val storiesRes = socialRepository.getActiveStories()
                if (storiesRes.isSuccess) {
                    _stories.value = storiesRes.getOrNull() ?: emptyList()
                }

                // 3. Reload host social profile & stats
                val profileRes = socialRepository.getHostSocialProfile()
                if (profileRes.isSuccess) {
                    val profile = profileRes.getOrNull()
                    _hostSocialProfile.value = profile
                    if (profile != null) {
                        loadHostPostsAndStories(profile.userId)
                    }
                }

                // 4. Reload host earnings
                val earningsRes = socialRepository.getHostSocialEarnings()
                if (earningsRes.isSuccess) {
                    _hostSocialEarnings.value = earningsRes.getOrNull()
                }
            } catch (e: Exception) {
                _errorMessage.value = e.message
            } finally {
                _isLoadingFeed.value = false
            }
        }
    }

    fun refreshFeed() {
        refreshAllSocialData()
    }

    fun navigateTo(destination: SocialDestination) {
        if (destination == SocialDestination.Home) {
            destinationStack.clear()
            destinationStack.add(SocialDestination.Home)
        } else {
            destinationStack.add(destination)
        }
        _currentDestination.value = destination
    }

    fun navigateBack(): Boolean {
        if (destinationStack.size > 1) {
            destinationStack.removeAt(destinationStack.size - 1)
            val prev = destinationStack.last()
            _currentDestination.value = prev
            if (prev == SocialDestination.Home) {
                clearSearch()
                closeUserProfile()
            }
            return true
        } else {
            _currentDestination.value = SocialDestination.Home
            clearSearch()
            closeUserProfile()
            return false
        }
    }

    fun navigateToHome() {
        destinationStack.clear()
        destinationStack.add(SocialDestination.Home)
        _currentDestination.value = SocialDestination.Home
        clearSearch()
        closeUserProfile()
    }

    fun openSearch() {
        clearSearch()
        navigateTo(SocialDestination.Search)
    }

    fun openHostProfile() {
        loadHostSocialProfile()
        loadHostSocialEarnings()
        navigateTo(SocialDestination.HostProfile)
    }

    fun openCreateContent(defaultType: String = "post") {
        navigateTo(SocialDestination.CreateContent(defaultType))
    }

    fun openPostViewer(post: SocialPostModel) {
        recordContentView("post", post.id)
        navigateTo(SocialDestination.PostViewer(post))
    }

    fun closePostViewer() {
        navigateBack()
    }

    fun loadHostSocialProfile() {
        viewModelScope.launch {
            val res = socialRepository.getHostSocialProfile()
            if (res.isSuccess) {
                val profile = res.getOrNull()
                _hostSocialProfile.value = profile
                if (profile != null) {
                    loadHostPostsAndStories(profile.userId)
                }
            }
        }
    }

    fun loadHostPostsAndStories(hostUserId: String) {
        viewModelScope.launch {
            val postsRes = socialRepository.getUserPosts(hostUserId)
            if (postsRes.isSuccess) {
                _hostPosts.value = postsRes.getOrNull() ?: emptyList()
            }
            val storiesRes = socialRepository.getUserStories(hostUserId)
            if (storiesRes.isSuccess) {
                _hostStories.value = storiesRes.getOrNull() ?: emptyList()
            }
        }
    }

    fun loadHostSocialEarnings() {
        viewModelScope.launch {
            val res = socialRepository.getHostSocialEarnings()
            if (res.isSuccess) {
                _hostSocialEarnings.value = res.getOrNull()
            }
        }
    }

    fun updateHostSocialProfile(bio: String?, hobbies: String?, avatarFile: File?, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _isUpdatingProfile.value = true
            _errorMessage.value = null
            val res = socialRepository.updateHostSocialProfile(bio = bio, hobbies = hobbies, avatarFile = avatarFile)
            _isUpdatingProfile.value = false
            if (res.isSuccess) {
                _hostSocialProfile.value = res.getOrNull()
                _successMessage.value = "Profile updated successfully"
                onSuccess()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to update profile"
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        _searchError.value = null
    }

    fun performSearch() {
        val query = _searchQuery.value.trim()
        if (query.isBlank()) return

        viewModelScope.launch {
            _isSearching.value = true
            _searchError.value = null
            _searchResult.value = null

            val res = socialRepository.searchUserProfile(query)
            _isSearching.value = false
            if (res.isSuccess) {
                val result = res.getOrNull()
                _searchResult.value = result
            } else {
                val ex = res.exceptionOrNull()
                val msg = ex?.message ?: "User not found"
                if (msg.contains("HOST_PROFILE_RESTRICTED", ignoreCase = true)) {
                    _searchError.value = "Cannot view Host profiles. You can search User profiles only."
                } else {
                    _searchError.value = msg
                }
            }
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchResult.value = null
        _searchError.value = null
    }

    fun openUserProfile(user: SocialSearchResult) {
        // STRICT RULE: HOST -> may NOT search/view HOST profiles
        if (user.isHost == true || user.isPartner == true) {
            _errorMessage.value = "Cannot view Host profiles. You can search User profiles only."
            return
        }

        _selectedUserProfile.value = user
        navigateTo(SocialDestination.UserProfile(user))
        viewModelScope.launch {
            // Synchronize fresh authoritative profile from backend
            val profileRes = socialRepository.searchUserProfile(user.userId)
            if (profileRes.isSuccess) {
                val fresh = profileRes.getOrNull()
                if (fresh != null) {
                    _selectedUserProfile.value = fresh
                }
            }
            val postsRes = socialRepository.getUserPosts(user.userId)
            if (postsRes.isSuccess) {
                _selectedUserPosts.value = postsRes.getOrNull() ?: emptyList()
            }
            val storiesRes = socialRepository.getUserStories(user.userId)
            if (storiesRes.isSuccess) {
                _selectedUserStories.value = storiesRes.getOrNull() ?: emptyList()
            }
        }
    }

    fun openUserProfileById(userId: String) {
        if (userId.isBlank()) {
            navigateToHome()
            return
        }
        viewModelScope.launch {
            val res = socialRepository.searchUserProfile(userId)
            if (res.isSuccess) {
                val user = res.getOrNull()
                if (user != null) {
                    openUserProfile(user)
                } else {
                    navigateToHome()
                }
            } else {
                navigateToHome()
            }
        }
    }

    fun closeUserProfile() {
        _selectedUserProfile.value = null
        _selectedUserPosts.value = emptyList()
        _selectedUserStories.value = emptyList()
    }

    fun createPost(mediaFile: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isPosting.value = true
            _errorMessage.value = null
            val res = socialRepository.createContent(type = "post", mediaFile = mediaFile, caption = caption)
            _isPosting.value = false
            if (res.isSuccess) {
                _successMessage.value = "Post shared successfully"
                refreshFeed()
                _hostSocialProfile.value?.userId?.let { loadHostPostsAndStories(it) }
                onComplete(true)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to create post"
                onComplete(false)
            }
        }
    }

    fun createStory(mediaFile: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isUploadingStory.value = true
            _errorMessage.value = null
            val res = socialRepository.createContent(type = "story", mediaFile = mediaFile, caption = caption)
            _isUploadingStory.value = false
            if (res.isSuccess) {
                _successMessage.value = "Story uploaded successfully (Live 24h)"
                refreshFeed()
                _hostSocialProfile.value?.userId?.let { loadHostPostsAndStories(it) }
                onComplete(true)
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to upload story"
                onComplete(false)
            }
        }
    }

    /**
     * Deletes the partner's own social post via authoritative RPC social_delete_post.
     * On confirmation and success:
     * - Cleans up storage if media_path was returned.
     * - Removes the post from local feed and host post list immediately.
     * - Closes post viewer if open.
     */
    fun deletePost(post: SocialPostModel, onComplete: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch {
            _isDeletingPost.value = true
            _errorMessage.value = null

            val res = socialRepository.deletePost(post.id)
            _isDeletingPost.value = false

            if (res.isSuccess) {
                _successMessage.value = "Post deleted successfully"

                // 1. Remove the post from the local Partner Social feed immediately
                _feedPosts.value = _feedPosts.value.filter { it.id != post.id }
                _hostPosts.value = _hostPosts.value.filter { it.id != post.id }
                _selectedUserPosts.value = _selectedUserPosts.value.filter { it.id != post.id }

                // 2. If the deleted post is open in a media viewer: close the viewer
                val current = _currentDestination.value
                if (current is SocialDestination.PostViewer && current.post.id == post.id) {
                    navigateBack()
                }

                // 3. Refresh profile / stats
                _hostSocialProfile.value?.userId?.let { loadHostPostsAndStories(it) }

                onComplete?.invoke(true)
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to delete post"
                _errorMessage.value = err
                onComplete?.invoke(false)
            }
        }
    }

    fun toggleLikePost(post: SocialPostModel) {
        viewModelScope.launch {
            val currentLiked = post.isLiked == true
            val currentCount = post.likesCount ?: 0
            val newLiked = !currentLiked
            val newCount = if (newLiked) currentCount + 1 else maxOf(0, currentCount - 1)

            // Optimistic update
            _feedPosts.value = _feedPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }
            _selectedUserPosts.value = _selectedUserPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }
            _hostPosts.value = _hostPosts.value.map {
                if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
            }

            val res = socialRepository.toggleLike(contentType = "post", contentId = post.id, currentIsLiked = currentLiked)
            if (!res.isSuccess) {
                // Revert on failure
                _feedPosts.value = _feedPosts.value.map {
                    if (it.id == post.id) it.copy(isLiked = currentLiked, likesCount = currentCount) else it
                }
            }
        }
    }

    fun toggleFollowUser(targetUserId: String, currentIsFollowing: Boolean) {
        viewModelScope.launch {
            val optimisticFollowing = !currentIsFollowing

            // 1. Immediate optimistic UI feedback
            _selectedUserProfile.value?.let { current ->
                if (current.userId == targetUserId) {
                    val followers = current.followersCount ?: 0
                    _selectedUserProfile.value = current.copy(
                        isFollowing = optimisticFollowing,
                        followersCount = if (optimisticFollowing) followers + 1 else maxOf(0, followers - 1)
                    )
                }
            }
            _searchResult.value?.let { current ->
                if (current.userId == targetUserId) {
                    val followers = current.followersCount ?: 0
                    _searchResult.value = current.copy(
                        isFollowing = optimisticFollowing,
                        followersCount = if (optimisticFollowing) followers + 1 else maxOf(0, followers - 1)
                    )
                }
            }
            _feedPosts.value = _feedPosts.value.map {
                if (it.userId == targetUserId) it.copy(isFollowing = optimisticFollowing) else it
            }

            val res = socialRepository.toggleFollow(targetUserId, currentIsFollowing)
            if (res.isSuccess) {
                val realFollowing = res.getOrNull() ?: optimisticFollowing
                _selectedUserProfile.value?.let { current ->
                    if (current.userId == targetUserId) {
                        _selectedUserProfile.value = current.copy(isFollowing = realFollowing)
                    }
                }
                _searchResult.value?.let { current ->
                    if (current.userId == targetUserId) {
                        _searchResult.value = current.copy(isFollowing = realFollowing)
                    }
                }
                _feedPosts.value = _feedPosts.value.map {
                    if (it.userId == targetUserId) it.copy(isFollowing = realFollowing) else it
                }

                // 2. Fetch authoritative counts and follow state from Supabase backend
                val freshProfileRes = socialRepository.searchUserProfile(targetUserId)
                if (freshProfileRes.isSuccess) {
                    val fresh = freshProfileRes.getOrNull()
                    if (fresh != null) {
                        _selectedUserProfile.value?.let { current ->
                            if (current.userId == targetUserId) {
                                _selectedUserProfile.value = fresh
                            }
                        }
                        _searchResult.value?.let { current ->
                            if (current.userId == targetUserId) {
                                _searchResult.value = fresh
                            }
                        }
                    }
                }
            } else {
                // Revert on failure
                val err = res.exceptionOrNull()?.message ?: "Failed to update follow status"
                _errorMessage.value = err
                _selectedUserProfile.value?.let { current ->
                    if (current.userId == targetUserId) {
                        _selectedUserProfile.value = current.copy(isFollowing = currentIsFollowing)
                    }
                }
                _searchResult.value?.let { current ->
                    if (current.userId == targetUserId) {
                        _searchResult.value = current.copy(isFollowing = currentIsFollowing)
                    }
                }
                _feedPosts.value = _feedPosts.value.map {
                    if (it.userId == targetUserId) it.copy(isFollowing = currentIsFollowing) else it
                }
                val freshProfileRes = socialRepository.searchUserProfile(targetUserId)
                if (freshProfileRes.isSuccess) {
                    val fresh = freshProfileRes.getOrNull()
                    if (fresh != null) {
                        _selectedUserProfile.value?.let { current ->
                            if (current.userId == targetUserId) {
                                _selectedUserProfile.value = fresh
                            }
                        }
                    }
                }
            }
        }
    }

    fun openPostById(postId: String) {
        if (postId.isBlank()) {
            navigateToHome()
            return
        }
        viewModelScope.launch {
            val post = _feedPosts.value.find { it.id == postId }
                ?: _hostPosts.value.find { it.id == postId }
                ?: socialRepository.getPostById(postId).getOrNull()

            if (post != null) {
                openPostViewer(post)
            } else {
                navigateToHome()
            }
        }
    }

    fun openStoryById(storyId: String) {
        if (storyId.isBlank()) {
            navigateToHome()
            return
        }
        viewModelScope.launch {
            val allStories = (_stories.value + _hostStories.value).distinctBy { it.id }
            val matchIdx = allStories.indexOfFirst { it.id == storyId }
            if (matchIdx >= 0) {
                openStoryViewer(allStories, matchIdx)
            } else {
                val fetchedStory = socialRepository.getStoryById(storyId).getOrNull()
                if (fetchedStory != null) {
                    openStoryViewer(listOf(fetchedStory), 0)
                } else {
                    navigateToHome()
                }
            }
        }
    }

    fun openPostAndCommentsById(postId: String) {
        if (postId.isBlank()) {
            navigateToHome()
            return
        }
        viewModelScope.launch {
            val post = _feedPosts.value.find { it.id == postId }
                ?: _hostPosts.value.find { it.id == postId }
                ?: socialRepository.getPostById(postId).getOrNull()

            if (post != null) {
                openPostViewer(post)
                openComments(postId)
            } else {
                navigateToHome()
            }
        }
    }

    fun openComments(postId: String) {
        _activeCommentPostId.value = postId
        _comments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            val res = socialRepository.getComments(contentId = postId)
            _isLoadingComments.value = false
            if (res.isSuccess) {
                _comments.value = res.getOrNull() ?: emptyList()
            }
        }
    }

    fun closeComments() {
        _activeCommentPostId.value = null
        _comments.value = emptyList()
    }

    fun postComment(commentText: String) {
        val postId = _activeCommentPostId.value ?: return
        if (commentText.isBlank()) return

        viewModelScope.launch {
            _isPostingComment.value = true
            val res = socialRepository.addComment(contentType = "post", contentId = postId, commentText = commentText)
            _isPostingComment.value = false
            if (res.isSuccess) {
                // Reload comments
                val refreshComments = socialRepository.getComments(contentId = postId)
                if (refreshComments.isSuccess) {
                    _comments.value = refreshComments.getOrNull() ?: emptyList()
                }
                // Update comment count in feed
                _feedPosts.value = _feedPosts.value.map {
                    if (it.id == postId) it.copy(commentsCount = (it.commentsCount ?: 0) + 1) else it
                }
                _selectedUserPosts.value = _selectedUserPosts.value.map {
                    if (it.id == postId) it.copy(commentsCount = (it.commentsCount ?: 0) + 1) else it
                }
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "Failed to post comment"
            }
        }
    }

    fun openStoryViewer(storiesList: List<SocialStoryModel>, initialIndex: Int = 0) {
        if (storiesList.isEmpty()) return
        _activeStoryViewerList.value = storiesList
        val validIndex = initialIndex.coerceIn(0, storiesList.size - 1)
        _activeStoryViewerIndex.value = validIndex

        val story = storiesList.getOrNull(validIndex)
        if (story != null) {
            recordContentView("story", story.id)
        }
        navigateTo(SocialDestination.StoryViewer(storiesList, validIndex))
    }

    fun nextStory() {
        val list = _activeStoryViewerList.value ?: return
        val nextIdx = _activeStoryViewerIndex.value + 1
        if (nextIdx < list.size) {
            _activeStoryViewerIndex.value = nextIdx
            recordContentView("story", list[nextIdx].id)
        } else {
            closeStoryViewer()
        }
    }

    fun prevStory() {
        val list = _activeStoryViewerList.value ?: return
        val prevIdx = _activeStoryViewerIndex.value - 1
        if (prevIdx >= 0) {
            _activeStoryViewerIndex.value = prevIdx
            recordContentView("story", list[prevIdx].id)
        }
    }

    fun closeStoryViewer() {
        _activeStoryViewerList.value = null
        _activeStoryViewerIndex.value = 0
        navigateBack()
    }

    fun recordContentView(contentType: String, contentId: String) {
        viewModelScope.launch {
            socialRepository.viewContent(contentType = contentType, contentId = contentId)
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}

class SocialViewModelFactory(
    private val application: Application
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocialViewModel::class.java)) {
            return SocialViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
