package com.example

import android.app.Application
import com.example.data.agora.AgoraCallManager
import com.example.data.api.SupabaseClient
import com.example.data.audio.AudioPlayerHelper
import com.example.data.audio.AudioRecorderHelper
import com.example.data.local.SessionManager
import com.example.data.repository.*

class BaatlyApp : Application() {

    lateinit var sessionManager: SessionManager
        private set
    lateinit var supabaseClient: SupabaseClient
        private set
    lateinit var agoraCallManager: AgoraCallManager
        private set
    lateinit var audioRecorderHelper: AudioRecorderHelper
        private set
    lateinit var audioPlayerHelper: AudioPlayerHelper
        private set

    lateinit var authRepository: AuthRepository
        private set
    lateinit var partnerRepository: PartnerRepository
        private set
    lateinit var callRepository: CallRepository
        private set
    lateinit var chatRepository: ChatRepository
        private set
    lateinit var walletRepository: WalletRepository
        private set
    lateinit var privateMediaRepository: PrivateMediaRepository
        private set
    lateinit var socialRepository: SocialRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        sessionManager = SessionManager(this)
        supabaseClient = SupabaseClient(sessionManager)
        agoraCallManager = AgoraCallManager(this)
        audioRecorderHelper = AudioRecorderHelper(this)
        audioPlayerHelper = AudioPlayerHelper()

        android.util.Log.d("BaatlyApp", "SUPABASE_URL configured = ${sessionManager.getSupabaseUrl().isNotBlank()}")
        android.util.Log.d("BaatlyApp", "SUPABASE_PUBLISHABLE_KEY configured = ${sessionManager.getSupabasePublishableKey().isNotBlank()}")
        android.util.Log.d("BaatlyApp", "AGORA_APP_ID configured = ${sessionManager.getAgoraAppId().isNotBlank()}")

        authRepository = AuthRepository(supabaseClient, sessionManager)
        partnerRepository = PartnerRepository(supabaseClient, sessionManager)
        callRepository = CallRepository(supabaseClient, sessionManager, agoraCallManager)
        chatRepository = ChatRepository(supabaseClient, sessionManager)
        walletRepository = WalletRepository(supabaseClient, sessionManager)
        privateMediaRepository = PrivateMediaRepository(supabaseClient, sessionManager)
        socialRepository = SocialRepository(supabaseClient, sessionManager)
    }

    companion object {
        lateinit var instance: BaatlyApp
            private set
    }
}
