package com.example.ui.screens.social

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.models.*
import com.example.data.repository.MediaLoadState
import com.example.data.repository.PrivateMediaRepository
import com.example.data.repository.rememberPrivateStorageUrl
import com.example.data.repository.rememberSocialMediaState
import com.example.ui.theme.*

// -------------------------------------------------------------------------------------------------
// 1. SOCIAL MEDIA IMAGE (High fidelity loader + shimmer + error state)
// -------------------------------------------------------------------------------------------------

@Composable
fun SocialMediaImage(
    mediaPath: String?,
    privateMediaRepo: PrivateMediaRepository,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    contentDescription: String? = null
) {
    val mediaState by rememberSocialMediaState(rawUrl = mediaPath, privateMediaRepo = privateMediaRepo)
    val shimmerBrush = rememberShimmerBrush()

    Box(
        modifier = modifier.background(Color(0xFF0F172A)),
        contentAlignment = Alignment.Center
    ) {
        when (val state = mediaState) {
            is MediaLoadState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(shimmerBrush)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .size(32.dp)
                            .align(Alignment.Center),
                        color = SocialColors.Purple,
                        strokeWidth = 2.5.dp
                    )
                }
            }
            is MediaLoadState.Success -> {
                AsyncImage(
                    model = state.url,
                    contentDescription = contentDescription,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = contentScale
                )
            }
            is MediaLoadState.Error -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E293B))
                        .padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0x33F43F5E)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.BrokenImage,
                            contentDescription = "Image unavailable",
                            tint = SocialColors.Rose,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Image unavailable",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 2. STORY SECTION (Vibrant neon gradient rings, distinct '+' for Partner's story)
// -------------------------------------------------------------------------------------------------

@Composable
fun StoriesRowSection(
    stories: List<SocialStoryModel>,
    hostProfile: SocialProfileModel?,
    onAddStoryClick: () -> Unit,
    onStoryClick: (List<SocialStoryModel>, Int) -> Unit,
    privateMediaRepo: PrivateMediaRepository
) {
    val userStoryGroups = remember(stories) {
        stories.groupBy { it.userId }
    }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        // "Add Story" / Host Story with distinct gradient '+' badge
        item(key = "add_story_item") {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onAddStoryClick() }
                    .testTag("add_story_button")
            ) {
                Box(
                    contentAlignment = Alignment.BottomEnd,
                    modifier = Modifier.size(72.dp)
                ) {
                    val hostAvatar = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
                    val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = hostAvatar, privateMediaRepo = privateMediaRepo).value

                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.sweepGradient(
                                    listOf(SocialColors.Purple, SocialColors.Pink, SocialColors.Blue, SocialColors.Purple)
                                )
                            )
                            .padding(2.5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedAvatar.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedAvatar,
                                    contentDescription = "Your Story",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(SocialColors.PurpleLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = SocialColors.Purple,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Prominent '+' Badge
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(SocialGradients.Hero)
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Story",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Your Story",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryLight
                )
            }
        }

        // Active Stories by Users with glowing multi-stop gradient rings
        items(
            items = userStoryGroups.entries.toList(),
            key = { it.key }
        ) { entry ->
            val userStories = entry.value
            val firstStory = userStories.first()
            val userName = firstStory.authorName
            val userAvatar = firstStory.authorAvatar
            val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = userAvatar, privateMediaRepo = privateMediaRepo).value

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onStoryClick(userStories, 0) }
                    .testTag("story_user_${entry.key}")
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(SocialGradients.StoryRing)
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(Color.White)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!resolvedAvatar.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatar,
                                contentDescription = userName,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(SocialColors.PinkLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = userName.take(1).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = SocialColors.Pink,
                                    fontSize = 20.sp
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = userName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextPrimaryLight,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 72.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 3. CREATE POST BANNER / CARD (Modern, colourful, encouraging partner to create)
// -------------------------------------------------------------------------------------------------

@Composable
fun CreatePostBanner(
    hostProfile: SocialProfileModel?,
    privateMediaRepo: PrivateMediaRepository,
    onClick: () -> Unit
) {
    val hostAvatar = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
    val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = hostAvatar, privateMediaRepo = privateMediaRepo).value

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("create_post_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SocialGradients.CreateCardAccent)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Partner Avatar
            if (!resolvedAvatar.isNullOrBlank()) {
                AsyncImage(
                    model = resolvedAvatar,
                    contentDescription = "Partner Avatar",
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .border(2.dp, SocialColors.Purple, CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SocialGradients.Hero),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "What's on your mind?",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Share photos, moments & stories",
                    fontSize = 11.sp,
                    color = SocialColors.Purple,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Colorful Post Action Button
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Transparent,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(SocialGradients.PrimaryCta)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Create",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Post",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 4. REDESIGNED SOCIAL POST CARD (Rich colourful header, rounded media, animated like)
// -------------------------------------------------------------------------------------------------

@Composable
fun SocialPostCard(
    post: SocialPostModel,
    hostUserId: String,
    privateMediaRepo: PrivateMediaRepository,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onFollowClick: () -> Unit,
    onUserClick: () -> Unit,
    onMediaClick: () -> Unit
) {
    val authorName = post.authorName
    val authorAvatar = post.authorAvatar
    val authorHandle = post.authorHandle
    val resolvedAuthorAvatar = rememberPrivateStorageUrl(rawUrl = authorAvatar, privateMediaRepo = privateMediaRepo).value
    val postMedia = post.mediaPath ?: post.mediaUrl
    val isLiked = post.isLiked == true

    // Heart bounce animation on like
    val heartScale by animateFloatAsState(
        targetValue = if (isLiked) 1.25f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "heart_scale_anim"
    )

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(22.dp))
            .testTag("social_post_${post.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Clickable Avatar + Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onUserClick() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SocialGradients.StoryRing)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(1.5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedAuthorAvatar.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedAuthorAvatar,
                                    contentDescription = authorName,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .background(SocialColors.PurpleLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = authorName.take(1).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        color = SocialColors.Purple,
                                        fontSize = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = authorName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (post.userId == hostUserId) {
                                Spacer(modifier = Modifier.width(5.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.Transparent,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(SocialGradients.HostBadge)
                                ) {
                                    Text(
                                        text = "HOST",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = authorHandle,
                            fontSize = 11.sp,
                            color = SocialColors.Purple,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Follow Button (if not self)
                if (post.userId != hostUserId) {
                    val isFollowing = post.isFollowing == true
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isFollowing) Color(0xFFF1F5F9) else Color.Transparent,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .then(
                                if (!isFollowing) Modifier.background(SocialGradients.PrimaryCta)
                                else Modifier
                            )
                            .clickable { onFollowClick() }
                            .testTag("follow_user_button_${post.userId}")
                    ) {
                        Text(
                            text = if (isFollowing) "Following" else "Follow",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isFollowing) TextSecondaryLight else Color.White,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Post Media (Focus of the card with smooth rounded corners)
            if (!postMedia.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .aspectRatio(1.15f)
                        .clickable { onMediaClick() }
                ) {
                    SocialMediaImage(
                        mediaPath = postMedia,
                        privateMediaRepo = privateMediaRepo,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        contentDescription = post.caption
                    )
                }
            }

            // Action Row (Like, Comment, Views)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button with heart bounce
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onLikeClick() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("like_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (isLiked) SocialColors.Rose else TextPrimaryLight,
                        modifier = Modifier
                            .size(24.dp)
                            .scale(heartScale)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${post.likesCount ?: 0}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isLiked) SocialColors.Rose else TextPrimaryLight
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Comment Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onCommentClick() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("comment_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = SocialColors.Purple,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${post.commentsCount ?: 0}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimaryLight
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // View Count Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SocialColors.PurpleLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Visibility,
                            contentDescription = "Views",
                            tint = SocialColors.Purple,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${post.viewsCount ?: 0}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SocialColors.Purple
                        )
                    }
                }
            }

            // Caption Section
            if (!post.caption.isNullOrBlank()) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(
                        text = post.caption,
                        fontSize = 13.sp,
                        color = TextPrimaryLight,
                        lineHeight = 18.sp
                    )
                }
            }

            // "View Comments" teaser if comments exist
            if ((post.commentsCount ?: 0) > 0) {
                Text(
                    text = "View all ${post.commentsCount} comments",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = SocialColors.Purple,
                    modifier = Modifier
                        .clickable { onCommentClick() }
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 5. SHIMMER SKELETON LOADING STATE (Matching the colourful theme)
// -------------------------------------------------------------------------------------------------

@Composable
fun SocialFeedSkeleton() {
    val shimmerBrush = rememberShimmerBrush()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        repeat(3) {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header Skeleton
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(shimmerBrush)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Box(
                                modifier = Modifier
                                    .size(width = 120.dp, height = 14.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(shimmerBrush)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(width = 80.dp, height = 10.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(shimmerBrush)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Media Skeleton
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(shimmerBrush)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Actions Skeleton
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(width = 60.dp, height = 24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(shimmerBrush)
                        )
                        Box(
                            modifier = Modifier
                                .size(width = 60.dp, height = 24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(shimmerBrush)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 6. BEAUTIFUL COLOURFUL EMPTY STATE
// -------------------------------------------------------------------------------------------------

@Composable
fun EmptySocialFeed(onCreatePostClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
            .border(1.dp, SocialColors.CardBorder, RoundedCornerShape(24.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SocialGradients.EmptyStateBg)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Layered colourful circular illustration
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.sweepGradient(
                            listOf(SocialColors.Pink, SocialColors.Purple, SocialColors.Cyan, SocialColors.Pink)
                        )
                    )
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Social Feed",
                        tint = SocialColors.Purple,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Welcome to Baatly Social",
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Share high quality photos, stories, and moments. Connect with followers and grow your audience.",
                fontSize = 13.sp,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.Transparent,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(SocialGradients.PrimaryCta)
                    .clickable { onCreatePostClick() }
                    .testTag("empty_feed_create_post_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Create First Post",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 7. COMMENTS BOTTOM SHEET (Clean, responsive, attractive)
// -------------------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsBottomSheet(
    comments: List<SocialCommentModel>,
    isLoading: Boolean,
    isPosting: Boolean,
    privateMediaRepo: PrivateMediaRepository,
    onDismiss: () -> Unit,
    onPostComment: (String) -> Unit
) {
    var commentText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = Modifier.testTag("comments_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Comments",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = SocialColors.PurpleLight
                    ) {
                        Text(
                            text = "${comments.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SocialColors.Purple,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

            // Comments List
            Box(modifier = Modifier.weight(1f)) {
                if (comments.isEmpty() && !isLoading) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = null,
                            tint = SocialColors.Purple,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No comments yet",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Be the first to share your thoughts!",
                            color = TextSecondaryLight,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(comments) { comment ->
                            val commenterName = comment.profile?.displayName ?: comment.profile?.username ?: "User"
                            val commenterAvatar = comment.profile?.avatarUrl
                            val resolvedAvatar = rememberPrivateStorageUrl(rawUrl = commenterAvatar, privateMediaRepo = privateMediaRepo).value

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                if (!resolvedAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatar,
                                        contentDescription = commenterName,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = commenterName.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple,
                                            fontSize = 14.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFFF8FAFC))
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = commenterName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimaryLight
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = comment.text,
                                        fontSize = 13.sp,
                                        color = TextPrimaryLight,
                                        lineHeight = 17.sp
                                    )
                                }
                            }
                        }
                    }
                }

                if (isLoading) {
                    CircularProgressIndicator(
                        color = SocialColors.Purple,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

            // Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("Write a comment...", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SocialColors.Purple,
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("comment_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = CircleShape,
                    color = Color.Transparent,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .then(
                            if (commentText.isNotBlank()) Modifier.background(SocialGradients.PrimaryCta)
                            else Modifier.background(Color(0xFFE2E8F0))
                        )
                        .clickable(enabled = commentText.isNotBlank() && !isPosting) {
                            onPostComment(commentText.trim())
                            commentText = ""
                        }
                        .testTag("send_comment_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isPosting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        } else {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send Comment",
                                tint = if (commentText.isNotBlank()) Color.White else TextSecondaryLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------------------
// 8. FULLSCREEN STORY VIEWER (Immersive, segmented progress bars, tap to skip)
// -------------------------------------------------------------------------------------------------

@Composable
fun FullscreenStoryViewer(
    stories: List<SocialStoryModel>,
    initialIndex: Int,
    privateMediaRepo: PrivateMediaRepository,
    onClose: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit
) {
    BackHandler { onClose() }

    val currentStory = stories.getOrNull(initialIndex) ?: return
    val authorName = currentStory.profile?.displayName ?: currentStory.profile?.username ?: "Baatly User"
    val authorAvatar = currentStory.socialProfile?.socialAvatarUrl ?: currentStory.profile?.avatarUrl
    val resolvedAuthorAvatar = rememberPrivateStorageUrl(rawUrl = authorAvatar, privateMediaRepo = privateMediaRepo).value
    val storyMedia = currentStory.mediaPath ?: currentStory.mediaUrl

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Story Image
            if (!storyMedia.isNullOrBlank()) {
                SocialMediaImage(
                    mediaPath = storyMedia,
                    privateMediaRepo = privateMediaRepo,
                    contentDescription = "Story",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Left & Right Touch Targets for navigation
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onPrev() }
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onNext() }
                )
            }

            // Top Header with Progress Bars
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Segmented Progress Bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    stories.forEachIndexed { index, _ ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (index <= initialIndex) Color.White else Color.White.copy(alpha = 0.35f)
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Author Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!resolvedAuthorAvatar.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAuthorAvatar,
                            contentDescription = authorName,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color.White, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SocialColors.Purple),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = authorName.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = authorName,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close story", tint = Color.White)
                    }
                }
            }

            // Caption overlay
            if (!currentStory.caption.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                            )
                        )
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 24.dp)
                ) {
                    Text(
                        text = currentStory.caption,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
