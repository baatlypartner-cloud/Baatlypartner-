package com.example.ui.screens.call

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.example.data.models.isUuid
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.example.data.models.CallModel
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.chat.ChatListScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveCallUiStatus
import com.example.ui.viewmodel.CallViewModel
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun IncomingCallDialog(
    call: CallModel,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    val context = LocalContext.current
    val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: "User"
    val callerAvatar = call.userProfile?.avatarUrl

    var showMicRationaleDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var isAccepting by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onAccept()
        } else {
            isAccepting = false
            showMicRationaleDialog = true
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringPulse"
    )

    Dialog(
        onDismissRequest = onReject,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxHeight()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(modifier = Modifier.height(48.dp))
                    Text(
                        text = "INCOMING AUDIO CALL",
                        color = BaatlyPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(28.dp))

                    // Caller Avatar with Ring Animation
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(BaatlyPrimaryLight),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!callerAvatar.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = callerAvatar),
                                contentDescription = "Caller",
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = callerName.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 42.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = callerName,
                        color = TextPrimaryLight,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Ringing...",
                        color = BaatlyGreen,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Accept & Reject Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 48.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reject Button
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = onReject,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(BaatlyRed)
                                .testTag("reject_call_button")
                        ) {
                            Icon(
                                Icons.Default.CallEnd,
                                contentDescription = "Reject",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Decline", color = TextSecondaryLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Accept Button
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = {
                                if (isAccepting) return@IconButton
                                isAccepting = true
                                val hasMic = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED

                                if (hasMic) {
                                    onAccept()
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            enabled = !isAccepting,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(if (isAccepting) BaatlyGreen.copy(alpha = 0.6f) else BaatlyGreen)
                                .testTag("accept_call_button")
                        ) {
                            Icon(
                                Icons.Default.Call,
                                contentDescription = "Accept",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Accept", color = TextSecondaryLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    if (showMicRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showMicRationaleDialog = false },
            title = { Text("Microphone Permission Required", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone access is required for voice calls and voice messages. Please grant microphone access to connect the call.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMicRationaleDialog = false
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("grant_mic_permission_dialog_button")
                ) {
                    Text("Grant Permission")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showMicRationaleDialog = false
                    showSettingsDialog = true
                }) {
                    Text("App Settings", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Open App Settings", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone permission is permanently denied. Please enable Microphone in App Settings to accept audio calls.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSettingsDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                ) {
                    Text("Open Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveCallScreen(
    callViewModel: CallViewModel,
    chatViewModel: ChatViewModel,
    onCallFinished: () -> Unit
) {
    val callState by callViewModel.callUiStatus.collectAsState()
    var showInCallChat by remember { mutableStateOf(false) }

    var selectedInCallChatParams by remember { mutableStateOf<Triple<String, String, String?>?>(null) }

    when (val state = callState) {
        is ActiveCallUiStatus.Connected -> {
            val call = state.call
            val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: "User"
            val callerAvatar = call.userProfile?.avatarUrl

            val minutes = state.durationSeconds / 60
            val seconds = state.durationSeconds % 60
            val durationStr = String.format("%02d:%02d", minutes, seconds)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyLightBackground)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = BaatlyGreenLight,
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyGreenBorder, BaatlyGreenBorder)))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(BaatlyGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "LIVE AUDIO CALL",
                                    color = BaatlyGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        // In-Call Chat Overlay Trigger
                        IconButton(
                            onClick = { showInCallChat = true },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White)
                                .testTag("in_call_chat_button")
                        ) {
                            Icon(
                                Icons.Default.Chat,
                                contentDescription = "Open Chat",
                                tint = BaatlyPrimary
                            )
                        }
                    }

                    // Center Caller Info & Timer
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (!callerAvatar.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = callerAvatar),
                                contentDescription = "Caller",
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = callerName.take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = callerName,
                            color = TextPrimaryLight,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = durationStr,
                            color = BaatlyPrimary,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        if (state.durationSeconds < 60) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Min 60s required for earning (${60 - state.durationSeconds}s left)",
                                color = BaatlyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Bottom Call Controls (Mute, Speaker, End)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(bottom = 32.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Mute Button
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(
                                    onClick = { callViewModel.toggleMute() },
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(if (state.isMuted) BaatlyRedLight else Color.White)
                                        .testTag("mute_call_button")
                                ) {
                                    Icon(
                                        imageVector = if (state.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                        contentDescription = "Mute",
                                        tint = if (state.isMuted) BaatlyRed else TextPrimaryLight
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.isMuted) "Unmute" else "Mute",
                                    color = TextSecondaryLight,
                                    fontSize = 12.sp
                                )
                            }

                            // End Call Button
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(
                                    onClick = { callViewModel.endActiveCall() },
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(BaatlyRed)
                                        .testTag("end_call_button")
                                ) {
                                    Icon(
                                        Icons.Default.CallEnd,
                                        contentDescription = "End Call",
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("End Call", color = TextPrimaryLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Speakerphone Button
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                IconButton(
                                    onClick = { callViewModel.toggleSpeakerphone() },
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(if (state.isSpeakerOn) BaatlyPrimaryLight else Color.White)
                                        .testTag("speaker_call_button")
                                ) {
                                    Icon(
                                        imageVector = if (state.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                        contentDescription = "Speaker",
                                        tint = if (state.isSpeakerOn) BaatlyPrimary else TextPrimaryLight
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (state.isSpeakerOn) "Speaker On" else "Speaker Off",
                                    color = TextSecondaryLight,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // In-Call Chat Bottom Sheet (Does NOT interrupt call audio)
                if (showInCallChat) {
                    ModalBottomSheet(
                        onDismissRequest = {
                            showInCallChat = false
                            selectedInCallChatParams = null
                        },
                        containerColor = Color.White
                    ) {
                        val activeChat = selectedInCallChatParams
                        if (activeChat != null) {
                            ChatDetailScreen(
                                conversationId = activeChat.first,
                                receiverId = activeChat.second,
                                receiverName = activeChat.third ?: "Baatly User",
                                chatViewModel = chatViewModel,
                                onBack = { selectedInCallChatParams = null }
                            )
                        } else {
                            ChatListScreen(
                                chatViewModel = chatViewModel,
                                onOpenConversation = { convId, userId, name ->
                                    selectedInCallChatParams = Triple(convId, userId, name)
                                }
                            )
                        }
                    }
                }
            }
        }

        is ActiveCallUiStatus.Ended -> {
            // End Call Summary Dialog
            AlertDialog(
                onDismissRequest = {
                    callViewModel.resetCallState()
                    onCallFinished()
                },
                title = {
                    Text("Call Summary", color = TextPrimaryLight, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column {
                        val min = state.durationSeconds / 60
                        val sec = state.durationSeconds % 60
                        Text(
                            text = "Call Duration: ${String.format("%02d:%02d", min, sec)}",
                            color = TextSecondaryLight,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Earning: ₹${String.format("%.2f", state.earning)}",
                            color = BaatlyGreen,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Aapki Call availability offline kar di gayi hai. Ready hone par Home screen se dobara online karein.",
                            color = TextSecondaryLight,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            callViewModel.resetCallState()
                            onCallFinished()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        modifier = Modifier.testTag("call_summary_done_button")
                    ) {
                        Text("Done")
                    }
                },
                containerColor = Color.White
            )
        }

        is ActiveCallUiStatus.Connecting -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyLightBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = BaatlyPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Connecting Agora voice channel...", color = TextPrimaryLight, fontSize = 14.sp)
                }
            }
        }

        is ActiveCallUiStatus.Error -> {
            AlertDialog(
                onDismissRequest = {
                    callViewModel.resetCallState()
                    onCallFinished()
                },
                title = { Text("Call Error", color = BaatlyRed) },
                text = { Text(state.message, color = TextPrimaryLight) },
                confirmButton = {
                    Button(
                        onClick = {
                            callViewModel.resetCallState()
                            onCallFinished()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                    ) {
                        Text("OK")
                    }
                },
                containerColor = Color.White
            )
        }

        else -> {}
    }
}
