package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CallModel(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "partner_id") val partnerId: String,
    @Json(name = "status") val status: String,
    @Json(name = "requested_at") val requestedAt: String? = null,
    @Json(name = "ringing_at") val ringingAt: String? = null,
    @Json(name = "accepted_at") val acceptedAt: String? = null,
    @Json(name = "connected_at") val connectedAt: String? = null,
    @Json(name = "ended_at") val endedAt: String? = null,
    @Json(name = "duration_seconds") val durationSeconds: Int? = 0,
    @Json(name = "user_coins_charged") val userCoinsCharged: Int? = 0,
    @Json(name = "partner_earning") val partnerEarning: Double? = 0.0,
    @Json(name = "termination_reason") val terminationReason: String? = null,
    @Json(name = "billing_status") val billingStatus: String? = null,
    @Json(name = "agora_channel_id") val agoraChannelId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "max_duration_seconds") val maxDurationSeconds: Int? = null,
    @Json(name = "max_duration_coins") val maxDurationCoins: Int? = null,
    // Optional joined user profile info for display
    @Json(name = "profiles") val userProfile: Profile? = null,
    // Host-specific user classification from backend ("new" or "repeat")
    @Json(name = "user_class") val userClass: String? = null
)

@JsonClass(generateAdapter = true)
data class ConversationModel(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "partner_id") val partnerId: String,
    @Json(name = "last_message_id") val lastMessageId: String? = null,
    @Json(name = "last_message_at") val lastMessageAt: String? = null,
    @Json(name = "user_blocked") val userBlocked: Boolean? = false,
    @Json(name = "partner_blocked") val partnerBlocked: Boolean? = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "user_cleared_at") val userClearedAt: String? = null,
    @Json(name = "partner_cleared_at") val partnerClearedAt: String? = null,
    // Optional joined profiles
    @Json(name = "profiles") val userProfile: Profile? = null,
    @Json(name = "last_message") val lastMessage: MessageModel? = null,
    @Json(name = "unread_count") val unreadCount: Int? = 0
)

@JsonClass(generateAdapter = true)
data class MessageModel(
    @Json(name = "id") val id: String,
    @Json(name = "conversation_id") val conversationId: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String,
    @Json(name = "message_type") val messageType: String, // "text", "image", "voice", "gift", "story_reply"
    @Json(name = "message_text") val messageText: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "media_duration_seconds") val mediaDurationSeconds: Int? = null,
    @Json(name = "reply_to_story_id") val replyToStoryId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "is_read") val isRead: Boolean? = false
)

@JsonClass(generateAdapter = true)
data class GiftModel(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "category") val category: String? = null,
    @Json(name = "coin_price") val coinPrice: Int,
    @Json(name = "partner_earning_percent") val partnerEarningPercent: Int? = 50,
    @Json(name = "icon_url") val iconUrl: String? = null,
    @Json(name = "animation_url") val animationUrl: String? = null,
    @Json(name = "display_order") val displayOrder: Int? = 0,
    @Json(name = "is_active") val isActive: Boolean? = true,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class GiftTransactionModel(
    @Json(name = "id") val id: String,
    @Json(name = "gift_id") val giftId: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String,
    @Json(name = "conversation_id") val conversationId: String? = null,
    @Json(name = "call_id") val callId: String? = null,
    @Json(name = "coin_price") val coinPrice: Int,
    @Json(name = "partner_earning") val partnerEarning: Double,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "gifts") val gift: GiftModel? = null
)

@JsonClass(generateAdapter = true)
data class TransactionModel(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "transaction_type") val transactionType: String, // partner_call_earning, partner_chat_earning, partner_gift_earning
    @Json(name = "coins") val coins: Int? = 0,
    @Json(name = "cash_amount") val cashAmount: Double? = 0.0,
    @Json(name = "call_id") val callId: String? = null,
    @Json(name = "message_id") val messageId: String? = null,
    @Json(name = "gift_transaction_id") val giftTransactionId: String? = null,
    @Json(name = "payment_id") val paymentId: String? = null,
    @Json(name = "reference_id") val referenceId: String? = null,
    @Json(name = "description") val description: String? = null,
    @Json(name = "created_by") val createdBy: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class WalletModel(
    @Json(name = "user_id") val userId: String,
    @Json(name = "coin_balance") val coinBalance: Int? = 0,
    @Json(name = "cash_balance") val cashBalance: Double? = 0.0,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class WithdrawalModel(
    @Json(name = "id") val id: String,
    @Json(name = "partner_id") val partnerId: String,
    @Json(name = "requested_amount") val requestedAmount: Double,
    @Json(name = "available_balance") val availableBalance: Double? = 0.0,
    @Json(name = "payment_method") val paymentMethod: String? = null,
    @Json(name = "payment_details") val paymentDetails: String? = null,
    @Json(name = "status") val status: String, // pending, approved, processed, rejected, completed
    @Json(name = "reviewed_by") val reviewedBy: String? = null,
    @Json(name = "reviewed_at") val reviewedAt: String? = null,
    @Json(name = "completed_at") val completedAt: String? = null,
    @Json(name = "rejection_reason") val rejectionReason: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class BlockModel(
    @Json(name = "id") val id: String,
    @Json(name = "blocker_id") val blockerId: String,
    @Json(name = "blocked_user_id") val blockedUserId: String,
    @Json(name = "reason") val reason: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "profiles") val blockedProfile: Profile? = null
)

@JsonClass(generateAdapter = true)
data class ReviewModel(
    @Json(name = "id") val id: String,
    @Json(name = "partner_id") val partnerId: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "rating") val rating: Double,
    @Json(name = "review_text") val reviewText: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class AgoraTokenRequest(
    @Json(name = "channel_name") val channelName: String
)

@JsonClass(generateAdapter = true)
data class AgoraTokenResponse(
    @Json(name = "app_id") val appId: String? = null,
    @Json(name = "uid") val uid: Long? = 0,
    @Json(name = "token") val token: String? = null,
    @Json(name = "agoraToken") val agoraToken: String? = null,
    @Json(name = "rtcToken") val rtcToken: String? = null,
    @Json(name = "channel_name") val channelName: String? = null,
    @Json(name = "channel") val channel: String? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null
) {
    val resolvedToken: String
        get() = (token ?: agoraToken ?: rtcToken ?: "").trim()

    val resolvedChannel: String
        get() = (channelName ?: channel ?: "").trim()
}

// RPC Request / Response Models
@JsonClass(generateAdapter = true)
data class CompleteHostOnboardingParams(
    @Json(name = "p_user_id") val pUserId: String,
    @Json(name = "p_display_name") val pDisplayName: String,
    @Json(name = "p_mobile_number") val pMobileNumber: String,
    @Json(name = "p_age") val pAge: Int,
    @Json(name = "p_bio") val pBio: String?,
    @Json(name = "p_hobbies") val pHobbies: String?,
    @Json(name = "p_avatar_url") val pAvatarUrl: String?,
    @Json(name = "p_username") val pUsername: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateVoiceVerificationParams(
    @Json(name = "p_audio_url") val pAudioUrl: String,
    @Json(name = "p_application_id") val pApplicationId: String? = null
)

@JsonClass(generateAdapter = true)
data class SubmitPartnerApplicationParams(
    @Json(name = "p_partner_display_name") val pPartnerDisplayName: String,
    @Json(name = "p_voice_verification_id") val pVoiceVerificationId: String?
)

@JsonClass(generateAdapter = true)
data class UpdateMyPartnerProfileParams(
    @Json(name = "p_partner_display_name") val pPartnerDisplayName: String?,
    @Json(name = "p_is_available") val pIsAvailable: Boolean,
    @Json(name = "p_is_online") val pIsOnline: Boolean,
    @Json(name = "p_audio_enabled") val pAudioEnabled: Boolean,
    @Json(name = "p_chat_enabled") val pChatEnabled: Boolean
)

@JsonClass(generateAdapter = true)
data class UpdateCallStateParams(
    @Json(name = "p_call_id") val pCallId: String,
    @Json(name = "p_new_status") val pNewStatus: String
)

@JsonClass(generateAdapter = true)
data class SettleCallParams(
    @Json(name = "p_call_id") val pCallId: String
)

@JsonClass(generateAdapter = true)
data class EnforceCallBalanceLimitParams(
    @Json(name = "p_call_id") val pCallId: String
)

@JsonClass(generateAdapter = true)
data class SendMessageParams(
    @Json(name = "p_conversation_id") val pConversationId: String,
    @Json(name = "p_receiver_id") val pReceiverId: String,
    @Json(name = "p_message_type") val pMessageType: String,
    @Json(name = "p_message_text") val pMessageText: String?,
    @Json(name = "p_media_url") val pMediaUrl: String?,
    @Json(name = "p_media_duration_seconds") val pMediaDurationSeconds: Int?
)

@JsonClass(generateAdapter = true)
data class RequestPartnerWithdrawalParams(
    @Json(name = "p_requested_amount") val pRequestedAmount: Double,
    @Json(name = "p_account_holder_name") val pAccountHolderName: String,
    @Json(name = "p_account_number") val pAccountNumber: String,
    @Json(name = "p_ifsc_code") val pIfscCode: String
)

@JsonClass(generateAdapter = true)
data class ClearMyConversationParams(
    @Json(name = "p_conversation_id") val pConversationId: String
)

@JsonClass(generateAdapter = true)
data class BlockUserParams(
    @Json(name = "p_blocked_user_id") val pBlockedUserId: String,
    @Json(name = "p_reason") val pReason: String? = "Blocked by host"
)

@JsonClass(generateAdapter = true)
data class UnblockUserParams(
    @Json(name = "p_blocked_user_id") val pBlockedUserId: String
)

@JsonClass(generateAdapter = true)
data class GetConversationParticipantProfileParams(
    @Json(name = "p_conversation_id") val pConversationId: String,
    @Json(name = "p_participant_id") val pParticipantId: String
)

@JsonClass(generateAdapter = true)
data class ConversationParticipantProfile(
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class UpdateMyProfileParams(
    @Json(name = "p_display_name") val pDisplayName: String? = null,
    @Json(name = "p_bio") val pBio: String? = null,
    @Json(name = "p_age") val pAge: Int? = null,
    @Json(name = "p_hobbies") val pHobbies: String? = null
)

@JsonClass(generateAdapter = true)
data class UpdateMyProfileAvatarParams(
    @Json(name = "p_avatar_path") val pAvatarPath: String
)

@JsonClass(generateAdapter = true)
data class SettleCallResponse(
    @Json(name = "success") val success: Boolean? = true,
    @Json(name = "call_id") val callId: String? = null,
    @Json(name = "conversation_id") val conversationId: String? = null,
    @Json(name = "duration_seconds") val durationSeconds: Int? = 0,
    @Json(name = "user_coins_charged") val userCoinsCharged: Int? = 0,
    @Json(name = "partner_earning") val partnerEarning: Double? = 0.0,
    @Json(name = "max_duration_seconds") val maxDurationSeconds: Int? = null,
    @Json(name = "already_settled") val alreadySettled: Boolean? = false
)

@JsonClass(generateAdapter = true)
data class EnforceCallBalanceLimitResponse(
    @Json(name = "should_disconnect") val shouldDisconnect: Boolean? = false,
    @Json(name = "reason") val reason: String? = null,
    @Json(name = "remaining_seconds") val remainingSeconds: Int? = null,
    @Json(name = "user_coins_remaining") val userCoinsRemaining: Int? = null
)

@JsonClass(generateAdapter = true)
data class RegisterFcmTokenParams(
    @Json(name = "p_token") val pToken: String,
    @Json(name = "p_platform") val pPlatform: String = "android",
    @Json(name = "p_device_id") val pDeviceId: String? = null,
    @Json(name = "p_device_info") val pDeviceInfo: String? = null
)

@JsonClass(generateAdapter = true)
data class TokenActionParams(
    @Json(name = "p_token") val pToken: String
)

@JsonClass(generateAdapter = true)
data class MarkConversationReadParams(
    @Json(name = "p_conversation_id") val pConversationId: String
)

@JsonClass(generateAdapter = true)
data class NotificationItemModel(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "notification_type") val notificationType: String? = null,
    @Json(name = "type") val type: String? = null,
    @Json(name = "title") val title: String? = null,
    @Json(name = "body") val body: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "is_read") val isRead: Boolean? = false,
    @Json(name = "created_at") val createdAt: String? = null
)

// --- Partner AI Chat Models ---
@JsonClass(generateAdapter = true)
data class PartnerAiChatRequest(
    @Json(name = "message") val message: String,
    @Json(name = "conversation_id") val conversationId: String? = null
)

@JsonClass(generateAdapter = true)
data class PartnerAiChatResponse(
    @Json(name = "reply") val reply: String? = null,
    @Json(name = "conversation_id") val conversationId: String? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val errorMessage: String? = null
)

@JsonClass(generateAdapter = true)
data class AiMessageModel(
    @Json(name = "id") val id: String = java.util.UUID.randomUUID().toString(),
    @Json(name = "conversation_id") val conversationId: String = "",
    @Json(name = "sender_type") val senderType: String = "user", // "user" or "assistant"
    @Json(name = "content") val content: String = "",
    @Json(name = "created_at") val createdAt: String? = null
)



