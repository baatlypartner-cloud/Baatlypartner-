package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.AiMessageModel
import com.example.data.repository.PartnerAiChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PartnerAiChatViewModel(
    private val repository: PartnerAiChatRepository
) : ViewModel() {

    private val _messages = MutableStateFlow<List<AiMessageModel>>(emptyList())
    val messages: StateFlow<List<AiMessageModel>> = _messages.asStateFlow()

    private val _conversationId = MutableStateFlow<String?>(repository.getStoredConversationId())
    val conversationId: StateFlow<String?> = _conversationId.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _isLoadingHistory = MutableStateFlow(false)
    val isLoadingHistory: StateFlow<Boolean> = _isLoadingHistory.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _latestAssistantReply = MutableStateFlow<String?>(null)
    val latestAssistantReply: StateFlow<String?> = _latestAssistantReply.asStateFlow()

    private var lastFailedMessage: String? = null
    private var isInitialized = false
    private var activePartnerId: String? = repository.getCurrentPartnerId()

    init {
        initChat()
    }

    /**
     * Initializes the chat session: loads or creates conversation ID and pulls historical messages.
     * Ensures session isolation across different partners.
     */
    fun initChat(forceReload: Boolean = false) {
        val currentPartner = repository.getCurrentPartnerId()
        if (currentPartner != activePartnerId) {
            // Partner changed (e.g. logout/login with different partner)
            activePartnerId = currentPartner
            isInitialized = false
            _messages.value = emptyList()
            _conversationId.value = repository.getStoredConversationId()
            _latestAssistantReply.value = null
            _errorMessage.value = null
            lastFailedMessage = null
        }

        if (!forceReload && isInitialized && _messages.value.isNotEmpty()) return

        viewModelScope.launch {
            _isLoadingHistory.value = true
            _errorMessage.value = null

            val convIdResult = repository.getOrCreateConversationId()
            val convId = convIdResult.getOrNull() ?: repository.getStoredConversationId()
            _conversationId.value = convId

            if (!convId.isNullOrBlank()) {
                val historyResult = repository.loadMessageHistory(convId)
                if (historyResult.isSuccess) {
                    val serverMessages = historyResult.getOrDefault(emptyList())
                    if (serverMessages.isNotEmpty()) {
                        _messages.value = serverMessages.distinctBy { it.id }
                        val latest = serverMessages.lastOrNull { it.senderType == "assistant" }?.content
                        if (!latest.isNullOrBlank()) {
                            _latestAssistantReply.value = latest
                        }
                    } else {
                        // Empty history: add initial warm introduction from Neha
                        val welcomeMsg = AiMessageModel(
                            id = "welcome_${convId}",
                            conversationId = convId,
                            senderType = "assistant",
                            content = "Namaste! Main Neha hoon, Baatly ki AI Assistant.\n\nMain aapki earnings, call metrics, daily score, rules ya kisi bhi technical problem mein 24/7 madad kar sakti hoon. Aap mujhse kya poochna chahte hain?",
                            createdAt = currentIsoTimestamp()
                        )
                        _messages.value = listOf(welcomeMsg)
                        _latestAssistantReply.value = "Main Neha hoon, Baatly ki AI Assistant. Main aapki madad ke liye 24/7 yahan hoon."
                    }
                } else {
                    if (_messages.value.isEmpty()) {
                        val welcomeMsg = AiMessageModel(
                            id = "welcome_${convId}",
                            conversationId = convId,
                            senderType = "assistant",
                            content = "Namaste! Main Neha hoon, Baatly ki AI Assistant.\n\nMain aapki earnings, call metrics, daily score, rules ya kisi bhi technical problem mein 24/7 madad kar sakti hoon. Aap mujhse kya poochna chahte hain?",
                            createdAt = currentIsoTimestamp()
                        )
                        _messages.value = listOf(welcomeMsg)
                        _latestAssistantReply.value = "Main Neha hoon, Baatly ki AI Assistant. Main aapki madad ke liye 24/7 yahan hoon."
                    }
                }
            } else {
                // If conversation could not be retrieved from backend
                val error = convIdResult.exceptionOrNull()?.message
                if (!error.isNullOrBlank()) {
                    _errorMessage.value = error
                }
            }

            _isLoadingHistory.value = false
            isInitialized = true
        }
    }

    /**
     * Sends a user message to Neha via the partner-ai-chat-v2 backend.
     */
    fun sendMessage(text: String) {
        sendMessageInternal(text, isRetry = false)
    }

    /**
     * Retries sending the last failed message without creating duplicates.
     */
    fun retryLastMessage() {
        val msg = lastFailedMessage ?: return
        sendMessageInternal(msg, isRetry = true)
    }

    private fun sendMessageInternal(text: String, isRetry: Boolean) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _isSending.value) return

        val cid = _conversationId.value

        val tempMsgId = "client_pending_${System.currentTimeMillis()}"
        val userMessage = AiMessageModel(
            id = tempMsgId,
            conversationId = cid ?: "",
            senderType = "user",
            content = trimmed,
            createdAt = currentIsoTimestamp()
        )

        if (!isRetry) {
            // Optimistically show user message once
            _messages.value = (_messages.value + userMessage).distinctBy { it.id }
        } else {
            // Ensure message exists in list without adding duplicates
            val alreadyVisible = _messages.value.any { it.senderType == "user" && it.content == trimmed }
            if (!alreadyVisible) {
                _messages.value = (_messages.value + userMessage).distinctBy { it.id }
            }
        }

        _isSending.value = true
        _errorMessage.value = null

        viewModelScope.launch {
            val result = repository.sendMessage(trimmed, cid)

            if (result.isSuccess) {
                val response = result.getOrNull()
                val replyText = response?.reply?.takeIf { it.isNotBlank() }
                    ?: "Aapka message receive ho gaya hai. Baatly Support aapki seva mein tatpar hai."

                val newCid = response?.conversationId ?: cid
                if (!newCid.isNullOrBlank()) {
                    _conversationId.value = newCid
                }

                // Try fetching authoritative server history to guarantee zero duplicates
                var reconciled = false
                if (!newCid.isNullOrBlank()) {
                    val freshHistoryResult = repository.loadMessageHistory(newCid)
                    if (freshHistoryResult.isSuccess) {
                        val freshMessages = freshHistoryResult.getOrDefault(emptyList())
                        if (freshMessages.isNotEmpty()) {
                            _messages.value = freshMessages.distinctBy { it.id }
                            reconciled = true
                        }
                    }
                }

                if (!reconciled) {
                    // Safe local reconciliation
                    val confirmedUser = userMessage.copy(id = "user_${System.currentTimeMillis()}")
                    val assistantMessage = AiMessageModel(
                        id = "asst_${System.currentTimeMillis()}",
                        conversationId = newCid ?: cid ?: "",
                        senderType = "assistant",
                        content = replyText,
                        createdAt = currentIsoTimestamp()
                    )

                    val withoutPending = _messages.value.filter { it.id != tempMsgId }
                    _messages.value = (withoutPending + confirmedUser + assistantMessage).distinctBy { it.id }
                }

                _latestAssistantReply.value = replyText
                lastFailedMessage = null
            } else {
                val errorText = result.exceptionOrNull()?.message
                    ?: "Message bhejne mein dikkat aayi. Kripya thodi der mein dobara try karein."
                _errorMessage.value = errorText
                lastFailedMessage = trimmed
                // DO NOT append assistant error bubbles to _messages.
                // The error is cleanly displayed in the UI banner with Retry option.
            }

            _isSending.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    private fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }
}

class PartnerAiChatViewModelFactory(
    private val repository: PartnerAiChatRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PartnerAiChatViewModel::class.java)) {
            return PartnerAiChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
