package com.example.ui.screens.onboarding

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberUpdatedMarkerState

private val DEFAULT_NCR_CENTER = LatLng(28.5355, 77.3910)

@Composable
fun PartnerFullScreenGoogleMap(
    modifier: Modifier = Modifier,
    pickupAddress: String? = null,
    pickupLatitude: Double? = null,
    pickupLongitude: Double? = null,
    dropAddress: String? = null,
    dropLatitude: Double? = null,
    dropLongitude: Double? = null
) {
    val context = LocalContext.current
    var currentLocation by remember { mutableStateOf<LatLng?>(null) }
    val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val locationAllowed = fineGranted || coarseGranted
    val locationManager = remember { context.getSystemService(LocationManager::class.java) }

    DisposableEffect(locationManager, locationAllowed) {
        var activeListener: LocationListener? = null
        if (locationAllowed) {
            try {
                val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                    .filter { provider -> runCatching { locationManager.isProviderEnabled(provider) }.getOrDefault(false) }
                providers.mapNotNull { provider -> runCatching { locationManager.getLastKnownLocation(provider) }.getOrNull() }
                    .maxByOrNull(Location::getTime)?.let { currentLocation = LatLng(it.latitude, it.longitude) }
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        currentLocation = LatLng(location.latitude, location.longitude)
                    }
                    @Deprecated("Deprecated by Android")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                    override fun onProviderEnabled(provider: String) = Unit
                    override fun onProviderDisabled(provider: String) = Unit
                }
                activeListener = listener
                providers.forEach { provider ->
                    runCatching { locationManager.requestLocationUpdates(provider, 5_000L, 10f, listener, Looper.getMainLooper()) }
                }
            } catch (_: SecurityException) { }
        }
        onDispose { activeListener?.let { runCatching { locationManager.removeUpdates(it) } } }
    }

    val pickup = if (pickupLatitude != null && pickupLongitude != null && pickupLatitude.isFinite() && pickupLatitude in -90.0..90.0 && pickupLongitude.isFinite() && pickupLongitude in -180.0..180.0) {
        LatLng(pickupLatitude, pickupLongitude)
    } else null
    val drop = if (dropLatitude != null && dropLongitude != null && dropLatitude.isFinite() && dropLatitude in -90.0..90.0 && dropLongitude.isFinite() && dropLongitude in -180.0..180.0) {
        LatLng(dropLatitude, dropLongitude)
    } else null
    val initial = pickup ?: drop ?: currentLocation ?: DEFAULT_NCR_CENTER
    val cameraState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initial, if (pickup != null || drop != null) 14f else 12f)
    }
    var mapLoaded by remember { mutableStateOf(false) }

    LaunchedEffect(pickup, drop, mapLoaded) {
        if (!mapLoaded) return@LaunchedEffect
        when {
            pickup != null && drop != null && pickup != drop -> {
                val bounds = LatLngBounds.Builder().include(pickup).include(drop).build()
                runCatching { cameraState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 150), 650) }
            }
            pickup != null -> cameraState.animate(CameraUpdateFactory.newLatLngZoom(pickup, 16f), 500)
            drop != null -> cameraState.animate(CameraUpdateFactory.newLatLngZoom(drop, 16f), 500)
        }
    }

    var hasCenteredOnCurrent by remember { mutableStateOf(false) }
    LaunchedEffect(currentLocation, pickup, drop, mapLoaded) {
        if (mapLoaded && pickup == null && drop == null && currentLocation != null && !hasCenteredOnCurrent) {
            cameraState.animate(CameraUpdateFactory.newLatLngZoom(currentLocation!!, 15f), 500)
            hasCenteredOnCurrent = true
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraState,
            onMapLoaded = { mapLoaded = true },
            properties = MapProperties(isMyLocationEnabled = locationAllowed),
            uiSettings = MapUiSettings(
                compassEnabled = true,
                zoomControlsEnabled = true,
                myLocationButtonEnabled = true,
                mapToolbarEnabled = false,
                rotationGesturesEnabled = true,
                scrollGesturesEnabled = true,
                tiltGesturesEnabled = true,
                zoomGesturesEnabled = true
            )
        ) {
            pickup?.let {
                Marker(
                    state = rememberUpdatedMarkerState(it),
                    title = "Pickup",
                    snippet = pickupAddress.orEmpty().ifBlank { "Pickup location" }
                )
            }
            drop?.let {
                Marker(
                    state = rememberUpdatedMarkerState(it),
                    title = "Drop",
                    snippet = dropAddress.orEmpty().ifBlank { "Drop location" }
                )
            }
        }
    }
}

@Composable
fun GoogleMapsNavigationButton(
    label: String,
    latitude: Double?,
    longitude: Double?,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    androidx.compose.material3.OutlinedButton(
        onClick = {
            val lat = latitude ?: return@OutlinedButton
            val lng = longitude ?: return@OutlinedButton
            val navigationUri = Uri.parse("google.navigation:q=$lat,$lng&mode=d")
            val appIntent = Intent(Intent.ACTION_VIEW, navigationUri).setPackage("com.google.android.apps.maps")
            try {
                context.startActivity(appIntent)
            } catch (_: ActivityNotFoundException) {
                val webUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving")
                context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
            }
        },
        enabled = enabled && latitude != null && longitude != null,
        modifier = modifier
    ) {
        androidx.compose.material.icons.Icons.Default.Navigation.let { icon ->
            androidx.compose.material3.Icon(imageVector = icon, contentDescription = null)
        }
        androidx.compose.foundation.layout.Spacer(Modifier.width(7.dp))
        androidx.compose.material3.Text(label)
    }
}
