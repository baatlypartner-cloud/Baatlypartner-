package com.example

import android.content.Context
import android.media.AudioManager
import androidx.test.core.app.ApplicationProvider
import com.example.data.agora.AgoraCallManager
import com.example.data.agora.AgoraCallState
import com.example.data.agora.RemoteVideoState
import com.example.data.audio.CallAudioManager
import com.example.service.BaatlyPartnerCallForegroundService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CallAudioLifecycleTest {

    @Test
    fun testCallAudioManager_requestAndReleaseFocus() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var focusLostCalled = false
        var focusRegainedCalled = false

        val callAudioManager = CallAudioManager(
            context = context,
            onFocusLostTemporarily = { focusLostCalled = true },
            onFocusRegained = { focusRegainedCalled = true }
        )

        val granted = callAudioManager.requestCallAudioFocus()
        assertTrue("Audio focus should be granted in VoIP session", granted)

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        assertEquals(AudioManager.MODE_IN_COMMUNICATION, audioManager.mode)
        assertFalse(audioManager.isMicrophoneMute)

        callAudioManager.releaseCallAudioFocus()
        // Mode restored
        assertEquals(AudioManager.MODE_NORMAL, audioManager.mode)
    }

    @Test
    fun testBaatlyPartnerCallForegroundService_lifecycleTracking() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertFalse(BaatlyPartnerCallForegroundService.isServiceRunning)

        // Starting with call ID
        BaatlyPartnerCallForegroundService.start(context, "call_test_123", "Test Host", false)
        assertEquals("call_test_123", BaatlyPartnerCallForegroundService.activeCallId)

        // Stopping active call service
        BaatlyPartnerCallForegroundService.stop(context)
        assertEquals(null, BaatlyPartnerCallForegroundService.activeCallId)
        assertFalse(BaatlyPartnerCallForegroundService.isServiceRunning)
    }

    @Test
    fun testAgoraCallState_initialState() {
        val agoraCallManager = AgoraCallManager()
        assertEquals(AgoraCallState.Idle, agoraCallManager.callState.value)
        assertEquals(RemoteVideoState.IDLE, agoraCallManager.remoteVideoState.value)
        assertFalse(agoraCallManager.remoteVideoFirstFrameRendered.value)
        assertTrue(agoraCallManager.isSpeakerphoneOn.value)
        assertFalse(agoraCallManager.isMuted.value)
    }
}
