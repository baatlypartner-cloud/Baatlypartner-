package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.provider.Settings
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SessionManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("baatly_partner_session", Context.MODE_PRIVATE)

    private val _accessToken = MutableStateFlow<String?>(prefs.getString(KEY_ACCESS_TOKEN, null))
    val accessToken: StateFlow<String?> = _accessToken.asStateFlow()

    private val _userId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _authUuid = MutableStateFlow<String?>(prefs.getString(KEY_AUTH_UUID, null))
    val authUuid: StateFlow<String?> = _authUuid.asStateFlow()

    fun getSupabaseUrl(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_URL, null)
        if (!stored.isNullOrBlank()) {
            val normalized = stored.trim().removeSuffix("/")
            val host = try {
                java.net.URI(normalized).host
            } catch (_: Exception) { null }

            if (host.equals(CANONICAL_SUPABASE_HOST, ignoreCase = true)) {
                return normalized
            } else {
                android.util.Log.w("SessionManager", "Removing stale or invalid custom_supabase_url ($stored); reverting to canonical production URL")
                prefs.edit().remove(KEY_CUSTOM_SUPABASE_URL).apply()
            }
        }

        val buildConfigUrl = try {
            BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
        } catch (_: Exception) { null }

        if (!buildConfigUrl.isNullOrBlank()) {
            val normalized = buildConfigUrl.trim().removeSuffix("/")
            val host = try {
                java.net.URI(normalized).host
            } catch (_: Exception) { null }

            if (host.equals(CANONICAL_SUPABASE_HOST, ignoreCase = true)) {
                return normalized
            }
        }

        return DEFAULT_SUPABASE_URL
    }

    fun getSupabasePublishableKey(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_KEY, null)
        if (!stored.isNullOrBlank()) {
            val trimmed = stored.trim()
            if (!trimmed.contains("placeholder") && trimmed.length > 20) {
                return trimmed
            } else {
                prefs.edit().remove(KEY_CUSTOM_SUPABASE_KEY).apply()
            }
        }

        val buildConfigKey = try {
            BuildConfig::class.java.getField("SUPABASE_PUBLISHABLE_KEY").get(null) as? String
        } catch (_: Exception) { null }

        return if (!buildConfigKey.isNullOrBlank() && !buildConfigKey.contains("placeholder")) {
            buildConfigKey.trim()
        } else {
            DEFAULT_SUPABASE_PUBLISHABLE_KEY
        }
    }

    fun getAgoraAppId(): String {
        val stored = prefs.getString(KEY_CUSTOM_AGORA_APP_ID, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder")) {
            return stored.trim()
        }
        val buildConfigAgora = try {
            BuildConfig::class.java.getField("AGORA_APP_ID").get(null) as? String
        } catch (_: Exception) { null }
        return if (!buildConfigAgora.isNullOrBlank() && !buildConfigAgora.contains("placeholder")) {
            buildConfigAgora.trim()
        } else {
            DEFAULT_AGORA_APP_ID
        }
    }

    fun saveCredentials(supabaseUrl: String?, publishableKey: String?, agoraAppId: String?) {
        prefs.edit().apply {
            if (!supabaseUrl.isNullOrBlank()) {
                val normalized = supabaseUrl.trim().removeSuffix("/")
                val host = try { java.net.URI(normalized).host } catch (_: Exception) { null }
                if (host.equals(CANONICAL_SUPABASE_HOST, ignoreCase = true)) {
                    putString(KEY_CUSTOM_SUPABASE_URL, normalized)
                } else {
                    remove(KEY_CUSTOM_SUPABASE_URL)
                }
            }
            if (!publishableKey.isNullOrBlank() && !publishableKey.contains("placeholder")) {
                putString(KEY_CUSTOM_SUPABASE_KEY, publishableKey.trim())
            }
            if (!agoraAppId.isNullOrBlank() && !agoraAppId.contains("placeholder")) {
                putString(KEY_CUSTOM_AGORA_APP_ID, agoraAppId.trim())
            }
            apply()
        }
    }

    fun saveSession(authUuid: String, userId: String, accessToken: String, refreshToken: String?) {
        if (authUuid.isBlank() || accessToken.isBlank()) return
        prefs.edit().apply {
            putString(KEY_AUTH_UUID, authUuid)
            putString(KEY_USER_ID, userId)
            putString(KEY_ACCESS_TOKEN, accessToken)
            if (!refreshToken.isNullOrBlank()) putString(KEY_REFRESH_TOKEN, refreshToken)
            apply()
        }

        _authUuid.value = authUuid
        _userId.value = userId
        _accessToken.value = accessToken
    }

    fun updateTokens(accessToken: String, refreshToken: String?) {
        if (accessToken.isBlank()) return
        prefs.edit().apply {
            putString(KEY_ACCESS_TOKEN, accessToken)
            if (!refreshToken.isNullOrBlank()) putString(KEY_REFRESH_TOKEN, refreshToken)
            apply()
        }
        _accessToken.value = accessToken
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_UUID)
            .remove(KEY_USER_ID)
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_LAST_REGISTERED_AUTH_UUID)
            .remove(KEY_LAST_REGISTERED_FCM_TOKEN)
            .apply()

        _authUuid.value = null
        _userId.value = null
        _accessToken.value = null
    }

    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)

    fun getStoredAuthUuid(): String? = prefs.getString(KEY_AUTH_UUID, null)

    fun getStoredUserId(): String? = prefs.getString(KEY_USER_ID, null)

    fun getStoredFcmToken(): String? = prefs.getString(KEY_FCM_TOKEN, null)

    fun saveFcmToken(token: String) {
        prefs.edit().putString(KEY_FCM_TOKEN, token.trim()).apply()
    }

    fun getLastRegisteredFcmToken(): String? = prefs.getString(KEY_LAST_REGISTERED_FCM_TOKEN, null)

    fun getLastRegisteredAuthUuid(): String? = prefs.getString(KEY_LAST_REGISTERED_AUTH_UUID, null)

    fun setLastRegisteredFcmToken(token: String?, authUuid: String?) {
        prefs.edit()
            .putString(KEY_LAST_REGISTERED_FCM_TOKEN, token)
            .putString(KEY_LAST_REGISTERED_AUTH_UUID, authUuid)
            .apply()
    }

    fun isNotificationPermissionRequested(): Boolean = prefs.getBoolean(KEY_NOTIFICATION_PERM_REQUESTED, false)

    fun setNotificationPermissionRequested(requested: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATION_PERM_REQUESTED, requested).apply()
    }

    fun getDeviceId(): String {
        val stored = prefs.getString(KEY_DEVICE_ID, null)
        if (!stored.isNullOrBlank()) return stored
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) { null }
        val deviceId = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") {
            androidId
        } else {
            UUID.randomUUID().toString()
        }
        prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply()
        return deviceId
    }

    fun getDeviceInfo(): String {
        return "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})"
    }

    fun hasStoredSession(): Boolean {
        val authId = _authUuid.value ?: prefs.getString(KEY_AUTH_UUID, null)
        val token = _accessToken.value ?: prefs.getString(KEY_ACCESS_TOKEN, null)
        val refresh = prefs.getString(KEY_REFRESH_TOKEN, null)
        return !authId.isNullOrBlank() && (!token.isNullOrBlank() || !refresh.isNullOrBlank())
    }

    fun isLoggedIn(): Boolean {
        val authId = _authUuid.value ?: prefs.getString(KEY_AUTH_UUID, null)
        val token = _accessToken.value ?: prefs.getString(KEY_ACCESS_TOKEN, null)
        return !authId.isNullOrBlank() && !token.isNullOrBlank()
    }

    fun getAssistantConversationId(partnerId: String? = null): String? {
        val id = partnerId ?: _userId.value ?: _authUuid.value ?: "default"
        return prefs.getString("${KEY_ASSISTANT_CONVERSATION_ID}_$id", null)
    }

    fun saveAssistantConversationId(conversationId: String, partnerId: String? = null) {
        val id = partnerId ?: _userId.value ?: _authUuid.value ?: "default"
        prefs.edit().putString("${KEY_ASSISTANT_CONVERSATION_ID}_$id", conversationId).apply()
    }

    companion object {
        const val CANONICAL_SUPABASE_HOST = "qewhxsbrnlgunygghpez.supabase.co"
        const val DEFAULT_SUPABASE_URL = "https://qewhxsbrnlgunygghpez.supabase.co"
        const val DEFAULT_SUPABASE_PUBLISHABLE_KEY = "sb_publishable_X05JHyvFNsJLfQ7k2iFp0w_ezNwN8Jj"
        const val DEFAULT_AGORA_APP_ID = "82771d17f30f40b09cb1790e9afc1e3f"

        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_AUTH_UUID = "auth_uuid"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_ASSISTANT_CONVERSATION_ID = "assistant_conversation_id"
        private const val KEY_CUSTOM_SUPABASE_URL = "custom_supabase_url"
        private const val KEY_CUSTOM_SUPABASE_KEY = "custom_supabase_key"
        private const val KEY_CUSTOM_AGORA_APP_ID = "custom_agora_app_id"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_LAST_REGISTERED_FCM_TOKEN = "last_registered_fcm_token"
        private const val KEY_LAST_REGISTERED_AUTH_UUID = "last_registered_auth_uuid"
        private const val KEY_NOTIFICATION_PERM_REQUESTED = "notification_perm_requested"
        private const val KEY_DEVICE_ID = "device_id"
    }
}
