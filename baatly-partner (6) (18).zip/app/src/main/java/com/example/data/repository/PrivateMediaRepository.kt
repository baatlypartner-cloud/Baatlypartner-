package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class PrivateMediaRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "PrivateMediaRepo"
    
    // In-memory cache: "bucket:path" -> Pair(signedUrl, expiryMillis)
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    fun invalidateCache(bucket: String? = null, path: String? = null) {
        if (bucket == null && path == null) {
            urlCache.clear()
        } else if (bucket != null && path != null) {
            val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
            urlCache.remove("$bucket:$cleanPath")
        } else if (bucket != null) {
            urlCache.keys.removeIf { it.startsWith("$bucket:") }
        } else if (path != null) {
            urlCache.keys.removeIf { it.contains(path) }
        }
    }

    suspend fun getSignedUrl(bucket: String, path: String, expiresInSeconds: Int = 7200, forceRefresh: Boolean = false): Result<String> = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        val cacheKey = "$bucket:$cleanPath"
        val now = System.currentTimeMillis()

        if (forceRefresh) {
            urlCache.remove(cacheKey)
        } else {
            urlCache[cacheKey]?.let { (cachedUrl, expiry) ->
                if (now < expiry - 60_000) { // Valid for at least another minute
                    return@withContext Result.success(cachedUrl)
                }
            }
        }

        try {
            // Public buckets like gift-media don't need signing
            if (bucket == "gift-media") {
                val publicUrl = supabaseClient.getPublicStorageUrl(bucket, cleanPath)
                return@withContext Result.success(publicUrl)
            }

            val signRes = supabaseClient.storageService.signObjectUrl(
                bucket = bucket,
                path = cleanPath,
                body = mapOf("expiresIn" to expiresInSeconds)
            )

            if (signRes.isSuccessful) {
                val rawBody = signRes.body()?.string() ?: ""
                val signedPart = try {
                    val json = JSONObject(rawBody)
                    json.optString("signedURL", "")
                } catch (e: Exception) {
                    ""
                }

                if (signedPart.isNotBlank()) {
                    val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
                    val fullUrl = if (signedPart.startsWith("http://") || signedPart.startsWith("https://")) {
                        signedPart
                    } else if (signedPart.startsWith("/storage/v1")) {
                        "$baseUrl$signedPart"
                    } else if (signedPart.startsWith("/object/sign")) {
                        "$baseUrl/storage/v1$signedPart"
                    } else {
                        "$baseUrl/storage/v1/object/sign/$bucket/$signedPart"
                    }

                    val expiryTime = now + (expiresInSeconds * 1000L)
                    urlCache[cacheKey] = Pair(fullUrl, expiryTime)
                    return@withContext Result.success(fullUrl)
                } else {
                    Log.e(TAG, "Empty signedURL in storage response for $bucket/$cleanPath: $rawBody")
                    return@withContext Result.failure(Exception("Empty signed URL for $bucket/$cleanPath"))
                }
            } else {
                val errorBody = signRes.errorBody()?.string() ?: "HTTP ${signRes.code()}"
                Log.e(TAG, "Storage sign failed for $bucket/$cleanPath: HTTP ${signRes.code()} - $errorBody")
                return@withContext Result.failure(Exception("Storage error ($bucket/$cleanPath): $errorBody"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining signed URL for $bucket/$cleanPath", e)
            Result.failure(e)
        }
    }

    suspend fun loadProfileImage(path: String?, forceRefresh: Boolean = false): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("profile-media/").removePrefix("/")
        return getSignedUrl("profile-media", clean, forceRefresh = forceRefresh).getOrNull()
    }

    suspend fun loadChatImage(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("chat-media/").removePrefix("/")
        return getSignedUrl("chat-media", clean).getOrNull()
    }

    suspend fun loadChatVoice(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("chat-media/").removePrefix("/")
        return getSignedUrl("chat-media", clean).getOrNull()
    }

    suspend fun loadVerificationAudio(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("voice-verifications/").removePrefix("/")
        return getSignedUrl("voice-verifications", clean).getOrNull()
    }

    suspend fun loadSocialMedia(bucket: String, path: String?, forceRefresh: Boolean = false): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("$bucket/").removePrefix("/")
        return getSignedUrl(bucket, clean, forceRefresh = forceRefresh).getOrNull()
    }

    suspend fun resolveMediaUrl(rawPathOrUrl: String?, forceRefresh: Boolean = false): String? {
        if (rawPathOrUrl.isNullOrBlank()) return null
        if (rawPathOrUrl.startsWith("http://") || rawPathOrUrl.startsWith("https://")) return rawPathOrUrl

        return when {
            rawPathOrUrl.startsWith("profile-media/") || rawPathOrUrl.contains("avatar") -> loadProfileImage(rawPathOrUrl, forceRefresh)
            rawPathOrUrl.startsWith("chat-media/") -> loadChatImage(rawPathOrUrl)
            rawPathOrUrl.startsWith("social-media/") -> loadSocialMedia("social-media", rawPathOrUrl, forceRefresh)
            rawPathOrUrl.startsWith("stories-media/") -> loadSocialMedia("stories-media", rawPathOrUrl, forceRefresh)
            rawPathOrUrl.startsWith("voice-verifications/") -> loadVerificationAudio(rawPathOrUrl)
            rawPathOrUrl.startsWith("gift-media/") -> {
                val clean = rawPathOrUrl.removePrefix("gift-media/").removePrefix("/")
                supabaseClient.getPublicStorageUrl("gift-media", clean)
            }
            else -> {
                if (rawPathOrUrl.contains("avatar")) loadProfileImage(rawPathOrUrl, forceRefresh)
                else null
            }
        }
    }

    suspend fun deleteMedia(bucket: String, path: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        try {
            urlCache.remove("$bucket:$cleanPath")
            val res = supabaseClient.storageService.deleteObject(bucket, cleanPath)
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                // Fallback to deleteObjects
                val res2 = supabaseClient.storageService.deleteObjects(bucket, mapOf("prefixes" to listOf(cleanPath)))
                if (res2.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val err = res.errorBody()?.string() ?: res2.errorBody()?.string() ?: "HTTP ${res.code()}"
                    Log.w(TAG, "Storage delete note for $bucket/$cleanPath: $err")
                    Result.failure(Exception(err))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Storage delete error for $bucket/$cleanPath", e)
            Result.failure(e)
        }
    }
}

sealed class MediaLoadState {
    object Loading : MediaLoadState()
    data class Success(val url: String) : MediaLoadState()
    data class Error(val message: String) : MediaLoadState()
}

@androidx.compose.runtime.Composable
fun rememberProfileAvatarUrl(rawUrl: String?, privateMediaRepo: PrivateMediaRepository): androidx.compose.runtime.State<String?> {
    val state = androidx.compose.runtime.remember(rawUrl) { androidx.compose.runtime.mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(rawUrl) {
        if (rawUrl.isNullOrBlank()) {
            state.value = null
        } else {
            state.value = privateMediaRepo.loadProfileImage(rawUrl)
        }
    }
    return state
}

@androidx.compose.runtime.Composable
fun rememberPrivateStorageUrl(rawUrl: String?, privateMediaRepo: PrivateMediaRepository): androidx.compose.runtime.State<String?> {
    val state = androidx.compose.runtime.remember(rawUrl) { androidx.compose.runtime.mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(rawUrl) {
        if (rawUrl.isNullOrBlank()) {
            state.value = null
        } else {
            state.value = privateMediaRepo.resolveMediaUrl(rawUrl)
        }
    }
    return state
}

@androidx.compose.runtime.Composable
fun rememberSocialMediaUrl(rawUrl: String?, defaultBucket: String = "social-media", privateMediaRepo: PrivateMediaRepository): androidx.compose.runtime.State<String?> {
    val state = androidx.compose.runtime.remember(rawUrl, defaultBucket) { androidx.compose.runtime.mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(rawUrl, defaultBucket) {
        if (rawUrl.isNullOrBlank()) {
            state.value = null
        } else if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
            state.value = rawUrl
        } else {
            val bucket = if (rawUrl.startsWith("stories-media/") || defaultBucket == "stories-media") "stories-media" else "social-media"
            state.value = privateMediaRepo.loadSocialMedia(bucket, rawUrl)
        }
    }
    return state
}

