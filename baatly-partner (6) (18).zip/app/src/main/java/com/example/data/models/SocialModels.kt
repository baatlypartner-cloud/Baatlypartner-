package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SocialPostModel(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String? = null,
    @Json(name = "signup_user_id") val signupUserId: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "is_owner_host") val isOwnerHost: Boolean? = null,
    @Json(name = "is_owner") val isOwner: Boolean? = null,
    @Json(name = "is_unlocked") val isUnlocked: Boolean? = null,
    @Json(name = "is_locked") val isLocked: Boolean? = null,
    @Json(name = "unlock_price_rupees") val unlockPriceRupees: Double? = null,
    @Json(name = "media_path") val mediaPath: String? = null,
    @Json(name = "media_bucket") val mediaBucket: String? = null,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "published_at") val publishedAt: String? = null,
    @Json(name = "visible_until") val visibleUntil: String? = null,
    @Json(name = "moderation_status") val moderationStatus: String? = null,
    @Json(name = "view_count") val viewCount: Int? = null,
    @Json(name = "views_count") val viewsCountAlt: Int? = null,
    @Json(name = "like_count") val likeCount: Int? = null,
    @Json(name = "likes_count") val likesCountAlt: Int? = null,
    @Json(name = "love_note_count") val loveNoteCount: Int? = null,
    @Json(name = "love_notes_count") val loveNotesCountAlt: Int? = null,
    @Json(name = "is_liked") val isLiked: Boolean? = null,
    @Json(name = "is_following") val isFollowing: Boolean? = null,
    @Json(name = "can_love_note") val canLoveNote: Boolean? = null,
    @Json(name = "can_voice_call") val canVoiceCall: Boolean? = null,
    @Json(name = "can_video_call") val canVideoCall: Boolean? = null,
    @Json(name = "sort_priority") val sortPriority: Int? = null
) {
    val effectiveLikesCount: Int
        get() = likeCount ?: likesCountAlt ?: 0

    val effectiveViewsCount: Int
        get() = viewCount ?: viewsCountAlt ?: 0

    val effectiveLoveNotesCount: Int
        get() = loveNoteCount ?: loveNotesCountAlt ?: 0

    val isPendingReview: Boolean
        get() = moderationStatus?.equals("pending", ignoreCase = true) == true
}

@JsonClass(generateAdapter = true)
data class SocialStoryModel(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "is_owner_host") val isOwnerHost: Boolean? = null,
    @Json(name = "is_owner") val isOwner: Boolean? = null,
    @Json(name = "is_unlocked") val isUnlocked: Boolean? = null,
    @Json(name = "is_locked") val isLocked: Boolean? = null,
    @Json(name = "unlock_price_rupees") val unlockPriceRupees: Double? = null,
    @Json(name = "media_path") val mediaPath: String? = null,
    @Json(name = "media_bucket") val mediaBucket: String? = null,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "expires_at") val expiresAt: String? = null,
    @Json(name = "is_active") val isActive: Boolean? = null,
    @Json(name = "moderation_status") val moderationStatus: String? = null,
    @Json(name = "views_count") val viewsCount: Int? = null,
    @Json(name = "likes_count") val likesCount: Int? = null,
    @Json(name = "love_notes_count") val loveNotesCount: Int? = null,
    @Json(name = "is_liked") val isLiked: Boolean? = null,
    @Json(name = "is_following") val isFollowing: Boolean? = null,
    @Json(name = "can_love_note") val canLoveNote: Boolean? = null,
    @Json(name = "can_voice_call") val canVoiceCall: Boolean? = null,
    @Json(name = "can_video_call") val canVideoCall: Boolean? = null
) {
    val isPendingReview: Boolean
        get() = moderationStatus?.equals("pending", ignoreCase = true) == true
}

@JsonClass(generateAdapter = true)
data class SocialTodayEarningsModel(
    @Json(name = "currency") val currency: String? = "INR",
    @Json(name = "today") val today: Double = 0.0,
    @Json(name = "views") val views: Double = 0.0,
    @Json(name = "likes") val likes: Double = 0.0,
    @Json(name = "love_notes") val loveNotes: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class SocialLifetimeEarningsModel(
    @Json(name = "currency") val currency: String? = "INR",
    @Json(name = "total") val total: Double = 0.0,
    @Json(name = "view_earnings") val viewEarnings: Double = 0.0,
    @Json(name = "like_earnings") val likeEarnings: Double = 0.0,
    @Json(name = "love_note_earnings") val loveNoteEarnings: Double = 0.0
)

// Request Parameters
@JsonClass(generateAdapter = true)
data class SocialFeedParams(
    @Json(name = "p_limit") val limit: Int = 20,
    @Json(name = "p_offset") val offset: Int = 0,
    @Json(name = "p_feed_mode") val feedMode: String = "for_you" // "for_you" or "following"
)

@JsonClass(generateAdapter = true)
data class SocialCreateContentParams(
    @Json(name = "p_type") val type: String, // "post" or "story"
    @Json(name = "p_media_path") val mediaPath: String,
    @Json(name = "p_caption") val caption: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialViewContentParams(
    @Json(name = "p_content_type") val contentType: String, // "post" or "story"
    @Json(name = "p_content_id") val contentId: String
)

@JsonClass(generateAdapter = true)
data class SocialToggleLikeParams(
    @Json(name = "p_content_type") val contentType: String, // "post" or "story"
    @Json(name = "p_content_id") val contentId: String
)

@JsonClass(generateAdapter = true)
data class SocialSendLoveNoteParams(
    @Json(name = "p_content_type") val contentType: String, // "post" or "story"
    @Json(name = "p_content_id") val contentId: String,
    @Json(name = "p_message") val message: String
)

@JsonClass(generateAdapter = true)
data class SocialFollowToggleParams(
    @Json(name = "p_target_user_id") val targetUserId: String
)

@JsonClass(generateAdapter = true)
data class SocialTimezoneParams(
    @Json(name = "p_timezone") val timezone: String = "Asia/Kolkata"
)
