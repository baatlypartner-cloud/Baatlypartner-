package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SocialRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager,
    private val privateMediaRepository: PrivateMediaRepository
) {
    private val TAG = "SocialRepository"

    suspend fun ensureProfile(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialEnsureProfile()
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "socialEnsureProfile error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialEnsureProfile exception", e)
            Result.failure(e)
        }
    }

    suspend fun getFeed(
        feedMode: String = "for_you",
        limit: Int = 20,
        offset: Int = 0
    ): Result<List<SocialPostModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetFeed(
                SocialFeedParams(limit = limit, offset = offset, feedMode = feedMode)
            )
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "socialGetFeed error ($feedMode): $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialGetFeed exception ($feedMode)", e)
            Result.failure(e)
        }
    }

    suspend fun getVisibleStories(): Result<List<SocialStoryModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetVisibleStories()
            if (res.isSuccessful) {
                Result.success(res.body() ?: emptyList())
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "socialGetVisibleStories error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialGetVisibleStories exception", e)
            Result.failure(e)
        }
    }

    suspend fun createContent(
        type: String, // "post" or "story"
        file: File,
        caption: String?
    ): Result<String> = withContext(Dispatchers.IO) {
        val authUid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid()
        if (authUid.isNullOrBlank()) {
            return@withContext Result.failure(Exception("Not authenticated"))
        }

        val isStory = type.equals("story", ignoreCase = true)
        val bucket = if (isStory) "stories-media" else "social-media"
        val folder = if (isStory) "stories" else "posts"
        val extension = file.extension.ifBlank { "jpg" }
        val filename = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.$extension"
        val storageObjectPath = "$authUid/$folder/$filename"

        // Determine MIME type
        val mimeType = when (extension.lowercase()) {
            "mp4", "mov", "m4v" -> "video/mp4"
            "png" -> "image/png"
            "webp" -> "image/webp"
            else -> "image/jpeg"
        }

        try {
            val requestBody = file.asRequestBody(mimeType.toMediaTypeOrNull())
            val uploadRes = supabaseClient.storageService.uploadObject(
                bucket = bucket,
                path = storageObjectPath,
                contentType = mimeType,
                body = requestBody
            )

            if (!uploadRes.isSuccessful) {
                val err = uploadRes.errorBody()?.string() ?: "Storage upload error: HTTP ${uploadRes.code()}"
                Log.e(TAG, "Storage upload failed for $bucket/$storageObjectPath: $err")
                return@withContext Result.failure(Exception(err))
            }

            // Path passed to RPC must include the bucket prefix as required by function validation
            val rpcMediaPath = "$bucket/$storageObjectPath"

            val createRes = supabaseClient.restService.socialCreateContent(
                SocialCreateContentParams(
                    type = if (isStory) "story" else "post",
                    mediaPath = rpcMediaPath,
                    caption = caption
                )
            )

            if (createRes.isSuccessful) {
                val responseRaw = createRes.body()?.string()?.trim()?.removeSurrounding("\"") ?: ""
                Log.d(TAG, "socialCreateContent success, created UUID: $responseRaw")
                Result.success(responseRaw)
            } else {
                val err = createRes.errorBody()?.string() ?: "Content creation failed: HTTP ${createRes.code()}"
                Log.e(TAG, "socialCreateContent error: $err")
                // Cleanup uploaded media
                try {
                    privateMediaRepository.deleteMedia(bucket, storageObjectPath)
                } catch (_: Exception) {}
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "createContent exception", e)
            Result.failure(e)
        }
    }

    suspend fun viewContent(contentType: String, contentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialViewContent(
                SocialViewContentParams(contentType = contentType, contentId = contentId)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "socialViewContent note: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialViewContent exception", e)
            Result.failure(e)
        }
    }

    suspend fun toggleLike(contentType: String, contentId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialToggleLike(
                SocialToggleLikeParams(contentType = contentType, contentId = contentId)
            )
            if (res.isSuccessful) {
                val raw = res.body()?.string() ?: "{}"
                val json = JSONObject(raw)
                val isLiked = json.optBoolean("liked", false)
                Result.success(isLiked)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "socialToggleLike error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialToggleLike exception", e)
            Result.failure(e)
        }
    }

    suspend fun sendLoveNote(contentType: String, contentId: String, message: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialSendLoveNote(
                SocialSendLoveNoteParams(contentType = contentType, contentId = contentId, message = message)
            )
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "socialSendLoveNote error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialSendLoveNote exception", e)
            Result.failure(e)
        }
    }

    suspend fun toggleFollow(targetUserId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialFollowToggle(
                SocialFollowToggleParams(targetUserId = targetUserId)
            )
            if (res.isSuccessful) {
                val raw = res.body()?.string() ?: "{}"
                val json = JSONObject(raw)
                val isFollowing = json.optBoolean("following", true)
                Result.success(isFollowing)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.e(TAG, "socialFollowToggle error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialFollowToggle exception", e)
            Result.failure(e)
        }
    }

    suspend fun getTodayEarnings(timezone: String = "Asia/Kolkata"): Result<SocialTodayEarningsModel> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetTodayEarnings(
                SocialTimezoneParams(timezone = timezone)
            )
            if (res.isSuccessful) {
                val raw = res.body()?.string() ?: "{}"
                val json = JSONObject(raw)
                val model = SocialTodayEarningsModel(
                    currency = json.optString("currency", "INR"),
                    today = json.optDouble("today", 0.0),
                    views = json.optDouble("views", 0.0),
                    likes = json.optDouble("likes", 0.0),
                    loveNotes = json.optDouble("love_notes", 0.0)
                )
                Result.success(model)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "socialGetTodayEarnings error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialGetTodayEarnings exception", e)
            Result.failure(e)
        }
    }

    suspend fun getLifetimeEarnings(): Result<SocialLifetimeEarningsModel> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.socialGetEarnings()
            if (res.isSuccessful) {
                val raw = res.body()?.string() ?: "{}"
                val json = JSONObject(raw)
                val model = SocialLifetimeEarningsModel(
                    currency = json.optString("currency", "INR"),
                    total = json.optDouble("total", 0.0),
                    viewEarnings = json.optDouble("view_earnings", 0.0),
                    likeEarnings = json.optDouble("like_earnings", 0.0),
                    loveNoteEarnings = json.optDouble("love_note_earnings", 0.0)
                )
                Result.success(model)
            } else {
                val err = res.errorBody()?.string() ?: "HTTP ${res.code()}"
                Log.w(TAG, "socialGetEarnings error: $err")
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "socialGetEarnings exception", e)
            Result.failure(e)
        }
    }
}
