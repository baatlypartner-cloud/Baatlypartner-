package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log

/**
 * Dedicated Call Audio Manager for Baatly Partner voice and video calls.
 * Manages Android AudioManager lifecycle, AudioFocus, and audio routing.
 * Ensures that background system sounds, notifications, or transient events
 * do not cut off active call audio, and maintains communication audio mode
 * (MODE_IN_COMMUNICATION) and audio routing throughout the call session.
 */
class CallAudioManager(
    context: Context,
    private val onFocusLostTemporarily: () -> Unit = {},
    private val onFocusRegained: () -> Unit = {}
) {
    private val TAG = "CallAudioManager"
    private val appContext = context.applicationContext ?: context
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private var previousAudioMode: Int = AudioManager.MODE_NORMAL
    private var previousMicrophoneMute: Boolean = false
    private var isFocusHeld: Boolean = false

    private var audioFocusRequest: AudioFocusRequest? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        Log.d(TAG, "ON_AUDIO_FOCUS_CHANGE: $focusChange")
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.d(TAG, "AUDIOFOCUS_GAIN: Audio focus regained. Ensuring communication mode.")
                ensureCommunicationMode()
                onFocusRegained()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.w(TAG, "AUDIOFOCUS_LOSS_TRANSIENT: Audio focus lost transiently. Preserving call audio session.")
                onFocusLostTemporarily()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                Log.d(TAG, "AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK: Notification ducking allowed. Preserving call voice.")
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.w(TAG, "AUDIOFOCUS_LOSS: Permanent audio focus loss (e.g. GSM phone call answered).")
                onFocusLostTemporarily()
            }
        }
    }

    @Synchronized
    fun requestCallAudioFocus(): Boolean {
        val am = audioManager ?: return false
        if (isFocusHeld) {
            ensureCommunicationMode()
            return true
        }

        previousAudioMode = am.mode
        previousMicrophoneMute = am.isMicrophoneMute

        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()

            audioFocusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusChangeListener,
                AudioManager.STREAM_VOICE_CALL,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }

        val granted = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        Log.d(TAG, "REQUEST_AUDIO_FOCUS_RESULT: granted=$granted, mode=${am.mode}")
        if (granted) {
            isFocusHeld = true
            ensureCommunicationMode()
        }
        return granted
    }

    @Synchronized
    fun ensureCommunicationMode() {
        val am = audioManager ?: return
        try {
            if (am.mode != AudioManager.MODE_IN_COMMUNICATION) {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                Log.d(TAG, "AudioManager mode set to MODE_IN_COMMUNICATION")
            }
            if (am.isMicrophoneMute) {
                am.isMicrophoneMute = false
                Log.d(TAG, "Unmuted AudioManager hardware microphone")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set audio mode: ${e.message}")
        }
    }

    @Synchronized
    fun releaseCallAudioFocus() {
        val am = audioManager ?: return
        if (!isFocusHeld) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { req ->
                    am.abandonAudioFocusRequest(req)
                }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(audioFocusChangeListener)
            }
            Log.d(TAG, "AUDIO_FOCUS_ABANDONED")
        } catch (e: Exception) {
            Log.w(TAG, "Error abandoning audio focus: ${e.message}")
        } finally {
            audioFocusRequest = null
            isFocusHeld = false
        }

        try {
            am.mode = previousAudioMode
            am.isMicrophoneMute = previousMicrophoneMute
            Log.d(TAG, "Restored previous audio mode: $previousAudioMode")
        } catch (e: Exception) {
            Log.w(TAG, "Error restoring previous audio mode: ${e.message}")
        }
    }
}
