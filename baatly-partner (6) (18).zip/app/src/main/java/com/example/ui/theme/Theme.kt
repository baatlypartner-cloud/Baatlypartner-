package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = BaatlyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC026D3),
    onPrimaryContainer = Color.White,
    secondary = BaatlySecondary,
    onSecondary = Color.White,
    tertiary = BaatlyPurple,
    onTertiary = Color.White,
    background = BaatlyDarkBackground,
    onBackground = TextPrimaryDark,
    surface = BaatlyDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = BaatlyDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = BaatlyDarkBorder,
    error = BaatlyRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = BaatlyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEDF2),
    onPrimaryContainer = BaatlyPrimary,
    secondary = BaatlySecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF3E8FF),
    onSecondaryContainer = BaatlySecondary,
    tertiary = BaatlyPurple,
    onTertiary = Color.White,
    background = BaatlyLightBackground,
    onBackground = TextPrimaryLight,
    surface = BaatlyLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = BaatlyLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = BaatlyLightBorder,
    error = BaatlyRed,
    onError = Color.White
)

val BaatlyShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),  // Buttons 18-20dp
    large = RoundedCornerShape(22.dp),   // Cards 22-24dp
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun BaatlyPartnerTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = BaatlyShapes,
        content = content
    )
}
