package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.SessionManager
import com.example.data.models.*
import com.example.data.repository.SocialRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class SocialUiState(
    val feedMode: String = "for_you", // "for_you" or "following"
    val forYouPosts: List<SocialPostModel> = emptyList(),
    val followingPosts: List<SocialPostModel> = emptyList(),
    val stories: List<SocialStoryModel> = emptyList(),
    val todayEarnings: SocialTodayEarningsModel = SocialTodayEarningsModel(),
    val lifetimeEarnings: SocialLifetimeEarningsModel = SocialLifetimeEarningsModel(),
    val isLoadingFeed: Boolean = false,
    val isLoadingStories: Boolean = false,
    val isLoadingEarnings: Boolean = false,
    val isCreatingContent: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val currentAuthUid: String? = null
)

class SocialViewModel(
    private val socialRepository: SocialRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val TAG = "SocialViewModel"

    private val _uiState = MutableStateFlow(
        SocialUiState(currentAuthUid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid())
    )
    val uiState: StateFlow<SocialUiState> = _uiState.asStateFlow()

    init {
        loadAll()
    }

    fun loadAll() {
        _uiState.value = _uiState.value.copy(
            currentAuthUid = sessionManager.authUuid.value ?: sessionManager.getStoredAuthUuid(),
            errorMessage = null
        )
        viewModelScope.launch {
            socialRepository.ensureProfile()
        }
        loadFeed("for_you")
        loadFeed("following")
        loadStories()
        loadEarnings()
    }

    fun refreshAll() = loadAll()

    fun setFeedMode(mode: String) {
        if (_uiState.value.feedMode != mode) {
            _uiState.value = _uiState.value.copy(feedMode = mode)
            if (mode == "following" && _uiState.value.followingPosts.isEmpty()) {
                loadFeed("following")
            }
        }
    }

    fun loadFeed(mode: String = _uiState.value.feedMode, offset: Int = 0) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingFeed = true)
            val res = socialRepository.getFeed(feedMode = mode, limit = 30, offset = offset)
            if (res.isSuccess) {
                val posts = res.getOrNull() ?: emptyList()
                if (mode == "for_you") {
                    _uiState.value = _uiState.value.copy(
                        forYouPosts = posts,
                        isLoadingFeed = false
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        followingPosts = posts,
                        isLoadingFeed = false
                    )
                }
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to load feed"
                Log.e(TAG, "loadFeed error ($mode): $err")
                _uiState.value = _uiState.value.copy(
                    isLoadingFeed = false,
                    errorMessage = if (mode == _uiState.value.feedMode) err else _uiState.value.errorMessage
                )
            }
        }
    }

    fun loadStories() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingStories = true)
            val res = socialRepository.getVisibleStories()
            if (res.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    stories = res.getOrNull() ?: emptyList(),
                    isLoadingStories = false
                )
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to load stories"
                Log.e(TAG, "loadStories error: $err")
                _uiState.value = _uiState.value.copy(
                    isLoadingStories = false
                )
            }
        }
    }

    fun loadEarnings() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingEarnings = true)
            val todayRes = socialRepository.getTodayEarnings("Asia/Kolkata")
            val lifetimeRes = socialRepository.getLifetimeEarnings()

            val today = todayRes.getOrNull() ?: _uiState.value.todayEarnings
            val lifetime = lifetimeRes.getOrNull() ?: _uiState.value.lifetimeEarnings

            _uiState.value = _uiState.value.copy(
                todayEarnings = today,
                lifetimeEarnings = lifetime,
                isLoadingEarnings = false
            )
        }
    }

    fun toggleLikePost(post: SocialPostModel) {
        val currentlyLiked = post.isLiked ?: false
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        // Optimistically update post in state
        fun updateList(list: List<SocialPostModel>): List<SocialPostModel> {
            return list.map {
                if (it.id == post.id) {
                    it.copy(
                        isLiked = newLiked,
                        likeCount = maxOf(0, it.effectiveLikesCount + delta)
                    )
                } else it
            }
        }

        _uiState.value = _uiState.value.copy(
            forYouPosts = updateList(_uiState.value.forYouPosts),
            followingPosts = updateList(_uiState.value.followingPosts)
        )

        viewModelScope.launch {
            val res = socialRepository.toggleLike("post", post.id)
            if (res.isFailure) {
                // Revert on failure
                fun revertList(list: List<SocialPostModel>): List<SocialPostModel> {
                    return list.map {
                        if (it.id == post.id) {
                            it.copy(
                                isLiked = currentlyLiked,
                                likeCount = maxOf(0, it.effectiveLikesCount - delta)
                            )
                        } else it
                    }
                }
                _uiState.value = _uiState.value.copy(
                    forYouPosts = revertList(_uiState.value.forYouPosts),
                    followingPosts = revertList(_uiState.value.followingPosts)
                )
            }
        }
    }

    fun toggleLikeStory(story: SocialStoryModel) {
        val currentlyLiked = story.isLiked ?: false
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        _uiState.value = _uiState.value.copy(
            stories = _uiState.value.stories.map {
                if (it.id == story.id) {
                    it.copy(
                        isLiked = newLiked,
                        likesCount = maxOf(0, (it.likesCount ?: 0) + delta)
                    )
                } else it
            }
        )

        viewModelScope.launch {
            val res = socialRepository.toggleLike("story", story.id)
            if (res.isFailure) {
                _uiState.value = _uiState.value.copy(
                    stories = _uiState.value.stories.map {
                        if (it.id == story.id) {
                            it.copy(
                                isLiked = currentlyLiked,
                                likesCount = maxOf(0, (it.likesCount ?: 0) - delta)
                            )
                        } else it
                    }
                )
            }
        }
    }

    fun toggleFollow(targetUserId: String) {
        viewModelScope.launch {
            val res = socialRepository.toggleFollow(targetUserId)
            if (res.isSuccess) {
                val isNowFollowing = res.getOrNull() ?: true
                // Update following flag in displayed posts
                fun updatePosts(list: List<SocialPostModel>): List<SocialPostModel> {
                    return list.map {
                        if (it.ownerId == targetUserId || it.signupUserId == targetUserId) {
                            it.copy(isFollowing = isNowFollowing)
                        } else it
                    }
                }
                _uiState.value = _uiState.value.copy(
                    forYouPosts = updatePosts(_uiState.value.forYouPosts),
                    followingPosts = updatePosts(_uiState.value.followingPosts)
                )
                // If following feed was active, refresh it
                if (_uiState.value.feedMode == "following") {
                    loadFeed("following")
                }
            } else {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Follow action failed: ${res.exceptionOrNull()?.message}"
                )
            }
        }
    }

    fun sendLoveNote(contentType: String, contentId: String, message: String, onComplete: (Boolean) -> Unit) {
        if (message.isBlank()) return
        viewModelScope.launch {
            val res = socialRepository.sendLoveNote(contentType, contentId, message.trim())
            if (res.isSuccess) {
                _uiState.value = _uiState.value.copy(successMessage = "Love Note sent successfully!")
                // Increment love note count locally
                if (contentType == "post") {
                    fun updatePosts(list: List<SocialPostModel>): List<SocialPostModel> {
                        return list.map {
                            if (it.id == contentId) {
                                it.copy(loveNoteCount = it.effectiveLoveNotesCount + 1)
                            } else it
                        }
                    }
                    _uiState.value = _uiState.value.copy(
                        forYouPosts = updatePosts(_uiState.value.forYouPosts),
                        followingPosts = updatePosts(_uiState.value.followingPosts)
                    )
                }
                onComplete(true)
            } else {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Failed to send Love Note: ${res.exceptionOrNull()?.message}"
                )
                onComplete(false)
            }
        }
    }

    fun viewContent(contentType: String, contentId: String) {
        viewModelScope.launch {
            socialRepository.viewContent(contentType, contentId)
        }
    }

    fun createPost(file: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isCreatingContent = true, errorMessage = null)
            val res = socialRepository.createContent("post", file, caption)
            if (res.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isCreatingContent = false,
                    successMessage = "Post submitted! (Pending review)"
                )
                loadFeed("for_you")
                onComplete(true)
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to upload post"
                Log.e(TAG, "createPost error: $err")
                _uiState.value = _uiState.value.copy(
                    isCreatingContent = false,
                    errorMessage = err
                )
                onComplete(false)
            }
        }
    }

    fun createStory(file: File, caption: String?, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isCreatingContent = true, errorMessage = null)
            val res = socialRepository.createContent("story", file, caption)
            if (res.isSuccess) {
                _uiState.value = _uiState.value.copy(
                    isCreatingContent = false,
                    successMessage = "Story shared! (Pending review)"
                )
                loadStories()
                onComplete(true)
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to upload story"
                Log.e(TAG, "createStory error: $err")
                _uiState.value = _uiState.value.copy(
                    isCreatingContent = false,
                    errorMessage = err
                )
                onComplete(false)
            }
        }
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }
}

class SocialViewModelFactory(
    private val socialRepository: SocialRepository,
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SocialViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SocialViewModel(socialRepository, sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
