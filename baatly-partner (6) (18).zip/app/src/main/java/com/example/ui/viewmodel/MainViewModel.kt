package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.CallModel
import com.example.data.models.PartnerProfile
import com.example.data.models.Profile
import com.example.data.repository.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.example.data.models.HostDailyScoreModel
import com.example.data.models.HostScoreThresholdModel
import com.example.data.models.HostWeeklyScoreModel

data class HomeUiData(
    val profile: Profile? = null,
    val partnerProfile: PartnerProfile? = null,
    val isCallOnline: Boolean = false,
    val isChatOnline: Boolean = false,
    val isVideoOnline: Boolean = false,
    val videoAccessStatus: String = "not_requested", // not_requested, pending, approved, rejected, suspended
    val isVideoAccessApproved: Boolean = false,
    val videoRejectionReason: String? = null,
    val todayEarnings: TodayEarningsBreakdown = TodayEarningsBreakdown(),
    val averageCallDurationSeconds: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val incomingCall: CallModel? = null,
    val isSuspended: Boolean = false,
    val suspensionReason: String? = null,
    val dailyPerformanceScore: HostDailyScoreModel? = null,
    val weeklyPerformanceScore: HostWeeklyScoreModel? = null,
    val performanceThresholds: List<HostScoreThresholdModel> = emptyList(),
    val isRefreshingPerformance: Boolean = false
)

class MainViewModel(
    private val partnerRepository: PartnerRepository,
    private val callRepository: CallRepository,
    private val walletRepository: WalletRepository,
    val privateMediaRepository: PrivateMediaRepository? = null,
    val hostPresenceManager: HostPresenceManager? = null,
    val hostPerformanceRepository: HostPerformanceRepository? = null
) : ViewModel() {

    private val _uiData = MutableStateFlow(HomeUiData())
    val uiData: StateFlow<HomeUiData> = _uiData.asStateFlow()

    private val handledCallIds = mutableSetOf<String>()
    private var incomingCallPollerJob: Job? = null
    private var ringTimeoutJob: Job? = null

    init {
        loadAllData()
        startIncomingCallPoller()
        observePerformance()
    }

    private fun observePerformance() {
        val repo = hostPerformanceRepository ?: return
        viewModelScope.launch {
            repo.todayDailyScore.collect { score ->
                _uiData.value = _uiData.value.copy(dailyPerformanceScore = score)
            }
        }
        viewModelScope.launch {
            repo.weeklyScores.collect { list ->
                _uiData.value = _uiData.value.copy(weeklyPerformanceScore = list.firstOrNull())
            }
        }
        viewModelScope.launch {
            repo.thresholds.collect { thresholdsList ->
                _uiData.value = _uiData.value.copy(performanceThresholds = thresholdsList)
            }
        }
    }

    fun refreshPerformance() {
        val repo = hostPerformanceRepository ?: return
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(isRefreshingPerformance = true)
            repo.getTodayDailyScore(forceRefresh = true)
            repo.getWeeklyScores(limit = 1)
            repo.getScoreThresholds()
            _uiData.value = _uiData.value.copy(
                isRefreshingPerformance = false,
                dailyPerformanceScore = repo.todayDailyScore.value,
                weeklyPerformanceScore = repo.weeklyScores.value.firstOrNull(),
                performanceThresholds = repo.thresholds.value
            )
        }
    }

    fun refreshEarnings() {
        viewModelScope.launch {
            val earningsRes = walletRepository.getTodayEarningsBreakdown()
            val earnings = earningsRes.getOrNull() ?: com.example.data.repository.TodayEarningsBreakdown(
                regularStatus = com.example.data.repository.EarningsFetchStatus.FAILED,
                socialStatus = com.example.data.repository.EarningsFetchStatus.FAILED,
                errorMessage = earningsRes.exceptionOrNull()?.message
            )
            _uiData.value = _uiData.value.copy(todayEarnings = earnings)
        }
    }

    fun loadAllData() {
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(isLoading = true, errorMessage = null)

            val profileRes = partnerRepository.getProfile()
            val partnerProfileRes = partnerRepository.getPartnerProfile()
            val videoStatusRes = partnerRepository.getVideoCallAccessStatus()
            val earningsRes = walletRepository.getTodayEarningsBreakdown()
            val avgDurationRes = callRepository.getAverageCallDuration()

            val profile = profileRes.getOrNull()
            val partnerProfile = partnerProfileRes.getOrNull()
            val videoStatus = videoStatusRes.getOrNull()
            val earnings = earningsRes.getOrNull() ?: com.example.data.repository.TodayEarningsBreakdown(
                regularStatus = com.example.data.repository.EarningsFetchStatus.FAILED,
                socialStatus = com.example.data.repository.EarningsFetchStatus.FAILED,
                errorMessage = earningsRes.exceptionOrNull()?.message
            )
            val avgDuration = avgDurationRes.getOrNull() ?: 0

            val isSuspended = profile?.accountStatus?.equals("suspended", ignoreCase = true) == true ||
                    partnerProfile?.approvalStatus?.equals("suspended", ignoreCase = true) == true

            val isCall = !isSuspended && (partnerProfile?.audioEnabled == true) && (partnerProfile.isAvailable == true)
            val isChat = !isSuspended && (partnerProfile?.chatEnabled == true)

            // Authoritative calculation of video call access:
            val currentVideoAccessStatus = _uiData.value.videoAccessStatus
            val currentIsVideoApproved = _uiData.value.isVideoAccessApproved
            val currentIsVideoOnline = _uiData.value.isVideoOnline
            val currentRejectionReason = _uiData.value.videoRejectionReason

            val isPartner = (partnerProfile?.isPartner == true)
            val isApproved = partnerProfile?.approvalStatus?.equals("approved", ignoreCase = true) == true
            val hasVideoCallAccess = partnerProfile?.videoCallAccess == true

            val finalVideoApproved = !isSuspended && isPartner && isApproved && hasVideoCallAccess

            // Authoritative video availability: strictly requires all backend conditions
            // is_partner = true, approval_status = approved, is_suspended = false,
            // video_call_access = true, video_enabled = true, is_online = true
            val finalVideoOnline = finalVideoApproved &&
                    (partnerProfile?.videoEnabled == true) &&
                    (partnerProfile?.isOnline == true)

            val finalVideoStatus: String
            val finalRejectionReason: String?

            if (videoStatus != null) {
                finalVideoStatus = if (finalVideoApproved) {
                    "approved"
                } else {
                    videoStatus.requestStatus?.ifBlank { "not_requested" } ?: "not_requested"
                }
                finalRejectionReason = videoStatus.requestRejectionReason
            } else {
                finalVideoStatus = if (finalVideoApproved) "approved" else currentVideoAccessStatus
                finalRejectionReason = currentRejectionReason
            }

            _uiData.value = _uiData.value.copy(
                profile = profile,
                partnerProfile = partnerProfile,
                isCallOnline = isCall,
                isChatOnline = isChat,
                isVideoOnline = finalVideoOnline,
                videoAccessStatus = finalVideoStatus,
                isVideoAccessApproved = finalVideoApproved,
                videoRejectionReason = finalRejectionReason,
                todayEarnings = earnings,
                averageCallDurationSeconds = avgDuration,
                isLoading = false,
                errorMessage = null,
                isSuspended = isSuspended,
                suspensionReason = if (isSuspended) "Account suspended: Host services are restricted." else null
            )

            // Sync Host Presence state with backend-authoritative values
            hostPresenceManager?.updatePresenceForAvailability(
                isCallOnline = isCall,
                isChatOnline = isChat,
                isSuspended = isSuspended
            )

            // Refresh today's daily and weekly scores if repo available
            hostPerformanceRepository?.getTodayDailyScore()
            hostPerformanceRepository?.getWeeklyScores(limit = 1)
        }
    }

    fun toggleCallAvailability(enabled: Boolean) {
        viewModelScope.launch {
            if (_uiData.value.isSuspended) {
                _uiData.value = _uiData.value.copy(errorMessage = "Account is suspended. You cannot go online.")
                return@launch
            }

            val currentChat = _uiData.value.isChatOnline
            val displayName = _uiData.value.partnerProfile?.partnerDisplayName ?: _uiData.value.profile?.displayName

            val isAvailable = enabled
            val isOnline = enabled || currentChat
            val audioEnabled = enabled
            val chatEnabled = currentChat

            // Temporarily show loading without optimistically locking UI to wrong state
            _uiData.value = _uiData.value.copy(isLoading = true, errorMessage = null)

            val res = partnerRepository.updateServiceAvailability(
                displayName = displayName,
                isAvailable = isAvailable,
                isOnline = isOnline,
                audioEnabled = audioEnabled,
                chatEnabled = chatEnabled
            )

            if (res.isFailure) {
                _uiData.value = _uiData.value.copy(
                    isLoading = false,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to update call status"
                )
            } else {
                // Immediately start/end presence based on user request (source of truth for session)
                if (enabled) {
                    hostPresenceManager?.startCallPresence()
                } else {
                    hostPresenceManager?.endCallPresence("user_toggled_off")
                }

                // Update UI state immediately to requested toggle
                _uiData.value = _uiData.value.copy(
                    isCallOnline = enabled,
                    isLoading = false,
                    errorMessage = null
                )

                // Refresh profile after presence update
                val updatedPartnerProfile = partnerRepository.getPartnerProfile().getOrNull()
                if (updatedPartnerProfile != null) {
                    _uiData.value = _uiData.value.copy(partnerProfile = updatedPartnerProfile)
                }
            }
        }
    }

    fun toggleChatAvailability(enabled: Boolean) {
        viewModelScope.launch {
            if (_uiData.value.isSuspended) {
                _uiData.value = _uiData.value.copy(errorMessage = "Account is suspended. You cannot go online.")
                return@launch
            }

            val currentCall = _uiData.value.isCallOnline
            val displayName = _uiData.value.partnerProfile?.partnerDisplayName ?: _uiData.value.profile?.displayName

            val isAvailable = currentCall
            val isOnline = enabled || currentCall
            val audioEnabled = currentCall
            val chatEnabled = enabled

            _uiData.value = _uiData.value.copy(isLoading = true, errorMessage = null)

            val res = partnerRepository.updateServiceAvailability(
                displayName = displayName,
                isAvailable = isAvailable,
                isOnline = isOnline,
                audioEnabled = audioEnabled,
                chatEnabled = chatEnabled
            )

            if (res.isFailure) {
                _uiData.value = _uiData.value.copy(
                    isLoading = false,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to update chat status"
                )
            } else {
                // Immediately start/end chat presence based on user request
                if (enabled) {
                    hostPresenceManager?.startChatPresence()
                } else {
                    hostPresenceManager?.endChatPresence("user_toggled_off")
                }

                // Update UI state immediately to requested toggle
                _uiData.value = _uiData.value.copy(
                    isChatOnline = enabled,
                    isLoading = false,
                    errorMessage = null
                )

                // Refresh profile after presence update
                val updatedPartnerProfile = partnerRepository.getPartnerProfile().getOrNull()
                if (updatedPartnerProfile != null) {
                    _uiData.value = _uiData.value.copy(partnerProfile = updatedPartnerProfile)
                }
            }
        }
    }

    fun toggleVideoAvailability(enabled: Boolean) {
        viewModelScope.launch {
            if (_uiData.value.isSuspended) {
                _uiData.value = _uiData.value.copy(errorMessage = "Account is suspended. You cannot go online.")
                return@launch
            }
            if (!_uiData.value.isVideoAccessApproved) {
                _uiData.value = _uiData.value.copy(errorMessage = "Video call access is not approved yet.")
                return@launch
            }

            // Do NOT set isVideoOnline = true locally before backend confirms
            _uiData.value = _uiData.value.copy(isLoading = true, errorMessage = null)

            val res = partnerRepository.setVideoEnabled(enabled)
            if (res.isFailure) {
                _uiData.value = _uiData.value.copy(
                    isLoading = false,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to update video status"
                )
            } else {
                // Fetch fresh status authoritatively from backend
                refreshVideoAccessStatus()
            }
        }
    }

    fun refreshVideoAccessStatus() {
        viewModelScope.launch {
            val videoStatusRes = partnerRepository.getVideoCallAccessStatus()
            val partnerProfileRes = partnerRepository.getPartnerProfile()
            val videoStatus = videoStatusRes.getOrNull()
            val partnerProfile = partnerProfileRes.getOrNull() ?: _uiData.value.partnerProfile

            val isPartner = (partnerProfile?.isPartner == true)
            val isApproved = partnerProfile?.approvalStatus?.equals("approved", ignoreCase = true) == true
            val isSuspended = _uiData.value.isSuspended ||
                    (partnerProfile?.approvalStatus?.equals("suspended", ignoreCase = true) == true)
            val hasVideoCallAccess = partnerProfile?.videoCallAccess == true

            val isVideoApproved = !isSuspended && isPartner && isApproved && hasVideoCallAccess

            // Authoritative single-source video availability strictly based on backend partner_profiles.video_enabled
            // No OR logic
            val isVideoOnline = isVideoApproved &&
                    (partnerProfile?.videoEnabled == true) &&
                    (partnerProfile?.isOnline == true)

            val displayRequestStatus = if (isVideoApproved) {
                "approved"
            } else {
                videoStatus?.requestStatus?.ifBlank { "not_requested" } ?: "not_requested"
            }

            _uiData.value = _uiData.value.copy(
                partnerProfile = partnerProfile,
                videoAccessStatus = displayRequestStatus,
                isVideoAccessApproved = isVideoApproved,
                isVideoOnline = isVideoOnline,
                videoRejectionReason = videoStatus?.requestRejectionReason,
                isLoading = false
            )
        }
    }

    fun submitVideoCallAccessRequest(
        videoFile: java.io.File,
        durationSeconds: Int = 30,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(
                isLoading = true
            )
            val res = partnerRepository.submitVideoCallAccessRequest(videoFile, durationSeconds)
            if (res.isSuccess) {
                // Fetch fresh authoritative status from RPC immediately
                val videoStatusRes = partnerRepository.getVideoCallAccessStatus()
                val partnerProfile = _uiData.value.partnerProfile
                val videoStatus = videoStatusRes.getOrNull()

                val isPartner = (partnerProfile?.isPartner == true)
                val isApproved = partnerProfile?.approvalStatus?.equals("approved", ignoreCase = true) == true
                val hasVideoCallAccess = partnerProfile?.videoCallAccess == true

                val isVideoApproved = isPartner && isApproved && hasVideoCallAccess

                val displayRequestStatus = if (isVideoApproved) {
                    "approved"
                } else {
                    videoStatus?.requestStatus?.ifBlank { "pending" } ?: "pending"
                }

                _uiData.value = _uiData.value.copy(
                    videoAccessStatus = displayRequestStatus,
                    isVideoAccessApproved = isVideoApproved,
                    videoRejectionReason = videoStatus?.requestRejectionReason,
                    isLoading = false
                )
                onComplete(true, null)
            } else {
                _uiData.value = _uiData.value.copy(isLoading = false)
                val errorMsg = res.exceptionOrNull()?.message ?: "Failed to submit video access request"
                onComplete(false, errorMsg)
            }
        }
    }

    private fun startIncomingCallPoller() {
        incomingCallPollerJob?.cancel()
        incomingCallPollerJob = viewModelScope.launch {
            val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }

            while (isActive) {
                // Poll for incoming call if Call or Video is online
                if (_uiData.value.isCallOnline || _uiData.value.isVideoOnline) {
                    val incoming = callRepository.checkForIncomingCall().getOrNull()
                    if (incoming != null) {
                        if (handledCallIds.contains(incoming.id) || incoming.endedAt != null) {
                            if (_uiData.value.incomingCall?.id == incoming.id) {
                                com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                                com.example.BaatlyApp.instance?.let { ctx ->
                                    com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, incoming.id)
                                }
                                _uiData.value = _uiData.value.copy(incomingCall = null)
                            }
                        } else {
                            // Check age (30s threshold)
                            val callTimeStr = incoming.ringingAt ?: incoming.requestedAt ?: incoming.createdAt
                            val callTime = try {
                                callTimeStr?.let { isoFormat.parse(it.substring(0, 19))?.time }
                            } catch (_: Exception) { null }

                            val isStale = callTime != null && (System.currentTimeMillis() - callTime > 30_000)

                            if (isStale || incoming.status in listOf("missed", "rejected", "cancelled", "completed", "ended")) {
                                handledCallIds.add(incoming.id)
                                com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                                com.example.BaatlyApp.instance?.let { ctx ->
                                    com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, incoming.id)
                                }
                                if (_uiData.value.incomingCall?.id == incoming.id) {
                                    _uiData.value = _uiData.value.copy(incomingCall = null)
                                }
                            } else {
                                // Transition requested -> ringing immediately
                                if (incoming.status == "requested") {
                                    callRepository.markCallRinging(incoming.id)
                                }

                                if (_uiData.value.incomingCall?.id != incoming.id) {
                                    _uiData.value = _uiData.value.copy(incomingCall = incoming)
                                    startRingTimeout(incoming.id)
                                }
                            }
                        }
                    } else {
                        if (_uiData.value.incomingCall != null) {
                            val activeCallId = _uiData.value.incomingCall?.id
                            com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                            if (activeCallId != null) {
                                com.example.BaatlyApp.instance?.let { ctx ->
                                    com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, activeCallId)
                                }
                            }
                            _uiData.value = _uiData.value.copy(incomingCall = null)
                        }
                    }
                } else {
                    if (_uiData.value.incomingCall != null) {
                        val activeCallId = _uiData.value.incomingCall?.id
                        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                        if (activeCallId != null) {
                            com.example.BaatlyApp.instance?.let { ctx ->
                                com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, activeCallId)
                            }
                        }
                        _uiData.value = _uiData.value.copy(incomingCall = null)
                    }
                }
                delay(3000)
            }
        }
    }

    private fun startRingTimeout(callId: String) {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = viewModelScope.launch {
            delay(30_000) // 30 seconds max ringing timeout
            if (_uiData.value.incomingCall?.id == callId) {
                com.example.data.audio.IncomingCallAudioManager.stopRingtone()
                com.example.BaatlyApp.instance?.let { ctx ->
                    com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, callId)
                }
                handledCallIds.add(callId)
                _uiData.value = _uiData.value.copy(incomingCall = null)
            }
        }
    }

    fun updateProfile(
        displayName: String?,
        bio: String? = null,
        age: Int? = null,
        avatarFile: java.io.File? = null,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(isLoading = true)
            val res = partnerRepository.updateHostProfile(displayName, bio, age, avatarFile)
            if (res.isSuccess) {
                privateMediaRepository?.invalidateCache("profile-media")
                loadAllData()
                onResult(true, null)
            } else {
                _uiData.value = _uiData.value.copy(isLoading = false)
                onResult(false, res.exceptionOrNull()?.message ?: "Failed to update profile")
            }
        }
    }

    fun dismissIncomingCall(callId: String? = null) {
        ringTimeoutJob?.cancel()
        com.example.data.audio.IncomingCallAudioManager.stopRingtone()
        val targetId = callId ?: _uiData.value.incomingCall?.id
        if (targetId != null) {
            handledCallIds.add(targetId)
            com.example.BaatlyApp.instance?.let { ctx ->
                com.example.data.notification.NotificationHelper.cancelIncomingCallNotification(ctx, targetId)
            }
        }
        _uiData.value = _uiData.value.copy(incomingCall = null)
    }

    fun clearError() {
        _uiData.value = _uiData.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        incomingCallPollerJob?.cancel()
        ringTimeoutJob?.cancel()
        hostPresenceManager?.endPresence()
    }
}

class MainViewModelFactory(
    private val partnerRepository: PartnerRepository,
    private val callRepository: CallRepository,
    private val walletRepository: WalletRepository,
    private val privateMediaRepository: PrivateMediaRepository? = null,
    private val hostPresenceManager: HostPresenceManager? = null,
    private val hostPerformanceRepository: HostPerformanceRepository? = null
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(
                partnerRepository,
                callRepository,
                walletRepository,
                privateMediaRepository,
                hostPresenceManager,
                hostPerformanceRepository
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
