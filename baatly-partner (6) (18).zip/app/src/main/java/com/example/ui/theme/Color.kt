package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ============================================================
// BAATLY BRAND DESIGN SYSTEM - OFFICIAL PALETTE
// ============================================================

// Exact Brand Colors
val BaatlyLightBackground = Color(0xFFFFF8F3) // Warm Cream Background
val BaatlyPrimary = Color(0xFFFF2D68)         // Vibrant Brand Pink / Rose
val BaatlyPrimaryLight = Color(0xFFFFF1F5)    // Soft Pink Tint / Container
val BaatlyPrimaryBorder = Color(0xFFFECDD6)   // Soft Pink Border
val BaatlySecondary = Color(0xFF7C3AED)       // Premium Purple Accent
val BaatlyTertiary = Color(0xFFC026D3)        // Magenta Accent
val BaatlyLightCard = Color(0xFFFFFFFF)       // Crisp White Card
val BaatlyLightSurface = Color(0xFFFFFFFF)    // Crisp White Surface
val BaatlyLightSurfaceVariant = Color(0xFFFFF1EB) // Soft Cream Tint

// Text Colors
val TextPrimaryLight = Color(0xFF171717)      // Deep Near-Black
val TextSecondaryLight = Color(0xFF777777)    // Readable Muted Slate
val TextMutedLight = Color(0xFFA3A3A3)        // Muted Caption Grey

// Status & Semantic Colors
val BaatlyGreen = Color(0xFF10B981)           // Soft Readable Emerald Green
val BaatlyGreenLight = Color(0xFFECFDF5)      // Green Container
val BaatlyGreenBorder = Color(0xFFA7F3D0)

val BaatlyRed = Color(0xFFF43F5E)             // Soft Rose Red
val BaatlyRedLight = Color(0xFFFFF1F2)
val BaatlyRedBorder = Color(0xFFFECDD3)

val BaatlyGold = Color(0xFFF59E0B)            // Soft Warm Amber
val BaatlyGoldLight = Color(0xFFFFFBEB)
val BaatlyGoldBorder = Color(0xFFFDE68A)

val BaatlyBlue = Color(0xFF3B82F6)            // Sky Blue Accent
val BaatlyBlueLight = Color(0xFFEFF6FF)

val BaatlyCyan = Color(0xFF06B6D4)            // Cyan Accent
val BaatlyCyanLight = Color(0xFFECFEFF)

val BaatlyPurple = Color(0xFF8B5CF6)          // Soft Violet
val BaatlyPurpleLight = Color(0xFFF5F3FF)

val BaatlySlate = Color(0xFF64748B)           // Neutral Grey for Unselected Icons
val BaatlySlateLight = Color(0xFFF8FAFC)

// Borders & Dividers
val BaatlyLightBorder = Color(0xFFF3E8E2)     // Subtle Warm Border
val BaatlyBorderSubtle = Color(0xFFFCE7F0)    // Soft Pink Border

// Dark Theme Fallback Variants
val BaatlyDarkBackground = Color(0xFF171216)
val BaatlyDarkSurface = Color(0xFF221A20)
val BaatlyDarkSurfaceVariant = Color(0xFF2E242C)
val BaatlyDarkCard = Color(0xFF221A20)
val BaatlyDarkBorder = Color(0xFF3A2E38)
val TextPrimaryDark = Color(0xFFFDF8F5)
val TextSecondaryDark = Color(0xFFA89F9E)

// Primary Gradient for Highlights, Selected Nav, Premium Buttons, and Earnings
val BaatlyGradient = Brush.horizontalGradient(
    listOf(Color(0xFFFF2D68), Color(0xFF7C3AED))
)

val BaatlyGradientVertical = Brush.verticalGradient(
    listOf(Color(0xFFFF2D68), Color(0xFF7C3AED))
)

val BaatlyEarningsGradient = Brush.linearGradient(
    listOf(
        Color(0xFF7C3AED), // Deep Purple
        Color(0xFFC026D3), // Magenta
        Color(0xFFFF2D68)  // Vibrant Pink
    )
)

val BaatlyCardGlowGradient = Brush.horizontalGradient(
    listOf(Color(0xFFFFF1F5), Color(0xFFF6EEFF))
)
