package com.example.ui.screens.social

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.models.SocialPostModel
import com.example.data.models.SocialStoryModel
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.data.repository.rememberSocialMediaUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.SocialViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(
    socialViewModel: SocialViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by socialViewModel.uiState.collectAsState()
    val privateMediaRepo = (context.applicationContext as BaatlyApp).privateMediaRepository

    var showCreatePostDialog by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var selectedStoryForViewer by remember { mutableStateOf<SocialStoryModel?>(null) }
    var loveNoteTarget by remember { mutableStateOf<Pair<String, String>?>(null) } // Pair(contentType, contentId)
    var showEarningsBreakdown by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.errorMessage, uiState.successMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
        uiState.successMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = Color.White,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Social",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "Creator Community & Stories",
                            fontSize = 11.sp,
                            color = TextSecondaryLight
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Earnings toggle badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (showEarningsBreakdown) BaatlyPrimary else Color(0xFFFFF1EB))
                                .clickable { showEarningsBreakdown = !showEarningsBreakdown }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("social_earnings_badge")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = if (showEarningsBreakdown) Color.White else BaatlyPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "₹${String.format(java.util.Locale.US, "%.1f", uiState.todayEarnings.today)}",
                                    color = if (showEarningsBreakdown) Color.White else BaatlyPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Create Post action button
                        IconButton(
                            onClick = { showCreatePostDialog = true },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(BaatlyGradient)
                                .testTag("create_post_button")
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Create Post",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Refresh button
                        IconButton(
                            onClick = { socialViewModel.loadAll() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF8FAFC))
                                .border(1.dp, BaatlyLightBorder, CircleShape)
                                .testTag("refresh_social_button")
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = BaatlySlate,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = BaatlyLightBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Social Earnings Breakdown Card (Expandable)
            if (showEarningsBreakdown) {
                item(key = "social_earnings_card") {
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        SocialEarningsDashboardCard(
                            today = uiState.todayEarnings,
                            lifetime = uiState.lifetimeEarnings,
                            onClose = { showEarningsBreakdown = false }
                        )
                    }
                }
            }

            // Stories Row Section
            item(key = "stories_section") {
                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                    Text(
                        text = "Stories",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. "Your Story" button
                        item(key = "create_your_story_item") {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { showCreateStoryDialog = true }
                                    .testTag("create_story_item")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .border(2.dp, Color(0xFFFF2D68), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFFFF1EB)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Add,
                                            contentDescription = "Add Story",
                                            tint = BaatlyPrimary,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Your Story",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimaryLight
                                )
                            }
                        }

                        // 2. Visible Stories List
                        items(uiState.stories, key = { it.id }) { story ->
                            val resolvedStoryAvatar by rememberProfileAvatarUrl(story.avatarUrl, privateMediaRepo)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable {
                                        selectedStoryForViewer = story
                                        socialViewModel.viewContent("story", story.id)
                                    }
                                    .testTag("story_item_${story.id}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(BaatlyGradient)
                                        .padding(2.5.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                ) {
                                    if (!resolvedStoryAvatar.isNullOrBlank()) {
                                        Image(
                                            painter = rememberAsyncImagePainter(model = resolvedStoryAvatar),
                                            contentDescription = story.displayName,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color(0xFFF3E8FF)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = (story.displayName ?: "H").take(1).uppercase(),
                                                color = BaatlySecondary,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = story.displayName?.takeIf { it.isNotBlank() } ?: "Host",
                                    fontSize = 11.sp,
                                    color = TextPrimaryLight,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 68.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // Feed Mode Switcher: For You vs Following
            item(key = "feed_mode_switcher") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White)
                            .border(1.dp, BaatlyLightBorder, RoundedCornerShape(20.dp))
                            .padding(4.dp)
                    ) {
                        Row {
                            FeedTabButton(
                                title = "For You",
                                isSelected = uiState.feedMode == "for_you",
                                onClick = { socialViewModel.setFeedMode("for_you") },
                                testTag = "feed_tab_for_you"
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            FeedTabButton(
                                title = "Following",
                                isSelected = uiState.feedMode == "following",
                                onClick = { socialViewModel.setFeedMode("following") },
                                testTag = "feed_tab_following"
                            )
                        }
                    }
                }
            }

            val currentPosts = if (uiState.feedMode == "for_you") uiState.forYouPosts else uiState.followingPosts

            if (uiState.isLoadingFeed && currentPosts.isEmpty()) {
                item(key = "loading_feed") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BaatlyPrimary, modifier = Modifier.size(32.dp))
                    }
                }
            } else if (currentPosts.isEmpty()) {
                item(key = "empty_feed") {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 24.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp)
                        ) {
                            Icon(
                                Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = BaatlySlate,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (uiState.feedMode == "for_you") "No posts yet" else "No posts from creators you follow",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Create your first post or explore community content to start your feed.",
                                fontSize = 12.sp,
                                color = TextSecondaryLight,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showCreatePostDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Post", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(currentPosts, key = { it.id }) { post ->
                    SocialPostCard(
                        post = post,
                        currentAuthUid = uiState.currentAuthUid,
                        onLike = { socialViewModel.toggleLikePost(post) },
                        onLoveNote = { loveNoteTarget = Pair("post", post.id) },
                        onFollow = { targetId -> socialViewModel.toggleFollow(targetId) },
                        onView = { socialViewModel.viewContent("post", post.id) }
                    )
                }
            }

            item(key = "social_bottom_spacer") {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    // Story Viewer Dialog
    selectedStoryForViewer?.let { story ->
        StoryViewerDialog(
            story = story,
            onClose = { selectedStoryForViewer = null },
            onLike = { socialViewModel.toggleLikeStory(story) },
            onLoveNote = { loveNoteTarget = Pair("story", story.id) }
        )
    }

    // Love Note Dialog
    loveNoteTarget?.let { (contentType, contentId) ->
        SendLoveNoteDialog(
            contentType = contentType,
            onDismiss = { loveNoteTarget = null },
            onSend = { message ->
                socialViewModel.sendLoveNote(contentType, contentId, message) { success ->
                    if (success) loveNoteTarget = null
                }
            }
        )
    }

    // Create Post Dialog
    if (showCreatePostDialog) {
        CreateSocialContentDialog(
            type = "post",
            isLoading = uiState.isCreatingContent,
            onDismiss = { showCreatePostDialog = false },
            onSubmit = { file, caption ->
                socialViewModel.createPost(file, caption) { success ->
                    if (success) showCreatePostDialog = false
                }
            }
        )
    }

    // Create Story Dialog
    if (showCreateStoryDialog) {
        CreateSocialContentDialog(
            type = "story",
            isLoading = uiState.isCreatingContent,
            onDismiss = { showCreateStoryDialog = false },
            onSubmit = { file, caption ->
                socialViewModel.createStory(file, caption) { success ->
                    if (success) showCreateStoryDialog = false
                }
            }
        )
    }
}

@Composable
fun FeedTabButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val bgColor by animateColorAsState(if (isSelected) BaatlyPrimary else Color.Transparent)
    val textColor by animateColorAsState(if (isSelected) Color.White else TextSecondaryLight)

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 7.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = textColor
        )
    }
}

@Composable
fun SocialPostCard(
    post: SocialPostModel,
    currentAuthUid: String?,
    onLike: () -> Unit,
    onLoveNote: () -> Unit,
    onFollow: (String) -> Unit,
    onView: () -> Unit
) {
    val context = LocalContext.current
    val privateMediaRepo = (context.applicationContext as BaatlyApp).privateMediaRepository

    val resolvedAvatarUrl by rememberProfileAvatarUrl(post.avatarUrl, privateMediaRepo)
    val resolvedMediaUrl by rememberSocialMediaUrl(
        rawUrl = post.mediaPath,
        defaultBucket = post.mediaBucket ?: "social-media",
        privateMediaRepo = privateMediaRepo
    )

    LaunchedEffect(post.id) {
        onView()
    }

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("social_post_card_${post.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Post Header: Avatar, Display Name, Follow & Pending Badges
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f, fill = false)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(BaatlyGradient)
                            .padding(2.dp)
                            .clip(CircleShape)
                    ) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedAvatarUrl),
                                contentDescription = post.displayName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0xFFFFF1EB)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (post.displayName ?: "H").take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = post.displayName?.takeIf { it.isNotBlank() } ?: "Creator",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryLight,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!post.publishedAt.isNullOrBlank()) {
                            Text(
                                text = formatSocialTimestamp(post.publishedAt),
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Pending Review badge for own content
                    if (post.isPendingReview) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFFFBEB))
                                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Pending Review",
                                color = Color(0xFFB45309),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Follow button if not own post
                    val isOwnPost = post.isOwner == true || post.ownerId == currentAuthUid || post.signupUserId == currentAuthUid
                    if (!isOwnPost && (post.ownerId != null || post.signupUserId != null)) {
                        val isFollowing = post.isFollowing ?: false
                        val targetUid = post.ownerId ?: post.signupUserId ?: ""
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isFollowing) Color(0xFFF1F5F9) else Color(0xFFFFEDF2))
                                .clickable { onFollow(targetUid) }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isFollowing) "Following" else "+ Follow",
                                color = if (isFollowing) TextSecondaryLight else BaatlyPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Caption
            if (!post.caption.isNullOrBlank()) {
                Text(
                    text = post.caption,
                    fontSize = 14.sp,
                    color = TextPrimaryLight,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }

            // Media Preview (Loaded via signed URL)
            if (!post.mediaPath.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 380.dp)
                        .padding(top = 6.dp)
                        .background(Color(0xFF171216)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedMediaUrl.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(model = resolvedMediaUrl),
                            contentDescription = "Post Media",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        CircularProgressIndicator(color = BaatlyPrimary, modifier = Modifier.size(24.dp))
                    }
                }
            }

            // Post Interaction Bar: Likes, Views, Love Notes
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Like button
                    val isLiked = post.isLiked ?: false
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onLike() }
                            .testTag("post_like_${post.id}")
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (isLiked) BaatlyPrimary else BaatlySlate,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "${post.effectiveLikesCount}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLiked) BaatlyPrimary else TextSecondaryLight
                        )
                    }

                    // Views count
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RemoveRedEye,
                            contentDescription = "Views",
                            tint = BaatlySlate,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "${post.effectiveViewsCount}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondaryLight
                        )
                    }

                    // Love Note button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onLoveNote() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.MailOutline,
                            contentDescription = "Love Note",
                            tint = BaatlySecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "${post.effectiveLoveNotesCount}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BaatlySecondary
                        )
                    }
                }

                // Send Note Quick Button
                Button(
                    onClick = { onLoveNote() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF3E8FF)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = null,
                        tint = BaatlySecondary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Note",
                        color = BaatlySecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SocialEarningsDashboardCard(
    today: com.example.data.models.SocialTodayEarningsModel,
    lifetime: com.example.data.models.SocialLifetimeEarningsModel,
    onClose: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BaatlyEarningsGradient)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SOCIAL MEDIA EARNINGS",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Today's Social", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        Text(
                            "₹${String.format(java.util.Locale.US, "%.2f", today.today)}",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Lifetime Social", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        Text(
                            "₹${String.format(java.util.Locale.US, "%.2f", lifetime.total)}",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Breakdown: Views, Likes, Love Notes
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.18f))
                        .padding(vertical = 8.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Views/Unlocks", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                        Text("₹${String.format(java.util.Locale.US, "%.2f", today.views)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Post Likes", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                        Text("₹${String.format(java.util.Locale.US, "%.2f", today.likes)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Love Notes", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                        Text("₹${String.format(java.util.Locale.US, "%.2f", today.loveNotes)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StoryViewerDialog(
    story: SocialStoryModel,
    onClose: () -> Unit,
    onLike: () -> Unit,
    onLoveNote: () -> Unit
) {
    val context = LocalContext.current
    val privateMediaRepo = (context.applicationContext as BaatlyApp).privateMediaRepository
    val resolvedMediaUrl by rememberSocialMediaUrl(
        rawUrl = story.mediaPath,
        defaultBucket = story.mediaBucket ?: "stories-media",
        privateMediaRepo = privateMediaRepo
    )

    BackHandler { onClose() }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Story Media
            if (!resolvedMediaUrl.isNullOrBlank()) {
                Image(
                    painter = rememberAsyncImagePainter(model = resolvedMediaUrl),
                    contentDescription = "Story media",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BaatlyPrimary)
                }
            }

            // Top Header: Creator info & Close button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BaatlyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (story.displayName ?: "H").take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = story.displayName ?: "Host",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (!story.createdAt.isNullOrBlank()) {
                            Text(
                                text = formatSocialTimestamp(story.createdAt),
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            // Bottom Caption & Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                if (!story.caption.isNullOrBlank()) {
                    Text(
                        text = story.caption,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .padding(10.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onLike,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = if (story.isLiked == true) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Like Story",
                            tint = if (story.isLiked == true) BaatlyPrimary else Color.White
                        )
                    }

                    Button(
                        onClick = onLoveNote,
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Send Love Note", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SendLoveNoteDialog(
    contentType: String,
    onDismiss: () -> Unit,
    onSend: (String) -> Unit
) {
    var message by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Send Love Note", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Write a heartfelt message to connect with the creator:",
                    fontSize = 13.sp,
                    color = TextSecondaryLight
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    placeholder = { Text("Enter your message...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BaatlyPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSend(message) },
                enabled = message.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
            ) {
                Text("Send Note")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondaryLight)
            }
        }
    )
}

@Composable
fun CreateSocialContentDialog(
    type: String, // "post" or "story"
    isLoading: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (File, String?) -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedUri = uri
    }

    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        title = {
            Text(
                text = if (type == "story") "Create Story" else "Create Post",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Media Picker Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFFF1EB))
                        .border(1.dp, BaatlyPrimary, RoundedCornerShape(16.dp))
                        .clickable { pickerLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedUri != null) {
                        Image(
                            painter = rememberAsyncImagePainter(model = selectedUri),
                            contentDescription = "Selected media",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = BaatlyPrimary, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Select Photo from Gallery", fontSize = 12.sp, color = BaatlyPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Caption (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BaatlyPrimary)
                )

                if (isLoading) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = BaatlyPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Uploading and publishing...", fontSize = 12.sp, color = TextSecondaryLight)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    val tempFile = copyUriToTempFile(context, uri)
                    if (tempFile != null) {
                        onSubmit(tempFile, caption.ifBlank { null })
                    }
                },
                enabled = selectedUri != null && !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
            ) {
                Text(if (type == "story") "Share Story" else "Post Now")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isLoading) {
                Text("Cancel", color = TextSecondaryLight)
            }
        }
    )
}

fun copyUriToTempFile(context: android.content.Context, uri: Uri): File? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val tempFile = File(context.cacheDir, "social_upload_${System.currentTimeMillis()}.jpg")
        val outputStream = FileOutputStream(tempFile)
        inputStream.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
            }
        }
        tempFile
    } catch (_: Exception) {
        null
    }
}

fun formatSocialTimestamp(rawIso: String?): String {
    if (rawIso.isNullOrBlank()) return ""
    return try {
        val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val cleanIso = if (rawIso.contains(".")) rawIso.substringBefore(".") else rawIso.replace("Z", "")
        val date = isoFormat.parse(cleanIso) ?: return ""
        val diffMs = System.currentTimeMillis() - date.time
        val minutes = diffMs / (60 * 1000)
        val hours = minutes / 60
        val days = hours / 24

        when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "${minutes}m ago"
            hours < 24 -> "${hours}h ago"
            days < 7 -> "${days}d ago"
            else -> {
                val fmt = java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault())
                fmt.format(date)
            }
        }
    } catch (_: Exception) {
        ""
    }
}
