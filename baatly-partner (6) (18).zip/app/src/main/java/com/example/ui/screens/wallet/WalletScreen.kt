package com.example.ui.screens.wallet

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.WalletViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    walletViewModel: WalletViewModel,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val uiState by walletViewModel.uiState.collectAsState()
    var showWithdrawDialog by remember { mutableStateOf(false) }

    val availableBalance = uiState.walletSummary?.effectiveAvailableBalance ?: uiState.wallet?.effectiveBalance ?: 0.0
    val pendingWithdrawal = uiState.walletSummary?.pendingWithdrawalRupees ?: 0.0
    val reservedWithdrawal = uiState.walletSummary?.withdrawalReservedRupees ?: 0.0

    var accountHolderName by remember { mutableStateOf("") }
    var accountNumber by remember { mutableStateOf("") }
    var ifscCode by remember { mutableStateOf("") }
    var withdrawalAmountText by remember { mutableStateOf("") }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            walletViewModel.clearError()
        }
    }

    LaunchedEffect(uiState.successMessage) {
        uiState.successMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            walletViewModel.clearSuccessMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Host Wallet & Kamai", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("wallet_back_button")) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { walletViewModel.loadWalletData() },
                        modifier = Modifier.testTag("refresh_wallet_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))

                // Available Balance Card
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "AVAILABLE HOST BALANCE",
                            color = TextSecondaryLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        if (uiState.isLoading && uiState.wallet == null) {
                            Box(modifier = Modifier.padding(vertical = 4.dp)) {
                                CircularProgressIndicator(
                                    color = BaatlyGreen,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.5.dp
                                )
                            }
                        } else {
                            Text(
                                text = "₹${String.format(java.util.Locale.US, "%.2f", availableBalance)}",
                                color = BaatlyGreen,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        if (pendingWithdrawal > 0.0 || reservedWithdrawal > 0.0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            val pendingTotal = pendingWithdrawal + reservedWithdrawal
                            Text(
                                text = "Processing / Reserved: ₹${String.format(java.util.Locale.US, "%.2f", pendingTotal)}",
                                color = TextSecondaryLight,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (availableBalance > 0) {
                                    withdrawalAmountText = String.format(java.util.Locale.US, "%.2f", availableBalance)
                                    showWithdrawDialog = true
                                }
                            },
                            enabled = availableBalance > 0,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("request_payout_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                        ) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Request Bank Withdrawal", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Today's Breakdown Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("TODAY'S EARNINGS BREAKDOWN", color = BaatlyPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Call Earnings:", color = TextSecondaryLight, fontSize = 13.sp)
                            Text("₹${String.format(java.util.Locale.US, "%.2f", uiState.todayBreakdown.callEarningsToday)}", color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Chat Earnings:", color = TextSecondaryLight, fontSize = 13.sp)
                            Text("₹${String.format(java.util.Locale.US, "%.2f", uiState.todayBreakdown.chatEarningsToday)}", color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Gift Earnings:", color = TextSecondaryLight, fontSize = 13.sp)
                            Text(
                                text = if (uiState.todayBreakdown.isRegularAvailable) 
                                    "₹${String.format(java.util.Locale.US, "%.2f", uiState.todayBreakdown.giftEarningsToday)}"
                                else "--",
                                color = TextPrimaryLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Social Earnings:", color = TextSecondaryLight, fontSize = 13.sp)
                            Text(
                                text = if (uiState.todayBreakdown.isSocialAvailable) 
                                    "₹${String.format(java.util.Locale.US, "%.2f", uiState.todayBreakdown.socialEarningsToday)}"
                                else "--",
                                color = TextPrimaryLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = BaatlyLightBorder)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Today:", color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = if (uiState.todayBreakdown.isFullFailure) "--"
                                else "₹${String.format(java.util.Locale.US, "%.2f", uiState.todayBreakdown.totalToday)}",
                                color = BaatlyGreen,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "TRANSACTION LEDGER HISTORY",
                    color = TextSecondaryLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (uiState.transactions.isEmpty()) {
                item {
                    Text(
                        text = "Koi transaction history nahi mili.",
                        color = TextSecondaryLight,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            } else {
                items(uiState.transactions) { tx ->
                    val isCredit = tx.displayAmountRupees >= 0
                    val amount = tx.displayAmountRupees
                    val typeLabel = when (tx.transactionType) {
                        "partner_call_earning" -> "Call Kamai"
                        "partner_chat_earning" -> "Chat Kamai"
                        "partner_gift_earning" -> "Gift Kamai"
                        "withdrawal" -> "Payout Withdrawal"
                        else -> tx.transactionType.replace("_", " ").capitalize()
                    }

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isCredit) BaatlyGreenLight else BaatlyRedLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (isCredit) BaatlyGreen else BaatlyRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(typeLabel, color = TextPrimaryLight, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(tx.description ?: "Authoritative credit", color = TextSecondaryLight, fontSize = 11.sp)
                                }
                            }

                            Text(
                                text = if (isCredit) "+₹${String.format(java.util.Locale.US, "%.2f", amount)}" else "-₹${String.format(java.util.Locale.US, "%.2f", -amount)}",
                                color = if (isCredit) BaatlyGreen else BaatlyRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (showWithdrawDialog) {
        val parsedAmount = withdrawalAmountText.toDoubleOrNull() ?: 0.0
        val isAmountValid = parsedAmount > 0.0 && parsedAmount <= availableBalance

        AlertDialog(
            onDismissRequest = {
                if (!uiState.isSubmittingWithdrawal) showWithdrawDialog = false
            },
            title = { Text("Request Bank Withdrawal", color = TextPrimaryLight, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Available to withdraw: ₹${String.format(java.util.Locale.US, "%.2f", availableBalance)}",
                        color = TextSecondaryLight,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = accountHolderName,
                        onValueChange = { accountHolderName = it },
                        label = { Text("Account Holder Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdrawal_account_holder_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = { accountNumber = it },
                        label = { Text("Account Number") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdrawal_account_number_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = ifscCode,
                        onValueChange = { ifscCode = it.uppercase() },
                        label = { Text("IFSC Code") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdrawal_ifsc_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = withdrawalAmountText,
                        onValueChange = { withdrawalAmountText = it },
                        label = { Text("Withdrawal Amount (₹)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdrawal_amount_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        walletViewModel.submitWithdrawal(
                            accountHolderName = accountHolderName,
                            accountNumber = accountNumber,
                            ifscCode = ifscCode,
                            amount = parsedAmount,
                            onSuccess = {
                                showWithdrawDialog = false
                                accountHolderName = ""
                                accountNumber = ""
                                ifscCode = ""
                                withdrawalAmountText = ""
                            }
                        )
                    },
                    enabled = !uiState.isSubmittingWithdrawal && isAmountValid && accountHolderName.isNotBlank() && accountNumber.isNotBlank() && ifscCode.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("submit_withdrawal_button")
                ) {
                    if (uiState.isSubmittingWithdrawal) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Submit Payout Request")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showWithdrawDialog = false },
                    enabled = !uiState.isSubmittingWithdrawal
                ) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }
}
