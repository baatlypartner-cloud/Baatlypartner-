package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.BaatlyApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MobilityLocationForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var locationManager: LocationManager? = null
    private var listener: LocationListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        startTracking()
        return START_STICKY
    }

    private fun startTracking() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            stopSelf()
            return
        }
        try {
            val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locationManager = manager
            val providers = mutableListOf<String>()
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
            if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)
            val updateListener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    scope.launch {
                        val repo = (application as BaatlyApp).partnerOnboardingRepository
                        val result = repo.sendPartnerHeartbeat(location.latitude, location.longitude, location.accuracy)
                        if (result.isFailure) Log.w(TAG, "Partner location heartbeat failed", result.exceptionOrNull())
                    }
                }
                @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            listener = updateListener
            providers.forEach { provider ->
                manager.requestLocationUpdates(provider, 5_000L, 10f, updateListener, Looper.getMainLooper())
            }
            if (providers.isEmpty()) Log.w(TAG, "No enabled location provider found")
        } catch (e: SecurityException) {
            Log.e(TAG, "Location permission revoked while starting tracking", e)
            stopSelf()
        } catch (e: Exception) {
            Log.e(TAG, "Could not start mobility location tracking", e)
            stopSelf()
        }
    }

    private fun stopTracking() {
        try { listener?.let { locationManager?.removeUpdates(it) } } catch (_: Exception) { }
        listener = null
        locationManager = null
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "BAATLY Partner location", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle("BAATLY Partner is online")
            .setContentText("Live GPS is syncing securely while your selected service is online.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        stopTracking()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "MobilityLocationService"
        private const val CHANNEL_ID = "baatly_mobility_location"
        private const val NOTIFICATION_ID = 7412
        const val ACTION_START = "com.example.service.MOBILITY_LOCATION_START"
        const val ACTION_STOP = "com.example.service.MOBILITY_LOCATION_STOP"
    }
}
