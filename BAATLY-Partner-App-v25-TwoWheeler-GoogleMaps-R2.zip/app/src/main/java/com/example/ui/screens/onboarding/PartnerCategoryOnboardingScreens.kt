package com.example.ui.screens.onboarding

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.models.MobilityPartnerApplicationModel
import com.example.data.models.MobilityRestaurantBranchModel
import com.example.data.models.MobilityRestaurantModel
import com.example.data.repository.PartnerOnboardingRepository
import com.example.service.MobilityLocationForegroundService
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF100D1E)
private val Ink2 = Color(0xFF201638)
private val Gold = Color(0xFFFFD58A)
private val Violet = Color(0xFF8B5CF6)
private val Mint = Color(0xFF64E6C1)
private val TextOnDark = Color(0xFFF8F5FF)

/** The first screen every new partner sees. HOST is routed back into the original flow. */
enum class PartnerCategory(val title: String, val subtitle: String, val art: String, val service: String? = null) {
    HOST("Hosting", "Live audio, chat and creator earnings", "🎙️"),
    TWO_WHEELER("Two-Wheeler Partner", "One application · Bike Taxi · Food · Parcel", "🏍️", "bike_taxi"),
    CAB("Cab Partner", "Auto, e-rickshaw, mini, sedan and SUV rides", "🚘", "cab"),
    RESTAURANT("Restaurant Partner", "List your outlet, menu and receive orders", "🍽️")
}

@Composable
fun PartnerCategorySelectionScreen(onSelect: (PartnerCategory) -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Ink2, Color(0xFF120E27))))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Box(
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF9C5CFF), Color(0xFF5E28B8)))),
                contentAlignment = Alignment.Center
            ) { Text("B", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.height(18.dp))
            Text("BAATLY PARTNER", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("Aap kis type ke partner banna chahte hain?", color = TextOnDark, fontSize = 25.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("Pehle apna business choose karein. Aage sirf usi category ka onboarding dikhega.", color = Color(0xFFBBB2D0), fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 19.sp)
            Spacer(Modifier.height(24.dp))

            val rows = listOf(
                listOf(PartnerCategory.HOST, PartnerCategory.TWO_WHEELER),
                listOf(PartnerCategory.CAB, PartnerCategory.RESTAURANT)
            )
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { category ->
                        PartnerCategoryCard(category, Modifier.weight(1f)) { onSelect(category) }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Mint, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(7.dp))
                Text("Secure onboarding · Supabase verification · R2 document storage", color = Color(0xFFBDB5CE), fontSize = 11.sp)
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun PartnerArtwork(category: PartnerCategory, height: androidx.compose.ui.unit.Dp) {
    val artwork = when (category) {
        PartnerCategory.HOST -> R.drawable.partner_art_host
        PartnerCategory.TWO_WHEELER -> R.drawable.partner_art_bike
        PartnerCategory.CAB -> R.drawable.partner_art_cab
        PartnerCategory.RESTAURANT -> R.drawable.partner_art_restaurant
    }
    Image(
        painter = painterResource(artwork),
        contentDescription = "${category.title} premium 3D artwork",
        modifier = Modifier.fillMaxWidth().height(height),
        contentScale = androidx.compose.ui.layout.ContentScale.Fit
    )
}

@Composable
private fun PartnerCategoryCard(category: PartnerCategory, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.height(174.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF30224D), Color(0xFF1A1530))))
            .border(1.dp, Color(0xFF625080), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
            PartnerArtwork(category, 82.dp)
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
        }
        Column {
            Text(category.title, color = TextOnDark, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(category.subtitle, color = Color(0xFFC7BED8), fontSize = 10.sp, lineHeight = 14.sp, maxLines = 2)
        }
    }
}

private data class PendingDocument(val bytes: ByteArray, val contentType: String, val fileName: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartnerCategoryOnboardingScreen(
    category: PartnerCategory,
    repository: PartnerOnboardingRepository,
    onBackToCategories: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasAccount by remember { mutableStateOf(repository.hasSession()) }
    var stage by remember { mutableStateOf(if (repository.hasSession()) "checking" else "account") }
    var authMode by remember { mutableStateOf("create") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf<String?>(null) }
    var mobilityApplication by remember { mutableStateOf<MobilityPartnerApplicationModel?>(null) }
    var restaurant by remember { mutableStateOf<MobilityRestaurantModel?>(null) }
    var restaurantBranch by remember { mutableStateOf<MobilityRestaurantBranchModel?>(null) }
    var restaurantCreatedId by remember { mutableStateOf<String?>(null) }
    val restaurantUploadedKeys = remember { mutableStateMapOf<String, String>() }
    val restaurantAttachedDocs = remember { mutableStateListOf<String>() }

    // Account fields are common across mobility and restaurant accounts; unlike Hosting, this does not create partner_profiles.
    var userId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }

    // Mobility / vehicle fields
    var applicantName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var stateName by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var emergencyName by remember { mutableStateOf("") }
    var emergencyPhone by remember { mutableStateOf("") }
    var vehicleType by remember { mutableStateOf(if (category == PartnerCategory.TWO_WHEELER) "bike" else "sedan") }
    var bikeVehicleType by remember { mutableStateOf("motorcycle") }
    var registration by remember { mutableStateOf("") }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var vehicleYear by remember { mutableStateOf("") }
    var colour by remember { mutableStateOf("") }
    var bankHolder by remember { mutableStateOf("") }
    var bankNumber by remember { mutableStateOf("") }
    var ifsc by remember { mutableStateOf("") }

    // Restaurant fields
    var restaurantName by remember { mutableStateOf("") }
    var legalName by remember { mutableStateOf("") }
    var cuisine by remember { mutableStateOf("") }
    var fssai by remember { mutableStateOf("") }
    var pan by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var supportEmail by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var branchName by remember { mutableStateOf("") }
    var postalCode by remember { mutableStateOf("") }
    var restaurantLatitude by remember { mutableStateOf("") }
    var restaurantLongitude by remember { mutableStateOf("") }
    var menuCategoryName by remember { mutableStateOf("") }
    var menuCategoryId by remember { mutableStateOf("") }
    var menuItemName by remember { mutableStateOf("") }
    var menuItemPrice by remember { mutableStateOf("") }
    var menuFoodType by remember { mutableStateOf("veg") }

    val pendingDocs = remember { mutableStateMapOf<String, PendingDocument>() }
    val mobilityUploadedKeys = remember { mutableStateMapOf<String, String>() }
    var activeDocumentType by remember { mutableStateOf("") }
    var documentLoading by remember { mutableStateOf(false) }
    var notificationPromptHandled by remember { mutableStateOf(false) }
    var pendingOnlineService by remember { mutableStateOf(category.service ?: "bike_taxi") }
    var dashboardRefreshToken by remember { mutableIntStateOf(0) }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        notificationPromptHandled = true
        stage = "dashboard"
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val documentType = activeDocumentType
            documentLoading = true
            scope.launch {
                try {
                    val loaded = withContext(Dispatchers.IO) {
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("Could not read selected document")
                        val mime = context.contentResolver.getType(uri) ?: "application/pdf"
                        if (bytes.size > 10 * 1024 * 1024) throw IllegalArgumentException("File must be 10 MB or smaller")
                        if (mime !in listOf("application/pdf", "image/jpeg", "image/png", "image/webp")) {
                            throw IllegalArgumentException("Choose a PDF, JPG, PNG or WebP file")
                        }
                        PendingDocument(bytes, mime, uri.lastPathSegment ?: documentType)
                    }
                    pendingDocs[documentType] = loaded
                    error = null
                } catch (e: Exception) { error = e.message ?: "Could not read document" }
                documentLoading = false
            }
        }
    }

    suspend fun refreshApplication() {
        if (category == PartnerCategory.RESTAURANT) {
            val result = repository.getLatestRestaurant()
            restaurant = result.getOrNull()
            val current = restaurant
            if (current != null) {
                val branches = repository.getRestaurantBranches(current.id).getOrNull().orEmpty()
                restaurantBranch = branches.firstOrNull()
                stage = if (current.onboardingStatus.equals("approved", true) && restaurantBranch != null) "dashboard" else "status"
            } else stage = "form"
        } else {
            val result = repository.getLatestMobilityApplication(category.service ?: "parcel")
            val selectedService = category.service ?: "parcel"
            mobilityApplication = result.getOrNull()?.takeIf { selectedService in it.requestedServices }
            val current = mobilityApplication
            stage = when (current?.applicationStatus?.lowercase()) {
                "approved" -> "dashboard"
                "pending", "under_review", "resubmission", "rejected" -> "status"
                else -> "form"
            }
        }
    }

    LaunchedEffect(category) {
        if (repository.hasSession()) {
            hasAccount = true
            try { refreshApplication() } catch (e: Exception) { error = e.message; stage = "form" }
        } else stage = "account"
    }

    LaunchedEffect(stage, notificationPromptHandled) {
        if (stage == "dashboard" && !notificationPromptHandled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (granted) notificationPromptHandled = true else stage = "notifications_permission"
        }
    }

    fun useCurrentRestaurantLocation() {
        try {
            val manager = context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            val recent = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
                .filter { manager.isProviderEnabled(it) }
                .mapNotNull { manager.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
            if (recent != null) {
                restaurantLatitude = recent.latitude.toString()
                restaurantLongitude = recent.longitude.toString()
                error = null
            } else error = "No recent device location found. Turn on GPS or enter the outlet latitude/longitude manually."
        } catch (_: SecurityException) {
            error = "Allow location while using the app, then try again."
        } catch (e: Exception) { error = e.message ?: "Could not read outlet location" }
    }
    val restaurantLocationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) useCurrentRestaurantLocation()
        else error = "Location permission denied. Enter the outlet coordinates manually or enable location permission."
    }

    val foregroundLocationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allowed = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (!allowed) error = "Location permission is needed to receive and complete nearby jobs."
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) stage = "background_location"
        else scope.launch {
            activateService(repository, pendingOnlineService, context, { busy = it }, { error = it }) { dashboardRefreshToken++ }
        }
    }
    val backgroundLocationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) error = "Background location is required to keep job tracking active when the app is minimized. Enable it in App Settings."
        else scope.launch {
            activateService(repository, pendingOnlineService, context, { busy = it }, { error = it }) { dashboardRefreshToken++ }
        }
    }
    val backgroundLocationSettingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) scope.launch {
            activateService(repository, pendingOnlineService, context, { busy = it }, { error = it }) { dashboardRefreshToken++ }
        } else error = "Settings mein Location permission ko 'Allow all the time' set karke wapas aayein."
    }
    fun openBackgroundLocationSettings() {
        backgroundLocationSettingsLauncher.launch(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        )
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Ink2, Color(0xFF120E27))))) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (stage == "account" || stage == "form" || stage == "status" || stage == "checking") onBackToCategories() else stage = "status" }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextOnDark)
                }
                Column(Modifier.weight(1f)) {
                    Text("BAATLY PARTNER", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text(category.title, color = TextOnDark, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
                if (stage != "dashboard") {
                    Surface(color = Color(0xFF35264F), shape = RoundedCornerShape(30.dp)) {
                        Text("SECURE", color = Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                    }
                }
            }
            when (stage) {
                "checking" -> FullScreenStatus("Checking your application", "BAATLY is securely checking your selected partner category.", "🔐", busy = true)
                "account" -> AccountAccessScreen(
                    category = category,
                    authMode = authMode,
                    onAuthModeChange = { authMode = it; error = null },
                    userId = userId, onUserId = { userId = it },
                    password = password, onPassword = { password = it },
                    displayName = displayName, onDisplayName = { displayName = it },
                    mobile = mobile, onMobile = { mobile = it },
                    busy = busy, error = error,
                    onSubmit = {
                        error = null
                        if (userId.trim().length < 3 || password.length < 6) error = "Enter a valid User ID and a password of at least 6 characters."
                        else if (authMode == "create" && (displayName.trim().length < 2 || !Regex("^[6-9][0-9]{9}$").matches(mobile.filter(Char::isDigit)))) error = "Enter your name and a valid 10-digit mobile number."
                        else scope.launch {
                            busy = true
                            val result = if (authMode == "create") repository.signUpAccount(userId, password, displayName, mobile) else repository.signInAccount(userId, password)
                            busy = false
                            if (result.isSuccess) {
                                hasAccount = true
                                if (authMode == "create") { applicantName = displayName.trim(); phone = mobile.filter(Char::isDigit) }
                                refreshApplication()
                            } else error = result.exceptionOrNull()?.message ?: "Could not continue"
                        }
                    }
                )
                "form" -> if (category == PartnerCategory.RESTAURANT) {
                    RestaurantApplicationForm(
                        restaurantName, { restaurantName = it }, legalName, { legalName = it }, cuisine, { cuisine = it },
                        fssai, { fssai = it }, pan, { pan = it }, gstin, { gstin = it }, supportEmail, { supportEmail = it },
                        phone, { phone = it }, city, { city = it }, stateName, { stateName = it }, address, { address = it },
                        branchName, { branchName = it }, postalCode, { postalCode = it },
                        restaurantLatitude, { restaurantLatitude = it }, restaurantLongitude, { restaurantLongitude = it },
                        onUseLocation = {
                            val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            if (fine || coarse) useCurrentRestaurantLocation()
                            else restaurantLocationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        },
                        description, { description = it }, bankHolder, { bankHolder = it }, bankNumber, { bankNumber = it }, ifsc, { ifsc = it },
                        pendingDocs, { activeDocumentType = it; docPicker.launch(arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp")) },
                        documentLoading, busy, error,
                        onSubmit = {
                            error = null
                            val requiredDocs = listOf("fssai_license", "pan_card", "bank_proof", "owner_identity", "restaurant_photo")
                            val latitudeValue = restaurantLatitude.toDoubleOrNull()
                            val longitudeValue = restaurantLongitude.toDoubleOrNull()
                            if (restaurantName.trim().length < 2 || address.trim().length < 5 || city.trim().length < 2 || stateName.trim().length < 2 || !Regex("^[6-9][0-9]{9}$").matches(phone.filter(Char::isDigit)) || latitudeValue == null || latitudeValue !in -90.0..90.0 || longitudeValue == null || longitudeValue !in -180.0..180.0 || fssai.isBlank() || pan.isBlank() || bankHolder.isBlank() || bankNumber.filter(Char::isDigit).length < 8 || ifsc.isBlank()) {
                                error = "Enter restaurant name, valid support phone, full address, city/state, outlet coordinates, FSSAI, PAN and bank settlement details."
                            } else if (!pendingDocs.keys.containsAll(requiredDocs)) {
                                error = "Please upload all 5 required restaurant documents before submitting."
                            } else scope.launch {
                                busy = true
                                try {
                                    val payload = mapOf<String, Any?>(
                                        "restaurant_name" to restaurantName.trim(), "legal_name" to legalName.trim(),
                                        "cuisine_types" to cuisine.split(",").map { it.trim() }.filter { it.isNotBlank() },
                                        "fssai_number" to fssai.trim(), "pan_number" to pan.trim(), "gstin" to gstin.trim().uppercase(),
                                        "support_phone" to phone.filter(Char::isDigit), "support_email" to supportEmail.trim(),
                                        "description" to description.trim(), "bank_account_holder" to bankHolder.trim(),
                                        "bank_account_number" to bankNumber.filter(Char::isDigit), "bank_ifsc" to ifsc.trim().uppercase(),
                                        "branch_name" to branchName.trim(), "address" to address.trim(), "city" to city.trim(),
                                        "state" to stateName.trim(), "postal_code" to postalCode.trim(),
                                        "latitude" to restaurantLatitude.toDoubleOrNull(), "longitude" to restaurantLongitude.toDoubleOrNull()
                                    )
                                    val restaurantId = restaurantCreatedId ?: run {
                                        val created = repository.submitRestaurantApplication(payload)
                                        if (created.isFailure) throw created.exceptionOrNull() ?: IllegalStateException("Could not create restaurant")
                                        created.getOrThrow().also { restaurantCreatedId = it }
                                    }
                                    val branch = restaurantBranch ?: repository.getRestaurantBranches(restaurantId).getOrNull()?.firstOrNull()
                                    restaurantBranch = branch
                                    for (docType in requiredDocs) {
                                        if (docType in restaurantAttachedDocs) continue
                                        val file = pendingDocs[docType] ?: continue
                                        val objectKey = restaurantUploadedKeys[docType] ?: run {
                                            val uploaded = repository.uploadDocument(file.bytes, file.contentType, "restaurant_document", restaurantId)
                                            if (uploaded.isFailure) throw uploaded.exceptionOrNull() ?: IllegalStateException("R2 upload failed for $docType")
                                            uploaded.getOrThrow().also { restaurantUploadedKeys[docType] = it }
                                        }
                                        val attached = repository.addRestaurantDocument(restaurantId, branch?.id, docType, objectKey)
                                        if (attached.isFailure) throw attached.exceptionOrNull() ?: IllegalStateException("Could not attach $docType")
                                        restaurantAttachedDocs.add(docType)
                                    }
                                    refreshApplication()
                                } catch (e: Exception) { error = e.message ?: "Restaurant application failed" }
                                busy = false
                            }
                        }
                    )
                } else {
                    MobilityApplicationForm(
                        category = category,
                        applicantName = applicantName, onApplicantName = { applicantName = it },
                        phone = phone, onPhone = { phone = it }, dob = dob, onDob = { dob = it },
                        city = city, onCity = { city = it }, stateName = stateName, onState = { stateName = it },
                        address = address, onAddress = { address = it }, emergencyName = emergencyName, onEmergencyName = { emergencyName = it },
                        emergencyPhone = emergencyPhone, onEmergencyPhone = { emergencyPhone = it },
                        vehicleType = vehicleType, onVehicleType = { vehicleType = it },
                        bikeVehicleType = bikeVehicleType, onBikeVehicleType = { bikeVehicleType = it },
                        registration = registration, onRegistration = { registration = it }, make = make, onMake = { make = it },
                        model = model, onModel = { model = it }, vehicleYear = vehicleYear, onVehicleYear = { vehicleYear = it },
                        colour = colour, onColour = { colour = it }, bankHolder = bankHolder, onBankHolder = { bankHolder = it },
                        bankNumber = bankNumber, onBankNumber = { bankNumber = it }, ifsc = ifsc, onIfsc = { ifsc = it },
                        pendingDocs = pendingDocs, onPickDocument = { activeDocumentType = it; docPicker.launch(arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp")) },
                        documentLoading = documentLoading, busy = busy, error = error,
                        onSubmit = {
                            error = null
                            val requiredDocs = mutableListOf("identity_proof", "driving_license", "vehicle_rc", "vehicle_insurance", "puc", "police_verification", "selfie", "bank_proof")
                            if (vehicleType != "bike") requiredDocs.addAll(listOf("vehicle_permit", "fitness_certificate"))
                            if (category == PartnerCategory.TWO_WHEELER) requiredDocs.add("bike_taxi_permit")
                            if (applicantName.trim().length < 2 || !Regex("^[6-9][0-9]{9}$").matches(phone.filter(Char::isDigit)) || city.trim().length < 2 || stateName.trim().length < 2 || registration.trim().isBlank()) {
                                error = "Name, valid mobile, city, state and vehicle registration are required."
                            } else if (!pendingDocs.keys.containsAll(requiredDocs)) {
                                error = "Upload all ${requiredDocs.size} documents required for this vehicle/service type."
                            } else scope.launch {
                                busy = true
                                try {
                                    val uploadedDocs = mutableListOf<Map<String, Any?>>()
                                    for (docType in requiredDocs) {
                                        val file = pendingDocs[docType] ?: continue
                                        val objectKey = mobilityUploadedKeys[docType] ?: run {
                                            val uploaded = repository.uploadDocument(file.bytes, file.contentType, "partner_document")
                                            if (uploaded.isFailure) throw uploaded.exceptionOrNull() ?: IllegalStateException("R2 upload failed for $docType")
                                            uploaded.getOrThrow().also { mobilityUploadedKeys[docType] = it }
                                        }
                                        uploadedDocs.add(mapOf("document_type" to docType, "object_key" to objectKey))
                                    }
                                    val requestedServices = if (category == PartnerCategory.TWO_WHEELER) {
                                        listOf("bike_taxi", "food_delivery", "parcel")
                                    } else {
                                        listOf("cab")
                                    }
                                    val payload = mapOf<String, Any?>(
                                        "applicant_name" to applicantName.trim(), "phone_number" to phone.filter(Char::isDigit),
                                        "date_of_birth" to dob.trim().ifBlank { null }, "city" to city.trim(), "state" to stateName.trim(),
                                        "address" to address.trim(), "vehicle_category" to vehicleType, "requested_services" to requestedServices,
                                        "emergency_contact_name" to emergencyName.trim(), "emergency_contact_phone" to emergencyPhone.filter(Char::isDigit),
                                        "bank_account_holder" to bankHolder.trim(), "bank_account_number" to bankNumber.filter(Char::isDigit),
                                        "bank_ifsc" to ifsc.trim().uppercase(),
                                        "vehicle" to mapOf(
                                            "registration_number" to registration.trim().uppercase(), "make" to make.trim(),
                                            "model" to if (category == PartnerCategory.TWO_WHEELER) "${bikeVehicleType.replaceFirstChar { it.uppercase() }} ${model.trim()}".trim() else model.trim(),
                                            "manufacture_year" to vehicleYear.toIntOrNull(), "colour" to colour.trim(),
                                            "passenger_capacity" to if (vehicleType == "bike") 1 else 4
                                        ),
                                        "documents" to uploadedDocs
                                    )
                                    val created = repository.submitMobilityApplication(payload)
                                    if (created.isFailure) throw created.exceptionOrNull() ?: IllegalStateException("Could not submit application")
                                    refreshApplication()
                                } catch (e: Exception) { error = e.message ?: "Application submission failed" }
                                busy = false
                            }
                        }
                    )
                }
                "status" -> ApplicationReviewScreen(
                    category = category,
                    status = if (category == PartnerCategory.RESTAURANT) restaurant?.onboardingStatus ?: "pending" else mobilityApplication?.applicationStatus ?: "pending",
                    rejectionReason = if (category == PartnerCategory.RESTAURANT) restaurant?.rejectionReason else mobilityApplication?.rejectionReason,
                    busy = busy, error = error,
                    onRefresh = { scope.launch { busy = true; refreshApplication(); busy = false } },
                    onResubmit = { if (category == PartnerCategory.RESTAURANT) restaurant = null else mobilityApplication = null; stage = "form" }
                )
                "notifications_permission" -> NotificationConsentScreen(
                    onContinue = { notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    onSkip = { notificationPromptHandled = true; stage = "dashboard" }
                )
                "background_location" -> BackgroundLocationConsentScreen(
                    onContinue = {
                        when {
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> openBackgroundLocationSettings()
                            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                            else -> scope.launch { activateService(repository, pendingOnlineService, context, { busy = it }, { error = it }) { dashboardRefreshToken++ } }
                        }
                    },
                    onOpenSettings = { openBackgroundLocationSettings() },
                    error = error, busy = busy
                )
                "dashboard" -> if (category == PartnerCategory.RESTAURANT) {
                    RestaurantPartnerDashboard(
                        restaurant = restaurant, branch = restaurantBranch, repository = repository,
                        categoryName = menuCategoryName, onCategoryName = { menuCategoryName = it },
                        categoryId = menuCategoryId, onCategoryId = { menuCategoryId = it },
                        itemName = menuItemName, onItemName = { menuItemName = it },
                        itemPrice = menuItemPrice, onItemPrice = { menuItemPrice = it },
                        foodType = menuFoodType, onFoodType = { menuFoodType = it },
                        menuImage = pendingDocs["menu_item_image"],
                        onPickMenuImage = { activeDocumentType = "menu_item_image"; docPicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) },
                        onClearMenuImage = { pendingDocs.remove("menu_item_image") },
                        busy = busy, error = error, onBusy = { busy = it }, onError = { error = it },
                        onBack = onBackToCategories
                    )
                } else {
                    MobilityPartnerDashboard(
                        category = category,
                        application = mobilityApplication,
                        repository = repository,
                        refreshToken = dashboardRefreshToken,
                        busy = busy,
                        error = error,
                        onToggleService = { serviceType, enable, otherServiceOnline ->
                            error = null
                            pendingOnlineService = serviceType
                            if (enable) {
                                val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                if (!fine && !coarse) foregroundLocationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) stage = "background_location"
                                else scope.launch { activateService(repository, serviceType, context, { busy = it }, { error = it }) { dashboardRefreshToken++ } }
                            } else {
                                scope.launch {
                                    busy = true
                                    val result = repository.setPartnerServiceOnline(serviceType, false)
                                    if (result.isFailure) error = result.exceptionOrNull()?.message
                                    else {
                                        if (!otherServiceOnline) context.startService(Intent(context, MobilityLocationForegroundService::class.java).setAction(MobilityLocationForegroundService.ACTION_STOP))
                                        dashboardRefreshToken++
                                    }
                                    busy = false
                                }
                            }
                        },
                        onBack = onBackToCategories
                    )
                }
                else -> FullScreenStatus("Welcome to BAATLY", "Your selected partner journey is ready.", category.art)
            }
        }
    }
}

private suspend fun activateService(
    repository: PartnerOnboardingRepository,
    serviceType: String,
    context: Context,
    setBusy: (Boolean) -> Unit,
    setError: (String?) -> Unit,
    onActivated: () -> Unit
) {
    setBusy(true)
    val result = repository.setPartnerServiceOnline(serviceType, true)
    if (result.isSuccess) {
        ContextCompat.startForegroundService(context, Intent(context, MobilityLocationForegroundService::class.java).setAction(MobilityLocationForegroundService.ACTION_START))
        setError(null)
        onActivated()
    } else setError(result.exceptionOrNull()?.message ?: "Could not go online")
    setBusy(false)
}

@Composable
private fun AccountAccessScreen(
    category: PartnerCategory,
    authMode: String, onAuthModeChange: (String) -> Unit,
    userId: String, onUserId: (String) -> Unit, password: String, onPassword: (String) -> Unit,
    displayName: String, onDisplayName: (String) -> Unit, mobile: String, onMobile: (String) -> Unit,
    busy: Boolean, error: String?, onSubmit: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 10.dp)) {
        PartnerArtwork(category, 118.dp)
        Text("Your partner account", color = TextOnDark, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("Create a BAATLY account or sign in. This step creates only your basic profile — it does not enrol you as a Host.", color = Color(0xFFC3BAD3), fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF30234A)).padding(4.dp)) {
            listOf("create" to "Create account", "login" to "Sign in").forEach { (value, label) ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(if (authMode == value) Violet else Color.Transparent).clickable { onAuthModeChange(value) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        if (authMode == "create") {
            PartnerInput("Full name", displayName, onDisplayName)
            PartnerInput("10-digit mobile number", mobile, onMobile, keyboard = KeyboardType.Phone)
        }
        PartnerInput("BAATLY User ID", userId, onUserId)
        PartnerInput("Password", password, onPassword, secret = true)
        Spacer(Modifier.height(18.dp))
        error?.let { ErrorStrip(it) }
        PrimaryAction(if (authMode == "create") "Create account & continue" else "Sign in & continue", busy, onSubmit)
        Spacer(Modifier.height(22.dp))
        Text("Your identity and onboarding records are verified by BAATLY. Documents are uploaded privately to Cloudflare R2.", color = Color(0xFFAFA5C3), fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun MobilityApplicationForm(
    category: PartnerCategory,
    applicantName: String, onApplicantName: (String) -> Unit, phone: String, onPhone: (String) -> Unit,
    dob: String, onDob: (String) -> Unit, city: String, onCity: (String) -> Unit,
    stateName: String, onState: (String) -> Unit, address: String, onAddress: (String) -> Unit,
    emergencyName: String, onEmergencyName: (String) -> Unit, emergencyPhone: String, onEmergencyPhone: (String) -> Unit,
    vehicleType: String, onVehicleType: (String) -> Unit, bikeVehicleType: String, onBikeVehicleType: (String) -> Unit,
    registration: String, onRegistration: (String) -> Unit,
    make: String, onMake: (String) -> Unit, model: String, onModel: (String) -> Unit,
    vehicleYear: String, onVehicleYear: (String) -> Unit, colour: String, onColour: (String) -> Unit,
    bankHolder: String, onBankHolder: (String) -> Unit, bankNumber: String, onBankNumber: (String) -> Unit,
    ifsc: String, onIfsc: (String) -> Unit, pendingDocs: Map<String, PendingDocument>, onPickDocument: (String) -> Unit,
    documentLoading: Boolean, busy: Boolean, error: String?, onSubmit: () -> Unit
) {
    val requiresCarDocs = vehicleType != "bike"
    val docTypes = buildList {
        addAll(listOf("identity_proof", "driving_license", "vehicle_rc", "vehicle_insurance", "puc", "police_verification", "selfie", "bank_proof"))
        if (requiresCarDocs) addAll(listOf("vehicle_permit", "fitness_certificate"))
        if (category == PartnerCategory.TWO_WHEELER) add("bike_taxi_permit")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        PartnerArtwork(category, 124.dp)
        Text("Step 1 · Personal & vehicle details", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("${category.title} onboarding", color = TextOnDark, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Text(if (category == PartnerCategory.TWO_WHEELER) "Ek hi application se Bike Taxi, Food Delivery aur Parcel Delivery unlock honge. Approval ke baad har service ko alag ON/OFF kar sakte hain." else "Your vehicle and driver documents will be reviewed for cab services.", color = Color(0xFFC2B9D4), fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(16.dp))
        SectionLabel("PERSONAL DETAILS")
        PartnerInput("Applicant full name", applicantName, onApplicantName)
        PartnerInput("Mobile number", phone, onPhone, keyboard = KeyboardType.Phone)
        PartnerInput("Date of birth (YYYY-MM-DD)", dob, onDob)
        PartnerInput("City", city, onCity)
        PartnerInput("State", stateName, onState)
        PartnerInput("Full address", address, onAddress, singleLine = false)
        PartnerInput("Emergency contact name (optional)", emergencyName, onEmergencyName)
        PartnerInput("Emergency contact number (optional)", emergencyPhone, onEmergencyPhone, keyboard = KeyboardType.Phone)
        Spacer(Modifier.height(14.dp))
        SectionLabel("VEHICLE DETAILS")
        if (category == PartnerCategory.CAB) {
            PartnerDropdown("Vehicle type", vehicleType, listOf("erickshaw", "auto", "mini", "sedan", "suv", "xl", "premium"), onVehicleType)
        } else {
            PartnerDropdown("Two-wheeler style", bikeVehicleType, listOf("motorcycle", "scooter"), onBikeVehicleType)
        }
        PartnerInput("Vehicle registration number", registration, onRegistration)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PartnerInput("Make", make, onMake) }
            Box(Modifier.weight(1f)) { PartnerInput("Model", model, onModel) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PartnerInput("Year", vehicleYear, onVehicleYear, keyboard = KeyboardType.Number) }
            Box(Modifier.weight(1f)) { PartnerInput("Colour", colour, onColour) }
        }
        Spacer(Modifier.height(14.dp))
        SectionLabel("BANK DETAILS")
        PartnerInput("Account holder name", bankHolder, onBankHolder)
        PartnerInput("Bank account number", bankNumber, onBankNumber, keyboard = KeyboardType.Number)
        PartnerInput("IFSC code", ifsc, onIfsc)
        Spacer(Modifier.height(14.dp))
        SectionLabel("VERIFICATION DOCUMENTS · PRIVATE R2 UPLOAD")
        Text("Application approval ke liye required documents. JPG, PNG, WebP ya PDF · max 10 MB each.", color = Color(0xFFC2B9D4), fontSize = 11.sp, lineHeight = 16.sp)
        docTypes.forEach { type -> DocumentPickerRow(type, pendingDocs[type], documentLoading) { onPickDocument(type) } }
        Spacer(Modifier.height(12.dp))
        Text("Required documents: ${pendingDocs.keys.intersect(docTypes.toSet()).size}/${docTypes.size}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        error?.let { ErrorStrip(it) }
        PrimaryAction("Submit ${category.title} application", busy || documentLoading, onSubmit)
        Spacer(Modifier.height(26.dp))
    }
}

@Composable
private fun RestaurantApplicationForm(
    restaurantName: String, onRestaurantName: (String) -> Unit, legalName: String, onLegalName: (String) -> Unit,
    cuisine: String, onCuisine: (String) -> Unit, fssai: String, onFssai: (String) -> Unit,
    pan: String, onPan: (String) -> Unit, gstin: String, onGstin: (String) -> Unit,
    supportEmail: String, onSupportEmail: (String) -> Unit, phone: String, onPhone: (String) -> Unit,
    city: String, onCity: (String) -> Unit, stateName: String, onState: (String) -> Unit,
    address: String, onAddress: (String) -> Unit, branchName: String, onBranchName: (String) -> Unit,
    postalCode: String, onPostalCode: (String) -> Unit,
    latitude: String, onLatitude: (String) -> Unit, longitude: String, onLongitude: (String) -> Unit, onUseLocation: () -> Unit,
    description: String, onDescription: (String) -> Unit,
    bankHolder: String, onBankHolder: (String) -> Unit, bankNumber: String, onBankNumber: (String) -> Unit, ifsc: String, onIfsc: (String) -> Unit,
    pendingDocs: Map<String, PendingDocument>, onPickDocument: (String) -> Unit,
    documentLoading: Boolean, busy: Boolean, error: String?, onSubmit: () -> Unit
) {
    val required = listOf("fssai_license", "pan_card", "bank_proof", "owner_identity", "restaurant_photo")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
        PartnerArtwork(PartnerCategory.RESTAURANT, 132.dp)
        Text("Restaurant onboarding", color = TextOnDark, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Text("Outlet, branch, compliance aur settlement details ek hi process mein submit karein.", color = Color(0xFFC2B9D4), fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(16.dp))
        SectionLabel("BUSINESS DETAILS")
        PartnerInput("Restaurant name", restaurantName, onRestaurantName)
        PartnerInput("Legal business name", legalName, onLegalName)
        PartnerInput("Cuisine types (comma separated)", cuisine, onCuisine)
        PartnerInput("FSSAI licence number", fssai, onFssai)
        PartnerInput("PAN number", pan, onPan)
        PartnerInput("GSTIN (optional)", gstin, onGstin)
        PartnerInput("Support phone", phone, onPhone, keyboard = KeyboardType.Phone)
        PartnerInput("Support email", supportEmail, onSupportEmail, keyboard = KeyboardType.Email)
        PartnerInput("Description", description, onDescription, singleLine = false)
        Spacer(Modifier.height(12.dp))
        SectionLabel("FIRST BRANCH")
        PartnerInput("Branch name", branchName, onBranchName)
        PartnerInput("Full outlet address", address, onAddress, singleLine = false)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PartnerInput("City", city, onCity) }
            Box(Modifier.weight(1f)) { PartnerInput("State", stateName, onState) }
        }
        PartnerInput("PIN code", postalCode, onPostalCode, keyboard = KeyboardType.Number)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PartnerInput("Outlet latitude", latitude, onLatitude, keyboard = KeyboardType.Decimal) }
            Box(Modifier.weight(1f)) { PartnerInput("Outlet longitude", longitude, onLongitude, keyboard = KeyboardType.Decimal) }
        }
        OutlinedButton(onClick = onUseLocation, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(8.dp))
            Text("Use current outlet location", color = TextOnDark)
        }
        Spacer(Modifier.height(12.dp))
        SectionLabel("SETTLEMENT DETAILS")
        PartnerInput("Account holder name", bankHolder, onBankHolder)
        PartnerInput("Bank account number", bankNumber, onBankNumber, keyboard = KeyboardType.Number)
        PartnerInput("IFSC code", ifsc, onIfsc)
        Spacer(Modifier.height(12.dp))
        SectionLabel("MANDATORY DOCUMENTS · CLOUD R2")
        Text("Admin approval ke liye in sabhi 5 files ka review zaroori hai.", color = Color(0xFFC2B9D4), fontSize = 11.sp)
        required.forEach { type -> DocumentPickerRow(type, pendingDocs[type], documentLoading) { onPickDocument(type) } }
        Spacer(Modifier.height(10.dp))
        Text("Uploaded: ${pendingDocs.keys.intersect(required.toSet()).size}/5", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        error?.let { ErrorStrip(it) }
        PrimaryAction("Submit restaurant application", busy || documentLoading, onSubmit)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ApplicationReviewScreen(
    category: PartnerCategory, status: String, rejectionReason: String?, busy: Boolean, error: String?,
    onRefresh: () -> Unit, onResubmit: () -> Unit
) {
    val approved = status.equals("approved", true)
    val rejected = status.equals("rejected", true) || status.equals("resubmission", true)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PartnerArtwork(category, 150.dp)
        Text(if (approved) "✅" else if (rejected) "📋" else "🛡️", fontSize = 62.sp)
        Spacer(Modifier.height(18.dp))
        Text(if (approved) "Application approved" else if (rejected) "Application needs an update" else "Application under review", color = TextOnDark, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("${category.title} · ${status.replaceFirstChar { it.uppercase() }}", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            if (approved) "Your ${category.title.lowercase()} partner profile is approved. Continue to your category dashboard."
            else if (rejected) "BAATLY review team ne additional information ya correction maangi hai. Reason neeche diya gaya hai."
            else "Your documents and details have been submitted. You will receive an update after the BAATLY review team completes verification.",
            color = Color(0xFFC6BDD5), fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 19.sp
        )
        if (!rejectionReason.isNullOrBlank()) {
            Spacer(Modifier.height(14.dp))
            Surface(color = Color(0xFF38213A), shape = RoundedCornerShape(16.dp)) { Text(rejectionReason, color = Color(0xFFFFD4D8), modifier = Modifier.padding(14.dp), fontSize = 12.sp) }
        }
        Spacer(Modifier.height(24.dp))
        error?.let { ErrorStrip(it) }
        if (rejected) PrimaryAction("Update application", busy, onResubmit)
        else PrimaryAction(if (approved) "Open partner dashboard" else "Refresh application status", busy, onRefresh)
        if (approved) { Spacer(Modifier.height(6.dp)); Text("Refresh once to open dashboard", color = Color(0xFFB6ACC7), fontSize = 10.sp) }
    }
}

@Composable
private fun NotificationConsentScreen(onContinue: () -> Unit, onSkip: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🔔", fontSize = 62.sp)
        Spacer(Modifier.height(18.dp))
        Text("Job notifications", color = TextOnDark, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text("New ride, food delivery, parcel offers aur restaurant orders ka alert milne ke liye notifications enable karein. App background mein ho tab bhi important updates pahunch sakein.", color = Color(0xFFC7BED8), fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        PrimaryAction("Enable notifications", false, onContinue)
        TextButton(onClick = onSkip) { Text("Continue without notifications", color = Gold) }
    }
}

@Composable
private fun BackgroundLocationConsentScreen(onContinue: () -> Unit, onOpenSettings: () -> Unit, error: String?, busy: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(86.dp).clip(CircleShape).background(Color(0xFF35234F)), contentAlignment = Alignment.Center) { Icon(Icons.Default.LocationOn, contentDescription = null, tint = Gold, modifier = Modifier.size(44.dp)) }
        Spacer(Modifier.height(20.dp))
        Text("Allow background location", color = TextOnDark, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text("Jab aap online honge, BAATLY ko aapki location background mein chahiye hogi taaki nearby ride, food ya parcel jobs sahi partner ko assign ho sakein aur customer live tracking dekh sake. Android 11 ya newer par App Settings → Permissions → Location mein 'Allow all the time' select karein.", color = Color(0xFFC7BED8), fontSize = 13.sp, lineHeight = 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        InfoTile("Only while you are online", "Location heartbeat is sent for active partner availability and assigned jobs.", "📍")
        Spacer(Modifier.height(14.dp))
        error?.let { ErrorStrip(it) }
        PrimaryAction("Continue to location permission", busy, onContinue)
        if (!error.isNullOrBlank()) TextButton(onClick = onOpenSettings) { Text("Open app settings", color = Gold) }
        Spacer(Modifier.height(8.dp))
        Text("You can go offline at any time. Location updates stop when you go offline.", color = Color(0xFFAAA0BB), fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MobilityPartnerDashboard(
    category: PartnerCategory,
    application: MobilityPartnerApplicationModel?,
    repository: PartnerOnboardingRepository,
    refreshToken: Int,
    busy: Boolean,
    error: String?,
    onToggleService: (serviceType: String, enable: Boolean, otherServiceOnline: Boolean) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var dashboard by remember { mutableStateOf<JSONObject?>(null) }
    var loadingDashboard by remember { mutableStateOf(true) }
    var actionBusy by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }
    var otpCode by remember { mutableStateOf("") }

    suspend fun reloadDashboard() {
        loadingDashboard = true
        val result = repository.getPartnerDashboard()
        if (result.isSuccess) {
            dashboard = result.getOrThrow()
            localError = null
        } else localError = result.exceptionOrNull()?.message ?: "Could not load partner jobs"
        loadingDashboard = false
    }
    LaunchedEffect(category, refreshToken) { reloadDashboard() }

    fun runAction(action: String, payload: Map<String, Any?>) {
        scope.launch {
            actionBusy = true
            localError = null
            val result = repository.performMobilityAction(action, payload)
            if (result.isFailure) localError = result.exceptionOrNull()?.message ?: "Action failed"
            else {
                otpCode = ""
                reloadDashboard()
            }
            actionBusy = false
        }
    }

    fun coordinate(job: JSONObject?, key: String): Double? {
        if (job == null || !job.has(key) || job.isNull(key)) return null
        return job.optDouble(key).takeIf { it.isFinite() && it in -180.0..180.0 }
    }

    val offers = dashboard?.optJSONArray("offers") ?: JSONArray()
    val active = dashboard?.optJSONObject("active_job")
    val activeType = active?.optString("job_type").orEmpty()
    val activeId = active?.optString("job_id").orEmpty()
    val activeJob = active?.optJSONObject("job")
    val activeStatus = activeJob?.optString("status").orEmpty()
    val wallet = dashboard?.optJSONObject("wallet")
    val services = dashboard?.optJSONArray("services") ?: JSONArray()
    val offeredJob = offers.optJSONObject(0)?.optJSONObject("job")
    val mapJob = activeJob ?: offeredJob
    val mapJobType = if (activeJob != null) activeType else offers.optJSONObject(0)?.optString("job_type").orEmpty()
    val pickupLat = coordinate(mapJob, "pickup_latitude")
    val pickupLng = coordinate(mapJob, "pickup_longitude")
    val dropLat = coordinate(mapJob, if (mapJobType == "food") "delivery_latitude" else "drop_latitude")
    val dropLng = coordinate(mapJob, if (mapJobType == "food") "delivery_longitude" else "drop_longitude")
    val pickupAddress = mapJob?.optString("pickup_address")?.takeIf { it.isNotBlank() }
        ?: mapJob?.optString("restaurant_name")?.takeIf { it.isNotBlank() } ?: "Pickup location"
    val dropAddress = mapJob?.optString("delivery_address")?.takeIf { it.isNotBlank() }
        ?: mapJob?.optString("drop_address")?.takeIf { it.isNotBlank() } ?: "Drop location"
    val serviceTypes = if (category == PartnerCategory.TWO_WHEELER) {
        listOf("bike_taxi", "food_delivery", "parcel")
    } else listOf("cab")
    val online = (0 until services.length()).mapNotNull { services.optJSONObject(it) }
        .any { it.optBoolean("is_online") }

    Box(Modifier.fillMaxSize()) {
        PartnerFullScreenGoogleMap(
            modifier = Modifier.fillMaxSize(),
            pickupAddress = pickupAddress,
            pickupLatitude = pickupLat,
            pickupLongitude = pickupLng,
            dropAddress = dropAddress,
            dropLatitude = dropLat,
            dropLongitude = dropLng
        )

        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                    .clip(RoundedCornerShape(18.dp)).background(Ink.copy(alpha = 0.94f)).padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextOnDark)
                }
                Column(Modifier.weight(1f)) {
                    Text(category.title, color = TextOnDark, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text(if (online) "LIVE GPS · ONLINE" else "GO ONLINE TO RECEIVE JOBS", color = if (online) Mint else Color(0xFFC5BBD4), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                }
                Surface(color = if (online) Color(0xFF174E43) else Color(0xFF44364F), shape = RoundedCornerShape(20.dp)) {
                    Text(if (online) "● LIVE" else "OFFLINE", color = if (online) Mint else Color(0xFFD5C8E5), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Column(
                Modifier.fillMaxWidth().heightIn(max = 570.dp)
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(Ink.copy(alpha = 0.96f))
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 17.dp, vertical = 15.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Your work, one screen", color = TextOnDark, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Text(if (category == PartnerCategory.TWO_WHEELER) "One approved bike · 3 services · choose what to receive" else "Cab requests and live trip status", color = Color(0xFFC5BCD4), fontSize = 11.sp)
                    }
                    if (loadingDashboard) CircularProgressIndicator(Modifier.size(22.dp), color = Gold, strokeWidth = 2.dp)
                }
                Spacer(Modifier.height(12.dp))
                SectionLabel(if (category == PartnerCategory.TWO_WHEELER) "CHOOSE YOUR ACTIVE SERVICES" else "CAB SERVICE")
                serviceTypes.forEach { serviceType ->
                    val service = (0 until services.length()).mapNotNull { services.optJSONObject(it) }
                        .firstOrNull { it.optString("service_type") == serviceType }
                    val enabled = service?.optBoolean("is_enabled") == true
                    val isOnline = service?.optBoolean("is_online") == true
                    val otherOnline = (0 until services.length()).mapNotNull { services.optJSONObject(it) }
                        .any { it.optString("service_type") != serviceType && it.optBoolean("is_online") }
                    val title = when (serviceType) {
                        "bike_taxi" -> "Bike Taxi"
                        "food_delivery" -> "Food Delivery"
                        "parcel" -> "Parcel Delivery"
                        else -> "Cab / Auto"
                    }
                    val subtitle = when (serviceType) {
                        "bike_taxi" -> "Passenger rides on your bike"
                        "food_delivery" -> "Restaurant pickup and customer drop"
                        "parcel" -> "Local parcel pickup and delivery"
                        else -> "Auto, e-rickshaw or car trips"
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(15.dp)).background(Color(0xFF2B2140)).padding(horizontal = 13.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(title, color = TextOnDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(if (enabled) subtitle else "Awaiting admin approval", color = Color(0xFFC1B7D0), fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Switch(
                                checked = isOnline,
                                onCheckedChange = { value -> onToggleService(serviceType, value, otherOnline) },
                                enabled = enabled && !busy && !actionBusy
                            )
                            Text(if (!enabled) "LOCKED" else if (isOnline) "ON" else "OFF", color = if (isOnline) Mint else Color(0xFFBDB2CC), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (serviceTypes.all { serviceType ->
                        (0 until services.length()).mapNotNull { services.optJSONObject(it) }
                            .none { it.optString("service_type") == serviceType && it.optBoolean("is_enabled") }
                    }) {
                    InfoTile("Approval pending", "Your service switches will unlock after BAATLY verifies your application and documents.", "🔐")
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    MiniStat("COD balance", "₹${wallet?.optString("balance_rupees", "0") ?: "0"}", Modifier.weight(1f))
                    MiniStat("Earnings", "₹${wallet?.optString("earning_balance_rupees", "0") ?: "0"}", Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))

                if (activeId.isNotBlank() && activeJob != null) {
                    SectionLabel("ACTIVE ${activeType.uppercase()} JOB · ${activeStatus.replace('_', ' ').uppercase()}")
                    Text(pickupAddress, color = TextOnDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("↓  $dropAddress", color = Color(0xFFC6BCD6), fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                        GoogleMapsNavigationButton("Navigate pickup", pickupLat, pickupLng, modifier = Modifier.weight(1f))
                        GoogleMapsNavigationButton("Navigate drop", dropLat, dropLng, modifier = Modifier.weight(1f))
                    }
                    Text("${activeJob.optString("route_distance_km", activeJob.optString("road_distance_km", "—"))} km · ₹${activeJob.optString("quoted_fare", activeJob.optString("customer_total", "—"))} · ${activeJob.optString("payment_method", "COD")}", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(9.dp))
                    when (activeType) {
                        "cab" -> when (activeStatus) {
                            "accepted", "driver_arriving" -> PrimaryAction("I'm at the pickup point", actionBusy, { runAction("mark_cab_arrived", mapOf("ride_id" to activeId)) })
                            "arrived" -> {
                                PartnerInput("Customer ride start code", otpCode, { otpCode = it }, keyboard = KeyboardType.Number)
                                PrimaryAction("Verify code & start ride", actionBusy, { runAction("verify_ride_code", mapOf("ride_id" to activeId, "code" to otpCode)) })
                            }
                            "in_progress" -> PrimaryAction("Complete ride", actionBusy, { runAction("complete_cab_ride", mapOf("ride_id" to activeId)) })
                        }
                        "food" -> when (activeStatus) {
                            "partner_assigned" -> {
                                PartnerInput("Restaurant pickup code", otpCode, { otpCode = it }, keyboard = KeyboardType.Number)
                                PrimaryAction("Verify pickup code", actionBusy, { runAction("partner_pickup_food", mapOf("order_id" to activeId, "code" to otpCode)) })
                            }
                            "picked_up" -> PrimaryAction("Food picked up · Start delivery", actionBusy, { runAction("partner_food_on_the_way", mapOf("order_id" to activeId)) })
                            "on_the_way" -> {
                                PartnerInput("Customer delivery code", otpCode, { otpCode = it }, keyboard = KeyboardType.Number)
                                PrimaryAction("Verify delivery & complete", actionBusy, { runAction("complete_food_order", mapOf("order_id" to activeId, "code" to otpCode)) })
                            }
                        }
                        "parcel" -> when (activeStatus) {
                            "accepted", "driver_arriving", "arrived" -> {
                                if (activeStatus != "arrived") PrimaryAction("Arrived at parcel pickup", actionBusy, { runAction("mark_parcel_arrived", mapOf("parcel_id" to activeId)) })
                                PartnerInput("Sender pickup code", otpCode, { otpCode = it }, keyboard = KeyboardType.Number)
                                PrimaryAction("Verify pickup & start delivery", actionBusy, { runAction("partner_pickup_parcel", mapOf("parcel_id" to activeId, "code" to otpCode)) })
                            }
                            "in_transit" -> {
                                PartnerInput("Receiver delivery code", otpCode, { otpCode = it }, keyboard = KeyboardType.Number)
                                PrimaryAction("Verify delivery & complete parcel", actionBusy, { runAction("complete_parcel", mapOf("parcel_id" to activeId, "code" to otpCode)) })
                            }
                        }
                    }
                } else {
                    SectionLabel("ACTIVE JOB")
                    InfoTile("No active job", "Your full-screen map is ready. Accept an incoming request to see the exact pickup and drop pins.", "🧭")
                }

                SectionLabel("INCOMING OFFERS · ${offers.length()}")
                if (loadingDashboard) {
                    Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
                } else if (offers.length() == 0) {
                    InfoTile("No new offers", "Keep one or more services ON. New matching jobs will appear here while GPS tracking stays active.", "🔔")
                } else {
                    for (index in 0 until offers.length()) {
                        val offer = offers.optJSONObject(index) ?: continue
                        val job = offer.optJSONObject("job") ?: JSONObject()
                        val offerId = offer.optString("id")
                        val jobType = offer.optString("job_type")
                        val offerPickup = job.optString("pickup_address").ifBlank { job.optString("restaurant_name", "Restaurant pickup") }
                        val offerDrop = if (jobType == "food") job.optString("delivery_address") else job.optString("drop_address")
                        val offerPickupLat = coordinate(job, "pickup_latitude")
                        val offerPickupLng = coordinate(job, "pickup_longitude")
                        val offerDropLat = coordinate(job, if (jobType == "food") "delivery_latitude" else "drop_latitude")
                        val offerDropLng = coordinate(job, if (jobType == "food") "delivery_longitude" else "drop_longitude")
                        val amount = if (jobType == "food") job.optString("delivery_partner_net", "—") else job.optString("quoted_fare", "—")
                        Column(Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF2B2140)).padding(12.dp)) {
                            Text("${jobType.uppercase()} REQUEST · ${offer.optString("radius_km")} KM RADIUS", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(offerPickup, color = TextOnDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("↓ ${offerDrop.ifBlank { "Drop details" }}", color = Color(0xFFC2B9D4), fontSize = 11.sp)
                            Text("₹$amount · ${job.optString("route_distance_km", job.optString("road_distance_km", "—"))} km · ${job.optString("payment_method", "COD")}", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                GoogleMapsNavigationButton("Pickup", offerPickupLat, offerPickupLng, modifier = Modifier.weight(1f))
                                GoogleMapsNavigationButton("Drop", offerDropLat, offerDropLng, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 7.dp)) {
                                OutlinedButton(onClick = { runAction("reject_offer", mapOf("offer_id" to offerId)) }, enabled = !actionBusy && !busy, modifier = Modifier.weight(1f)) { Text("Reject", color = Color(0xFFFFB7C3)) }
                                Button(onClick = { scope.launch { actionBusy = true; val result = repository.respondToOffer(offerId, true); if (result.isFailure) localError = result.exceptionOrNull()?.message else reloadDashboard(); actionBusy = false } }, enabled = !actionBusy && !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Accept offer", color = Color.White) }
                            }
                        }
                    }
                }
                error?.let { ErrorStrip(it) }
                localError?.let { ErrorStrip(it) }
                TextButton(onClick = { scope.launch { reloadDashboard() } }, enabled = !loadingDashboard) { Text("Refresh jobs", color = Gold) }
                TextButton(onClick = onBack) { Text("Switch partner category", color = Gold) }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF2B2140)).padding(12.dp)) {
        Text(label, color = Color(0xFFBDB3D0), fontSize = 10.sp)
        Text(value, color = TextOnDark, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RestaurantPartnerDashboard(
    restaurant: MobilityRestaurantModel?, branch: MobilityRestaurantBranchModel?, repository: PartnerOnboardingRepository,
    categoryName: String, onCategoryName: (String) -> Unit, categoryId: String, onCategoryId: (String) -> Unit,
    itemName: String, onItemName: (String) -> Unit, itemPrice: String, onItemPrice: (String) -> Unit,
    foodType: String, onFoodType: (String) -> Unit,
    menuImage: PendingDocument?, onPickMenuImage: () -> Unit, onClearMenuImage: () -> Unit,
    busy: Boolean, error: String?, onBusy: (Boolean) -> Unit, onError: (String?) -> Unit, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var isOpen by remember { mutableStateOf(branch?.isOpen == true) }
    var dashboard by remember { mutableStateOf<JSONObject?>(null) }
    var orders by remember { mutableStateOf(JSONArray()) }
    var menuCategories by remember { mutableStateOf(JSONArray()) }
    var menuItems by remember { mutableStateOf(JSONArray()) }
    var loading by remember { mutableStateOf(true) }

    suspend fun reload() {
        loading = true
        val result = repository.getPartnerDashboard()
        if (result.isSuccess) {
            dashboard = result.getOrThrow()
            val restaurants = dashboard?.optJSONArray("restaurants") ?: JSONArray()
            val found = (0 until restaurants.length()).mapNotNull { restaurants.optJSONObject(it) }
                .firstOrNull { it.optString("id") == restaurant?.id }
            orders = found?.optJSONArray("orders") ?: JSONArray()
            menuCategories = found?.optJSONArray("menu_categories") ?: JSONArray()
            menuItems = found?.optJSONArray("menu_items") ?: JSONArray()
            val branches = found?.optJSONArray("branches") ?: JSONArray()
            val current = (0 until branches.length()).mapNotNull { branches.optJSONObject(it) }
                .firstOrNull { it.optString("id") == branch?.id }
            if (current != null) isOpen = current.optBoolean("is_open", isOpen)
        } else onError(result.exceptionOrNull()?.message ?: "Could not load restaurant orders")
        loading = false
    }
    LaunchedEffect(restaurant?.id) { reload() }

    fun updateOrder(orderId: String, action: String) {
        scope.launch {
            onBusy(true); onError(null)
            val result = repository.updateRestaurantOrder(orderId, action)
            if (result.isFailure) onError(result.exceptionOrNull()?.message)
            else reload()
            onBusy(false)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        PartnerArtwork(PartnerCategory.RESTAURANT, 128.dp)
        Text(restaurant?.restaurantName ?: "Restaurant dashboard", color = TextOnDark, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        Text("Restaurant Partner workspace", color = Color(0xFFC2B9D4), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        InfoTile(if (isOpen) "Outlet is accepting orders" else "Outlet is closed", "Only an admin-approved and active branch can receive BAATLY orders.", if (isOpen) "🟢" else "🍽️")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Accept new orders", color = TextOnDark, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Switch(checked = isOpen, onCheckedChange = { value ->
                val branchId = branch?.id
                if (branchId != null) scope.launch {
                    onBusy(true); onError(null)
                    val result = repository.setRestaurantBranchOpen(branchId, value)
                    if (result.isSuccess) isOpen = value else onError(result.exceptionOrNull()?.message)
                    onBusy(false)
                }
            }, enabled = !busy && branch?.isActive == true)
        }
        Spacer(Modifier.height(16.dp))
        SectionLabel("LIVE ORDERS · ${orders.length()}")
        if (loading) {
            Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
        } else if (orders.length() == 0) {
            InfoTile("No active orders", "New customer orders will appear here. Keep your approved branch open to receive orders.", "🧾")
        } else {
            for (index in 0 until orders.length()) {
                val order = orders.optJSONObject(index) ?: continue
                val orderId = order.optString("id")
                val orderStatus = order.optString("status")
                val orderItems = order.optJSONArray("items") ?: JSONArray()
                Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2C2142)).padding(13.dp)) {
                    Text("ORDER #${orderId.take(8).uppercase()} · ${orderStatus.replace('_',' ').uppercase()}", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(order.optString("delivery_address", "Customer delivery"), color = TextOnDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text("₹${order.optString("customer_total", "0")} · ${order.optString("payment_method", "COD")}", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    for (itemIndex in 0 until orderItems.length()) {
                        val item = orderItems.optJSONObject(itemIndex) ?: continue
                        Text("${item.optString("quantity")} × ${item.optString("item_name_snapshot")}  ·  ₹${item.optString("line_total")}", color = Color(0xFFC2B9D4), fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    when (orderStatus) {
                        "placed" -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { updateOrder(orderId, "reject") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Reject", color = Color(0xFFFFB7C3)) }
                            Button(onClick = { updateOrder(orderId, "accept") }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Accept order", color = Color.White) }
                        }
                        "restaurant_accepted" -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { updateOrder(orderId, "preparing") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Preparing", color = Gold) }
                            Button(onClick = { updateOrder(orderId, "ready") }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Ready", color = Color.White) }
                        }
                        "preparing" -> PrimaryAction("Mark ready for pickup", busy, { updateOrder(orderId, "ready") })
                        "ready" -> Text("Ready · Waiting for delivery partner", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SectionLabel("CURRENT MENU · ${menuItems.length()} ITEMS")
        if (menuCategories.length() > 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                for (catIndex in 0 until menuCategories.length()) {
                    val menuCat = menuCategories.optJSONObject(catIndex) ?: continue
                    Surface(color = Color(0xFF37264F), shape = RoundedCornerShape(20.dp)) {
                        Text(menuCat.optString("name"), color = TextOnDark, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
            }
        }
        if (menuItems.length() == 0) {
            InfoTile("Menu is empty", "Add a category and start adding dishes with price, food type and an optional R2 photo.", "🍲")
        } else {
            for (menuIndex in 0 until menuItems.length()) {
                val menuItem = menuItems.optJSONObject(menuIndex) ?: continue
                val itemId = menuItem.optString("id")
                val isAvailable = menuItem.optBoolean("is_available", true)
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF2B2140)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(menuItem.optString("item_name"), color = TextOnDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("₹${menuItem.optString("price")} · ${menuItem.optString("food_type").replace('_',' ')} · ${if (menuItem.optString("image_object_key").isNotBlank()) "Photo added" else "No photo"}", color = Color(0xFFC2B9D4), fontSize = 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Switch(checked = isAvailable, onCheckedChange = { value ->
                            scope.launch {
                                onBusy(true); onError(null)
                                val result = repository.upsertMenuItem(mapOf(
                                    "id" to itemId, "restaurant_id" to restaurant?.id, "branch_id" to branch?.id,
                                    "category_id" to menuItem.optString("category_id").ifBlank { null },
                                    "item_name" to menuItem.optString("item_name"), "description" to menuItem.optString("description"),
                                    "price" to menuItem.optDouble("price"), "image_object_key" to menuItem.optString("image_object_key").ifBlank { null },
                                    "food_type" to menuItem.optString("food_type", "veg"), "is_available" to value,
                                    "is_active" to menuItem.optBoolean("is_active", true),
                                    "preparation_time_minutes" to menuItem.optInt("preparation_time_minutes", 20),
                                    "display_order" to menuItem.optInt("display_order", 0)
                                ))
                                if (result.isSuccess) reload() else onError(result.exceptionOrNull()?.message)
                                onBusy(false)
                            }
                        }, enabled = !busy)
                        Text(if (isAvailable) "Available" else "Paused", color = if (isAvailable) Mint else Color(0xFFFFC5CB), fontSize = 9.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SectionLabel("MENU MANAGEMENT")
        PartnerInput("New menu category", categoryName, onCategoryName)
        PrimaryAction("Save category", busy, {
            val restId = restaurant?.id ?: return@PrimaryAction
            scope.launch {
                onBusy(true); onError(null)
                val result = repository.upsertMenuCategory(mapOf("restaurant_id" to restId, "branch_id" to branch?.id, "name" to categoryName.trim()))
                if (result.isSuccess) { onCategoryId(result.getOrThrow()); onCategoryName(""); reload() }
                else onError(result.exceptionOrNull()?.message)
                onBusy(false)
            }
        })
        if (categoryId.isNotBlank()) Text("Saved category ID: ${categoryId.take(8)}", color = Mint, fontSize = 10.sp)
        Spacer(Modifier.height(12.dp))
        PartnerInput("Menu item name", itemName, onItemName)
        PartnerInput("Price (₹)", itemPrice, onItemPrice, keyboard = KeyboardType.Decimal)
        PartnerDropdown("Food type", foodType, listOf("veg", "non_veg", "egg"), onFoodType)
        DocumentPickerRow("menu item photo (optional)", menuImage, false, onPickMenuImage)
        if (menuImage != null) TextButton(onClick = onClearMenuImage) { Text("Remove selected photo", color = Color(0xFFFFB7C3)) }
        PrimaryAction("Add menu item", busy, {
            val restId = restaurant?.id ?: return@PrimaryAction
            val price = itemPrice.toDoubleOrNull()
            if (price == null || price < 0 || itemName.isBlank()) { onError("Enter item name and a valid price."); return@PrimaryAction }
            scope.launch {
                onBusy(true); onError(null)
                val imageKey = if (menuImage != null) {
                    val upload = repository.uploadDocument(menuImage.bytes, menuImage.contentType, "menu_image", restId)
                    if (upload.isFailure) {
                        onError(upload.exceptionOrNull()?.message ?: "Menu photo upload failed")
                        onBusy(false)
                        return@launch
                    }
                    upload.getOrThrow()
                } else null
                val result = repository.upsertMenuItem(mapOf(
                    "restaurant_id" to restId, "branch_id" to branch?.id, "category_id" to categoryId.ifBlank { null },
                    "item_name" to itemName.trim(), "price" to price, "food_type" to foodType,
                    "image_object_key" to imageKey, "is_available" to true, "is_active" to true
                ))
                if (result.isSuccess) { onItemName(""); onItemPrice(""); onClearMenuImage(); reload() }
                else onError(result.exceptionOrNull()?.message)
                onBusy(false)
            }
        })
        Spacer(Modifier.height(14.dp))
        InfoTile("Branch", branch?.branchName ?: "Primary branch", "🏬")
        InfoTile("Location", listOfNotNull(branch?.address, branch?.city, branch?.state).joinToString(", ").ifBlank { "Not available" }, "📍")
        error?.let { ErrorStrip(it) }
        TextButton(onClick = { scope.launch { reload() } }, enabled = !loading) { Text("Refresh restaurant orders", color = Gold) }
        Spacer(Modifier.height(16.dp))
        Text("Orders, menu, branch status and settlement records are linked to your restaurant account. Customer-facing availability is controlled by your approved branch status.", color = Color(0xFFBDB3D0), fontSize = 11.sp, lineHeight = 16.sp)
        TextButton(onClick = onBack) { Text("Switch partner category", color = Gold) }
    }
}

@Composable
private fun FullScreenStatus(title: String, description: String, art: String, busy: Boolean = false) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(art, fontSize = 62.sp)
        Spacer(Modifier.height(16.dp))
        Text(title, color = TextOnDark, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Color(0xFFC3BAD3), fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
        if (busy) { Spacer(Modifier.height(18.dp)); CircularProgressIndicator(color = Gold) }
    }
}

@Composable
private fun PartnerInput(
    label: String, value: String, onValueChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false, singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label) }, singleLine = singleLine,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF594B70),
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedLabelColor = Gold, unfocusedLabelColor = Color(0xFFB7ADC8), cursorColor = Gold
        ),
        shape = RoundedCornerShape(14.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PartnerDropdown(label: String, value: String, options: List<String>, onValue: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value.replace('_', ' ').replaceFirstChar { it.uppercase() }, onValueChange = {}, readOnly = true,
            label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth().padding(bottom = 9.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF594B70), focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = Gold, unfocusedLabelColor = Color(0xFFB7ADC8)),
            shape = RoundedCornerShape(14.dp)
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option.replace('_', ' ').replaceFirstChar { it.uppercase() }) }, onClick = { onValue(option); expanded = false }) }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Gold, fontSize = 10.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
}

@Composable
private fun InfoTile(title: String, description: String, art: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A2040)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(art, fontSize = 28.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = TextOnDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(description, color = Color(0xFFC1B8D0), fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun DocumentPickerRow(type: String, file: PendingDocument?, loading: Boolean, onPick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 7.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF2B2140)).clickable(onClick = onPick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (file != null) Icons.Default.CheckCircle else Icons.Default.CloudUpload, contentDescription = null, tint = if (file != null) Mint else Gold)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(type.replace('_', ' ').replaceFirstChar { it.uppercase() }, color = TextOnDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(file?.fileName ?: if (loading) "Reading file…" else "Tap to attach PDF or image", color = Color(0xFFB9AFC9), fontSize = 9.sp)
        }
        Text(if (file != null) "Added" else "Add", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ErrorStrip(message: String) {
    Surface(color = Color(0xFF402333), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Text(message, color = Color(0xFFFFCDD6), fontSize = 11.sp, modifier = Modifier.padding(12.dp), lineHeight = 16.sp)
    }
}

@Composable
private fun PrimaryAction(label: String, busy: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = !busy,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Violet, disabledContainerColor = Color(0xFF594A70))
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
        else Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
