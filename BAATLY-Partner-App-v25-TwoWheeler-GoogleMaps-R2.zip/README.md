# BAATLY Partner App — v1.2.0 (versionCode 25)

The app starts with **four partner choices** before any onboarding begins:

- **Hosting** — continues into the existing Host onboarding, verification and Host experience. The previous Host flow is kept separate.
- **Two-Wheeler Partner** — one bike/scooter application covers **Bike Taxi, Food Delivery and Parcel Delivery**. After admin approval, the Go Online workspace shows three independent ON/OFF switches. The partner can turn on any one, two or all three services without applying again.
- **Cab Partner** — one cab application for auto, e-rickshaw, mini, sedan, SUV, XL or premium vehicles.
- **Restaurant Partner** — outlet, branch, compliance documents, menu and live restaurant orders.

## Mobility workflow

A two-wheeler applicant submits one identity, bike and banking application with `requested_services` set to `bike_taxi`, `food_delivery` and `parcel`. The existing BAATLY review RPC approves those requested services together. The approved service rows are controlled independently from the Go Online screen. Cab applicants submit only the `cab` service.

The mobility workspace uses a **full-screen Google Map** behind the work panel. Active jobs and incoming offers display pickup/drop pins when the server has coordinates. Each pickup/drop navigation action opens the same coordinate directly in Google Maps; if the Google Maps app is unavailable, it opens Google Maps directions in a browser. While any mobility service is online, `MobilityLocationForegroundService` sends authenticated GPS heartbeats every five seconds / ten metres (subject to actual device movement and Android background-location rules).

## Supabase and Cloudflare R2

The app connects to the existing BAATLY Supabase project and deployed Edge Functions:

- `baatly-mobility-api` — partner application submission, restaurant creation, independent service online state, dashboard offers, active jobs, OTP actions, restaurant order state and menu writes.
- `baatly-mobility-media` — signed Cloudflare R2 uploads for partner documents, restaurant compliance files and menu images.

Private onboarding documents and menu photos upload directly to signed R2 URLs and then call `finalize_upload`. These new mobility/restaurant document paths do not use Supabase Storage.

### Mobility documents

- All driver/vehicle applications: identity proof, driving licence, vehicle RC, vehicle insurance, PUC, police verification, selfie and bank proof.
- Commercial vehicle categories: vehicle permit and fitness certificate.
- Two-Wheeler Partner: bike-taxi permit, because Bike Taxi is included in the same application.

### Restaurant documents

Restaurant onboarding requires FSSAI licence, PAN card, bank proof, owner identity and restaurant photo. The app creates the outlet/branch and owner membership, uploads the files to R2 and attaches them to the restaurant/branch.

## Google Maps API key

The Google Maps SDK for Android and Maps Compose are configured. The key is read from the local root `.env` file through the Secrets Gradle Plugin and inserted into the Android manifest as `com.google.android.geo.API_KEY`.

- `MAPS_API_KEY` is already present in this local project `.env` file for local builds.
- `.env` is in `.gitignore`; do **not** commit it or paste the key into Kotlin/XML source.
- For GitHub Actions, save the key as a repository secret named `MAPS_API_KEY`; the included `Build BAATLY Partner Debug APK` workflow writes it into an ignored `.env` file and builds the debug APK.
- In Google Cloud Console, enable **Maps SDK for Android** and restrict the key to Android app `com.aistudio.baatlypartner.hostapp` plus the release/debug signing certificate SHA-1 fingerprints. Also apply API restrictions.

Google Maps Android keys are embedded in the compiled APK, so Android application restrictions are essential even when the source key is kept outside version control.

## Permission flow

- Job/order notifications: explained on a full-screen permission step before the partner workspace.
- Foreground location: requested when a mobility partner turns on a service.
- Background location: explained and requested separately for continuous trip tracking when the app is minimized.
- The location foreground service stays active while at least one mobility service is online and stops after the last service is switched off.
- Documents and menu photos use the Android document picker; camera access is not required for these uploads.

## Build

1. Open this project directory in Android Studio and allow Gradle sync.
2. Confirm the local `.env` has `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `AGORA_APP_ID` and `MAPS_API_KEY`.
3. Build with `./gradlew :app:assembleDebug` or use **Build > Make Project**.
4. For release signing, provide `KEYSTORE_PATH`, `STORE_PASSWORD` and `KEY_PASSWORD` through your local build environment or CI secrets. Do not commit signing credentials.

The previous Host flow is intentionally kept separate. This revision uses the existing BAATLY mobility and restaurant tables/RPCs and the already-deployed R2 media function.
