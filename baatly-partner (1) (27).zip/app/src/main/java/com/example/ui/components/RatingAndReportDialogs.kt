package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BaatlyApp
import com.example.data.models.CallRatingEligibility
import com.example.data.models.UserRatingModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

val REPORT_CATEGORIES = listOf(
    "Harassment",
    "Inappropriate Behavior",
    "Spam",
    "Scam/Fraud",
    "Abusive Content",
    "Other"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportUserDialog(
    reportedUserId: String,
    userName: String,
    callId: String? = null,
    messageId: String? = null,
    onDismiss: () -> Unit,
    onReportSubmitted: () -> Unit = {}
) {
    val context = LocalContext.current
    val app = context.applicationContext as BaatlyApp
    val callRepo = app.callRepository
    val scope = rememberCoroutineScope()

    var selectedCategory by remember { mutableStateOf(REPORT_CATEGORIES.first()) }
    var description by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (isSuccess) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(BaatlyGreenLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BaatlyGreen,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Report Submitted",
                            color = TextPrimaryLight,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Thank you for helping keep Baatly safe. Our moderation team will investigate this report promptly.",
                            color = TextSecondaryLight,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = {
                                onReportSubmitted()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("report_success_done_button")
                        ) {
                            Text("Done", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyRedLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Report,
                                    contentDescription = null,
                                    tint = BaatlyRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Report User",
                                color = TextPrimaryLight,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            enabled = !isSubmitting,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Close",
                                tint = TextSecondaryLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Reporting: $userName",
                        color = TextSecondaryLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Select Reason",
                        color = TextPrimaryLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        REPORT_CATEGORIES.forEach { category ->
                            val isSelected = selectedCategory == category
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) BaatlyPrimaryLight else Color(0xFFF8FAFC))
                                    .clickable(enabled = !isSubmitting) { selectedCategory = category }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedCategory = category },
                                    colors = RadioButtonDefaults.colors(selectedColor = BaatlyPrimary),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = category,
                                    color = if (isSelected) BaatlyPrimary else TextPrimaryLight,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Additional Details (Optional)",
                        color = TextPrimaryLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        placeholder = { Text("Provide any details that can help our review...", fontSize = 12.sp, color = TextSecondaryLight) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .testTag("report_description_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder
                        ),
                        maxLines = 4
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = BaatlyRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            enabled = !isSubmitting,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel", color = TextSecondaryLight)
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    isSubmitting = true
                                    errorMessage = null
                                    val res = callRepo.submitUserReport(
                                        reportedUserId = reportedUserId,
                                        category = selectedCategory,
                                        description = description.takeIf { it.isNotBlank() },
                                        callId = callId,
                                        messageId = messageId
                                    )
                                    isSubmitting = false
                                    if (res.isSuccess) {
                                        isSuccess = true
                                    } else {
                                        errorMessage = res.exceptionOrNull()?.message ?: "Failed to submit report. Please try again."
                                    }
                                }
                            },
                            enabled = !isSubmitting,
                            colors = ButtonDefaults.buttonColors(containerColor = BaatlyRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_report_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text("Submit", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PostCallRatingSection(
    callId: String,
    userId: String,
    userName: String,
    onRatingSubmitted: () -> Unit = {},
    onRequestReport: () -> Unit = {}
) {
    val context = LocalContext.current
    val app = context.applicationContext as BaatlyApp
    val callRepo = app.callRepository
    val scope = rememberCoroutineScope()

    var eligibility by remember { mutableStateOf<CallRatingEligibility?>(null) }
    var isCheckingEligibility by remember { mutableStateOf(true) }

    var selectedRating by remember { mutableIntStateOf(5) }
    var reviewText by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var submitError by remember { mutableStateOf<String?>(null) }
    var hasRated by remember { mutableStateOf(false) }

    LaunchedEffect(callId) {
        isCheckingEligibility = true
        val res = callRepo.getCallRatingEligibility(callId)
        eligibility = res.getOrNull()
        isCheckingEligibility = false
    }

    if (isCheckingEligibility) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = BaatlyPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Checking rating eligibility...", fontSize = 12.sp, color = TextSecondaryLight)
        }
        return
    }

    val eligible = eligibility?.eligible == true
    val alreadyRated = eligibility?.rated == true || hasRated

    if (alreadyRated) {
        Surface(
            color = Color(0xFFF0FDF4),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Star, contentDescription = null, tint = BaatlyGold, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Rating recorded! Thank you for rating this call.",
                    color = Color(0xFF166534),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        return
    }

    if (!eligible) {
        // Not eligible for rating (e.g. call too short or rejected)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = eligibility?.reason ?: "Call completed",
                fontSize = 11.sp,
                color = TextSecondaryLight
            )
            TextButton(
                onClick = onRequestReport,
                modifier = Modifier.testTag("post_call_report_button")
            ) {
                Icon(Icons.Default.Report, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Report Caller", color = BaatlyRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        return
    }

    // Eligible for rating!
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("post_call_rating_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Rate Call with $userName",
                color = TextPrimaryLight,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // 5 Stars interactive selector
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                (1..5).forEach { star ->
                    IconButton(
                        onClick = { selectedRating = star },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("rating_star_$star")
                    ) {
                        Icon(
                            imageVector = if (star <= selectedRating) Icons.Filled.Star else Icons.Outlined.Star,
                            contentDescription = "Star $star",
                            tint = if (star <= selectedRating) BaatlyGold else Color(0xFFCBD5E1),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = reviewText,
                onValueChange = { reviewText = it },
                placeholder = { Text("Write feedback (optional)...", fontSize = 11.sp, color = TextSecondaryLight) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(65.dp)
                    .testTag("call_rating_review_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BaatlyGold,
                    unfocusedBorderColor = Color(0xFFE2E8F0),
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                maxLines = 2
            )

            if (submitError != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = submitError ?: "",
                    color = BaatlyRed,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onRequestReport,
                    modifier = Modifier.testTag("post_call_report_button")
                ) {
                    Icon(Icons.Default.Report, contentDescription = null, tint = BaatlyRed, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Report", color = BaatlyRed, fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        scope.launch {
                            isSubmitting = true
                            submitError = null
                            val res = callRepo.submitCallRating(
                                callId = callId,
                                ratedUserId = userId,
                                rating = selectedRating,
                                reviewText = reviewText.takeIf { it.isNotBlank() }
                            )
                            isSubmitting = false
                            if (res.isSuccess) {
                                hasRated = true
                                onRatingSubmitted()
                            } else {
                                submitError = res.exceptionOrNull()?.message ?: "Failed to submit rating"
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyGold),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("submit_call_rating_button")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Submit Rating", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
