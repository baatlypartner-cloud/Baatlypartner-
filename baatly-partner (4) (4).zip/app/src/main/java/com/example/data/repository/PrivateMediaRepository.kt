package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class PrivateMediaRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    private val TAG = "PrivateMediaRepo"
    
    // In-memory cache: "bucket:path" -> Pair(signedUrl, expiryMillis)
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    suspend fun getSignedUrl(bucket: String, path: String, expiresInSeconds: Int = 7200): Result<String> = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        val cacheKey = "$bucket:$cleanPath"
        val now = System.currentTimeMillis()

        urlCache[cacheKey]?.let { (cachedUrl, expiry) ->
            if (now < expiry - 60_000) { // Valid for at least another minute
                return@withContext Result.success(cachedUrl)
            }
        }

        try {
            // Public buckets like gift-media don't need signing
            if (bucket == "gift-media") {
                val publicUrl = supabaseClient.getPublicStorageUrl(bucket, cleanPath)
                return@withContext Result.success(publicUrl)
            }

            val signRes = supabaseClient.storageService.signObjectUrl(
                bucket = bucket,
                path = cleanPath,
                body = mapOf("expiresIn" to expiresInSeconds)
            )

            if (signRes.isSuccessful) {
                val rawBody = signRes.body()?.string() ?: ""
                val signedPart = try {
                    val json = JSONObject(rawBody)
                    json.optString("signedURL", "")
                } catch (e: Exception) {
                    ""
                }

                if (signedPart.isNotBlank()) {
                    val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
                    val fullUrl = if (signedPart.startsWith("http://") || signedPart.startsWith("https://")) {
                        signedPart
                    } else if (signedPart.startsWith("/storage/v1")) {
                        "$baseUrl$signedPart"
                    } else if (signedPart.startsWith("/object/sign")) {
                        "$baseUrl/storage/v1$signedPart"
                    } else {
                        "$baseUrl/storage/v1/object/sign/$bucket/$signedPart"
                    }

                    val expiryTime = now + (expiresInSeconds * 1000L)
                    urlCache[cacheKey] = Pair(fullUrl, expiryTime)
                    return@withContext Result.success(fullUrl)
                } else {
                    Log.e(TAG, "Empty signedURL in storage response for $bucket/$cleanPath: $rawBody")
                    return@withContext Result.failure(Exception("Empty signed URL for $bucket/$cleanPath"))
                }
            } else {
                val errorBody = signRes.errorBody()?.string() ?: "HTTP ${signRes.code()}"
                Log.e(TAG, "Storage sign failed for $bucket/$cleanPath: HTTP ${signRes.code()} - $errorBody")
                return@withContext Result.failure(Exception("Storage error ($bucket/$cleanPath): $errorBody"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error obtaining signed URL for $bucket/$cleanPath", e)
            Result.failure(e)
        }
    }

    suspend fun loadProfileImage(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("profile-media/").removePrefix("/")
        return getSignedUrl("profile-media", clean).getOrNull()
    }

    suspend fun loadChatImage(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("chat-media/").removePrefix("/")
        return getSignedUrl("chat-media", clean).getOrNull()
    }

    suspend fun loadChatVoice(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("chat-media/").removePrefix("/")
        return getSignedUrl("chat-media", clean).getOrNull()
    }

    suspend fun loadVerificationAudio(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("voice-verifications/").removePrefix("/")
        return getSignedUrl("voice-verifications", clean).getOrNull()
    }

    suspend fun loadSocialMedia(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val clean = path.removePrefix("social-media/").removePrefix("/")
        val res = getSignedUrl("social-media", clean)
        if (res.isFailure) {
            Log.e(TAG, "loadSocialMedia failed for path '$path': ${res.exceptionOrNull()?.message}")
        }
        return res.getOrNull()
    }

    suspend fun resolveSocialMediaUrl(rawPathOrUrl: String?): String? {
        if (rawPathOrUrl.isNullOrBlank()) return null
        if (rawPathOrUrl.startsWith("http://") || rawPathOrUrl.startsWith("https://")) return rawPathOrUrl
        val clean = rawPathOrUrl.removePrefix("social-media/").removePrefix("/")
        val res = getSignedUrl("social-media", clean)
        if (res.isFailure) {
            Log.e(TAG, "resolveSocialMediaUrl failed for '$rawPathOrUrl': ${res.exceptionOrNull()?.message}")
        }
        return res.getOrNull()
    }

    suspend fun resolveMediaUrl(rawPathOrUrl: String?): String? {
        if (rawPathOrUrl.isNullOrBlank()) return null
        if (rawPathOrUrl.startsWith("http://") || rawPathOrUrl.startsWith("https://")) return rawPathOrUrl

        return when {
            rawPathOrUrl.startsWith("profile-media/") -> loadProfileImage(rawPathOrUrl)
            rawPathOrUrl.startsWith("chat-media/") -> loadChatImage(rawPathOrUrl)
            rawPathOrUrl.startsWith("voice-verifications/") -> loadVerificationAudio(rawPathOrUrl)
            rawPathOrUrl.startsWith("social-media/") -> loadSocialMedia(rawPathOrUrl)
            rawPathOrUrl.startsWith("gift-media/") -> {
                val clean = rawPathOrUrl.removePrefix("gift-media/").removePrefix("/")
                supabaseClient.getPublicStorageUrl("gift-media", clean)
            }
            else -> {
                // For paths like "<auth-uuid>/<file>", resolve using social-media signed URL
                loadSocialMedia(rawPathOrUrl)
            }
        }
    }

    suspend fun deleteMedia(bucket: String, path: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        try {
            urlCache.remove("$bucket:$cleanPath")
            val res = supabaseClient.storageService.deleteObject(bucket, cleanPath)
            if (res.isSuccessful) {
                Result.success(Unit)
            } else {
                // Fallback to deleteObjects
                val res2 = supabaseClient.storageService.deleteObjects(bucket, mapOf("prefixes" to listOf(cleanPath)))
                if (res2.isSuccessful) {
                    Result.success(Unit)
                } else {
                    val err = res.errorBody()?.string() ?: res2.errorBody()?.string() ?: "HTTP ${res.code()}"
                    Log.w(TAG, "Storage delete note for $bucket/$cleanPath: $err")
                    Result.failure(Exception(err))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Storage delete error for $bucket/$cleanPath", e)
            Result.failure(e)
        }
    }

    suspend fun deleteSocialMedia(mediaPath: String?): Result<Unit> {
        if (mediaPath.isNullOrBlank()) return Result.success(Unit)
        val clean = mediaPath.removePrefix("social-media/").removePrefix("/")
        return deleteMedia("social-media", clean)
    }
}

sealed class MediaLoadState {
    object Loading : MediaLoadState()
    data class Success(val url: String) : MediaLoadState()
    data class Error(val message: String) : MediaLoadState()
}

@androidx.compose.runtime.Composable
fun rememberPrivateStorageUrl(rawUrl: String?, privateMediaRepo: PrivateMediaRepository): androidx.compose.runtime.State<String?> {
    val state = androidx.compose.runtime.remember(rawUrl) { androidx.compose.runtime.mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(rawUrl) {
        if (rawUrl.isNullOrBlank()) {
            state.value = null
        } else {
            state.value = privateMediaRepo.resolveMediaUrl(rawUrl)
        }
    }
    return state
}

@androidx.compose.runtime.Composable
fun rememberSocialMediaState(rawUrl: String?, privateMediaRepo: PrivateMediaRepository): androidx.compose.runtime.State<MediaLoadState> {
    val state = androidx.compose.runtime.remember(rawUrl) {
        androidx.compose.runtime.mutableStateOf<MediaLoadState>(
            if (rawUrl.isNullOrBlank()) MediaLoadState.Error("No media") else MediaLoadState.Loading
        )
    }
    androidx.compose.runtime.LaunchedEffect(rawUrl) {
        if (rawUrl.isNullOrBlank()) {
            state.value = MediaLoadState.Error("No media")
        } else {
            state.value = MediaLoadState.Loading
            val resolved = privateMediaRepo.resolveSocialMediaUrl(rawUrl)
            if (!resolved.isNullOrBlank()) {
                state.value = MediaLoadState.Success(resolved)
            } else {
                state.value = MediaLoadState.Error("Unable to load media")
            }
        }
    }
    return state
}

