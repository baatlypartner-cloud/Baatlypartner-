package com.example.ui.screens.social

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.models.SocialPostModel
import com.example.data.models.SocialStoryModel
import com.example.data.models.toSearchResult
import com.example.data.repository.PrivateMediaRepository
import com.example.data.repository.rememberPrivateStorageUrl
import com.example.ui.theme.*
import com.example.ui.viewmodel.SocialDestination
import com.example.ui.viewmodel.SocialViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialHomeScreen(
    socialViewModel: SocialViewModel,
    privateMediaRepo: PrivateMediaRepository
) {
    val feedPosts by socialViewModel.feedPosts.collectAsState()
    val stories by socialViewModel.stories.collectAsState()
    val hostProfile by socialViewModel.hostSocialProfile.collectAsState()
    val isLoadingFeed by socialViewModel.isLoadingFeed.collectAsState()
    val followInProgressUserIds by socialViewModel.followInProgressUserIds.collectAsState()

    // Comments Sheet State
    val activeCommentPostId by socialViewModel.activeCommentPostId.collectAsState()
    val comments by socialViewModel.comments.collectAsState()
    val isLoadingComments by socialViewModel.isLoadingComments.collectAsState()
    val isPostingComment by socialViewModel.isPostingComment.collectAsState()

    val hostUserId = hostProfile?.userId ?: ""
    val hostAvatar = hostProfile?.socialAvatarUrl ?: hostProfile?.profile?.avatarUrl
    val resolvedHostAvatar = rememberPrivateStorageUrl(rawUrl = hostAvatar, privateMediaRepo = privateMediaRepo).value

    Scaffold(
        topBar = {
            Surface(
                color = Color.White,
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: Logo & Title with Gradient Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.Hero),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Social Logo",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Baatly",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = TextPrimaryLight
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Social",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = SocialColors.Purple
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.Transparent,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(SocialGradients.Hero)
                                ) {
                                    Text(
                                        text = "PARTNER",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Right: Actions (Refresh, Search, Create +, Host Profile)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Refresh button
                        IconButton(
                            onClick = { socialViewModel.refreshFeed() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SocialColors.PurpleLight)
                                .testTag("social_refresh_button")
                        ) {
                            if (isLoadingFeed) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = SocialColors.Purple
                                )
                            } else {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "Refresh",
                                    tint = SocialColors.Purple,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Search button
                        IconButton(
                            onClick = { socialViewModel.openSearch() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SocialColors.PurpleLight)
                                .testTag("social_search_toggle_button")
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = "Search",
                                tint = SocialColors.Purple,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Host Profile Avatar
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SocialGradients.StoryRing)
                                .padding(1.8.dp)
                                .clickable { socialViewModel.openHostProfile() }
                                .testTag("social_host_profile_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(1.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolvedHostAvatar.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedHostAvatar,
                                        contentDescription = "My Profile",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .background(SocialColors.PurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (hostProfile?.profile?.displayName ?: "H").take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = SocialColors.Purple,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        containerColor = Color(0xFFF8FAFC)
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("social_feed_list"),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // 1. Stories Section
            item(key = "stories_section") {
                StoriesRowSection(
                    stories = stories,
                    hostProfile = hostProfile,
                    onAddStoryClick = {
                        socialViewModel.navigateTo(SocialDestination.CreateContent("story"))
                    },
                    onStoryClick = { storyList, index ->
                        socialViewModel.openStoryViewer(storyList, index)
                    },
                    privateMediaRepo = privateMediaRepo
                )
                HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
            }

            // 2. Create Post Hero Card
            item(key = "create_post_banner") {
                Spacer(modifier = Modifier.height(6.dp))
                CreatePostBanner(
                    hostProfile = hostProfile,
                    privateMediaRepo = privateMediaRepo,
                    onClick = {
                        socialViewModel.navigateTo(SocialDestination.CreateContent("post"))
                    }
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            // 3. Posts Stream / Skeleton / Empty State
            if (isLoadingFeed && feedPosts.isEmpty()) {
                item(key = "skeleton_loader") {
                    SocialFeedSkeleton()
                }
            } else if (feedPosts.isEmpty()) {
                item(key = "empty_feed") {
                    EmptySocialFeed(
                        onCreatePostClick = {
                            socialViewModel.navigateTo(SocialDestination.CreateContent("post"))
                        }
                    )
                }
            } else {
                items(
                    items = feedPosts,
                    key = { it.id }
                ) { post ->
                    SocialPostCard(
                        post = post,
                        hostUserId = hostUserId,
                        privateMediaRepo = privateMediaRepo,
                        onLikeClick = { socialViewModel.toggleLikePost(post) },
                        onCommentClick = { socialViewModel.openComments(post.id) },
                        onFollowClick = { socialViewModel.toggleFollowUser(post.userId, post.isFollowing == true) },
                        onUserClick = {
                            if (post.userId == hostUserId) {
                                socialViewModel.openHostProfile()
                            } else {
                                val searchResult = post.toSearchResult()
                                socialViewModel.openUserProfile(searchResult)
                            }
                        },
                        onMediaClick = {
                            socialViewModel.openPostViewer(post)
                        },
                        onDeleteClick = {
                            socialViewModel.deletePost(post)
                        },
                        isFollowInProgress = followInProgressUserIds.contains(post.userId) ||
                                (!post.ownerId.isNullOrBlank() && followInProgressUserIds.contains(post.ownerId))
                    )
                }
            }
        }
    }

    // Comments Sheet
    if (activeCommentPostId != null) {
        CommentsBottomSheet(
            comments = comments,
            isLoading = isLoadingComments,
            isPosting = isPostingComment,
            privateMediaRepo = privateMediaRepo,
            onDismiss = { socialViewModel.closeComments() },
            onPostComment = { text ->
                socialViewModel.postComment(text)
            }
        )
    }
}
