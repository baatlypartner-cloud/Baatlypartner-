package com.example.ui.screens.social

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.repository.PrivateMediaRepository
import com.example.ui.viewmodel.SocialDestination
import com.example.ui.viewmodel.SocialViewModel

/**
 * Root Social Hub Screen
 * Seamlessly routes between screens without overlaying multiple states.
 */
@Composable
fun SocialScreen(
    socialViewModel: SocialViewModel,
    privateMediaRepo: PrivateMediaRepository,
    hostUserId: String = ""
) {
    val currentDestination by socialViewModel.currentDestination.collectAsState()
    val errorMessage by socialViewModel.errorMessage.collectAsState()
    val successMessage by socialViewModel.successMessage.collectAsState()

    val hostProfile by socialViewModel.hostSocialProfile.collectAsState()
    val hostPosts by socialViewModel.hostPosts.collectAsState()
    val hostStories by socialViewModel.hostStories.collectAsState()
    val hostEarnings by socialViewModel.hostSocialEarnings.collectAsState()

    val selectedUser by socialViewModel.selectedUserProfile.collectAsState()
    val selectedUserPosts by socialViewModel.selectedUserPosts.collectAsState()
    val selectedUserStories by socialViewModel.selectedUserStories.collectAsState()
    val followInProgressUserIds by socialViewModel.followInProgressUserIds.collectAsState()

    val isPosting by socialViewModel.isPosting.collectAsState()
    val isUploadingStory by socialViewModel.isUploadingStory.collectAsState()

    val activeStoryViewerList by socialViewModel.activeStoryViewerList.collectAsState()
    val activeStoryViewerIndex by socialViewModel.activeStoryViewerIndex.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
    }

    LaunchedEffect(successMessage) {
        successMessage?.let {
            snackbarHostState.showSnackbar(it)
            socialViewModel.clearMessages()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentDestination,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "social_destination_transition"
        ) { destination ->
            when (destination) {
                is SocialDestination.Home -> {
                    SocialHomeScreen(
                        socialViewModel = socialViewModel,
                        privateMediaRepo = privateMediaRepo
                    )
                }

                is SocialDestination.Search -> {
                    SocialSearchScreen(
                        socialViewModel = socialViewModel,
                        privateMediaRepo = privateMediaRepo,
                        onBack = { socialViewModel.navigateBack() }
                    )
                }

                is SocialDestination.UserProfile -> {
                    selectedUser?.let { user ->
                        UserSocialProfileFullScreen(
                            user = user,
                            posts = selectedUserPosts,
                            stories = selectedUserStories,
                            privateMediaRepo = privateMediaRepo,
                            onBack = { socialViewModel.navigateBack() },
                            onFollowToggle = { socialViewModel.toggleFollowUser(user.userId, user.isFollowing == true) },
                            onStoryClick = { stories, index ->
                                socialViewModel.openStoryViewer(stories, index)
                            },
                            onPostLike = { post ->
                                socialViewModel.toggleLikePost(post)
                            },
                            onPostComment = { post ->
                                socialViewModel.openComments(post.id)
                            },
                            isFollowInProgress = followInProgressUserIds.contains(user.userId)
                        )
                    } ?: run {
                        socialViewModel.navigateBack()
                    }
                }

                is SocialDestination.HostProfile -> {
                    HostSocialProfileFullScreen(
                        hostProfile = hostProfile,
                        hostPosts = hostPosts,
                        hostStories = hostStories,
                        hostEarnings = hostEarnings,
                        privateMediaRepo = privateMediaRepo,
                        onBack = { socialViewModel.navigateBack() },
                        onUpdateProfile = { bio, hobbies, avatarFile, onComplete ->
                            socialViewModel.updateHostSocialProfile(bio, hobbies, avatarFile) {
                                onComplete()
                            }
                        },
                        onStoryClick = { stories, index ->
                            socialViewModel.openStoryViewer(stories, index)
                        },
                        onPostLike = { post ->
                            socialViewModel.toggleLikePost(post)
                        },
                        onPostComment = { post ->
                            socialViewModel.openComments(post.id)
                        },
                        onPostDelete = { post ->
                            socialViewModel.deletePost(post)
                        }
                    )
                }

                is SocialDestination.CreateContent -> {
                    CreateSocialContentScreen(
                        defaultType = destination.defaultType,
                        isPosting = isPosting,
                        isUploadingStory = isUploadingStory,
                        onBack = { socialViewModel.navigateBack() },
                        onCreatePost = { file, caption ->
                            socialViewModel.createPost(file, caption) {
                                socialViewModel.navigateBack()
                            }
                        },
                        onCreateStory = { file, caption ->
                            socialViewModel.createStory(file, caption) {
                                socialViewModel.navigateBack()
                            }
                        }
                    )
                }

                is SocialDestination.PostViewer -> {
                    SocialPostViewerScreen(
                        post = destination.post,
                        hostUserId = hostProfile?.userId.orEmpty(),
                        privateMediaRepo = privateMediaRepo,
                        onBack = { socialViewModel.navigateBack() },
                        onLikeClick = { socialViewModel.toggleLikePost(destination.post) },
                        onCommentClick = { socialViewModel.openComments(destination.post.id) },
                        onDeleteClick = {
                            socialViewModel.deletePost(destination.post)
                        }
                    )
                }

                is SocialDestination.StoryViewer -> {
                    val activeStories = activeStoryViewerList ?: destination.stories
                    FullscreenStoryViewer(
                        stories = activeStories,
                        initialIndex = activeStoryViewerIndex,
                        privateMediaRepo = privateMediaRepo,
                        onClose = { socialViewModel.closeStoryViewer() },
                        onNext = { socialViewModel.nextStory() },
                        onPrev = { socialViewModel.prevStory() }
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("social_snackbar")
        )
    }
}
