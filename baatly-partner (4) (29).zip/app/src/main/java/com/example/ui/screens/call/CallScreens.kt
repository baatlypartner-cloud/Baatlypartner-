package com.example.ui.screens.call

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.view.SurfaceView
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.models.isUuid
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.example.BaatlyApp
import com.example.data.models.CallModel
import com.example.data.repository.rememberProfileAvatarUrl
import com.example.ui.components.PostCallRatingSection
import com.example.ui.components.ReportUserDialog
import com.example.ui.screens.chat.ChatDetailScreen
import com.example.ui.screens.chat.ChatListScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveCallUiStatus
import com.example.ui.viewmodel.CallViewModel
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun IncomingCallDialog(
    call: CallModel,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    val context = LocalContext.current
    val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: "User"
    val callerAvatar = call.userProfile?.avatarUrl
    val app = LocalContext.current.applicationContext as BaatlyApp
    val privateMediaRepo = app.privateMediaRepository
    val callRepo = app.callRepository
    val resolvedCallerAvatar by rememberProfileAvatarUrl(callerAvatar, privateMediaRepo)

    // Host-specific caller classification state (authoritative source: host_call_sessions.user_class)
    var userClass by remember(call.id) { mutableStateOf(call.userClass) }
    var isLoadingClassification by remember(call.id) { mutableStateOf(call.userClass.isNullOrBlank()) }

    LaunchedEffect(call.id) {
        if (userClass.isNullOrBlank()) {
            isLoadingClassification = true
            val fetchedClass = callRepo.getHostCallSessionUserClass(call.id)
            userClass = fetchedClass
            isLoadingClassification = false
        } else {
            isLoadingClassification = false
        }
    }

    // Map strictly to ONLY TWO allowed categories: NEW USER or REPEAT USER
    val normalizedClass = userClass?.trim()?.lowercase()
    val classificationLabel: String? = when (normalizedClass) {
        "new" -> "NEW USER"
        "repeat" -> "REPEAT USER"
        else -> null
    }

    // Check if incoming call is video
    val isVideoCall = call.callType?.equals("video", ignoreCase = true) == true

    var showMicRationaleDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var isAccepting by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onAccept()
        } else {
            isAccepting = false
            showMicRationaleDialog = true
        }
    }

    val videoPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val micOk = perms[Manifest.permission.RECORD_AUDIO] == true
        val camOk = perms[Manifest.permission.CAMERA] == true
        if (micOk && camOk) {
            onAccept()
        } else {
            isAccepting = false
            showMicRationaleDialog = true
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringPulse"
    )

    Dialog(
        onDismissRequest = onReject,
        properties = com.example.security.AppSecurityManager.secureDialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxHeight()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(modifier = Modifier.height(48.dp))
                    Text(
                        text = if (isVideoCall) "INCOMING VIDEO CALL" else "INCOMING AUDIO CALL",
                        color = if (isVideoCall) Color(0xFF7C3AED) else BaatlyPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(28.dp))

                    // Caller Avatar with Ring Animation
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(BaatlyPrimaryLight),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!resolvedCallerAvatar.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = resolvedCallerAvatar),
                                contentDescription = "Caller",
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = callerName.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 42.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = callerName,
                        color = TextPrimaryLight,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Authoritative User Classification Badge (NEW USER / REPEAT USER)
                    if (classificationLabel != null) {
                        val isRepeat = classificationLabel == "REPEAT USER"
                        val badgeBg = if (isRepeat) BaatlyGreenLight else BaatlyPrimaryLight
                        val badgeBorder = if (isRepeat) BaatlyGreenBorder else BaatlyPrimaryBorder
                        val badgeColor = if (isRepeat) Color(0xFF059669) else BaatlyPrimary
                        val badgeIcon = if (isRepeat) Icons.Outlined.Autorenew else Icons.Outlined.PersonAdd

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = badgeBg,
                            border = BorderStroke(1.dp, badgeBorder),
                            modifier = Modifier.testTag("caller_classification_badge")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = badgeIcon,
                                    contentDescription = null,
                                    tint = badgeColor,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = classificationLabel,
                                    color = badgeColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    } else if (isLoadingClassification) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.testTag("caller_classification_loading")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(11.dp),
                                    strokeWidth = 1.5.dp,
                                    color = Color(0xFF94A3B8)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Checking caller...",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    } else {
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Text(
                        text = "Ringing...",
                        color = BaatlyGreen,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Accept & Reject Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 48.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reject Button
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = onReject,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(BaatlyRed)
                                .testTag("reject_call_button")
                        ) {
                            Icon(
                                Icons.Default.CallEnd,
                                contentDescription = "Reject",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Decline", color = TextSecondaryLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Accept Button
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = {
                                if (isAccepting) return@IconButton
                                isAccepting = true
                                val hasMic = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED

                                if (isVideoCall) {
                                    val hasCamera = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) == PackageManager.PERMISSION_GRANTED

                                    if (hasMic && hasCamera) {
                                        onAccept()
                                    } else {
                                        videoPermissionsLauncher.launch(
                                            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                                        )
                                    }
                                } else {
                                    if (hasMic) {
                                        onAccept()
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            enabled = !isAccepting,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(if (isAccepting) BaatlyGreen.copy(alpha = 0.6f) else BaatlyGreen)
                                .testTag("accept_call_button")
                        ) {
                            Icon(
                                if (isVideoCall) Icons.Default.Videocam else Icons.Default.Call,
                                contentDescription = "Accept",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Accept", color = TextSecondaryLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    if (showMicRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showMicRationaleDialog = false },
            title = { Text("Microphone Permission Required", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone access is required for voice calls and voice messages. Please grant microphone access to connect the call.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMicRationaleDialog = false
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                    modifier = Modifier.testTag("grant_mic_permission_dialog_button")
                ) {
                    Text("Grant Permission")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showMicRationaleDialog = false
                    showSettingsDialog = true
                }) {
                    Text("App Settings", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Open App Settings", fontWeight = FontWeight.Bold, color = TextPrimaryLight) },
            text = {
                Text(
                    "Microphone permission is permanently denied. Please enable Microphone in App Settings to accept audio calls.",
                    color = TextSecondaryLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSettingsDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                ) {
                    Text("Open Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = Color.White
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveCallScreen(
    callViewModel: CallViewModel,
    chatViewModel: ChatViewModel,
    onCallFinished: () -> Unit
) {
    val callState by callViewModel.callUiStatus.collectAsState()
    var showInCallChat by remember { mutableStateOf(false) }

    var selectedInCallChatParams by remember { mutableStateOf<Triple<String, String, String?>?>(null) }

    val context = LocalContext.current
    val activity = context as? android.app.Activity

    // Intercept Back button during active Agora call:
    // Prevents finishing MainActivity or dropping the call.
    // Moves task to back so Agora two-way voice call and foreground service continue uninterrupted.
    BackHandler(
        enabled = callState is ActiveCallUiStatus.Connected || callState is ActiveCallUiStatus.Connecting
    ) {
        if (selectedInCallChatParams != null) {
            selectedInCallChatParams = null
        } else if (showInCallChat) {
            showInCallChat = false
        } else {
            android.util.Log.d("ActiveCallScreen", "BACK_HANDLER: moving task to back to maintain active voice call")
            activity?.moveTaskToBack(true)
        }
    }

    when (val state = callState) {
        is ActiveCallUiStatus.Connected -> {
            if (state.call.callType?.equals("video", ignoreCase = true) == true) {
                ActiveVideoCallScreen(
                    callViewModel = callViewModel,
                    chatViewModel = chatViewModel,
                    onCallFinished = onCallFinished,
                    state = state
                )
            } else {
                val call = state.call
                val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                    ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                    ?: "User"
                val callerAvatar = call.userProfile?.avatarUrl
                val resolvedCallerAvatar by rememberProfileAvatarUrl(callerAvatar, chatViewModel.privateMediaRepository)

                val minutes = state.durationSeconds / 60
                val seconds = state.durationSeconds % 60
                val durationStr = String.format("%02d:%02d", minutes, seconds)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(BaatlyLightBackground)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = BaatlyGreenLight,
                                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyGreenBorder, BaatlyGreenBorder)))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(BaatlyGreen)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LIVE AUDIO CALL",
                                        color = BaatlyGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            // In-Call Chat Overlay Trigger
                            IconButton(
                                onClick = { showInCallChat = true },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .testTag("in_call_chat_button")
                            ) {
                                Icon(
                                    Icons.Default.Chat,
                                    contentDescription = "Open Chat",
                                    tint = BaatlyPrimary
                                )
                            }
                        }

                        // Center Caller Info & Timer
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (!resolvedCallerAvatar.isNullOrBlank()) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = resolvedCallerAvatar),
                                    contentDescription = "Caller",
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(CircleShape)
                                        .background(BaatlyPrimaryLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = callerName.take(1).uppercase(),
                                        color = BaatlyPrimary,
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = callerName,
                                color = TextPrimaryLight,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = durationStr,
                                color = BaatlyPrimary,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            if (state.elapsedSeconds < 60) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Min 60s required for earning (${60 - state.elapsedSeconds}s left)",
                                    color = BaatlyGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Bottom Call Controls (Mute, Speaker, End)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(bottom = 32.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Mute Button
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(
                                        onClick = { callViewModel.toggleMute() },
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(if (state.isMuted) BaatlyRedLight else Color.White)
                                            .testTag("mute_call_button")
                                    ) {
                                        Icon(
                                            imageVector = if (state.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                            contentDescription = "Mute",
                                            tint = if (state.isMuted) BaatlyRed else TextPrimaryLight
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (state.isMuted) "Unmute" else "Mute",
                                        color = TextSecondaryLight,
                                        fontSize = 12.sp
                                    )
                                }

                                // End Call Button
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(
                                        onClick = { callViewModel.endActiveCall() },
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(BaatlyRed)
                                            .testTag("end_call_button")
                                    ) {
                                        Icon(
                                            Icons.Default.CallEnd,
                                            contentDescription = "End Call",
                                            tint = Color.White,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("End Call", color = TextPrimaryLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                // Speakerphone Button
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(
                                        onClick = { callViewModel.toggleSpeakerphone() },
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(if (state.isSpeakerOn) BaatlyPrimaryLight else Color.White)
                                            .testTag("speaker_call_button")
                                    ) {
                                        Icon(
                                            imageVector = if (state.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                            contentDescription = "Speaker",
                                            tint = if (state.isSpeakerOn) BaatlyPrimary else TextPrimaryLight
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (state.isSpeakerOn) "Speaker On" else "Speaker Off",
                                        color = TextSecondaryLight,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    // In-Call Chat Bottom Sheet (Does NOT interrupt call audio)
                    if (showInCallChat) {
                        ModalBottomSheet(
                            onDismissRequest = {
                                showInCallChat = false
                                selectedInCallChatParams = null
                            },
                            containerColor = Color.White
                        ) {
                            val activeChat = selectedInCallChatParams
                            if (activeChat != null) {
                                ChatDetailScreen(
                                    conversationId = activeChat.first,
                                    receiverId = activeChat.second,
                                    receiverName = activeChat.third ?: "Baatly User",
                                    chatViewModel = chatViewModel,
                                    onBack = { selectedInCallChatParams = null }
                                )
                            } else {
                                ChatListScreen(
                                    chatViewModel = chatViewModel,
                                    onOpenConversation = { convId, userId, name ->
                                        selectedInCallChatParams = Triple(convId, userId, name)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        is ActiveCallUiStatus.Ended -> {
            var showReportDialog by remember(state.call.id) { mutableStateOf(false) }
            val callerUserId = state.call.userId ?: state.call.userProfile?.id ?: ""
            val callerName = state.call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: state.call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
                ?: "User"

            if (showReportDialog && callerUserId.isNotBlank()) {
                ReportUserDialog(
                    reportedUserId = callerUserId,
                    userName = callerName,
                    callId = state.call.id,
                    onDismiss = { showReportDialog = false },
                    onReportSubmitted = { showReportDialog = false }
                )
            }

            // End Call Summary Dialog
            AlertDialog(
                onDismissRequest = {
                    callViewModel.resetCallState()
                    onCallFinished()
                },
                title = {
                    Text("Call Summary", color = TextPrimaryLight, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        val min = state.durationSeconds / 60
                        val sec = state.durationSeconds % 60
                        Text(
                            text = "Call Duration: ${String.format("%02d:%02d", min, sec)}",
                            color = TextSecondaryLight,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Earning: ₹${String.format("%.2f", state.earning)}",
                            color = BaatlyGreen,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (callerUserId.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            PostCallRatingSection(
                                callId = state.call.id,
                                userId = callerUserId,
                                userName = callerName,
                                onRatingSubmitted = {},
                                onRequestReport = { showReportDialog = true }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Aapki Call availability offline kar di gayi hai. Ready hone par Home screen se dobara online karein.",
                            color = TextSecondaryLight,
                            fontSize = 11.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            callViewModel.resetCallState()
                            onCallFinished()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        modifier = Modifier.testTag("call_summary_done_button")
                    ) {
                        Text("Done")
                    }
                },
                containerColor = Color.White
            )
        }

        is ActiveCallUiStatus.Connecting -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BaatlyLightBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = BaatlyPrimary)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Connecting Agora voice channel...", color = TextPrimaryLight, fontSize = 14.sp)
                }
            }
        }

        is ActiveCallUiStatus.Error -> {
            AlertDialog(
                onDismissRequest = {
                    callViewModel.resetCallState()
                    onCallFinished()
                },
                title = { Text("Call Error", color = BaatlyRed) },
                text = { Text(state.message, color = TextPrimaryLight) },
                confirmButton = {
                    Button(
                        onClick = {
                            callViewModel.resetCallState()
                            onCallFinished()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                    ) {
                        Text("OK")
                    }
                },
                containerColor = Color.White
            )
        }

        else -> {}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveVideoCallScreen(
    callViewModel: CallViewModel,
    chatViewModel: ChatViewModel,
    onCallFinished: () -> Unit,
    state: ActiveCallUiStatus.Connected
) {
    val call = state.call
    val callerName = call.userProfile?.displayName?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: call.userProfile?.username?.takeIf { it.isNotBlank() && !isUuid(it) }
        ?: "User"
    val callerAvatar = call.userProfile?.avatarUrl
    val resolvedCallerAvatar by rememberProfileAvatarUrl(callerAvatar, chatViewModel.privateMediaRepository)

    val remoteUid by callViewModel.remoteVideoUid.collectAsState()
    val isCameraMuted by callViewModel.isCameraMuted.collectAsState()
    var showInCallChat by remember { mutableStateOf(false) }
    var selectedInCallChatParams by remember { mutableStateOf<Triple<String, String, String?>?>(null) }

    val minutes = state.durationSeconds / 60
    val seconds = state.durationSeconds % 60
    val durationStr = String.format("%02d:%02d", minutes, seconds)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. Remote Video Surface (Fullscreen background)
        if (remoteUid != null && remoteUid != 0) {
            AndroidView(
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        setZOrderMediaOverlay(false)
                        callViewModel.setupRemoteVideo(this, remoteUid!!)
                    }
                },
                update = { surfaceView ->
                    callViewModel.setupRemoteVideo(surfaceView, remoteUid!!)
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Waiting for caller's video
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (!resolvedCallerAvatar.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(model = resolvedCallerAvatar),
                            contentDescription = "Caller",
                            modifier = Modifier
                                .size(100.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF7C3AED)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = callerName.take(1).uppercase(),
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = callerName,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = Color(0xFF818CF8),
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Connecting user video...",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 2. Local Host Camera Preview (Floating PiP in Top Right)
        if (!isCameraMuted) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 64.dp, end = 16.dp)
                    .width(110.dp)
                    .height(160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.DarkGray)
                    .border(2.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            setZOrderMediaOverlay(true)
                            callViewModel.setupLocalVideo(this)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // 3. Top Overlay Bar: Caller Name, Connection Status, Duration, Switch Camera
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Caller Info & Live Video Call Pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xCC000000)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = callerName,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Connected • ",
                                color = Color(0xFF34D399),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = durationStr,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Top action icon (Switch Camera)
            IconButton(
                onClick = { callViewModel.switchCamera() },
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x99000000))
                    .testTag("switch_camera_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Cameraswitch,
                    contentDescription = "Switch Camera",
                    tint = Color.White
                )
            }
        }

        // 4. Bottom Controls Floating Bar: Exactly GIFT, MUTE, CUT
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (state.elapsedSeconds < 60) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xCC000000),
                    modifier = Modifier.padding(bottom = 14.dp)
                ) {
                    Text(
                        text = "Min 60s required for earning (${60 - state.elapsedSeconds}s left)",
                        color = Color(0xFFFBBF24),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }
            }

            // Exactly Three Primary Controls: GIFT, MUTE, CUT
            Surface(
                shape = RoundedCornerShape(36.dp),
                color = Color(0xDD0F172A),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. GIFT
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { showInCallChat = true },
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Color(0x33FFFFFF))
                                .testTag("in_call_gift_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = "Gift",
                                tint = Color(0xFFF472B6),
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "GIFT",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    // 2. MUTE
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { callViewModel.toggleMute() },
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(if (state.isMuted) Color(0xFFEF4444) else Color(0x33FFFFFF))
                                .testTag("mute_call_button")
                        ) {
                            Icon(
                                imageVector = if (state.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = if (state.isMuted) "MUTED" else "MUTE",
                            color = if (state.isMuted) Color(0xFFF87171) else Color.White.copy(alpha = 0.85f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    // 3. CUT
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { callViewModel.endActiveCall() },
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFDC2626))
                                .testTag("end_call_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "Cut Call",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "CUT",
                            color = Color(0xFFF87171),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // 5. In-Call Chat Sheet
        if (showInCallChat) {
            ModalBottomSheet(
                onDismissRequest = {
                    showInCallChat = false
                    selectedInCallChatParams = null
                },
                containerColor = Color.White
            ) {
                val activeChat = selectedInCallChatParams
                if (activeChat != null) {
                    ChatDetailScreen(
                        conversationId = activeChat.first,
                        receiverId = activeChat.second,
                        receiverName = activeChat.third ?: "Baatly User",
                        chatViewModel = chatViewModel,
                        onBack = { selectedInCallChatParams = null }
                    )
                } else {
                    ChatListScreen(
                        chatViewModel = chatViewModel,
                        onOpenConversation = { convId, userId, name ->
                            selectedInCallChatParams = Triple(convId, userId, name)
                        }
                    )
                }
            }
        }
    }
}
