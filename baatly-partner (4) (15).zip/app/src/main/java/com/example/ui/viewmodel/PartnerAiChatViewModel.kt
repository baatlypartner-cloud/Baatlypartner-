package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.AiMessageModel
import com.example.data.repository.PartnerAiChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PartnerAiChatViewModel(
    private val repository: PartnerAiChatRepository
) : ViewModel() {

    private val _messages = MutableStateFlow<List<AiMessageModel>>(emptyList())
    val messages: StateFlow<List<AiMessageModel>> = _messages.asStateFlow()

    private val _conversationId = MutableStateFlow<String?>(repository.getStoredConversationId())
    val conversationId: StateFlow<String?> = _conversationId.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _isLoadingHistory = MutableStateFlow(false)
    val isLoadingHistory: StateFlow<Boolean> = _isLoadingHistory.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _latestAssistantReply = MutableStateFlow<String?>(null)
    val latestAssistantReply: StateFlow<String?> = _latestAssistantReply.asStateFlow()

    private var lastFailedMessage: String? = null
    private var isInitialized = false

    init {
        initChat()
    }

    /**
     * Initializes the chat session: loads or creates conversation ID and pulls historical messages.
     */
    fun initChat() {
        if (isInitialized && _messages.value.isNotEmpty()) return

        viewModelScope.launch {
            _isLoadingHistory.value = true
            _errorMessage.value = null

            val convIdResult = repository.getOrCreateConversationId()
            val convId = convIdResult.getOrNull() ?: repository.getStoredConversationId()
            _conversationId.value = convId

            if (!convId.isNullOrBlank()) {
                val historyResult = repository.loadMessageHistory(convId)
                if (historyResult.isSuccess) {
                    val serverMessages = historyResult.getOrDefault(emptyList())
                    if (serverMessages.isNotEmpty()) {
                        _messages.value = serverMessages
                        // Extract latest assistant message for preview
                        val latest = serverMessages.lastOrNull { it.senderType == "assistant" }?.content
                        if (!latest.isNullOrBlank()) {
                            _latestAssistantReply.value = latest
                        }
                    } else {
                        // Empty history: add initial warm introduction from Neha
                        val welcomeMsg = AiMessageModel(
                            id = UUID.randomUUID().toString(),
                            conversationId = convId,
                            senderType = "assistant",
                            content = "Namaste! Main Neha hoon, Baatly ki AI Assistant.\n\nMain aapki earnings, call metrics, daily score, rules ya kisi bhi technical problem mein 24/7 madad kar sakti hoon. Aap mujhse kya poochna chahte hain?",
                            createdAt = currentIsoTimestamp()
                        )
                        _messages.value = listOf(welcomeMsg)
                        _latestAssistantReply.value = "Main Neha hoon, Baatly ki AI Assistant. Main aapki madad ke liye 24/7 yahan hoon."
                    }
                } else {
                    // Fallback to welcome message if history fetch had issues
                    if (_messages.value.isEmpty()) {
                        val welcomeMsg = AiMessageModel(
                            id = UUID.randomUUID().toString(),
                            conversationId = convId,
                            senderType = "assistant",
                            content = "Namaste! Main Neha hoon, Baatly ki AI Assistant.\n\nMain aapki earnings, call metrics, daily score, rules ya kisi bhi technical problem mein 24/7 madad kar sakti hoon. Aap mujhse kya poochna chahte hain?",
                            createdAt = currentIsoTimestamp()
                        )
                        _messages.value = listOf(welcomeMsg)
                        _latestAssistantReply.value = "Main Neha hoon, Baatly ki AI Assistant. Main aapki madad ke liye 24/7 yahan hoon."
                    }
                }
            }

            _isLoadingHistory.value = false
            isInitialized = true
        }
    }

    /**
     * Sends a user message to Neha via the partner-ai-chat backend.
     */
    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _isSending.value) return

        val cid = _conversationId.value ?: UUID.randomUUID().toString()
        _conversationId.value = cid

        val userMessage = AiMessageModel(
            id = UUID.randomUUID().toString(),
            conversationId = cid,
            senderType = "user",
            content = trimmed,
            createdAt = currentIsoTimestamp()
        )

        // Optimistically show user message
        _messages.value = _messages.value + userMessage
        _isSending.value = true
        _errorMessage.value = null
        lastFailedMessage = null

        viewModelScope.launch {
            val result = repository.sendMessage(trimmed, cid)

            if (result.isSuccess) {
                val response = result.getOrNull()
                val replyText = response?.reply?.takeIf { it.isNotBlank() }
                    ?: "Aapka message receive ho gaya hai. Baatly Support aapki seva mein tatpar hai."

                val newCid = response?.conversationId ?: cid
                _conversationId.value = newCid

                val assistantMessage = AiMessageModel(
                    id = UUID.randomUUID().toString(),
                    conversationId = newCid,
                    senderType = "assistant",
                    content = replyText,
                    createdAt = currentIsoTimestamp()
                )

                _messages.value = _messages.value + assistantMessage
                _latestAssistantReply.value = replyText
            } else {
                val errorText = result.exceptionOrNull()?.message
                    ?: "Message bhejne mein dikkat aayi. Kripya thodi der mein dobara try karein."
                _errorMessage.value = errorText
                lastFailedMessage = trimmed

                // Add helpful escalation guidance message if network/system error
                val guidanceMsg = AiMessageModel(
                    id = UUID.randomUUID().toString(),
                    conversationId = cid,
                    senderType = "assistant",
                    content = "Maaf kijiye, connection mein temporary dikkat aayi hai: $errorText\n\nAgar aapko urgent help chahiye, toh aap official WhatsApp support (8744048708) par bhi connect kar sakte hain.",
                    createdAt = currentIsoTimestamp()
                )
                _messages.value = _messages.value + guidanceMsg
            }

            _isSending.value = false
        }
    }

    fun retryLastMessage() {
        val msg = lastFailedMessage ?: return
        sendMessage(msg)
    }

    fun clearError() {
        _errorMessage.value = null
    }

    private fun currentIsoTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }
}

class PartnerAiChatViewModelFactory(
    private val repository: PartnerAiChatRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PartnerAiChatViewModel::class.java)) {
            return PartnerAiChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
