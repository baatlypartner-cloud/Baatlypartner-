package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SessionManager
import com.example.data.models.AiMessageModel
import com.example.data.models.PartnerAiChatRequest
import com.example.data.models.PartnerAiChatResponse
import com.example.data.repository.PartnerAiChatRepository
import com.example.ui.screens.chat.formatAiMessageTime
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PartnerAiChatTest {

    @Test
    fun testSessionManagerPersistsAssistantConversationId() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)

        val partnerId = "test_partner_${UUID.randomUUID()}"
        val convId = UUID.randomUUID().toString()

        assertNull(sessionManager.getAssistantConversationId(partnerId))

        sessionManager.saveAssistantConversationId(convId, partnerId)
        assertEquals(convId, sessionManager.getAssistantConversationId(partnerId))
    }

    @Test
    fun testSupportWhatsAppConstants() {
        assertEquals("8744048708", PartnerAiChatRepository.SUPPORT_WHATSAPP_NUMBER)
        assertTrue(PartnerAiChatRepository.SUPPORT_WHATSAPP_URL.contains("8744048708"))
    }

    @Test
    fun testAiMessageModelSerialization() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(AiMessageModel::class.java)

        val message = AiMessageModel(
            id = "msg-123",
            conversationId = "conv-456",
            senderType = "assistant",
            content = "Main Neha hoon, Baatly ki AI Assistant.",
            createdAt = "2026-03-30T12:00:00Z"
        )

        val json = adapter.toJson(message)
        assertNotNull(json)
        assertTrue(json.contains("Main Neha hoon"))

        val parsed = adapter.fromJson(json)
        assertNotNull(parsed)
        assertEquals("msg-123", parsed?.id)
        assertEquals("assistant", parsed?.senderType)
        assertEquals("Main Neha hoon, Baatly ki AI Assistant.", parsed?.content)
    }

    @Test
    fun testPartnerAiChatRequestAndResponseSerialization() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val reqAdapter = moshi.adapter(PartnerAiChatRequest::class.java)
        val resAdapter = moshi.adapter(PartnerAiChatResponse::class.java)

        val request = PartnerAiChatRequest(message = "Score kaise improve karein?", conversationId = "conv-001")
        val reqJson = reqAdapter.toJson(request)
        assertTrue(reqJson.contains("Score kaise improve karein?"))

        val responseJson = """{"reply":"Call pickup rate badhayein","conversation_id":"conv-001"}"""
        val response = resAdapter.fromJson(responseJson)
        assertNotNull(response)
        assertEquals("Call pickup rate badhayein", response?.reply)
        assertEquals("conv-001", response?.conversationId)
    }

    @Test
    fun testFormatAiMessageTime() {
        val formatted = formatAiMessageTime("2026-03-30T10:30:00Z")
        assertNotNull(formatted)
        assertFalse(formatted.isEmpty())
    }
}
