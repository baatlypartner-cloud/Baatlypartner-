package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.PartnerApplication
import com.example.data.models.VoiceVerification
import com.example.data.repository.AuthRepository
import com.example.data.repository.HostApplicationState
import com.example.data.repository.HostFullStatus
import com.example.data.repository.PartnerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    object SignedOut : AuthUiState()
    data class VoiceVerificationRequired(val displayName: String, val applicationId: String?) : AuthUiState()
    data class ApplicationStatus(val status: HostFullStatus) : AuthUiState()
    object Approved : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Loading)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _hostStatus = MutableStateFlow<HostFullStatus?>(null)
    val hostStatus: StateFlow<HostFullStatus?> = _hostStatus.asStateFlow()

    init {
        checkCurrentStatus()
    }

    fun checkCurrentStatus() {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val res = authRepository.fetchHostStatus()
            if (res.isSuccess) {
                val status = res.getOrNull()!!
                _hostStatus.value = status
                _uiState.value = mapStatusToUiState(status)
            } else {
                val errMsg = res.exceptionOrNull()?.message ?: "Failed to connect to server"
                _uiState.value = AuthUiState.Error(errMsg)
            }
        }
    }

    private fun mapStatusToUiState(status: HostFullStatus): AuthUiState {
        return when (status.state) {
            HostApplicationState.NOT_LOGGED_IN -> AuthUiState.SignedOut
            HostApplicationState.NO_APPLICATION -> {
                val name = status.partnerProfile?.partnerDisplayName ?: status.profile?.displayName ?: "Host"
                AuthUiState.VoiceVerificationRequired(name, status.application?.id)
            }
            HostApplicationState.PENDING,
            HostApplicationState.RESUBMISSION,
            HostApplicationState.REJECTED -> {
                AuthUiState.ApplicationStatus(status)
            }
            HostApplicationState.APPROVED,
            HostApplicationState.SUSPENDED -> AuthUiState.Approved
        }
    }

    fun transitionToVoiceVerification(displayName: String, applicationId: String?) {
        _uiState.value = AuthUiState.VoiceVerificationRequired(displayName, applicationId)
    }

    fun signIn(userId: String, password: String) {
        val normalized = userId.trim().lowercase()
        if (normalized.length < 3 || normalized.length > 30) {
            _uiState.value = AuthUiState.Error("User ID must be between 3 and 30 characters.")
            return
        }
        if (password.isBlank()) {
            _uiState.value = AuthUiState.Error("Password cannot be empty.")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val res = authRepository.signInHost(normalized, password)
            if (res.isSuccess) {
                val status = res.getOrNull()!!
                _hostStatus.value = status
                _uiState.value = mapStatusToUiState(status)
            } else {
                _uiState.value = AuthUiState.Error(res.exceptionOrNull()?.message ?: "Sign in failed")
            }
        }
    }

    fun signUp(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        ageStr: String,
        bio: String?,
        avatarFile: File?
    ) {
        val normalized = userId.trim().lowercase()
        val userIdRegex = Regex("^[a-z0-9._-]+$")
        if (normalized.length < 3 || normalized.length > 30 || !userIdRegex.matches(normalized)) {
            _uiState.value = AuthUiState.Error("User ID must be 3-30 characters (letters, numbers, dot, underscore, hyphen).")
            return
        }

        if (displayName.trim().isBlank()) {
            _uiState.value = AuthUiState.Error("Display Name is required.")
            return
        }

        val cleanedMobile = mobileNumber.trim()
        val mobileRegex = Regex("^[6-9][0-9]{9}$")
        if (!mobileRegex.matches(cleanedMobile)) {
            _uiState.value = AuthUiState.Error("Please enter a valid 10-digit Indian mobile number (starting with 6-9).")
            return
        }

        val age = ageStr.trim().toIntOrNull()
        if (age == null || age < 18 || age > 100) {
            _uiState.value = AuthUiState.Error("Age must be between 18 and 100.")
            return
        }

        if (password.length < 6) {
            _uiState.value = AuthUiState.Error("Password must be at least 6 characters.")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val res = authRepository.signUpHost(
                userId = normalized,
                password = password,
                displayName = displayName.trim(),
                mobileNumber = cleanedMobile,
                age = age,
                bio = bio?.trim(),
                avatarFile = avatarFile
            )
            if (res.isSuccess) {
                val status = res.getOrNull()!!
                _hostStatus.value = status
                _uiState.value = mapStatusToUiState(status)
            } else {
                _uiState.value = AuthUiState.Error(res.exceptionOrNull()?.message ?: "Sign up failed")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            authRepository.logout()
            _hostStatus.value = HostFullStatus(state = HostApplicationState.NOT_LOGGED_IN)
            _uiState.value = AuthUiState.SignedOut
        }
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error) {
            if (_hostStatus.value != null) {
                _uiState.value = mapStatusToUiState(_hostStatus.value!!)
            } else {
                _uiState.value = AuthUiState.SignedOut
            }
        }
    }

    private val _isDeletingAccount = MutableStateFlow(false)
    val isDeletingAccount: StateFlow<Boolean> = _isDeletingAccount.asStateFlow()

    private val _accountDeletionSuccess = MutableStateFlow<String?>(null)
    val accountDeletionSuccess: StateFlow<String?> = _accountDeletionSuccess.asStateFlow()

    private val _accountDeletionError = MutableStateFlow<String?>(null)
    val accountDeletionError: StateFlow<String?> = _accountDeletionError.asStateFlow()

    fun requestAccountDeletion(onResult: ((Boolean, String) -> Unit)? = null) {
        if (_isDeletingAccount.value) return
        viewModelScope.launch {
            _isDeletingAccount.value = true
            _accountDeletionError.value = null
            val res = authRepository.requestAccountDeletion()
            _isDeletingAccount.value = false
            if (res.isSuccess) {
                val msg = res.getOrNull() ?: "Your account deletion request has been submitted successfully."
                _accountDeletionSuccess.value = msg
                onResult?.invoke(true, msg)
            } else {
                val err = res.exceptionOrNull()?.message ?: "Failed to submit account deletion request. Please try again."
                _accountDeletionError.value = err
                onResult?.invoke(false, err)
            }
        }
    }

    fun clearAccountDeletionState() {
        _accountDeletionError.value = null
        _accountDeletionSuccess.value = null
    }
}

class AuthViewModelFactory(private val authRepository: AuthRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(authRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
