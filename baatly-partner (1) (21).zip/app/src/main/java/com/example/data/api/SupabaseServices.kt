package com.example.data.api

import com.example.data.models.*
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface SupabaseAuthService {
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Body request: AuthSignUpRequest
    ): Response<AuthResponse>

    @POST("auth/v1/token")
    suspend fun signIn(
        @Query("grant_type") grantType: String = "password",
        @Body request: AuthSignInRequest
    ): Response<AuthResponse>

    @POST("auth/v1/token")
    suspend fun refreshToken(
        @Query("grant_type") grantType: String = "refresh_token",
        @Body body: Map<String, String>
    ): Response<AuthResponse>

    @POST("auth/v1/logout")
    suspend fun logout(): Response<Unit>
}

interface SupabaseRestService {
    // --- RPCs ---
    @POST("rest/v1/rpc/complete_host_onboarding")
    suspend fun completeHostOnboarding(
        @Body params: CompleteHostOnboardingParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/create_partner_voice_verification")
    suspend fun createPartnerVoiceVerification(
        @Body params: CreateVoiceVerificationParams
    ): Response<String?>

    @POST("rest/v1/rpc/submit_partner_application")
    suspend fun submitPartnerApplication(
        @Body params: SubmitPartnerApplicationParams
    ): Response<String?>

    @POST("rest/v1/rpc/update_my_partner_profile")
    suspend fun updateMyPartnerProfile(
        @Body params: UpdateMyPartnerProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_call_state")
    suspend fun updateCallState(
        @Body params: UpdateCallStateParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/settle_call")
    suspend fun settleCall(
        @Body params: SettleCallParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/enforce_call_balance_limit")
    suspend fun enforceCallBalanceLimit(
        @Body params: EnforceCallBalanceLimitParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/send_message")
    suspend fun sendMessage(
        @Body params: SendMessageParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/request_partner_withdrawal")
    suspend fun requestPartnerWithdrawal(
        @Body params: RequestPartnerWithdrawalParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/clear_my_conversation")
    suspend fun clearMyConversation(
        @Body params: ClearMyConversationParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/block_user")
    suspend fun blockUser(
        @Body params: BlockUserParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/unblock_user")
    suspend fun unblockUserRpc(
        @Body params: UnblockUserParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/get_conversation_participant_profile")
    suspend fun getConversationParticipantProfile(
        @Body params: GetConversationParticipantProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_my_profile")
    suspend fun updateMyProfile(
        @Body params: UpdateMyProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_my_profile_avatar")
    suspend fun updateMyProfileAvatar(
        @Body params: UpdateMyProfileAvatarParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/request_account_deletion")
    suspend fun requestAccountDeletion(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    // --- Social RPCs ---
    @POST("rest/v1/rpc/social_get_visible_feed")
    suspend fun socialGetVisibleFeed(
        @Body params: SocialGetVisibleFeedParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_get_visible_stories")
    suspend fun socialGetVisibleStories(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_get_visible_stories_for_owner")
    suspend fun socialGetVisibleStoriesForOwner(
        @Body params: SocialGetVisibleStoriesForOwnerParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_ensure_profile")
    suspend fun socialEnsureProfile(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_is_host")
    suspend fun socialIsHost(
        @Body params: SocialIsHostParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_role")
    suspend fun socialRole(
        @Body params: SocialRoleParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_search_profile")
    suspend fun socialSearchProfile(
        @Body params: SocialSearchProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_public_profile")
    suspend fun socialPublicProfile(
        @Body params: SocialPublicProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_update_profile")
    suspend fun socialUpdateProfile(
        @Body params: SocialUpdateProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_follow_toggle")
    suspend fun socialFollowToggle(
        @Body params: SocialFollowToggleParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_unlock_post")
    suspend fun socialUnlockPost(
        @Body params: SocialUnlockPostParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_create_content")
    suspend fun socialCreateContent(
        @Body params: SocialCreateContentParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_get_earnings")
    suspend fun socialGetEarnings(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_view_content")
    suspend fun socialViewContent(
        @Body params: SocialViewContentParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_toggle_like")
    suspend fun socialToggleLike(
        @Body params: SocialToggleLikeParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_add_comment")
    suspend fun socialAddComment(
        @Body params: SocialAddCommentParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/social_delete_post")
    suspend fun socialDeletePost(
        @Body params: SocialDeletePostParams
    ): Response<ResponseBody>

    // --- FCM Token RPCs ---
    @POST("rest/v1/rpc/register_fcm_token")
    suspend fun registerFcmToken(
        @Body params: RegisterFcmTokenParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/deactivate_fcm_token")
    suspend fun deactivateFcmToken(
        @Body params: TokenActionParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/unregister_fcm_token")
    suspend fun unregisterFcmToken(
        @Body params: TokenActionParams
    ): Response<ResponseBody>

    // --- Notifications Table Queries ---
    @GET("rest/v1/notifications")
    suspend fun getNotifications(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<NotificationItemModel>>

    @PATCH("rest/v1/notifications")
    suspend fun markNotificationAsRead(
        @Query("id") idFilter: String,
        @Body body: Map<String, @JvmSuppressWildcards Any?>
    ): Response<ResponseBody>

    // --- Table queries ---
    @GET("rest/v1/profiles")
    suspend fun getProfile(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<Profile>>

    @GET("rest/v1/profiles")
    suspend fun getProfiles(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<Profile>>

    @GET("rest/v1/partner_profiles")
    suspend fun getPartnerProfile(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<PartnerProfile>>

    @GET("rest/v1/partner_applications")
    suspend fun getPartnerApplications(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<PartnerApplication>>

    @GET("rest/v1/voice_verifications")
    suspend fun getVoiceVerifications(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<VoiceVerification>>

    @GET("rest/v1/wallets")
    suspend fun getWallet(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<WalletModel>>

    @GET("rest/v1/transactions")
    suspend fun getTransactions(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<TransactionModel>>

    @GET("rest/v1/calls")
    suspend fun getPartnerCalls(
        @Query("partner_id") partnerIdFilter: String,
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<CallModel>>

    @GET("rest/v1/calls")
    suspend fun getIncomingCalls(
        @Query("partner_id") partnerIdFilter: String,
        @Query("status") statusFilter: String = "in.(requested,ringing)",
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<CallModel>>

    @GET("rest/v1/calls")
    suspend fun getCallById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)"
    ): Response<List<CallModel>>

    @GET("rest/v1/conversations")
    suspend fun getConversations(
        @Query("partner_id") partnerIdFilter: String,
        @Query("select") select: String = "*,profiles!conversations_user_id_fkey(*)",
        @Query("order") order: String = "last_message_at.desc.nullslast"
    ): Response<List<ConversationModel>>

    @GET("rest/v1/messages")
    suspend fun getMessages(
        @Query("conversation_id") conversationIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.asc",
        @Query("limit") limit: Int = 200
    ): Response<List<MessageModel>>

    @POST("rest/v1/rpc/mark_conversation_read")
    suspend fun markConversationRead(
        @Body params: MarkConversationReadParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/partner_ai_get_or_create_conversation")
    suspend fun partnerAiGetOrCreateConversation(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @GET("rest/v1/ai_messages")
    suspend fun getAiMessages(
        @Query("conversation_id") conversationIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.asc",
        @Query("limit") limit: Int = 100
    ): Response<List<AiMessageModel>>

    @GET("rest/v1/gifts")
    suspend fun getGifts(
        @Query("is_active") activeFilter: String = "eq.true",
        @Query("order") order: String = "display_order.asc"
    ): Response<List<GiftModel>>

    @GET("rest/v1/gift_transactions")
    suspend fun getGiftTransactions(
        @Query("receiver_id") receiverIdFilter: String,
        @Query("select") select: String = "*,gifts(*)",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<GiftTransactionModel>>

    @GET("rest/v1/withdrawals")
    suspend fun getWithdrawals(
        @Query("partner_id") partnerIdFilter: String,
        @Query("order") order: String = "created_at.desc"
    ): Response<List<WithdrawalModel>>

    @GET("rest/v1/blocks")
    suspend fun getBlocks(
        @Query("blocker_id") blockerIdFilter: String,
        @Query("select") select: String = "*,profiles!blocks_blocked_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<BlockModel>>

    @DELETE("rest/v1/blocks")
    suspend fun unblockUser(
        @Query("id") idFilter: String
    ): Response<Unit>

    @GET("rest/v1/reviews")
    suspend fun getReviews(
        @Query("partner_id") partnerIdFilter: String,
        @Query("order") order: String = "created_at.desc"
    ): Response<List<ReviewModel>>

    // --- Social Table Queries ---
    @GET("rest/v1/social_profiles")
    suspend fun getSocialProfiles(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialProfileModel>>

    @GET("rest/v1/social_profiles")
    suspend fun getSocialProfilesBatch(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialProfileModel>>

    @PATCH("rest/v1/social_profiles")
    suspend fun updateSocialProfile(
        @Query("user_id") userIdFilter: String,
        @Body body: Map<String, @JvmSuppressWildcards Any?>
    ): Response<ResponseBody>

    @POST("rest/v1/social_profiles")
    suspend fun upsertSocialProfile(
        @Header("Prefer") prefer: String = "resolution=merge-duplicates",
        @Body body: Map<String, @JvmSuppressWildcards Any?>
    ): Response<ResponseBody>

    @GET("rest/v1/social_posts")
    suspend fun getSocialPosts(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<SocialPostModel>>

    @GET("rest/v1/social_posts")
    suspend fun getSocialPostById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialPostModel>>

    @GET("rest/v1/social_posts")
    suspend fun getSocialPostsByOwner(
        @Query("owner_id") ownerIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<SocialPostModel>>

    @GET("rest/v1/social_stories")
    suspend fun getSocialStories(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("is_active") activeFilter: String = "eq.true"
    ): Response<List<SocialStoryModel>>

    @GET("rest/v1/social_stories")
    suspend fun getSocialStoryById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialStoryModel>>

    @GET("rest/v1/social_stories")
    suspend fun getSocialStoriesByOwner(
        @Query("owner_id") ownerIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<SocialStoryModel>>

    @GET("rest/v1/social_content_stats")
    suspend fun getSocialContentStats(
        @Query("content_id") contentIdFilter: String? = null,
        @Query("content_type") contentTypeFilter: String? = null,
        @Query("select") select: String = "*"
    ): Response<List<SocialContentStatsModel>>

    @GET("rest/v1/social_content_stats")
    suspend fun getSocialContentStatsBatch(
        @Query("content_id") contentIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialContentStatsModel>>

    @GET("rest/v1/social_comments")
    suspend fun getSocialComments(
        @Query("content_id") contentIdFilter: String? = null,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.asc"
    ): Response<List<SocialCommentModel>>

    @GET("rest/v1/social_likes")
    suspend fun getSocialLikes(
        @Query("user_id") userIdFilter: String,
        @Query("content_id") contentIdFilter: String? = null,
        @Query("select") select: String = "*"
    ): Response<List<SocialLikeModel>>

    @GET("rest/v1/social_follows")
    suspend fun getSocialFollows(
        @Query("follower_id") followerIdFilter: String,
        @Query("following_id") followingIdFilter: String? = null,
        @Query("select") select: String = "*"
    ): Response<List<SocialFollowModel>>

    @GET("rest/v1/social_earnings")
    suspend fun getSocialEarnings(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<SocialEarningsModel>>

    // --- Host Call Presence Tracking RPCs ---
    @POST("rest/v1/rpc/host_start_presence")
    suspend fun hostStartPresence(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/host_presence_heartbeat")
    suspend fun hostPresenceHeartbeat(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/host_end_presence")
    suspend fun hostEndPresence(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    // --- Host Chat Presence Tracking RPCs ---
    @POST("rest/v1/rpc/host_start_chat_presence")
    suspend fun hostStartChatPresence(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/host_chat_heartbeat")
    suspend fun hostChatHeartbeat(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/host_end_chat_presence")
    suspend fun hostEndChatPresence(
        @Body body: Map<String, String> = emptyMap()
    ): Response<ResponseBody>

    // --- Host Performance Queries ---
    @GET("rest/v1/host_daily_scores")
    suspend fun getHostDailyScores(
        @Query("host_id") hostIdFilter: String? = null,
        @Query("partner_id") partnerIdFilter: String? = null,
        @Query("user_id") userIdFilter: String? = null,
        @Query("score_date") scoreDateFilter: String? = null,
        @Query("select") select: String = "*",
        @Query("order") order: String = "score_date.desc",
        @Query("limit") limit: Int? = null
    ): Response<List<HostDailyScoreModel>>

    @GET("rest/v1/host_weekly_scores")
    suspend fun getHostWeeklyScores(
        @Query("host_id") hostIdFilter: String? = null,
        @Query("partner_id") partnerIdFilter: String? = null,
        @Query("user_id") userIdFilter: String? = null,
        @Query("select") select: String = "*",
        @Query("order") order: String = "week_end.desc",
        @Query("limit") limit: Int? = null
    ): Response<List<HostWeeklyScoreModel>>

    @GET("rest/v1/host_score_thresholds")
    suspend fun getHostScoreThresholds(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.asc"
    ): Response<List<HostScoreThresholdModel>>

    @GET("rest/v1/host_call_sessions")
    suspend fun getHostCallSession(
        @Query("call_id") callIdFilter: String,
        @Query("host_id") hostIdFilter: String? = null,
        @Query("select") select: String = "*",
        @Query("limit") limit: Int = 1
    ): Response<List<HostCallSessionModel>>
}

interface SupabaseStorageService {
    @POST("storage/v1/object/{bucket}/{path}")
    suspend fun uploadObject(
        @Path("bucket") bucket: String,
        @Path(value = "path", encoded = true) path: String,
        @Header("Content-Type") contentType: String,
        @Body body: RequestBody
    ): Response<ResponseBody>

    @POST("storage/v1/object/sign/{bucket}/{path}")
    suspend fun signObjectUrl(
        @Path("bucket") bucket: String,
        @Path(value = "path", encoded = true) path: String,
        @Body body: Map<String, Int>
    ): Response<ResponseBody>

    @DELETE("storage/v1/object/{bucket}/{path}")
    suspend fun deleteObject(
        @Path("bucket") bucket: String,
        @Path(value = "path", encoded = true) path: String
    ): Response<ResponseBody>

    @HTTP(method = "DELETE", path = "storage/v1/object/{bucket}", hasBody = true)
    suspend fun deleteObjects(
        @Path("bucket") bucket: String,
        @Body body: Map<String, List<String>>
    ): Response<ResponseBody>
}

interface SupabaseEdgeService {
    @POST("functions/v1/agora-token")
    suspend fun getAgoraToken(
        @Body request: AgoraTokenRequest
    ): Response<AgoraTokenResponse>

    @POST("functions/v1/partner-ai-chat-v2")
    suspend fun sendPartnerAiChat(
        @Body request: PartnerAiChatRequest
    ): Response<PartnerAiChatResponse>
}
