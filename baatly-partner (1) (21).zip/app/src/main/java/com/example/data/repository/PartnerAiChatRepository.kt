package com.example.data.repository

import android.util.Log
import com.example.data.api.SupabaseClient
import com.example.data.local.SessionManager
import com.example.data.models.AiMessageModel
import com.example.data.models.PartnerAiChatRequest
import com.example.data.models.PartnerAiChatResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

class PartnerAiChatRepository(
    private val supabaseClient: SupabaseClient,
    private val sessionManager: SessionManager
) {
    companion object {
        private const val TAG = "PartnerAiChatRepo"
        const val SUPPORT_WHATSAPP_NUMBER = "8744048708"
        const val SUPPORT_WHATSAPP_URL = "https://wa.me/918744048708?text=Namaste%20Baatly%20Support,%20main%20ek%20Partner%20hoon%20aur%20mujhe%20madad%20chahiye."
    }

    /**
     * Retrieves the stored conversation ID from persistent storage for the current partner.
     */
    fun getStoredConversationId(): String? {
        val currentPartnerId = sessionManager.userId.value ?: sessionManager.authUuid.value
        return sessionManager.getAssistantConversationId(currentPartnerId)
    }

    /**
     * Gets the authenticated partner ID if available.
     */
    fun getCurrentPartnerId(): String? {
        return sessionManager.userId.value ?: sessionManager.authUuid.value
    }

    /**
     * Gets or creates the assistant conversation ID for the current partner.
     * Checks local persistence first, then syncs with Supabase RPC.
     */
    suspend fun getOrCreateConversationId(): Result<String> = withContext(Dispatchers.IO) {
        val currentPartnerId = sessionManager.userId.value ?: sessionManager.authUuid.value
        val storedId = sessionManager.getAssistantConversationId(currentPartnerId)

        try {
            // Call authoritative RPC to get or create conversation
            val res = supabaseClient.restService.partnerAiGetOrCreateConversation()
            if (res.isSuccessful) {
                val rawBody = res.body()?.string()?.trim()
                val serverConvId = rawBody?.replace("\"", "")?.trim()
                if (!serverConvId.isNullOrBlank() && serverConvId != "null") {
                    sessionManager.saveAssistantConversationId(serverConvId, currentPartnerId)
                    return@withContext Result.success(serverConvId)
                }
            } else {
                Log.w(TAG, "partner_ai_get_or_create_conversation returned: ${res.code()}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception during getOrCreateConversation RPC", e)
        }

        // Fallback to locally stored conversation ID if RPC had network issue
        if (!storedId.isNullOrBlank()) {
            return@withContext Result.success(storedId)
        }

        // If backend conversation cannot be fetched and no local ID exists, fail cleanly
        Result.failure(Exception("Support conversation shuru nahi ho payi. Kripya internet connection check karein aur dobara try karein."))
    }

    /**
     * Loads previous message history for this partner's assistant conversation.
     */
    suspend fun loadMessageHistory(conversationId: String): Result<List<AiMessageModel>> = withContext(Dispatchers.IO) {
        try {
            val res = supabaseClient.restService.getAiMessages(
                conversationIdFilter = "eq.$conversationId",
                order = "created_at.asc",
                limit = 100
            )

            if (res.isSuccessful) {
                val messages = res.body() ?: emptyList()
                Result.success(messages)
            } else {
                val err = res.errorBody()?.string() ?: "Failed to load messages"
                Log.w(TAG, "loadMessageHistory failed: ${res.code()} - $err")
                Result.failure(Exception("Message history load nahi ho payi."))
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error loading history", e)
            Result.failure(Exception("Aapka internet connection nahi chal raha hai. Kripya connect karke dobara try karein."))
        } catch (e: Exception) {
            Log.e(TAG, "Error loading history", e)
            Result.failure(Exception("Message history load karne mein dikkat aayi."))
        }
    }

    /**
     * Sends a message to the partner-ai-chat edge function using the partner's JWT.
     */
    suspend fun sendMessage(
        messageText: String,
        conversationId: String?
    ): Result<PartnerAiChatResponse> = withContext(Dispatchers.IO) {
        val trimmed = messageText.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(Exception("Message khali nahi ho sakta."))
        }

        val currentPartnerId = sessionManager.userId.value ?: sessionManager.authUuid.value
        val effectiveConvId = conversationId ?: sessionManager.getAssistantConversationId(currentPartnerId)

        try {
            val request = PartnerAiChatRequest(
                message = trimmed,
                conversationId = effectiveConvId
            )

            val res = supabaseClient.edgeService.sendPartnerAiChat(request)

            if (res.isSuccessful) {
                val body = res.body()
                if (body != null) {
                    val returnedCid = body.conversationId
                    if (!returnedCid.isNullOrBlank()) {
                        sessionManager.saveAssistantConversationId(returnedCid, currentPartnerId)
                    }
                    if (!body.reply.isNullOrBlank()) {
                        return@withContext Result.success(body)
                    } else if (!body.error.isNullOrBlank()) {
                        return@withContext Result.failure(Exception("abhi Neha ka response load nahi ho pa raha ek baar retry karte hain"))
                    } else {
                        return@withContext Result.success(body)
                    }
                } else {
                    return@withContext Result.failure(Exception("abhi Neha ka response load nahi ho pa raha ek baar retry karte hain"))
                }
            } else {
                val errBody = res.errorBody()?.string() ?: ""
                Log.w(TAG, "sendPartnerAiChat error: ${res.code()} - $errBody")

                when {
                    res.code() == 401 -> {
                        Result.failure(Exception("Aapka session expire ho gaya hai. Kripya dobara login karein."))
                    }
                    res.code() == 403 -> {
                        Result.failure(Exception(
                            "Baatly Support abhi keval approved partners ke liye available hai. Kripya apna partner verification complete karein."
                        ))
                    }
                    else -> {
                        Result.failure(Exception(
                            "abhi Neha ka response load nahi ho pa raha ek baar retry karte hain"
                        ))
                    }
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error during sendPartnerAiChat", e)
            Result.failure(Exception("abhi connection thoda weak lag raha hai ek baar phir try karte hain"))
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during sendPartnerAiChat", e)
            Result.failure(Exception("abhi Neha ka response load nahi ho pa raha ek baar retry karte hain"))
        }
    }
}
