package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.api.SupabaseClient
import com.example.data.api.SupabaseRestService
import com.example.data.local.SessionManager
import com.example.data.repository.AuthRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import retrofit2.http.POST

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AccountDeletionTest {

    @Test
    fun testRequestAccountDeletionEndpointAnnotation() {
        val method = SupabaseRestService::class.java.methods.find { it.name == "requestAccountDeletion" }
        assertNotNull("requestAccountDeletion method must exist on SupabaseRestService", method)
        val postAnnotation = method?.getAnnotation(POST::class.java)
        assertNotNull("requestAccountDeletion must have @POST annotation", postAnnotation)
        assertEquals("rest/v1/rpc/request_account_deletion", postAnnotation?.value)
    }

    @Test
    fun testRequestAccountDeletionUnauthenticatedFails() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)
        sessionManager.clearSession()

        val supabaseClient = SupabaseClient(sessionManager)
        val authRepository = AuthRepository(supabaseClient, sessionManager)

        val result = authRepository.requestAccountDeletion()
        assertTrue(result.isFailure)
        val errorMsg = result.exceptionOrNull()?.message ?: ""
        assertTrue(errorMsg.contains("Not authenticated", ignoreCase = true))
    }

    @Test
    fun testAccountDeletionDialogExactTextRequirements() {
        val dialogTitle = "Delete Account"
        val dialogMessage = "Your account deletion request will be submitted. This action cannot be undone."
        val cancelButtonText = "Cancel"
        val deleteButtonText = "Delete Account"
        val successMessage = "Your account deletion request has been submitted successfully."

        assertEquals("Delete Account", dialogTitle)
        assertEquals("Your account deletion request will be submitted. This action cannot be undone.", dialogMessage)
        assertEquals("Cancel", cancelButtonText)
        assertEquals("Delete Account", deleteButtonText)
        assertEquals("Your account deletion request has been submitted successfully.", successMessage)
    }
}
