package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SessionManager
import com.example.data.models.AiMessageModel
import com.example.data.models.PartnerAiChatRequest
import com.example.data.models.PartnerAiChatResponse
import com.example.data.repository.PartnerAiChatRepository
import com.example.ui.screens.chat.formatAiMessageTime
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PartnerAiChatTest {

    @Test
    fun testSessionManagerPersistsAssistantConversationId() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)

        val partnerId = "test_partner_${UUID.randomUUID()}"
        val convId = UUID.randomUUID().toString()

        assertNull(sessionManager.getAssistantConversationId(partnerId))

        sessionManager.saveAssistantConversationId(convId, partnerId)
        assertEquals(convId, sessionManager.getAssistantConversationId(partnerId))
    }

    @Test
    fun testSupportWhatsAppConstants() {
        assertEquals("8744048708", PartnerAiChatRepository.SUPPORT_WHATSAPP_NUMBER)
        assertTrue(PartnerAiChatRepository.SUPPORT_WHATSAPP_URL.contains("8744048708"))
    }

    @Test
    fun testAiMessageModelSerialization() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(AiMessageModel::class.java)

        val message = AiMessageModel(
            id = "msg-123",
            conversationId = "conv-456",
            senderType = "assistant",
            content = "Main Neha hoon, Baatly ki AI Assistant.",
            createdAt = "2026-03-30T12:00:00Z"
        )

        val json = adapter.toJson(message)
        assertNotNull(json)
        assertTrue(json.contains("Main Neha hoon"))

        val parsed = adapter.fromJson(json)
        assertNotNull(parsed)
        assertEquals("msg-123", parsed?.id)
        assertEquals("assistant", parsed?.senderType)
        assertEquals("Main Neha hoon, Baatly ki AI Assistant.", parsed?.content)
    }

    @Test
    fun testPartnerAiChatRequestAndResponseSerialization() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val reqAdapter = moshi.adapter(PartnerAiChatRequest::class.java)
        val resAdapter = moshi.adapter(PartnerAiChatResponse::class.java)

        val request = PartnerAiChatRequest(message = "Score kaise improve karein?", conversationId = "conv-001")
        val reqJson = reqAdapter.toJson(request)
        assertTrue(reqJson.contains("Score kaise improve karein?"))

        val responseJson = """{"reply":"Call pickup rate badhayein","conversation_id":"conv-001"}"""
        val response = resAdapter.fromJson(responseJson)
        assertNotNull(response)
        assertEquals("Call pickup rate badhayein", response?.reply)
        assertEquals("conv-001", response?.conversationId)
    }

    @Test
    fun testPartnerAiChatResponseWithIntentAndEscalation() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val resAdapter = moshi.adapter(PartnerAiChatResponse::class.java)

        val json = """
            {
                "conversation_id": "conv-v2-test",
                "assistant": "Neha",
                "role": "assistant",
                "reply": "Main Neha hoon, Baatly ki AI Assistant 🙂",
                "assistant_identity": "ai_assistant",
                "intent": "friendly_chat",
                "escalation_level": "none",
                "support_contact": null
            }
        """.trimIndent()

        val parsed = resAdapter.fromJson(json)
        assertNotNull(parsed)
        assertEquals("conv-v2-test", parsed?.conversationId)
        assertEquals("Neha", parsed?.assistant)
        assertEquals("friendly_chat", parsed?.intent)
        assertEquals("none", parsed?.escalationLevel)
        assertNull(parsed?.supportContact)
    }

    @Test
    fun testEscalationLogicOnlyForCriticalOrContact() {
        val normalMsg = AiMessageModel(
            senderType = "assistant",
            content = "Call earning first 5 min ₹1/min aur uske baad ₹1.40/min hoti hai.",
            intent = "guidance",
            escalationLevel = "none"
        )
        val isNormalEscalated = normalMsg.escalationLevel.equals("critical", ignoreCase = true) ||
                normalMsg.escalationLevel.equals("escalated", ignoreCase = true) ||
                !normalMsg.supportContact.isNullOrBlank() ||
                normalMsg.content.contains("8744048708")
        assertFalse(isNormalEscalated)

        val criticalMsg = AiMessageModel(
            senderType = "assistant",
            content = "Aapka issue escalate kar diya gaya hai. Kripya official support se sampark karein.",
            intent = "critical_escalation",
            escalationLevel = "critical",
            supportContact = "8744048708"
        )
        val isCriticalEscalated = criticalMsg.escalationLevel.equals("critical", ignoreCase = true) ||
                criticalMsg.escalationLevel.equals("escalated", ignoreCase = true) ||
                !criticalMsg.supportContact.isNullOrBlank() ||
                criticalMsg.content.contains("8744048708")
        assertTrue(isCriticalEscalated)
    }

    @Test
    fun testSupabaseEdgeServiceV2EndpointAnnotation() {
        val method = com.example.data.api.SupabaseEdgeService::class.java.methods.find { it.name == "sendPartnerAiChat" }
        assertNotNull("sendPartnerAiChat method must exist on SupabaseEdgeService", method)
        val postAnnotation = method?.getAnnotation(retrofit2.http.POST::class.java)
        assertNotNull("sendPartnerAiChat must have @POST annotation", postAnnotation)
        assertEquals("functions/v1/partner-ai-chat-v2", postAnnotation?.value)
    }

    @Test
    fun testFormatAiMessageTime() {
        val formatted = formatAiMessageTime("2026-03-30T10:30:00Z")
        assertNotNull(formatted)
        assertFalse(formatted.isEmpty())
    }

    @Test
    fun testMultiPartnerSessionIsolation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)

        val partnerA = "partner_uuid_aaa_111"
        val partnerB = "partner_uuid_bbb_222"
        val convA = "conv_aaa_999"
        val convB = "conv_bbb_888"

        sessionManager.saveAssistantConversationId(convA, partnerA)
        sessionManager.saveAssistantConversationId(convB, partnerB)

        assertEquals(convA, sessionManager.getAssistantConversationId(partnerA))
        assertEquals(convB, sessionManager.getAssistantConversationId(partnerB))
        assertNotEquals(sessionManager.getAssistantConversationId(partnerA), sessionManager.getAssistantConversationId(partnerB))
    }

    @Test
    fun testMessageDeduplicationByIdAndContent() {
        val msg1 = AiMessageModel(id = "m1", conversationId = "c1", senderType = "user", content = "Payout cycle kya hai?")
        val msg2 = AiMessageModel(id = "m1", conversationId = "c1", senderType = "user", content = "Payout cycle kya hai?")
        val msg3 = AiMessageModel(id = "m2", conversationId = "c1", senderType = "assistant", content = "Har Monday ko payout hota hai.")

        val rawList = listOf(msg1, msg2, msg3)
        val deduplicated = rawList.distinctBy { it.id }

        assertEquals(2, deduplicated.size)
        assertEquals("m1", deduplicated[0].id)
        assertEquals("m2", deduplicated[1].id)
    }

    @Test
    fun testPartnerAiChatResponseWithDynamicSuggestions() {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val resAdapter = moshi.adapter(PartnerAiChatResponse::class.java)

        val json = """
            {
                "conversation_id": "conv-v2-sugg",
                "reply": "Baatly par 4 tarah ki earning hoti hai 🙂",
                "intent": "guidance",
                "escalation_level": "none",
                "quick_suggestions": [
                    "Call earning kaise calculate hoti hai?",
                    "Chat earning kaise milti hai?"
                ]
            }
        """.trimIndent()

        val parsed = resAdapter.fromJson(json)
        assertNotNull(parsed)
        assertEquals(2, parsed?.quickSuggestions?.size)
        assertEquals("Call earning kaise calculate hoti hai?", parsed?.quickSuggestions?.get(0))
    }

    @Test
    fun testWelcomeMessageIdentityNotHumanOrMeerut() {
        val welcomeContent = "Hey 👋 Main Neha hoon, Baatly ki AI Assistant.\n\nBaatly se related kisi bhi cheez ke baare mein pooch sakte ho — problem ho, guidance chahiye ho ya bas baat karni ho 🙂"
        assertTrue(welcomeContent.contains("AI Assistant"))
        assertFalse(welcomeContent.contains("human", ignoreCase = true))
        assertFalse(welcomeContent.contains("Meerut", ignoreCase = true))
        assertFalse(welcomeContent.contains("real girl", ignoreCase = true))
    }
}
