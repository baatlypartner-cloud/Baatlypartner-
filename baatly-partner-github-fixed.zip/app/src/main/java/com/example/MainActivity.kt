package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.MainApp
import com.example.ui.theme.BaatlyPartnerTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val baatlyApp = application as BaatlyApp
    setContent {
      BaatlyPartnerTheme {
        MainApp(app = baatlyApp)
      }
    }
  }
}

