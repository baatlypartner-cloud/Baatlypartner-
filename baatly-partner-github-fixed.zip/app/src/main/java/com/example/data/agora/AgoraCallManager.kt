package com.example.data.agora

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.BaatlyApp
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AgoraCallState {
    object Idle : AgoraCallState()
    object Initializing : AgoraCallState()
    object Joining : AgoraCallState()
    data class Joined(val channelName: String, val uid: Int) : AgoraCallState()
    data class UserConnected(val remoteUid: Int) : AgoraCallState()
    data class UserDisconnected(val remoteUid: Int) : AgoraCallState()
    data class Error(val errorCode: Int, val message: String) : AgoraCallState()
    object Left : AgoraCallState()
}

class AgoraCallManager(context: Context? = null) {
    private val TAG = "AgoraCallManager"

    private var appContext: Context? = context?.applicationContext ?: context ?: runCatching { BaatlyApp.instance.applicationContext }.getOrNull() ?: runCatching { BaatlyApp.instance }.getOrNull()

    private var rtcEngine: RtcEngine? = null

    var lastErrorMessage: String? = null
        private set

    private val _callState = MutableStateFlow<AgoraCallState>(AgoraCallState.Idle)
    val callState: StateFlow<AgoraCallState> = _callState.asStateFlow()

    private val _isSpeakerphoneOn = MutableStateFlow(true)
    val isSpeakerphoneOn: StateFlow<Boolean> = _isSpeakerphoneOn.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private fun getValidContext(): Context? {
        return appContext?.applicationContext
            ?: appContext
            ?: runCatching { BaatlyApp.instance.applicationContext }.getOrNull()
            ?: runCatching { BaatlyApp.instance }.getOrNull()
    }

    fun attachContext(ctx: Context) {
        val resolved = ctx.applicationContext ?: ctx
        this.appContext = resolved
    }

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.d(TAG, "ON_JOIN_CHANNEL_SUCCESS: channel=$channel, uid=$uid, elapsed=$elapsed")
            lastErrorMessage = null
            _callState.value = AgoraCallState.Joined(channel ?: "", uid)
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.d(TAG, "REMOTE_USER_JOINED: remoteUid=$uid, elapsed=$elapsed")
            rtcEngine?.muteRemoteAudioStream(uid, false)
            _callState.value = AgoraCallState.UserConnected(uid)
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            Log.d(TAG, "onUserOffline: remoteUid=$uid, reason=$reason")
            _callState.value = AgoraCallState.UserDisconnected(uid)
        }

        override fun onRemoteAudioStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            Log.d(TAG, "REMOTE_AUDIO_STATE: uid=$uid, state=$state, reason=$reason, elapsed=$elapsed")
            when (state) {
                Constants.REMOTE_AUDIO_STATE_STARTING -> {
                    Log.d(TAG, "REMOTE_AUDIO_STATE: starting for uid=$uid, reason=$reason")
                }
                Constants.REMOTE_AUDIO_STATE_DECODING -> {
                    Log.d(TAG, "REMOTE_AUDIO_PLAYING: remote audio decoding/playing for uid=$uid, reason=$reason")
                }
                Constants.REMOTE_AUDIO_STATE_STOPPED -> {
                    Log.d(TAG, "REMOTE_AUDIO_STOPPED: remote audio stopped for uid=$uid, reason=$reason")
                }
                Constants.REMOTE_AUDIO_STATE_FROZEN -> {
                    Log.w(TAG, "REMOTE_AUDIO_STATE: remote audio frozen for uid=$uid, reason=$reason")
                }
                Constants.REMOTE_AUDIO_STATE_FAILED -> {
                    Log.e(TAG, "REMOTE_AUDIO_ERROR: remote audio failed for uid=$uid, reason=$reason")
                }
                else -> {
                    Log.d(TAG, "REMOTE_AUDIO_STATE: state=$state for uid=$uid, reason=$reason")
                }
            }
        }

        override fun onLocalAudioStateChanged(state: Int, error: Int) {
            Log.d(TAG, "LOCAL_AUDIO_STATE_CHANGED: state=$state, error=$error")
            when (state) {
                Constants.LOCAL_AUDIO_STREAM_STATE_STOPPED -> {
                    Log.d(TAG, "LOCAL_AUDIO_ENABLED: false (stopped), error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_RECORDING -> {
                    Log.d(TAG, "LOCAL_AUDIO_ENABLED: true (recording), error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_ENCODING -> {
                    Log.d(TAG, "LOCAL_AUDIO_ENABLED: true (encoding), error=$error")
                }
                Constants.LOCAL_AUDIO_STREAM_STATE_FAILED -> {
                    Log.e(TAG, "LOCAL_AUDIO_ENABLED: false (failed), error=$error")
                }
            }
        }

        override fun onAudioRouteChanged(routing: Int) {
            Log.d(TAG, "SPEAKERPHONE_STATE: audio route changed to $routing")
            _isSpeakerphoneOn.value = (routing == Constants.AUDIO_ROUTE_SPEAKERPHONE || routing == 3)
        }

        override fun onLeaveChannel(stats: RtcStats?) {
            Log.d(TAG, "onLeaveChannel")
            _callState.value = AgoraCallState.Left
        }

        override fun onError(err: Int) {
            Log.e(TAG, "AGORA_ERROR: Agora onError code=$err")
            val errStr = "AGORA_ERROR: Agora error code $err"
            lastErrorMessage = errStr
            _callState.value = AgoraCallState.Error(err, errStr)
        }
    }

    fun initialize(appId: String): Boolean {
        val trimmedAppId = appId.trim()

        // 1. Context validation & diagnostic logging
        val targetContext = getValidContext()
        val isContextValid = targetContext != null
        val finalAppContext = targetContext?.applicationContext ?: targetContext
        val isAppContextValid = finalAppContext != null

        Log.d(TAG, "AGORA_CONTEXT_CHECK: context valid = $isContextValid, applicationContext valid = $isAppContextValid")

        if (finalAppContext == null) {
            Log.e(TAG, "Cannot initialize Agora: Application Context is null")
            val err = "Android Context is null. Cannot initialize Agora RTC engine."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-3, err)
            safeRelease()
            return false
        }

        // 2. Check microphone permission
        val hasMicPermission = ContextCompat.checkSelfPermission(
            finalAppContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMicPermission) {
            Log.e(TAG, "Cannot initialize Agora: Microphone permission (RECORD_AUDIO) not granted")
            val err = "Microphone permission (RECORD_AUDIO) not granted. Please grant microphone access."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-2, err)
            safeRelease()
            return false
        }

        // 3. Validate App ID
        if (trimmedAppId.isBlank()) {
            Log.e(TAG, "Cannot initialize Agora: App ID is blank")
            val err = "Agora App ID is missing or blank"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        if (trimmedAppId.contains("placeholder", ignoreCase = true) ||
            trimmedAppId.contains("fake", ignoreCase = true) ||
            trimmedAppId.length < 10
        ) {
            Log.e(TAG, "Cannot initialize Agora: Invalid or placeholder App ID detected")
            val err = "Invalid or placeholder Agora App ID configured"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        Log.d(TAG, "AGORA_APP_ID_VALIDATED: Agora App ID configured = true, Agora App ID valid = true")

        if (rtcEngine != null) {
            Log.d(TAG, "Agora RtcEngine already initialized")
            return true
        }

        _callState.value = AgoraCallState.Initializing

        val config = RtcEngineConfig().apply {
            mContext = finalAppContext
            mAppId = trimmedAppId
            mEventHandler = rtcEventHandler
            mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
        }

        // 4. Isolate RtcEngine.create
        Log.d(TAG, "RTC_ENGINE_CREATE_START")
        val engine: RtcEngine = try {
            RtcEngine.create(config) ?: throw IllegalStateException("RtcEngine.create returned null")
        } catch (t: Throwable) {
            Log.e(TAG, "RTC_ENGINE_CREATE_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "RtcEngine.create failed: ${t.javaClass.simpleName}: ${t.message ?: "unknown error"}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }

        rtcEngine = engine
        Log.d(TAG, "RTC_ENGINE_CREATE_SUCCESS: Agora initialized successfully")
        Log.d(TAG, "AUDIO_ENGINE_CREATED: success")

        // 5. Enable Audio
        Log.d(TAG, "ENABLE_AUDIO_START")
        val audioRes = try {
            engine.enableAudio()
        } catch (t: Throwable) {
            Log.e(TAG, "ENABLE_AUDIO_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "enableAudio failed: ${t.javaClass.simpleName}: ${t.message}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }
        Log.d(TAG, "ENABLE_AUDIO_RESULT: code=$audioRes")
        if (audioRes != Constants.ERR_OK && audioRes != 0) {
            Log.e(TAG, "ENABLE_AUDIO_FAILED: Agora error code $audioRes")
            val err = "enableAudio failed with Agora error code: $audioRes"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(audioRes, err)
            safeRelease()
            return false
        }
        Log.d(TAG, "ENABLE_AUDIO_SUCCESS")

        // 6. Configure Audio Profile, Recording, and Playback
        val localAudioRes = engine.enableLocalAudio(true)
        Log.d(TAG, "LOCAL_AUDIO_ENABLED: true, result=$localAudioRes")

        val unMuteLocalRes = engine.muteLocalAudioStream(false)
        Log.d(TAG, "LOCAL_AUDIO_MUTED: false, result=$unMuteLocalRes")

        engine.muteAllRemoteAudioStreams(false)
        engine.adjustRecordingSignalVolume(100)
        engine.adjustPlaybackSignalVolume(100)

        // 7. Video configuration (Audio-only call) - non-fatal
        Log.d(TAG, "DISABLE_VIDEO_START")
        try {
            val videoRes = engine.disableVideo()
            if (videoRes == Constants.ERR_OK || videoRes == 0) {
                Log.d(TAG, "DISABLE_VIDEO_SUCCESS")
            } else {
                Log.w(TAG, "DISABLE_VIDEO_NON_FATAL: returned code $videoRes (expected for audio-only profile)")
            }
        } catch (t: Throwable) {
            Log.w(TAG, "DISABLE_VIDEO_NON_FATAL: exception ignored for audio-only: ${t.javaClass.simpleName}: ${t.message}")
        }

        // 8. Enable Speakerphone
        Log.d(TAG, "SPEAKERPHONE_START")
        engine.setDefaultAudioRoutetoSpeakerphone(true)
        val speakerRes = try {
            engine.setEnableSpeakerphone(true)
        } catch (t: Throwable) {
            Log.e(TAG, "SPEAKERPHONE_FAILED: ${t.javaClass.name}: ${t.message}", t)
            val err = "setEnableSpeakerphone failed: ${t.javaClass.simpleName}: ${t.message}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            safeRelease()
            return false
        }
        if (speakerRes != Constants.ERR_OK && speakerRes != 0) {
            Log.w(TAG, "SPEAKERPHONE_WARNING: returned Agora code $speakerRes")
        }
        Log.d(TAG, "SPEAKERPHONE_STATE: enabled=true, result=$speakerRes")

        _isSpeakerphoneOn.value = true
        _isMuted.value = false
        lastErrorMessage = null
        return true
    }

    fun joinChannel(token: String, channelName: String, uid: Int = 0): Boolean {
        val targetContext = getValidContext()
        val finalAppContext = targetContext?.applicationContext ?: targetContext

        val hasMicPermission = finalAppContext != null && ContextCompat.checkSelfPermission(
            finalAppContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        Log.d(TAG, "LOCAL_MIC_PERMISSION: granted=$hasMicPermission")

        if (!hasMicPermission) {
            Log.e(TAG, "Cannot join Agora channel: Microphone permission (RECORD_AUDIO) not granted")
            val err = "Microphone permission (RECORD_AUDIO) not granted. Cannot join voice channel."
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-2, err)
            return false
        }

        val engine = rtcEngine
        if (engine == null) {
            Log.e(TAG, "RtcEngine not initialized when joining channel")
            val err = "RtcEngine not initialized when joining channel"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            return false
        }

        if (channelName.isBlank()) {
            Log.e(TAG, "Cannot join Agora channel: channelName is blank")
            val err = "Agora channelName is blank"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            return false
        }

        // Ensure local audio is active and unmuted before joining
        engine.enableLocalAudio(true)
        engine.muteLocalAudioStream(false)
        engine.muteAllRemoteAudioStreams(false)

        _callState.value = AgoraCallState.Joining
        Log.d(TAG, "JOIN_CHANNEL_START: channel=$channelName, uid=$uid")
        return try {
            val options = ChannelMediaOptions().apply {
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
            }
            val res = engine.joinChannel(token, channelName, uid, options)
            Log.d(TAG, "JOIN_CHANNEL_RESULT: code=$res")
            if (res == Constants.ERR_OK || res == 0) {
                lastErrorMessage = null
                true
            } else {
                Log.e(TAG, "AGORA_ERROR: joinChannel failed with Agora error code: $res")
                val err = "joinChannel failed with Agora error code: $res"
                lastErrorMessage = err
                _callState.value = AgoraCallState.Error(res, err)
                false
            }
        } catch (t: Throwable) {
            Log.e(TAG, "AGORA_ERROR: joinChannel exception: ${t.javaClass.name}: ${t.message}", t)
            val err = "joinChannel failed: ${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
            lastErrorMessage = err
            _callState.value = AgoraCallState.Error(-1, err)
            false
        }
    }

    fun setSpeakerphone(enabled: Boolean) {
        val res = rtcEngine?.setEnableSpeakerphone(enabled)
        _isSpeakerphoneOn.value = enabled
        Log.d(TAG, "SPEAKERPHONE_STATE: enabled=$enabled, result=$res")
    }

    fun toggleSpeakerphone() {
        val next = !_isSpeakerphoneOn.value
        setSpeakerphone(next)
    }

    fun setMute(muted: Boolean) {
        val res = rtcEngine?.muteLocalAudioStream(muted)
        _isMuted.value = muted
        Log.d(TAG, "LOCAL_AUDIO_MUTED: muted=$muted, result=$res")
    }

    fun toggleMute() {
        val next = !_isMuted.value
        setMute(next)
    }

    fun leaveChannel() {
        try {
            rtcEngine?.leaveChannel()
        } catch (e: Exception) {
            Log.e(TAG, "Error leaving channel", e)
        }
        _callState.value = AgoraCallState.Idle
    }

    private fun safeRelease() {
        try {
            rtcEngine?.leaveChannel()
        } catch (_: Exception) {}
        try {
            RtcEngine.destroy()
        } catch (_: Exception) {}
        rtcEngine = null
        _isSpeakerphoneOn.value = false
        _isMuted.value = false
    }

    fun release() {
        try {
            safeRelease()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing Agora engine", e)
        }
        _callState.value = AgoraCallState.Idle
    }
}

