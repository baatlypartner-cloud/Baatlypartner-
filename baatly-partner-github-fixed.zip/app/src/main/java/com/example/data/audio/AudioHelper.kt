package com.example.data.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class AudioRecorderHelper(private val context: Context) {
    private val TAG = "AudioRecorderHelper"
    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var recordingStartTime = 0L

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    fun startRecording(prefix: String = "voice_rec"): File? {
        try {
            stopRecording()
            val outputFile = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}.m4a")
            currentOutputFile = outputFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            mediaRecorder = recorder
            recordingStartTime = System.currentTimeMillis()
            _isRecording.value = true
            return outputFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording", e)
            _isRecording.value = false
            return null
        }
    }

    fun stopRecording(): Pair<File?, Int> {
        val durationSeconds = if (recordingStartTime > 0) {
            ((System.currentTimeMillis() - recordingStartTime) / 1000).toInt()
        } else 0

        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recorder", e)
        } finally {
            mediaRecorder = null
            _isRecording.value = false
            recordingStartTime = 0L
        }

        return Pair(currentOutputFile, durationSeconds)
    }

    fun cancelRecording() {
        stopRecording()
        currentOutputFile?.delete()
        currentOutputFile = null
    }
}

class AudioPlayerHelper {
    private val TAG = "AudioPlayerHelper"
    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPlayingPath = MutableStateFlow<String?>(null)
    val currentPlayingPath: StateFlow<String?> = _currentPlayingPath.asStateFlow()

    fun playAudio(pathOrUrl: String, onCompletion: (() -> Unit)? = null) {
        stopAudio()
        try {
            val isRemote = pathOrUrl.startsWith("http://") || pathOrUrl.startsWith("https://")
            mediaPlayer = MediaPlayer().apply {
                setDataSource(pathOrUrl)
                setOnCompletionListener {
                    _isPlaying.value = false
                    _currentPlayingPath.value = null
                    onCompletion?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error: what=$what extra=$extra")
                    _isPlaying.value = false
                    _currentPlayingPath.value = null
                    true
                }

                if (isRemote) {
                    setOnPreparedListener { mp ->
                        mp.start()
                        _isPlaying.value = true
                        _currentPlayingPath.value = pathOrUrl
                    }
                    prepareAsync()
                } else {
                    prepare()
                    start()
                    _isPlaying.value = true
                    _currentPlayingPath.value = pathOrUrl
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio: $pathOrUrl", e)
            _isPlaying.value = false
            _currentPlayingPath.value = null
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing MediaPlayer", e)
        } finally {
            mediaPlayer = null
            _isPlaying.value = false
            _currentPlayingPath.value = null
        }
    }
}
