package com.example.data.api

import com.example.data.models.*
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface SupabaseAuthService {
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Body request: AuthSignUpRequest
    ): Response<AuthResponse>

    @POST("auth/v1/token")
    suspend fun signIn(
        @Query("grant_type") grantType: String = "password",
        @Body request: AuthSignInRequest
    ): Response<AuthResponse>

    @POST("auth/v1/token")
    suspend fun refreshToken(
        @Query("grant_type") grantType: String = "refresh_token",
        @Body body: Map<String, String>
    ): Response<AuthResponse>

    @POST("auth/v1/logout")
    suspend fun logout(): Response<Unit>
}

interface SupabaseRestService {
    // --- RPCs ---
    @POST("rest/v1/rpc/complete_host_onboarding")
    suspend fun completeHostOnboarding(
        @Body params: CompleteHostOnboardingParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/create_partner_voice_verification")
    suspend fun createPartnerVoiceVerification(
        @Body params: CreateVoiceVerificationParams
    ): Response<String?>

    @POST("rest/v1/rpc/submit_partner_application")
    suspend fun submitPartnerApplication(
        @Body params: SubmitPartnerApplicationParams
    ): Response<String?>

    @POST("rest/v1/rpc/update_my_partner_profile")
    suspend fun updateMyPartnerProfile(
        @Body params: UpdateMyPartnerProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_call_state")
    suspend fun updateCallState(
        @Body params: UpdateCallStateParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/settle_call")
    suspend fun settleCall(
        @Body params: SettleCallParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/enforce_call_balance_limit")
    suspend fun enforceCallBalanceLimit(
        @Body params: EnforceCallBalanceLimitParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/send_message")
    suspend fun sendMessage(
        @Body params: SendMessageParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/request_partner_withdrawal")
    suspend fun requestPartnerWithdrawal(
        @Body params: RequestPartnerWithdrawalParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/clear_my_conversation")
    suspend fun clearMyConversation(
        @Body params: ClearMyConversationParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/block_user")
    suspend fun blockUser(
        @Body params: BlockUserParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/unblock_user")
    suspend fun unblockUserRpc(
        @Body params: UnblockUserParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/get_conversation_participant_profile")
    suspend fun getConversationParticipantProfile(
        @Body params: GetConversationParticipantProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_my_profile")
    suspend fun updateMyProfile(
        @Body params: UpdateMyProfileParams
    ): Response<ResponseBody>

    @POST("rest/v1/rpc/update_my_profile_avatar")
    suspend fun updateMyProfileAvatar(
        @Body params: UpdateMyProfileAvatarParams
    ): Response<ResponseBody>

    // --- Table queries ---
    @GET("rest/v1/profiles")
    suspend fun getProfile(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<Profile>>

    @GET("rest/v1/partner_profiles")
    suspend fun getPartnerProfile(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<PartnerProfile>>

    @GET("rest/v1/partner_applications")
    suspend fun getPartnerApplications(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<PartnerApplication>>

    @GET("rest/v1/voice_verifications")
    suspend fun getVoiceVerifications(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<VoiceVerification>>

    @GET("rest/v1/wallets")
    suspend fun getWallet(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*"
    ): Response<List<WalletModel>>

    @GET("rest/v1/transactions")
    suspend fun getTransactions(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<TransactionModel>>

    @GET("rest/v1/calls")
    suspend fun getPartnerCalls(
        @Query("partner_id") partnerIdFilter: String,
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 50
    ): Response<List<CallModel>>

    @GET("rest/v1/calls")
    suspend fun getIncomingCalls(
        @Query("partner_id") partnerIdFilter: String,
        @Query("status") statusFilter: String = "in.(requested,ringing)",
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc",
        @Query("limit") limit: Int = 1
    ): Response<List<CallModel>>

    @GET("rest/v1/calls")
    suspend fun getCallById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*,profiles!calls_user_id_fkey(*)"
    ): Response<List<CallModel>>

    @GET("rest/v1/conversations")
    suspend fun getConversations(
        @Query("partner_id") partnerIdFilter: String,
        @Query("select") select: String = "*,profiles!conversations_user_id_fkey(*)",
        @Query("order") order: String = "last_message_at.desc.nullslast"
    ): Response<List<ConversationModel>>

    @GET("rest/v1/messages")
    suspend fun getMessages(
        @Query("conversation_id") conversationIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.asc",
        @Query("limit") limit: Int = 200
    ): Response<List<MessageModel>>

    @PATCH("rest/v1/messages")
    suspend fun markMessagesAsRead(
        @Query("conversation_id") conversationIdFilter: String,
        @Query("receiver_id") receiverIdFilter: String,
        @Query("read_at") readAtFilter: String = "is.null",
        @Body body: Map<String, String>
    ): Response<ResponseBody>

    @GET("rest/v1/gifts")
    suspend fun getGifts(
        @Query("is_active") activeFilter: String = "eq.true",
        @Query("order") order: String = "display_order.asc"
    ): Response<List<GiftModel>>

    @GET("rest/v1/gift_transactions")
    suspend fun getGiftTransactions(
        @Query("receiver_id") receiverIdFilter: String,
        @Query("select") select: String = "*,gifts(*)",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<GiftTransactionModel>>

    @GET("rest/v1/withdrawals")
    suspend fun getWithdrawals(
        @Query("partner_id") partnerIdFilter: String,
        @Query("order") order: String = "created_at.desc"
    ): Response<List<WithdrawalModel>>

    @GET("rest/v1/blocks")
    suspend fun getBlocks(
        @Query("blocker_id") blockerIdFilter: String,
        @Query("select") select: String = "*,profiles!blocks_blocked_user_id_fkey(*)",
        @Query("order") order: String = "created_at.desc"
    ): Response<List<BlockModel>>

    @DELETE("rest/v1/blocks")
    suspend fun unblockUser(
        @Query("id") idFilter: String
    ): Response<Unit>

    @GET("rest/v1/reviews")
    suspend fun getReviews(
        @Query("partner_id") partnerIdFilter: String,
        @Query("order") order: String = "created_at.desc"
    ): Response<List<ReviewModel>>
}

interface SupabaseStorageService {
    @POST("storage/v1/object/{bucket}/{path}")
    suspend fun uploadObject(
        @Path("bucket") bucket: String,
        @Path(value = "path", encoded = true) path: String,
        @Header("Content-Type") contentType: String,
        @Body body: RequestBody
    ): Response<ResponseBody>

    @POST("storage/v1/object/sign/{bucket}/{path}")
    suspend fun signObjectUrl(
        @Path("bucket") bucket: String,
        @Path(value = "path", encoded = true) path: String,
        @Body body: Map<String, Int>
    ): Response<ResponseBody>
}

interface SupabaseEdgeService {
    @POST("functions/v1/agora-token")
    suspend fun getAgoraToken(
        @Body request: AgoraTokenRequest
    ): Response<AgoraTokenResponse>
}
