package com.example.data.api

import com.example.data.local.SessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class SupabaseClient(private val sessionManager: SessionManager) {

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val builder = original.newBuilder()

        val apiKey = sessionManager.getSupabasePublishableKey()
        if (apiKey.isNotBlank()) {
            builder.header("apikey", apiKey)
        }

        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        } else if (apiKey.isNotBlank()) {
            builder.header("Authorization", "Bearer $apiKey")
        }

        chain.proceed(builder.build())
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var cachedBaseUrl: String? = null
    private var cachedRetrofit: Retrofit? = null

    private fun getRetrofit(): Retrofit {
        val currentBaseUrl = sessionManager.getSupabaseUrl().let {
            if (it.endsWith("/")) it else "$it/"
        }
        if (cachedRetrofit == null || cachedBaseUrl != currentBaseUrl) {
            cachedBaseUrl = currentBaseUrl
            cachedRetrofit = Retrofit.Builder()
                .baseUrl(currentBaseUrl)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
                .build()
        }
        return cachedRetrofit!!
    }

    val authService: SupabaseAuthService
        get() = getRetrofit().create(SupabaseAuthService::class.java)

    val restService: SupabaseRestService
        get() = getRetrofit().create(SupabaseRestService::class.java)

    val storageService: SupabaseStorageService
        get() = getRetrofit().create(SupabaseStorageService::class.java)

    val edgeService: SupabaseEdgeService
        get() = getRetrofit().create(SupabaseEdgeService::class.java)

    fun getAuthenticatedStorageUrl(bucket: String, path: String): String {
        val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
        val cleanedPath = path.removePrefix("$bucket/").removePrefix("/")
        return "$baseUrl/storage/v1/object/authenticated/$bucket/$cleanedPath"
    }

    fun getPublicStorageUrl(bucket: String, path: String): String {
        val baseUrl = sessionManager.getSupabaseUrl().removeSuffix("/")
        val cleanedPath = path.removePrefix("$bucket/").removePrefix("/")
        return "$baseUrl/storage/v1/object/public/$bucket/$cleanedPath"
    }
}
