package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("baatly_partner_session", Context.MODE_PRIVATE)

    private val _accessToken = MutableStateFlow<String?>(prefs.getString(KEY_ACCESS_TOKEN, null))
    val accessToken: StateFlow<String?> = _accessToken.asStateFlow()

    private val _userId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _authUuid = MutableStateFlow<String?>(prefs.getString(KEY_AUTH_UUID, null))
    val authUuid: StateFlow<String?> = _authUuid.asStateFlow()

    fun getSupabaseUrl(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_URL, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder") && !stored.contains("your-supabase-url")) {
            return stored.trim().removeSuffix("/")
        }
        val buildConfigUrl = runCatching {
            BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
        }.getOrNull()

        return buildConfigUrl
            ?.trim()
            ?.removeSuffix("/")
            ?.takeIf { it.isNotBlank() && !it.contains("placeholder") && !it.contains("your-supabase-url") }
            ?: ""
    }

    fun getSupabasePublishableKey(): String {
        val stored = prefs.getString(KEY_CUSTOM_SUPABASE_KEY, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder")) {
            return stored.trim()
        }
        val buildConfigKey = runCatching {
            BuildConfig::class.java.getField("SUPABASE_PUBLISHABLE_KEY").get(null) as? String
        }.getOrNull()

        return buildConfigKey
            ?.trim()
            ?.takeIf { it.isNotBlank() && !it.contains("placeholder") }
            ?: ""
    }

    fun getAgoraAppId(): String {
        val stored = prefs.getString(KEY_CUSTOM_AGORA_APP_ID, null)
        if (!stored.isNullOrBlank() && !stored.contains("placeholder")) {
            return stored.trim()
        }
        val buildConfigAgora = runCatching {
            BuildConfig::class.java.getField("AGORA_APP_ID").get(null) as? String
        }.getOrNull()

        return buildConfigAgora
            ?.trim()
            ?.takeIf { it.isNotBlank() && !it.contains("placeholder") }
            ?: ""
    }

    fun saveCredentials(supabaseUrl: String?, publishableKey: String?, agoraAppId: String?) {
        prefs.edit().apply {
            if (!supabaseUrl.isNullOrBlank()) putString(KEY_CUSTOM_SUPABASE_URL, supabaseUrl.trim())
            if (!publishableKey.isNullOrBlank()) putString(KEY_CUSTOM_SUPABASE_KEY, publishableKey.trim())
            if (!agoraAppId.isNullOrBlank()) putString(KEY_CUSTOM_AGORA_APP_ID, agoraAppId.trim())
            apply()
        }
    }

    fun saveSession(authUuid: String, userId: String, accessToken: String, refreshToken: String?) {
        prefs.edit()
            .putString(KEY_AUTH_UUID, authUuid)
            .putString(KEY_USER_ID, userId)
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .putString(KEY_REFRESH_TOKEN, refreshToken)
            .apply()

        _authUuid.value = authUuid
        _userId.value = userId
        _accessToken.value = accessToken
    }

    fun updateTokens(accessToken: String, refreshToken: String?) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .apply {
                if (refreshToken != null) putString(KEY_REFRESH_TOKEN, refreshToken)
            }
            .apply()
        _accessToken.value = accessToken
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_UUID)
            .remove(KEY_USER_ID)
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .apply()

        _authUuid.value = null
        _userId.value = null
        _accessToken.value = null
    }

    fun isLoggedIn(): Boolean {
        return !_accessToken.value.isNullOrBlank() && !_authUuid.value.isNullOrBlank()
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_AUTH_UUID = "auth_uuid"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_CUSTOM_SUPABASE_URL = "custom_supabase_url"
        private const val KEY_CUSTOM_SUPABASE_KEY = "custom_supabase_key"
        private const val KEY_CUSTOM_AGORA_APP_ID = "custom_agora_app_id"
    }
}
