package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AudioPlayerHelper
import com.example.data.audio.AudioRecorderHelper
import com.example.data.repository.PartnerRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

sealed class VoiceVerificationState {
    object Idle : VoiceVerificationState()
    data class Recording(val durationSeconds: Int) : VoiceVerificationState()
    data class Recorded(val file: File, val durationSeconds: Int, val isPlaying: Boolean = false) : VoiceVerificationState()
    object Submitting : VoiceVerificationState()
    object SubmittedSuccess : VoiceVerificationState()
    data class Error(val message: String) : VoiceVerificationState()
}

class VoiceVerificationViewModel(
    private val partnerRepository: PartnerRepository,
    val audioRecorderHelper: AudioRecorderHelper,
    val audioPlayerHelper: AudioPlayerHelper
) : ViewModel() {

    private val _state = MutableStateFlow<VoiceVerificationState>(VoiceVerificationState.Idle)
    val state: StateFlow<VoiceVerificationState> = _state.asStateFlow()

    private var recordTimerJob: Job? = null
    private var recordedFile: File? = null
    private var recordedDuration = 0

    fun startRecording() {
        audioPlayerHelper.stopAudio()
        val file = audioRecorderHelper.startRecording("host_verification")
        if (file != null) {
            recordedFile = file
            recordedDuration = 0
            _state.value = VoiceVerificationState.Recording(0)

            recordTimerJob?.cancel()
            recordTimerJob = viewModelScope.launch {
                while (isActive) {
                    delay(1000)
                    recordedDuration++
                    _state.value = VoiceVerificationState.Recording(recordedDuration)
                    if (recordedDuration >= 30) {
                        stopRecording()
                        break
                    }
                }
            }
        } else {
            _state.value = VoiceVerificationState.Error("Could not start microphone recording. Check permissions.")
        }
    }

    fun stopRecording() {
        recordTimerJob?.cancel()
        val (file, duration) = audioRecorderHelper.stopRecording()
        if (file != null && file.exists() && duration >= 10) {
            recordedFile = file
            recordedDuration = duration.coerceAtMost(30)
            _state.value = VoiceVerificationState.Recorded(file, recordedDuration, false)
        } else {
            recordedFile = null
            recordedDuration = 0
            _state.value = VoiceVerificationState.Error("Voice sample must be at least 10 seconds (recorded: ${duration}s). Please record again.")
        }
    }

    fun playRecordedAudio() {
        val file = recordedFile ?: return
        _state.value = VoiceVerificationState.Recorded(file, recordedDuration, true)
        audioPlayerHelper.playAudio(file.absolutePath) {
            _state.value = VoiceVerificationState.Recorded(file, recordedDuration, false)
        }
    }

    fun stopAudioPlayback() {
        val file = recordedFile ?: return
        audioPlayerHelper.stopAudio()
        _state.value = VoiceVerificationState.Recorded(file, recordedDuration, false)
    }

    fun reRecord() {
        audioPlayerHelper.stopAudio()
        audioRecorderHelper.cancelRecording()
        recordedFile = null
        recordedDuration = 0
        _state.value = VoiceVerificationState.Idle
    }

    fun submitVoiceVerification(displayName: String, applicationId: String?) {
        val file = recordedFile
        if (file == null || !file.exists() || recordedDuration < 10) {
            _state.value = VoiceVerificationState.Error("Please record a voice sample of at least 10 seconds.")
            return
        }

        viewModelScope.launch {
            _state.value = VoiceVerificationState.Submitting
            // 1. Upload voice and create verification record
            val voiceRes = partnerRepository.submitVoiceVerification(file, applicationId)
            if (voiceRes.isFailure) {
                _state.value = VoiceVerificationState.Error(voiceRes.exceptionOrNull()?.message ?: "Voice upload failed")
                return@launch
            }

            val voiceId = voiceRes.getOrNull()

            // 2. Submit application
            val appRes = partnerRepository.submitPartnerApplication(
                displayName = displayName.ifBlank { "Host" },
                voiceVerificationId = voiceId
            )

            if (appRes.isFailure) {
                _state.value = VoiceVerificationState.Error(appRes.exceptionOrNull()?.message ?: "Application submission failed")
                return@launch
            }

            _state.value = VoiceVerificationState.SubmittedSuccess
        }
    }

    fun clearError() {
        if (_state.value is VoiceVerificationState.Error) {
            if (recordedFile != null) {
                _state.value = VoiceVerificationState.Recorded(recordedFile!!, recordedDuration, false)
            } else {
                _state.value = VoiceVerificationState.Idle
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        recordTimerJob?.cancel()
        audioPlayerHelper.stopAudio()
    }
}

class VoiceVerificationViewModelFactory(
    private val partnerRepository: PartnerRepository,
    private val audioRecorderHelper: AudioRecorderHelper,
    private val audioPlayerHelper: AudioPlayerHelper
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VoiceVerificationViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VoiceVerificationViewModel(partnerRepository, audioRecorderHelper, audioPlayerHelper) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
