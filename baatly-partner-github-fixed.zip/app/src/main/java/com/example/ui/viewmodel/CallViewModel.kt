package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.agora.AgoraCallManager
import com.example.data.agora.AgoraCallState
import com.example.data.local.SessionManager
import com.example.data.models.CallModel
import com.example.data.repository.CallRepository
import com.example.data.repository.PartnerRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

sealed class ActiveCallUiStatus {
    object Idle : ActiveCallUiStatus()
    data class Incoming(val call: CallModel) : ActiveCallUiStatus()
    data class Connecting(val call: CallModel) : ActiveCallUiStatus()
    data class Connected(
        val call: CallModel,
        val durationSeconds: Int = 0,
        val isMuted: Boolean = false,
        val isSpeakerOn: Boolean = true,
        val maxDurationSeconds: Int? = null
    ) : ActiveCallUiStatus()
    data class Ended(val call: CallModel, val durationSeconds: Int, val earning: Double) : ActiveCallUiStatus()
    data class Error(val message: String) : ActiveCallUiStatus()
}

class CallViewModel(
    private val callRepository: CallRepository,
    private val partnerRepository: PartnerRepository,
    private val agoraCallManager: AgoraCallManager,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val TAG = "CallViewModel"

    private val _callUiStatus = MutableStateFlow<ActiveCallUiStatus>(ActiveCallUiStatus.Idle)
    val callUiStatus: StateFlow<ActiveCallUiStatus> = _callUiStatus.asStateFlow()

    private val _isCallScreenMinimized = MutableStateFlow(false)
    val isCallScreenMinimized: StateFlow<Boolean> = _isCallScreenMinimized.asStateFlow()

    private val _recentCalls = MutableStateFlow<List<CallModel>>(emptyList())
    val recentCalls: StateFlow<List<CallModel>> = _recentCalls.asStateFlow()

    private val _isLoadingRecent = MutableStateFlow(false)
    val isLoadingRecent: StateFlow<Boolean> = _isLoadingRecent.asStateFlow()

    private var durationTimerJob: Job? = null
    private var currentActiveCall: CallModel? = null
    private var activeCallDurationSeconds = 0
    private val isAcceptingCall = AtomicBoolean(false)

    init {
        loadRecentCalls()
    }

    fun minimizeCallScreen() {
        _isCallScreenMinimized.value = true
    }

    fun restoreCallScreen() {
        _isCallScreenMinimized.value = false
    }

    fun loadRecentCalls() {
        viewModelScope.launch {
            _isLoadingRecent.value = true
            val res = callRepository.getRecentCalls()
            if (res.isSuccess) {
                _recentCalls.value = res.getOrNull() ?: emptyList()
            }
            _isLoadingRecent.value = false
        }
    }

    fun acceptIncomingCall(call: CallModel) {
        Log.d(TAG, "ACCEPT_CLICKED: callId=${call.id}")
        if (!isAcceptingCall.compareAndSet(false, true)) {
            Log.w(TAG, "ACCEPT_CLICKED: ignored duplicate concurrent accept action")
            return
        }

        currentActiveCall = call
        _callUiStatus.value = ActiveCallUiStatus.Connecting(call)
        _isCallScreenMinimized.value = false

        viewModelScope.launch {
            try {
                // 1. Verify current backend status before accepting
                Log.d(TAG, "CALL_STATE: checking current status for callId=${call.id}")
                val freshCallRes = callRepository.getCallById(call.id)
                var latestCall = freshCallRes.getOrNull() ?: call

                if (latestCall.status in listOf("missed", "rejected", "cancelled", "completed", "ended") || latestCall.endedAt != null) {
                    Log.w(TAG, "CALL_STATE: call already ended or missed (${latestCall.status})")
                    _callUiStatus.value = ActiveCallUiStatus.Error("Call was already ended or missed.")
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                // 2. If call is in 'requested' state, transition to 'ringing' first
                if (latestCall.status == "requested") {
                    val ringRes = callRepository.markCallRinging(call.id)
                    if (ringRes.isFailure) {
                        val err = "Could not update call state to ringing: ${ringRes.exceptionOrNull()?.message}"
                        Log.e(TAG, "CALL_STATE_FAILED: $err")
                        _callUiStatus.value = ActiveCallUiStatus.Error(err)
                        currentActiveCall = null
                        isAcceptingCall.set(false)
                        return@launch
                    }
                }

                // 3. Transition from 'ringing' to 'accepted'
                val acceptRes = callRepository.acceptCall(call.id)
                if (acceptRes.isFailure) {
                    val err = acceptRes.exceptionOrNull()?.message ?: "Failed to accept call"
                    Log.e(TAG, "CALL_STATE_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }
                Log.d(TAG, "CALL_STATE: call accepted on server")

                // 4. Read calls.agora_channel_id from Supabase call record
                if (latestCall.agoraChannelId.isNullOrBlank()) {
                    val refreshedRes = callRepository.getCallById(call.id)
                    if (refreshedRes.isSuccess && refreshedRes.getOrNull() != null) {
                        latestCall = refreshedRes.getOrNull()!!
                    }
                }

                val agoraChannelId = latestCall.agoraChannelId?.trim().orEmpty()
                if (agoraChannelId.isBlank()) {
                    val err = "Agora channel ID missing on call record (calls.agora_channel_id is empty)"
                    Log.e(TAG, "AGORA_ERROR: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val channelName = agoraChannelId
                Log.d(TAG, "TOKEN_REQUEST_START: channelName=$channelName")
                val tokenRes = callRepository.fetchAgoraToken(channelName)
                if (tokenRes.isFailure) {
                    val err = tokenRes.exceptionOrNull()?.message ?: "Failed to get Agora token"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val agoraData = tokenRes.getOrNull()
                if (agoraData == null) {
                    val err = "Empty response received from Agora token service"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }
                Log.d(TAG, "TOKEN_REQUEST_SUCCESS")

                val tokenToUse = agoraData.resolvedToken
                if (tokenToUse.isBlank()) {
                    val err = "Received empty Agora token from token service"
                    Log.e(TAG, "AGORA_ERROR: TOKEN_REQUEST_FAILED: $err")
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                val rawAppId = if (!agoraData.appId.isNullOrBlank()) agoraData.appId else sessionManager.getAgoraAppId()
                val appId = rawAppId.trim()

                // 5. Initialize Agora Engine
                val initOk = agoraCallManager.initialize(appId)
                if (!initOk) {
                    val errorMsg = agoraCallManager.lastErrorMessage ?: "Failed to initialize Agora RTC engine"
                    Log.e(TAG, "AGORA_ERROR: initialize failed: $errorMsg")
                    _callUiStatus.value = ActiveCallUiStatus.Error(errorMsg)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                // 6. Join Agora Channel using exact calls.agora_channel_id
                val uid = agoraData.uid?.toInt() ?: 0

                val joinOk = agoraCallManager.joinChannel(token = tokenToUse, channelName = channelName, uid = uid)
                if (!joinOk) {
                    val errorMsg = agoraCallManager.lastErrorMessage ?: "Failed to join voice channel"
                    Log.e(TAG, "AGORA_ERROR: joinChannel failed to initiate: $errorMsg")
                    _callUiStatus.value = ActiveCallUiStatus.Error(errorMsg)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                // 7. Wait for ON_JOIN_CHANNEL_SUCCESS callback before marking connected
                val joinState = withTimeoutOrNull(15000) {
                    agoraCallManager.callState.first { it is AgoraCallState.Joined || it is AgoraCallState.Error }
                }

                if (joinState == null) {
                    val err = "Timed out waiting for Agora voice connection confirmation"
                    Log.e(TAG, "AGORA_ERROR: $err")
                    agoraCallManager.leaveChannel()
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                if (joinState is AgoraCallState.Error) {
                    val err = joinState.message
                    Log.e(TAG, "AGORA_ERROR: Join failed with state error: $err")
                    agoraCallManager.leaveChannel()
                    _callUiStatus.value = ActiveCallUiStatus.Error(err)
                    currentActiveCall = null
                    isAcceptingCall.set(false)
                    return@launch
                }

                Log.d(TAG, "ON_JOIN_CHANNEL_SUCCESS: voice channel connected")

                // 8. Only mark backend connected AFTER Agora join succeeds
                callRepository.markCallConnected(call.id)

                // 9. Auto turn off Call availability for Host, but keep Chat availability state untouched!
                val partnerProf = partnerRepository.getPartnerProfile().getOrNull()
                val chatState = partnerProf?.chatEnabled ?: false
                partnerRepository.updateServiceAvailability(
                    displayName = partnerProf?.partnerDisplayName,
                    isAvailable = false,
                    isOnline = chatState,
                    audioEnabled = false,
                    chatEnabled = chatState
                )

                // 10. Start duration timer & set Connected UI State
                activeCallDurationSeconds = 0
                _callUiStatus.value = ActiveCallUiStatus.Connected(
                    call = latestCall,
                    durationSeconds = 0,
                    isMuted = false,
                    isSpeakerOn = true,
                    maxDurationSeconds = latestCall.maxDurationSeconds
                )

                startDurationTimer(latestCall)
            } catch (t: Throwable) {
                Log.e(TAG, "CRITICAL_EXCEPTION during call accept flow: ${t.javaClass.name}: ${t.message}", t)
                val err = "Call connection failure: ${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}"
                _callUiStatus.value = ActiveCallUiStatus.Error(err)
                currentActiveCall = null
                try {
                    agoraCallManager.release()
                } catch (_: Throwable) {}
            } finally {
                isAcceptingCall.set(false)
            }
        }
    }

    fun rejectIncomingCall(call: CallModel) {
        viewModelScope.launch {
            callRepository.rejectCall(call.id)
            _callUiStatus.value = ActiveCallUiStatus.Idle
            currentActiveCall = null
        }
    }

    private fun startDurationTimer(call: CallModel) {
        durationTimerJob?.cancel()
        durationTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                activeCallDurationSeconds++
                val current = _callUiStatus.value
                if (current is ActiveCallUiStatus.Connected) {
                    _callUiStatus.value = current.copy(durationSeconds = activeCallDurationSeconds)

                    // Periodic backend balance check every 10 seconds
                    if (activeCallDurationSeconds % 10 == 0) {
                        val enforceRes = callRepository.enforceCallBalanceLimit(call.id)
                        if (enforceRes.isSuccess && enforceRes.getOrNull()?.shouldDisconnect == true) {
                            endActiveCall("User balance limit reached")
                            break
                        }
                    }

                    // Check if max duration reached
                    val maxSec = current.maxDurationSeconds
                    if (maxSec != null && activeCallDurationSeconds >= maxSec) {
                        endActiveCall("Max coin balance reached")
                        break
                    }
                }
            }
        }
    }

    fun toggleMute() {
        agoraCallManager.toggleMute()
        val current = _callUiStatus.value
        if (current is ActiveCallUiStatus.Connected) {
            _callUiStatus.value = current.copy(isMuted = agoraCallManager.isMuted.value)
        }
    }

    fun toggleSpeakerphone() {
        agoraCallManager.toggleSpeakerphone()
        val current = _callUiStatus.value
        if (current is ActiveCallUiStatus.Connected) {
            _callUiStatus.value = current.copy(isSpeakerOn = agoraCallManager.isSpeakerphoneOn.value)
        }
    }

    fun endActiveCall(reason: String? = null) {
        durationTimerJob?.cancel()
        val call = currentActiveCall
        if (call == null) {
            _callUiStatus.value = ActiveCallUiStatus.Idle
            return
        }

        viewModelScope.launch {
            agoraCallManager.leaveChannel()
            // Backend-authoritative settlement (single idempotent execution)
            val settleRes = callRepository.endCall(call.id)
            val settlement = settleRes.getOrNull()

            val finalDuration = settlement?.durationSeconds ?: activeCallDurationSeconds
            val finalEarning = settlement?.partnerEarning ?: 0.0

            _callUiStatus.value = ActiveCallUiStatus.Ended(
                call = call,
                durationSeconds = finalDuration,
                earning = finalEarning
            )
            currentActiveCall = null
            loadRecentCalls()
        }
    }

    fun resetCallState() {
        _callUiStatus.value = ActiveCallUiStatus.Idle
        currentActiveCall = null
    }

    override fun onCleared() {
        super.onCleared()
        durationTimerJob?.cancel()
        agoraCallManager.leaveChannel()
    }
}

class CallViewModelFactory(
    private val callRepository: CallRepository,
    private val partnerRepository: PartnerRepository,
    private val agoraCallManager: AgoraCallManager,
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CallViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CallViewModel(callRepository, partnerRepository, agoraCallManager, sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
