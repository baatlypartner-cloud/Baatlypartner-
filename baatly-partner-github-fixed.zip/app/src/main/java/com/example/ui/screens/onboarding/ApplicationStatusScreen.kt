package com.example.ui.screens.onboarding

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.repository.HostApplicationState
import com.example.data.repository.HostFullStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplicationStatusScreen(
    status: HostFullStatus,
    authViewModel: AuthViewModel,
    onNavigateToReVerification: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val isResubmission = status.state == HostApplicationState.RESUBMISSION
    val isRejected = status.state == HostApplicationState.REJECTED
    val isPending = status.state == HostApplicationState.PENDING

    val headline = when {
        isResubmission -> "Aapka Voice Sample Dobara Chahiye"
        isRejected -> "Aapka Application Approve Nahi Hua"
        else -> "Aapka Application Review Mein Hai"
    }

    val subtitle = when {
        isResubmission -> status.resubmissionReason ?: "Kripya apna voice sample saaf aawaz mein dobara record karein."
        isRejected -> status.rejectionReason ?: "Aapka voice sample ya profile criteria meet nahi hua."
        else -> "Baatly team aapki aawaz aur details verify kar rahi hai. Approval milte hi aap Live Calls aur Chat shuru kar sakenge."
    }

    val badgeColor = when {
        isResubmission -> BaatlyGold
        isRejected -> BaatlyRed
        else -> BaatlyPrimary
    }
    val badgeBg = when {
        isResubmission -> BaatlyGoldLight
        isRejected -> BaatlyRedLight
        else -> BaatlyPrimaryLight
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BaatlyLightBackground)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(16.dp))

                // Hero Banner
                Image(
                    painter = painterResource(id = R.drawable.baatly_host_banner_1787770983213),
                    contentDescription = "Host Banner",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Crop
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Status Icon Badge
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(badgeBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            isResubmission -> Icons.Default.Warning
                            isRejected -> Icons.Default.Cancel
                            else -> Icons.Default.HourglassTop
                        },
                        contentDescription = "Status",
                        tint = badgeColor,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = headline,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = subtitle,
                            fontSize = 13.sp,
                            color = TextSecondaryLight,
                            lineHeight = 20.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (status.partnerProfile != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = BaatlyLightBorder)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Display Name:", color = TextSecondaryLight, fontSize = 13.sp)
                                Text(status.partnerProfile.partnerDisplayName ?: "Host", color = TextPrimaryLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Application Status:", color = TextSecondaryLight, fontSize = 13.sp)
                                Text(status.application?.status?.uppercase() ?: "PENDING", color = badgeColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Bottom Actions
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isResubmission) {
                    Button(
                        onClick = onNavigateToReVerification,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("resubmit_voice_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Record Voice Sample Again", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Refresh Status Button
                Button(
                    onClick = { authViewModel.checkCurrentStatus() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("refresh_status_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Check Approval Status", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // WhatsApp Support Manager Button
                OutlinedButton(
                    onClick = {
                        val url = "https://wa.me/8744048708?text=Hello%20Baatly%20Support,%20I%20am%20a%20Host%20inquiring%20about%20my%20application"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("whatsapp_support_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BaatlyGreen)
                ) {
                    Icon(Icons.Default.HeadsetMic, contentDescription = null, tint = BaatlyGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Contact Support (WhatsApp)", fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = { authViewModel.logout() },
                    modifier = Modifier.testTag("status_logout_button")
                ) {
                    Text("Sign Out", color = TextSecondaryLight, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
