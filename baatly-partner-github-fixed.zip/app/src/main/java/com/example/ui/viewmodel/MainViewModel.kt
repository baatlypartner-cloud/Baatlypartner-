package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.models.CallModel
import com.example.data.models.PartnerProfile
import com.example.data.models.Profile
import com.example.data.repository.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class HomeUiData(
    val profile: Profile? = null,
    val partnerProfile: PartnerProfile? = null,
    val isCallOnline: Boolean = false,
    val isChatOnline: Boolean = false,
    val todayEarnings: TodayEarningsBreakdown = TodayEarningsBreakdown(),
    val averageCallDurationSeconds: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val incomingCall: CallModel? = null
)

class MainViewModel(
    private val partnerRepository: PartnerRepository,
    private val callRepository: CallRepository,
    private val walletRepository: WalletRepository
) : ViewModel() {

    private val _uiData = MutableStateFlow(HomeUiData())
    val uiData: StateFlow<HomeUiData> = _uiData.asStateFlow()

    private val handledCallIds = mutableSetOf<String>()
    private var incomingCallPollerJob: Job? = null
    private var ringTimeoutJob: Job? = null

    init {
        loadAllData()
        startIncomingCallPoller()
    }

    fun loadAllData() {
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(isLoading = true, errorMessage = null)

            val profileRes = partnerRepository.getProfile()
            val partnerProfileRes = partnerRepository.getPartnerProfile()
            val earningsRes = walletRepository.getTodayEarningsBreakdown()
            val avgDurationRes = callRepository.getAverageCallDuration()

            val profile = profileRes.getOrNull()
            val partnerProfile = partnerProfileRes.getOrNull()
            val earnings = earningsRes.getOrNull() ?: TodayEarningsBreakdown()
            val avgDuration = avgDurationRes.getOrNull() ?: 0

            val isCall = partnerProfile?.audioEnabled == true && partnerProfile.isAvailable == true
            val isChat = partnerProfile?.chatEnabled == true

            _uiData.value = _uiData.value.copy(
                profile = profile,
                partnerProfile = partnerProfile,
                isCallOnline = isCall,
                isChatOnline = isChat,
                todayEarnings = earnings,
                averageCallDurationSeconds = avgDuration,
                isLoading = false,
                errorMessage = null
            )
        }
    }

    fun toggleCallAvailability(enabled: Boolean) {
        viewModelScope.launch {
            val currentChat = _uiData.value.isChatOnline
            val displayName = _uiData.value.partnerProfile?.partnerDisplayName ?: _uiData.value.profile?.displayName

            val isAvailable = enabled
            val isOnline = enabled || currentChat
            val audioEnabled = enabled
            val chatEnabled = currentChat

            _uiData.value = _uiData.value.copy(isCallOnline = enabled)

            val res = partnerRepository.updateServiceAvailability(
                displayName = displayName,
                isAvailable = isAvailable,
                isOnline = isOnline,
                audioEnabled = audioEnabled,
                chatEnabled = chatEnabled
            )

            if (res.isFailure) {
                _uiData.value = _uiData.value.copy(
                    isCallOnline = !enabled,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to update call status"
                )
            } else {
                // Refresh partner profile
                val updatedPartnerProfile = partnerRepository.getPartnerProfile().getOrNull()
                if (updatedPartnerProfile != null) {
                    _uiData.value = _uiData.value.copy(partnerProfile = updatedPartnerProfile)
                }
            }
        }
    }

    fun toggleChatAvailability(enabled: Boolean) {
        viewModelScope.launch {
            val currentCall = _uiData.value.isCallOnline
            val displayName = _uiData.value.partnerProfile?.partnerDisplayName ?: _uiData.value.profile?.displayName

            val isAvailable = currentCall
            val isOnline = enabled || currentCall
            val audioEnabled = currentCall
            val chatEnabled = enabled

            _uiData.value = _uiData.value.copy(isChatOnline = enabled)

            val res = partnerRepository.updateServiceAvailability(
                displayName = displayName,
                isAvailable = isAvailable,
                isOnline = isOnline,
                audioEnabled = audioEnabled,
                chatEnabled = chatEnabled
            )

            if (res.isFailure) {
                _uiData.value = _uiData.value.copy(
                    isChatOnline = !enabled,
                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to update chat status"
                )
            } else {
                // Refresh partner profile
                val updatedPartnerProfile = partnerRepository.getPartnerProfile().getOrNull()
                if (updatedPartnerProfile != null) {
                    _uiData.value = _uiData.value.copy(partnerProfile = updatedPartnerProfile)
                }
            }
        }
    }

    private fun startIncomingCallPoller() {
        incomingCallPollerJob?.cancel()
        incomingCallPollerJob = viewModelScope.launch {
            val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }

            while (isActive) {
                // Only poll for incoming call if Call is online
                if (_uiData.value.isCallOnline) {
                    val incoming = callRepository.checkForIncomingCall().getOrNull()
                    if (incoming != null) {
                        if (handledCallIds.contains(incoming.id) || incoming.endedAt != null) {
                            if (_uiData.value.incomingCall?.id == incoming.id) {
                                _uiData.value = _uiData.value.copy(incomingCall = null)
                            }
                        } else {
                            // Check age (30s threshold)
                            val callTimeStr = incoming.ringingAt ?: incoming.requestedAt ?: incoming.createdAt
                            val callTime = try {
                                callTimeStr?.let { isoFormat.parse(it.substring(0, 19))?.time }
                            } catch (_: Exception) { null }

                            val isStale = callTime != null && (System.currentTimeMillis() - callTime > 30_000)

                            if (isStale || incoming.status in listOf("missed", "rejected", "cancelled", "completed", "ended")) {
                                handledCallIds.add(incoming.id)
                                if (_uiData.value.incomingCall?.id == incoming.id) {
                                    _uiData.value = _uiData.value.copy(incomingCall = null)
                                }
                            } else {
                                // Transition requested -> ringing immediately
                                if (incoming.status == "requested") {
                                    callRepository.markCallRinging(incoming.id)
                                }

                                if (_uiData.value.incomingCall?.id != incoming.id) {
                                    _uiData.value = _uiData.value.copy(incomingCall = incoming)
                                    startRingTimeout(incoming.id)
                                }
                            }
                        }
                    } else {
                        if (_uiData.value.incomingCall != null) {
                            _uiData.value = _uiData.value.copy(incomingCall = null)
                        }
                    }
                } else {
                    if (_uiData.value.incomingCall != null) {
                        _uiData.value = _uiData.value.copy(incomingCall = null)
                    }
                }
                delay(3000)
            }
        }
    }

    private fun startRingTimeout(callId: String) {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = viewModelScope.launch {
            delay(30_000) // 30 seconds max ringing timeout
            if (_uiData.value.incomingCall?.id == callId) {
                handledCallIds.add(callId)
                _uiData.value = _uiData.value.copy(incomingCall = null)
            }
        }
    }

    fun updateProfile(
        displayName: String?,
        bio: String? = null,
        age: Int? = null,
        avatarFile: java.io.File? = null,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            _uiData.value = _uiData.value.copy(isLoading = true)
            val res = partnerRepository.updateHostProfile(displayName, bio, age, avatarFile)
            if (res.isSuccess) {
                loadAllData()
                onResult(true, null)
            } else {
                _uiData.value = _uiData.value.copy(isLoading = false)
                onResult(false, res.exceptionOrNull()?.message ?: "Failed to update profile")
            }
        }
    }

    fun dismissIncomingCall(callId: String? = null) {
        ringTimeoutJob?.cancel()
        if (callId != null) {
            handledCallIds.add(callId)
        } else {
            _uiData.value.incomingCall?.let { handledCallIds.add(it.id) }
        }
        _uiData.value = _uiData.value.copy(incomingCall = null)
    }

    fun clearError() {
        _uiData.value = _uiData.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        incomingCallPollerJob?.cancel()
        ringTimeoutJob?.cancel()
    }
}

class MainViewModelFactory(
    private val partnerRepository: PartnerRepository,
    private val callRepository: CallRepository,
    private val walletRepository: WalletRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(partnerRepository, callRepository, walletRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
