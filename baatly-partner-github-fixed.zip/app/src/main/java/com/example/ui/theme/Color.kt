package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish - Primary & Brand Colors
val BaatlyPrimary = Color(0xFF4F46E5)         // Indigo 600
val BaatlyPrimaryVariant = Color(0xFF4338CA)  // Indigo 700
val BaatlyPrimaryLight = Color(0xFFEEF2FF)    // Indigo 50
val BaatlyPrimaryBorder = Color(0xFFC7D2FE)   // Indigo 200

val BaatlySecondary = Color(0xFF4F46E5)       // Brand Accent
val BaatlyTertiary = Color(0xFF0EA5E9)        // Sky Blue 500

// Background & Surfaces (Professional Slate Light Theme)
val BaatlyLightBackground = Color(0xFFF6F8FA) // Crisp Clean Slate Background
val BaatlyLightSurface = Color(0xFFFFFFFF)    // Pure White Surface
val BaatlyLightSurfaceVariant = Color(0xFFF1F5F9) // Slate 100
val BaatlyLightCard = Color(0xFFFFFFFF)       // Pure White Card
val BaatlyLightBorder = Color(0xFFE2E8F0)     // Slate 200

// Dark Theme Variants
val BaatlyDarkBackground = Color(0xFF0F172A)  // Slate 900
val BaatlyDarkSurface = Color(0xFF1E293B)     // Slate 800
val BaatlyDarkSurfaceVariant = Color(0xFF334155) // Slate 700
val BaatlyDarkCard = Color(0xFF1E293B)        // Slate 800
val BaatlyDarkBorder = Color(0xFF334155)

// Status & Accent Colors with Soft Pastel Containers
val BaatlyGreen = Color(0xFF10B981)           // Emerald 500
val BaatlyGreenLight = Color(0xFFECFDF5)      // Emerald 50
val BaatlyGreenBorder = Color(0xFFA7F3D0)

val BaatlyRed = Color(0xFFF43F5E)             // Rose 500
val BaatlyRedLight = Color(0xFFFFF1F2)        // Rose 50
val BaatlyRedBorder = Color(0xFFFECDD3)

val BaatlyGold = Color(0xFFF59E0B)            // Amber 500
val BaatlyGoldLight = Color(0xFFFFFBEB)       // Amber 50
val BaatlyGoldBorder = Color(0xFFFDE68A)

val BaatlyBlue = Color(0xFF3B82F6)            // Blue 500
val BaatlyBlueLight = Color(0xFFEFF6FF)       // Blue 50

val BaatlyCyan = Color(0xFF06B6D4)            // Cyan 500
val BaatlyCyanLight = Color(0xFFECFEFF)       // Cyan 50

val BaatlyPurple = Color(0xFF8B5CF6)          // Purple 500
val BaatlyPurpleLight = Color(0xFFF5F3FF)     // Purple 50

val BaatlySlate = Color(0xFF64748B)           // Slate 500
val BaatlySlateLight = Color(0xFFF8FAFC)      // Slate 50

// Typography Colors
val TextPrimaryLight = Color(0xFF0F172A)      // Slate 900
val TextSecondaryLight = Color(0xFF64748B)    // Slate 500
val TextMutedLight = Color(0xFF94A3B8)        // Slate 400

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
