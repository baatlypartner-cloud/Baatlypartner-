package com.example.ui.screens.auth

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthUiState
import com.example.ui.viewmodel.AuthViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
    authViewModel: AuthViewModel,
    onNavigateToSignIn: () -> Unit
) {
    val context = LocalContext.current
    val uiState by authViewModel.uiState.collectAsState()

    var displayName by remember { mutableStateOf("") }
    var userId by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedImageFile by remember { mutableStateOf<File?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.cacheDir, "avatar_${System.currentTimeMillis()}.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                selectedImageFile = file
            } catch (_: Exception) {}
        }
    }

    val errorMessage = (uiState as? AuthUiState.Error)?.message
    val isLoading = uiState is AuthUiState.Loading

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BaatlyLightBackground)
            .padding(horizontal = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(36.dp))

            // Header
            Text(
                text = "Partner Registration",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Become a verified Baatly Audio Jockey",
                fontSize = 13.sp,
                color = TextSecondaryLight,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Avatar Upload Picker
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(BaatlyPrimaryLight)
                    .border(1.5.dp, BaatlyPrimaryBorder, CircleShape)
                    .clickable { photoPickerLauncher.launch("image/*") }
                    .testTag("avatar_picker"),
                contentAlignment = Alignment.Center
            ) {
                if (selectedImageUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(model = selectedImageUri),
                        contentDescription = "Selected Avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.AddAPhoto,
                            contentDescription = "Add Photo",
                            tint = BaatlyPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "Photo",
                            fontSize = 10.sp,
                            color = BaatlyPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Display Name
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = {
                            displayName = it
                            authViewModel.clearError()
                        },
                        label = { Text("Host Display Name") },
                        placeholder = { Text("e.g. RJ Roshni") },
                        leadingIcon = {
                            Icon(Icons.Default.Badge, contentDescription = null, tint = BaatlyPrimary)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("display_name_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // User ID
                    OutlinedTextField(
                        value = userId,
                        onValueChange = {
                            userId = it.lowercase().trim()
                            authViewModel.clearError()
                        },
                        label = { Text("Unique User ID") },
                        placeholder = { Text("e.g. roshni_host") },
                        leadingIcon = {
                            Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = BaatlyPrimary)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("user_id_signup_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Mobile Number
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = {
                            if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                                mobileNumber = it
                                authViewModel.clearError()
                            }
                        },
                        label = { Text("Mobile Number (10 Digits)") },
                        placeholder = { Text("e.g. 98XXXXXXXX") },
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = BaatlyPrimary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("mobile_number_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Age
                    OutlinedTextField(
                        value = age,
                        onValueChange = {
                            if (it.length <= 3 && it.all { char -> char.isDigit() }) {
                                age = it
                                authViewModel.clearError()
                            }
                        },
                        label = { Text("Age (18 - 100)") },
                        placeholder = { Text("e.g. 23") },
                        leadingIcon = {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = BaatlyPrimary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("age_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Bio
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("Bio / About Your Voice (Optional)") },
                        placeholder = { Text("e.g. Friendly conversationalist...") },
                        leadingIcon = {
                            Icon(Icons.Default.Description, contentDescription = null, tint = BaatlyPrimary)
                        },
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bio_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Password
                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            authViewModel.clearError()
                        },
                        label = { Text("Password (Min 6 chars)") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = BaatlyPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                    tint = TextSecondaryLight
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BaatlyPrimary,
                            unfocusedBorderColor = BaatlyLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = BaatlyPrimary,
                            unfocusedLabelColor = TextSecondaryLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("signup_password_input")
                    )

                    if (!errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorMessage,
                            color = BaatlyRed,
                            fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            authViewModel.signUp(
                                userId = userId,
                                password = password,
                                displayName = displayName,
                                mobileNumber = mobileNumber,
                                ageStr = age,
                                bio = bio,
                                avatarFile = selectedImageFile
                            )
                        },
                        enabled = !isLoading && displayName.isNotBlank() && userId.isNotBlank() && mobileNumber.length == 10 && age.isNotBlank() && password.length >= 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("complete_signup_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BaatlyPrimary,
                            disabledContainerColor = BaatlyPrimary.copy(alpha = 0.4f)
                        )
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "Register & Continue",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Already registered? ",
                    color = TextSecondaryLight,
                    fontSize = 14.sp
                )
                TextButton(
                    onClick = onNavigateToSignIn,
                    modifier = Modifier.testTag("back_to_sign_in_button")
                ) {
                    Text(
                        text = "Sign In",
                        color = BaatlyPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
        }
    }
}
