package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallKamaiScreen(
    mainViewModel: MainViewModel,
    onBack: () -> Unit
) {
    val uiData by mainViewModel.uiData.collectAsState()
    val partner = uiData.partnerProfile

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Call Kamai & Slabs", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("call_kamai_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Lifetime Call Stats Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("LIFETIME CALL EARNINGS", color = TextSecondaryLight, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("₹${String.format("%.2f", partner?.totalCallEarnings ?: 0.0)}", color = BaatlyGreen, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = BaatlyLightBorder)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Total Calls", color = TextSecondaryLight, fontSize = 11.sp)
                            Text("${partner?.totalCalls ?: 0}", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Total Minutes", color = TextSecondaryLight, fontSize = 11.sp)
                            Text("${String.format("%.1f", partner?.totalCallMinutes ?: 0.0)} min", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Rating", color = TextSecondaryLight, fontSize = 11.sp)
                            Text("★ ${String.format("%.1f", partner?.rating ?: 5.0)}", color = BaatlyGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("EARNING SLABS (PER CALL)", color = TextPrimaryLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))

            val slabs = listOf(
                Pair("0 - 60 Seconds", "₹0 (Minimum duration 60s required)"),
                Pair("1st 2 Minutes", "₹1.00 / Minute"),
                Pair("Next 8 Minutes (2 - 10 min)", "₹1.50 / Minute"),
                Pair("Next 15 Minutes (10 - 25 min)", "₹1.90 / Minute"),
                Pair("25+ Minutes", "₹2.50 / Minute")
            )

            slabs.forEach { (duration, rate) ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(duration, color = TextPrimaryLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(rate, color = BaatlyGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = BaatlyPrimaryLight),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyPrimaryBorder, BaatlyPrimaryBorder))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = BaatlyPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Call kamai automatically settle ho kar aapke Wallet balance mein add hoti hai. 60 seconds se kam call par earning nahi milti.",
                        color = Color(0xFF312E81),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
