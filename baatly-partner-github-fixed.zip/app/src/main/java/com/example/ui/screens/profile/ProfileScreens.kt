package com.example.ui.screens.profile

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.data.models.BlockModel
import com.example.data.repository.PartnerRepository
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

data class ProfileMenuItem(
    val title: String,
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconColor: Color,
    val onClick: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    mainViewModel: MainViewModel,
    authViewModel: AuthViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val uiData by mainViewModel.uiData.collectAsState()
    val partner = uiData.partnerProfile
    val profile = uiData.profile

    var showEditProfileSheet by remember { mutableStateOf(false) }
    var editDisplayName by remember(partner, profile) {
        mutableStateOf(partner?.partnerDisplayName ?: profile?.displayName ?: "")
    }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isSavingProfile by remember { mutableStateOf(false) }
    var editErrorMessage by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    val menuItems = listOf(
        ProfileMenuItem("Edit Profile", Icons.Default.Edit, BaatlyPrimaryLight, BaatlyPrimary) { showEditProfileSheet = true },
        ProfileMenuItem("Frame Niyam (Slabs & Rules)", Icons.Default.MenuBook, BaatlyPrimaryLight, BaatlyPrimary) { onNavigate("frame_niyam") },
        ProfileMenuItem("Strike Niyam (Safety & Ban Policy)", Icons.Default.Gavel, BaatlyRedLight, BaatlyRed) { onNavigate("strike_niyam") },
        ProfileMenuItem("Blocked Users", Icons.Default.Block, BaatlyRoseOrRedLight(), BaatlyRed) { onNavigate("blocked_users") },
        ProfileMenuItem("Host Training Guide", Icons.Default.PlayCircle, BaatlyGoldLight, BaatlyGold) { onNavigate("training") },
        ProfileMenuItem("WhatsApp Support Manager", Icons.Default.HeadsetMic, BaatlyGreenLight, BaatlyGreen) {
            val url = "https://wa.me/8744048708?text=Hello%20Baatly%20Support,%20I%20am%20a%20Host"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Host Profile", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(
                        onClick = { showEditProfileSheet = true },
                        modifier = Modifier.testTag("edit_profile_top_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = BaatlyPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Profile Card
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        val avatarUrl = profile?.avatarUrl
                        if (!avatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = avatarUrl),
                                contentDescription = "Avatar",
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (partner?.partnerDisplayName ?: profile?.displayName ?: "H").take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimary)
                                .clickable { showEditProfileSheet = true }
                                .padding(5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Change Photo", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = partner?.partnerDisplayName ?: profile?.displayName ?: "Audio Jockey",
                        color = TextPrimaryLight,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "@${profile?.username ?: profile?.id?.take(8) ?: "host"}",
                        color = TextSecondaryLight,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { showEditProfileSheet = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = BaatlyPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Profile", fontSize = 13.sp, color = BaatlyPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Divider(color = BaatlyLightBorder)

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${partner?.totalCalls ?: 0}", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Total Calls", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${String.format("%.0f", partner?.totalCallMinutes ?: 0.0)}m", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Call Minutes", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("★ ${String.format("%.1f", partner?.rating ?: 5.0)}", color = BaatlyGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Rating", color = TextSecondaryLight, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Menu Options
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    menuItems.forEachIndexed { idx, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { item.onClick() }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(item.iconBgColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        item.icon,
                                        contentDescription = null,
                                        tint = item.iconColor,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = item.title,
                                    color = TextPrimaryLight,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = TextSecondaryLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        if (idx < menuItems.size - 1) {
                            Divider(color = BaatlyLightBorder, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Logout Button
            Button(
                onClick = { authViewModel.logout() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("profile_logout_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BaatlyRedLight)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = BaatlyRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out as Host", color = BaatlyRed, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Edit Profile Bottom Sheet
        if (showEditProfileSheet) {
            ModalBottomSheet(
                onDismissRequest = {
                    showEditProfileSheet = false
                    selectedImageUri = null
                    editErrorMessage = null
                },
                containerColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Edit Host Profile", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimaryLight)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Avatar Preview & Change button
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier.clickable { photoPickerLauncher.launch("image/*") }
                    ) {
                        if (selectedImageUri != null) {
                            Image(
                                painter = rememberAsyncImagePainter(model = selectedImageUri),
                                contentDescription = "Selected Avatar",
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else if (!profile?.avatarUrl.isNullOrBlank()) {
                            Image(
                                painter = rememberAsyncImagePainter(model = profile?.avatarUrl),
                                contentDescription = "Current Avatar",
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(CircleShape)
                                    .background(BaatlyPrimaryLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (editDisplayName.ifBlank { "H" }).take(1).uppercase(),
                                    color = BaatlyPrimary,
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(BaatlyPrimary)
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit photo", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    TextButton(onClick = { photoPickerLauncher.launch("image/*") }) {
                        Text("Change Profile Photo", color = BaatlyPrimary, fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = editDisplayName,
                        onValueChange = { editDisplayName = it },
                        label = { Text("Display Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_display_name_input")
                    )

                    if (editErrorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(editErrorMessage ?: "", color = BaatlyRed, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (editDisplayName.trim().isBlank()) {
                                editErrorMessage = "Display name cannot be empty"
                                return@Button
                            }
                            isSavingProfile = true
                            editErrorMessage = null

                            val avatarFile = selectedImageUri?.let { uri ->
                                try {
                                    val inputStream = context.contentResolver.openInputStream(uri)
                                    val tempFile = java.io.File(context.cacheDir, "avatar_${System.currentTimeMillis()}.jpg")
                                    val outputStream = java.io.FileOutputStream(tempFile)
                                    inputStream?.copyTo(outputStream)
                                    inputStream?.close()
                                    outputStream.close()
                                    tempFile
                                } catch (_: Exception) {
                                    null
                                }
                            }

                            mainViewModel.updateProfile(
                                displayName = editDisplayName.trim(),
                                avatarFile = avatarFile
                            ) { success, err ->
                                isSavingProfile = false
                                if (success) {
                                    showEditProfileSheet = false
                                    selectedImageUri = null
                                } else {
                                    editErrorMessage = err ?: "Failed to save profile"
                                }
                            }
                        },
                        enabled = !isSavingProfile,
                        colors = ButtonDefaults.buttonColors(containerColor = BaatlyPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_profile_button")
                    ) {
                        if (isSavingProfile) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text("Save Changes", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

private fun BaatlyRoseOrRedLight(): Color = BaatlyRedLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockedUsersScreen(
    partnerRepository: PartnerRepository,
    onBack: UnitCallback
) {
    val coroutineScope = rememberCoroutineScope()
    var blockedList by remember { mutableStateOf<List<BlockModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    fun loadBlocks() {
        coroutineScope.launch {
            isLoading = true
            val res = partnerRepository.getBlockedUsers()
            if (res.isSuccess) {
                blockedList = res.getOrNull() ?: emptyList()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadBlocks()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Blocked Users", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("blocked_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = TextPrimaryLight
                )
            )
        },
        containerColor = BaatlyLightBackground
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (blockedList.isEmpty() && !isLoading) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BaatlyGreen, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Koi User Block Nahi Hai", color = TextPrimaryLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    items(blockedList) { block ->
                        val userName = block.blockedProfile?.displayName ?: block.blockedProfile?.username ?: "User #${block.blockedUserId.take(6)}"

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BaatlyLightBorder, BaatlyLightBorder))),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(userName, color = TextPrimaryLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(block.reason ?: "Blocked by host", color = TextSecondaryLight, fontSize = 11.sp)
                                }
                                TextButton(
                                    onClick = {
                                        val targetUserId = block.blockedUserId
                                        blockedList = blockedList.filter { it.blockedUserId != targetUserId }
                                        coroutineScope.launch {
                                            partnerRepository.unblockUser(targetUserId)
                                            loadBlocks()
                                        }
                                    },
                                    modifier = Modifier.testTag("unblock_button_${block.blockedUserId}")
                                ) {
                                    Text("Unblock", color = BaatlyPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                CircularProgressIndicator(
                    color = BaatlyPrimary,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

typealias UnitCallback = () -> Unit
